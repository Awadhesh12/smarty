<?php
require_once('../../../config.php');
class courseMapping
{
	function __construct(){
		global $DB,$USER;
		$this->db=$DB;
		$this->user=$USER;
	}	
	function courseListMapping(){
		$sql="SELECT cdm.id,c.fullname, cdm.designation_id,cdm.status,cdm.no_days,cdm.created_at,cdm.updated_at,cdm.language_id FROM {course_designation_map} cdm 
		INNER JOIN {course} c ON cdm.course_id=c.id
		WHERE cdm.status=0 AND c.visible=1";
		$clists=$this->db->get_records_sql($sql);
		$data=[];
		$index=0;
		$action="";
		$listm=[];
		foreach($clists as $key => $value){
			$dsql="SELECT d_name FROM {ums_designations} WHERE id IN(".$value->designation_id.")";
			$dlist=$this->db->get_records_sql($dsql);
			foreach($dlist as $key => $value1){
				$listm[]=$value1->d_name;
			}
			$d_name=implode(', ', $listm);
			$listm='';
			$data[$index]['Sr']         =$index+1;
			$data[$index]['CourseName'] =$value->fullname;
			$data[$index]['no_days']    =$value->no_days." Days";
			$data[$index]['Designation']=@$d_name;
			$data[$index]['Language']   ="";
			if(@$value->language_id==1){
				$data[$index]['Language']   ='HINDI';
			}
			if(@$value->language_id==2){
				$data[$index]['Language']   ='ENGLISH';
			}
			$data[$index]['Status']     =$value->status==0?"Active":"In Active";
			$buttons='<button title="Update" class="button1" type="button" name="edit" id="edit" onclick="editValue('.$value->id.');">'.
			'<i class="fa fa-pencil-square-o"></i></button>'.
			'<button title="Delete" class="button1" type="button" name="edit" id="edit" onclick="deleteConfirm('.$value->id.');">'.
			'<i class="fa fa-trash-o"></i></button>';
			$data[$index]['Action']     =$buttons;
			$index++;
		}
		echo json_encode(array_values($data));
	}
	function designationlist($selected=""){
		$result = $this->db->get_records_sql("SELECT *
			FROM mdl_ums_designations 
			where deleted = '0' AND d_name!='admin' AND d_name NOT IN('HO','ZH','RM','MSDM') AND d_name IN('TSE','TVS','TME','TCC','TLS','TCM','TVG','DET','DEV','DEX','NEV','NEX','TLB','NTB','TSS','TRF','INT','TDM','TRR')
			order by d_name");
		return $result;
	}
	function addCourseMapping(){
		$insertlist=[];
		$msg["message"]="";
		$msg["response"]=false;
		$insertlist['course_id']     =$_REQUEST['course_id'];
		$sql="SELECT cdm.course_id, c.fullname FROM {course_designation_map} cdm 
		INNER JOIN {course} c ON cdm.course_id=c.id
		WHERE cdm.status=0 AND c.visible=1 AND cdm.course_id='".$insertlist['course_id']."'";
		$fetchExistcourse=$this->db->get_record_sql($sql);
		if(sizeof($_REQUEST['designation'])>0){
			$designationfloat=implode(', ', $_REQUEST['designation']);
			$insertlist['designation_id']=$designationfloat;
		}
		$insertlist['created_at']=date('Y-m-d H:i:s');
		$insertlist['status']    =0;
		$insertlist['no_days']   =$_REQUEST['no_days'];
		$insertlist['language_id']=$_REQUEST['language_id'];
		$insertlist['updated_at']=$insertlist['created_at'];
		if($fetchExistcourse->course_id==""){
			$this->db->insert_record('course_designation_map', $insertlist, $returnid=true, $bulk=false);
			$msg["message"]="<div class='alert alert-success'>Course Added Successfully</div>";
			$msg["response"]=true;
		}else{
            $msg["message"]="<div class='alert alert-danger'>Course ( ".$fetchExistcourse->fullname." already exist) Already Exist.</div>";
			$msg["response"]=true;
		}
		echo json_encode($msg);
		die();
	}
	function updateCourseMapping(){
		$insertlist=[];
		$msg["message"]="";
		$msg["response"]=false;
		$insertlist['course_id']     =$_REQUEST['course_id'];
		$sql="SELECT cdm.id, cdm.course_id, c.fullname FROM {course_designation_map} cdm 
		INNER JOIN {course} c ON cdm.course_id=c.id
		WHERE cdm.status=0 AND c.visible=1 AND cdm.course_id='".$insertlist['course_id']."'";
		$fetchExistcourse=$this->db->get_record_sql($sql);
		if(sizeof($_REQUEST['designation'])>0){
			$designationfloat=implode(', ', $_REQUEST['designation']);
			$insertlist['designation_id']=$designationfloat;
		}
		$insertlist['created_at']=date('Y-m-d H:i:s');
		$insertlist['status']    =0;
		$insertlist['no_days']   =$_REQUEST['no_days'];
		$insertlist['language_id']=$_REQUEST['language_id'];
		$insertlist['updated_at']=$insertlist['created_at'];

		if($fetchExistcourse->course_id!="" && $_REQUEST['updateid']!=$fetchExistcourse->id){
			$msg["message"]="<div class='alert alert-danger'>Course already exist</div>";
			$msg["response"]=true;
		}else{
			$insertlist['id']=$_REQUEST['updateid'];
			if($this->db->update_record('course_designation_map', $insertlist, $bulk=false)==true){
				$msg["message"]="<div class='alert alert-success'>Course Updated Successfully</div>";
				$msg["response"]=true;
			}
		}
		echo json_encode($msg);
		die();
	}
	function editCourseMapping(){
		$insertlist=[];
		$insertlist['course_id']     =$_REQUEST['course_id'];
		$sql="SELECT cdm.id, cdm.course_id, cdm.no_days, cdm.designation_id, cdm.language_id FROM {course_designation_map} cdm 
		INNER JOIN {course} c ON cdm.course_id=c.id
		WHERE cdm.status=0 AND c.visible=1 AND cdm.id=".$insertlist['course_id']."";
		$fetchcourse=$this->db->get_record_sql($sql);
		echo json_encode($fetchcourse);
		die();
	}
	function deleteCourseMapping(){
		$msg["message"]="";
		$msg["response"]=false;
		$insertlist['status']    =1;
		$insertlist['id']        = str_replace("'","",$_REQUEST['course_id']);
		if($this->db->update_record('course_designation_map', $insertlist, $bulk=false)==true){
			$msg["message"]="<div class='alert alert-success'>Course Deleted Successfully</div>";
			$msg["response"]=true;
		}
		echo json_encode($msg);
		die();
	}
	function course_list($selected=""){
		$categoryId = 3;
		$result = $this->db->get_records_sql('SELECT id,fullname FROM {course} WHERE category = '.$categoryId.' AND visible = 1 ORDER BY fullname ASC', array());
		$list="";
		foreach($result as $rows){
			$cid         = $rows->id;
			$coursename  = $rows->fullname;	
			$list .= "<option value=".$cid.">".ucwords($coursename)."</option>";
		}
		return $list;
	}
}
	function deleteCourseMapping(){
	}
$obj = new courseMapping();
if(isset($_GET['__g__']) && $_GET['__g__'] == 'courseListMapping'){
	$obj->courseListMapping();
}
if(isset($_GET['__g__']) && $_GET['__g__'] == 'addCourseMapping'){
	$obj->addCourseMapping();
}
if(isset($_GET['__g__']) && $_GET['__g__'] == 'editCourseMapping'){
	$obj->editCourseMapping();
}
if(isset($_GET['__g__']) && $_GET['__g__'] == 'updateCourseMapping'){
	$obj->updateCourseMapping();
}
if(isset($_GET['__g__']) && $_GET['__g__'] == 'deleteCourseMapping'){
	$obj->deleteCourseMapping();
}