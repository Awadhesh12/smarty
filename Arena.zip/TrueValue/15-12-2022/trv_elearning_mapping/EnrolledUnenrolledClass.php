<?php
ini_set('max_execution_time', 0);
ini_set('memory_limit', -1);
require_once('/var/www/html/config.php');
class EnrolledUnenrolledClass{
/*	function __construct(){
		global $DB,$USER;
		$this->DB=$DB;
		$this->USER=$USER;
		$this->USER->id=276062;
	}*/
	function courseContextIdFn($courseid){
		global $DB;
		$result = $DB->get_records_sql("SELECT id FROM {context} where contextlevel=50 AND instanceid='".$courseid."'", array());
		$contextid="";
		foreach($result as $rows){
			$contextid =  $rows->id;
		}
		return $contextid;
	}
	function getEnrolIdFn($courseid){
		global $DB;
		$values = array();
		$sql = "select id from {enrol} where courseid=$courseid and enrol='manual'";
		$val="0";
		if($courseid!=0){
			$obj=$DB->get_records_sql($sql, $values);
			foreach($obj as $rows){
				$val = $rows->id;
			}
		}
		return $val;
	}
		
	function EnrolledFn($courseid, $userid){
		global $DB;
		$start_date=date('Y-m-d');
		$date = date($start_date." 23:59:00");
		$duration = strtotime($date . '+ 90 days');
		$contextid  = $this->courseContextIdFn($courseid);
		$start_date = strtotime($start_date);
		$modifierid = $userid;
		$record = new stdClass();
		$record->roleid       = "5";   //Role id(default student)
		$record->contextid    = $contextid; //related to courseid form context table
		$record->userid       = $modifierid;  //taking from select menu
		$record->timemodified = time();  //Modifier
		$record->modifierid   = $modifierid; //Modifier id (like admin, sub admin or teacher)         
		$record->component    = '';   //component              
		$record->itemid       = '0';   //itemid   
		$record->sortorder    = '0';   //sortorder
		$resultAssignment=$DB->get_record('role_assignments', 
			['roleid'=>$record->roleid, 'userid'=>$record->userid, 'contextid'=>$contextid]);
		if($resultAssignment->id==""){
			$lastinsertid = $DB->insert_record('role_assignments', $record);
		}

		$record1 = new stdClass();
		$record1->enrolid      = $this->getEnrolIdFn($courseid);   //get enrol id from 'enrol' table
		$record1->userid       = $modifierid;   //taking from select menu
		$record1->timestart    = $start_date;  //Start date
		$record1->timeend      = $duration;  //End date             
		$record1->modifierid   = $modifierid; //
		$record1->timecreated  = time();  //
		$record1->timemodified = time();  //
		$resultEnrollment=$DB->get_record('user_enrolments', 
			['enrolid'=>$record1->enrolid, 'userid'=>$record1->userid]);
		if($resultEnrollment->id==""){
			$lastinsertenrollid    = $DB->insert_record('user_enrolments', $record1);
			return true;
		}
	}
    function courseEnrollmentActivation(){
      global $DB;
      $fsql="SELECT id, designation_id FROM {course_designation_map} WHERE status=0";
      $fuser = $DB->get_records_sql($fsql);
      $listD='';
      $i=0;
      foreach($fuser as $key => $value){
      	if($i==0){
      		$listD.=$value->designation_id;
      	}else{
      		$listD.=','.$value->designation_id;
      	}
      	$i++;
      }
      $list=[$listD];
      print_r($list);
      /*$CurrentDate=date('Y-m-d');
      $days = (strtotime($CurrentDate) - strtotime($fuser->doj)) / (60 * 60 * 24);*/
    }
	function unEnrolledFn($courseid, $userid){
		global $DB;
		$enrolid_user = $this->getEnrolIdFn($courseid);
		$contextid  = $this->courseContextIdFn($courseid);
		$unEnrolled_assignment_sql = "DELETE FROM {role_assignments} WHERE contextid= '".$contextid."'  AND userid = '".$userid."'";
		$DB->execute($unEnrolled_assignment_sql, array());
		$unEnrolled_enrolments_sql = "DELETE FROM {user_enrolments}  WHERE enrolid= '".$enrolid_user."' AND userid = '".$userid."'";
		$DB->execute($unEnrolled_enrolments_sql, array());
	}
}
$obj=new EnrolledUnenrolledClass;
//$obj->EnrolledFn(369, 301741);
$obj->courseEnrollmentActivation();
//$obj->unEnrolledFn(369, 301741);