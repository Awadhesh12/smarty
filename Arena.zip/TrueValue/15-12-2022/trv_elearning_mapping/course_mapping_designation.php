<?php
require_once('../../../config.php');
require_login();
require_once('course_mapping_designation_class.php'); 
$systemcontext = context_system::instance();
$url = new moodle_url('/local/pagecontainer/trv_elearning_mapping/course_mapping_designation.php');
$PAGE->set_context($systemcontext);
$PAGE->set_title('Upgrade Program Mapping');
$PAGE->set_heading('Upgrade Program Mapping');
echo $OUTPUT->header();
$id   = $USER->id;
$user = $USER->username;
$obj  = new courseMapping();
$courseList      = $obj->course_list();
$designationlist = $obj->designationlist();
?>
<style type="text/css">
	.designation_utr {
		float: left;
		margin: 11px;
	}
</style>
<div class="row">
	<form name="form1" id="form1" method="post">
		<div role="main">
			<span id="maincontent"></span>
			<span id="errormsg"></span>
			<div class="filter_buttons add_btn_div">
				<div class="col-xs-12">
					<div class="text-right">
						<button type="button" class="btn btn-default filteropt viewbutton">Add</button>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-12" style="display: none;" id="filteropt">
			<div class="panel-body">
				<div class="row">
					<div class="col-sm-12" style="font-weight: bold;">
						<center>
							<label class="control-label">Course</label>&nbsp;<span style="color: red;font-weight: bolder;">*</span>
						</center>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<select name="course_id" id="course_id"  class="form-control" style="width: 300px; margin: auto;">
							<option value="">Select Course</option>
							<?php echo $courseList;?>
						</select>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12" style="font-weight: bold;">
						<center>
							<label class="control-label">Designation</label>&nbsp;<span style="color: red;font-weight: bolder;">*</span>
						</center>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="col-sm-5">
							<div class="form-group no-margin-hr">
								<label class="control-label">Select All</label>&nbsp;<input type="checkbox" name="selectall">
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<?php foreach($designationlist as $list){?>
							<div class="designation_utr">
								<label><?=$list->d_name?></label>&nbsp;&nbsp;<input type="checkbox" value="<?=$list->id?>" name="designation[]">
							</div>
						<?php }?>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12" style="font-weight: bold;">
						<center>
							<label class="control-label">Days</label>&nbsp;<span style="color: red;font-weight: bolder;">*</span>
						</center>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<select class="form-control" id="no_days" name="no_days" style="width: 300px; margin: auto;">
							<option value="">Select</option>
							<option value="0_45">0-45 days</option>
							<option value="46_90">46-90 days</option>
							<option value="91_120">91-120 days</option>
							<option value="121_180">121-180 days</option>
							<option value="181_270">181-270 days</option>
							<option value="271_365">271-365 days</option>
						</select>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12" style="font-weight: bold;">
						<center>
							<label class="control-label">Language</label>&nbsp;<span style="color: red;font-weight: bolder;">*</span>
						</center>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<select class="form-control" id="language_id" name="language_id" style="width: 300px; margin: auto;">
							<option value="">Select</option>
							<option value="1">HINDI</option>
							<option value="2">ENGLISH</option>
						</select>
					</div>
				</div>
			</div>
			<div class="panel-footer text-center" style="text-align:center;">
				<input type="hidden" id="updateid" name="updateid" value="">
				<input type="submit" name="submit" id="submit" value="Add" class="btn btn-primary">
				<input class="btn btn-primary" type="reset" value="Reset">
			</div>
		</div>
	</form>
	<div>&nbsp;</div>
	<div class="clear" style="clear:both;"></div>
		<div class="col-md-12">
		<div class="table-primary">
			<table class="table table-striped table-bordered" id="datatableid" cellspacing="0" width="100%">
				<thead>
					<tr>
						<th>Sr.No</th>
						<th>Course Name</th>
						<th>Designation</th>
						<th>No. Days</th>
						<th>Language</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
	<div class="col-md-1"></div>
</div>
<link rel="stylesheet" type="text/css" href="../css/jquery.dataTables.min.css">
<link rel="stylesheet" href="../css/font-awesome.min.css">
<link rel="stylesheet" href="../css/jquery.timepicker.min.css">
<link rel="stylesheet" href="../css/jquery-ui.css">
<script type="text/javascript" language="javascript" src="../js/jquery-1.12.4.js"></script>
<script type="text/javascript" language="javascript" src="../js/jquery.dataTables.min.js"></script>	
<script src="../js/jquery-ui.js"></script>
<script src="../js/jquery.timepicker.min.js"></script>
<script src="../js/jquery-ui-timepicker-addon-i18n.min.js"></script>
<script type="text/javascript" src="../js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="../js/buttons.flash.min.js"></script>
<script type="text/javascript" src="../js/jszip.min.js"></script>
<script type="text/javascript" src="../js/pdfmake.min.js"></script>
<script type="text/javascript" src="../js/vfs_fonts.js"></script>
<script type="text/javascript" src="../js/buttons.html5.min.js"></script>
<script type="text/javascript" src="../js/buttons.print.min.js"></script>
<script type="text/javascript">
	$(document).on('click', '.viewbutton', function(){
		$('#filteropt').toggle();
		$('#form1')[0].reset();
		$('#submit').val('Add');
		$('#updateid').val('');
	});

	$(document).on('click','[name="selectall"]',function(){
		$("[name='designation[]']").prop('checked', false);
		if($(this).prop('checked')==true){
			$("[name='designation[]']").prop('checked', true);
		}
	});
	$(document).on('submit','#form1',function(e){
		e.preventDefault();
		var Action='';
		if($('#submit').val()=="Add"){
			Action='addCourseMapping';	
		}
		if($('#submit').val()=="Update"){
			Action='updateCourseMapping';	
		}
		$.ajax({
			type: "POST",
			url:  "course_mapping_designation_class.php?__g__="+Action+"&__u__=<?php echo $USER->id;?>",
			data: $("#form1").serialize(),
			dataType:"json",
			success: function(response){					
				$("#errormsg").show();
				$("#errormsg").html(response.message).delay(1000).fadeOut(100);
				$('html, body').animate({scrollTop:0}, 'slow');
				location.reload();
			}
		});
	});

	function editValue(id){
		$.ajax({
			type: "POST",
			url:  "course_mapping_designation_class.php?__g__=editCourseMapping&__u__=<?php echo $USER->id;?>&course_id='"+id+"'",
			dataType:'Json',
			success: function(response){
				$('#course_id option[value="'+response.course_id+'"]').attr("selected", "selected");
				$('#no_days option[value="'+response.no_days+'"]').attr("selected", "selected");
				$('#language_id option[value="'+response.language_id+'"]').attr("selected", "selected");
				$("#updateid").val(response.id);
				$("#submit").val('Update');
				result = response.designation_id.split(',');
				$.each(result, function(i, val){
					$("input[type=checkbox][value='"+$.trim(val)+"']").prop("checked", true);
				});
			}
		});
		$('#filteropt').toggle();
	}
	function deleteConfirm(id){
		var result = confirm("Are you sure you want to delete?");
		if(result){
			$.ajax({
				type: "POST",
				dataType: 'json',	
				url: "course_mapping_designation_class.php?__g__=deleteCourseMapping&__u__=<?php echo $USER->id;?>&course_id='"+id+"'", 
				success: function(result){
					if(result.response==false){
						alert(result.message);
					}
					if(result.response==true){
						setTimeout(function() {
							location.reload();
						}, 2000);
					}
					$("#errormsg").show();
					$("#errormsg").html(result.message).delay(1000).fadeOut(100);
					$('html, body').animate({scrollTop:0}, 'slow');
				}
			});
		   }
		}
	function populate(){
		$('#datatableid').show();
		$('#datatableid').dataTable().fnDestroy();
		$(document).ready(function(){
			var frmval = $('#form1').serialize();
			$('#datatableid').DataTable({
				"ajax": {
					"url": "course_mapping_designation_class.php?__g__=courseListMapping&__u__=<?php echo $USER->id;?>",
					"dataSrc": ""
				},
				"language": {
					"search": "Search",
					"searchPlaceholder":"Type here to search"
				},
				dom: 'Bfrtip',
				buttons: [{
					extend: 'excel',
					text: 'Export to Excel',
					className: 'buttons-excel',
					title: '',
					exportOptions: {
						columns: [ 0, 1, 2, 3, 4, 5, 6]
					}
				}],
				"columns": [ 
				{ "data": "Sr"},
				{ "data": "CourseName" },
				{ "data": "Designation"},
				{ "data": "no_days"},
				{ "data": "Language"},
				{ "data": "Status" },
				{ "data": "Action" }
				]
			});
		});
	}
	populate();
</script>
<?php
echo $OUTPUT->footer ();
