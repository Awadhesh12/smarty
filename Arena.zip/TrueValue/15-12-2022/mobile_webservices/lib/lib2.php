<?php
error_reporting(E_ALL);
require_once('../../../config.php');

$userid = 6981; 
$scormid = 129;
		
		$startTime = microtime(true);
		$total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '".$userid."' AND sb.scormid = '".$scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') AND sb.attempt <= 3");
		$courseStatus = '';
		$i = 1;
		
		if(!empty($total_attempt)){
			foreach($total_attempt as $val)
				{
					if($val->value == 'completed' || $val->value == 'passed')
					{
						$courseStatus = "Completed";
						break;
					}
					else
					{
						$courseStatus = "Incomplete";
					}
					if($i >=3){
						$courseStatus = "Completed";
					}
					$i++;
				}
		}else{
			$courseStatus = 'Not Started';
		}
		$endTime = microtime(true);
		$executionTime = $endTime - $startTime;
		echo " Execution time of script = ".$executionTime." sec"; 
?>