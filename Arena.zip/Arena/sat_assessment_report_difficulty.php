<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('CLI_SCRIPT', false);
ini_set('max_execution_time', 3000);
ini_set('memory_limit', -1);
require_once('/var/www/html/config.php');
include('../class/datatable.php');
// $c_id = 424;
// $topicid = 523;
// $topic = "level 1 TECH **************************";

$cs_sql = "SELECT id,course_id,topic_id,topic_name,course_name from mdl_ums_sat where deleted = 0";
$cs_result = $DB->get_records_sql($cs_sql);

// echo "<pre>"; print_r($cs_result); die;
// $pre = $topicid = '';
// $pre1 = $topic = '';
foreach ($cs_result as $key => $cs_res) {
	// $c_id = $cs_res->course_id;
	// $topicid .= $pre.''.$cs_res->topic_id;
	// $pre = ', ';
	// $topic .= $pre1.''.$cs_res->topic_name;
	// $pre1 = ', ';
	$c_id = $cs_res->course_id;
	$topicid = $cs_res->topic_id;
	$topic = $cs_res->topic_name;

	$sql = "SELECT u.id as userid, q.id as quizid, q.name as quizname, gi.grademax,qa.id as qa_id, u.username, u.firstname, u.lastname, emp.phone, emp.doj, emp.designation_id, emp.gender,emp.profile_photo_upload,emp.outlet_id as outlet_id, emp.region_id as region_id, emp.state_id as state_id, emp.city_id as city_id,emp.location_id as location_id, reg.r_name as region_name, st.s_name as state, ct.c_name as city, out1.o_name as outlet, out1.o_code_latest as outletcode,desig.id as desig_id, desig.d_name as desig_name, otg.id as og_group_id,otg.og_name as og_group_name
		FROM mdl_quiz  q
		INNER JOIN mdl_quiz_attempts  qa ON qa.quiz = q.id
		INNER JOIN mdl_grade_items gi ON gi.iteminstance = q.id
		INNER JOIN mdl_user u ON u.id = qa.userid    
		INNER JOIN mdl_ums_employeemaster  emp ON emp.userid = u.id
		LEFT  JOIN mdl_ums_regions  reg ON reg.id = emp.region_id
		LEFT  JOIN mdl_ums_state st ON st.id  = emp.state_id
		LEFT  JOIN mdl_ums_city ct ON ct.id  = emp.city_id
		LEFT  JOIN mdl_ums_outlet out1 ON out1.id = emp.outlet_id
		LEFT  JOIN mdl_ums_outlet_group otg ON otg.id = out1.outlet_group_id
		LEFT  JOIN mdl_ums_designations  desig ON desig.id = emp.designation_id
		WHERE u.deleted = 0 AND u.id not in (2,4) AND gi.itemmodule ='quiz' and q.course = $c_id group by u.id";		
// echo $sql;die;
	
	$result = $DB->get_records_sql($sql);
	// echo "<pre>";print_r($result);exit;
	// echo count($result); die;
	$data = array();
	$i = 0;

	foreach ($result as  $value) 
	{
		// echo $value->outlet_id; die;
		$fullname = $value->firstname.' '.$value->lastname;

		$sql1 = "SELECT que.id as questionid, qa.sumgrades,qa.state,qa.timefinish,qa.uniqueid, quec.id as cat_id, quec.name as cat_name,que.questionsummary,que.rightanswer,que.responsesummary,quec.parent
		FROM mdl_quiz_attempts qa
        inner join mdl_question_attempts que on que.questionusageid = qa.uniqueid
		INNER JOIN mdl_question q ON que.questionid = q.id
		INNER JOIN mdl_question_categories quec ON q.category = quec.id
		WHERE qa.quiz = '".$value->quizid."' and qa.userid='".$value->userid."' group by quec.id";

		// echo $sql1; die;

		$result1 = $DB->get_records_sql($sql1);

		// echo '<pre>'; print_r($result1); die;

		
		$ccid = array();
		// echo "<pre>";print_r($result1);exit;
		foreach ($result1 as $key => $value1) 
		{

			if($value1->state =='' || $value1->state == NULL){ //notstarted
				$status = "Not Started";
				$timecompleted = '-';
				$result_status = '-';
				$score = '-';
				$per = '-';
				$profeciency = '-';
			}else if($value1->state == 'inprogress'){//inprogress
				$status = "Incomplete";
				$timecompleted = '-';
				$result_status = '-';
				$score = '-';
				$per = '-';
				$profeciency = '-';
			}elseif($value1->state == 'finished'){ //finished
				$status = "Completed";
				$timecompleted = date('d/m/Y',$value1->timefinish);
				$score = round($value1->sumgrades);
				// $score = round($grades->sumgrades);
				$percentage = round(($score*100)/$value->grademax);
				$per		= $percentage."%";
				if($percentage >= 70){
					$result_status = 'Pass';
				}else{
					$result_status = 'Fail';
				}
				if($percentage >= 70 && $percentage < 80 && $result_status = 'Pass'){
					$profeciency = 'No Band';
				}
				elseif($percentage >= 80 && $percentage < 85 && $result_status = 'Pass') {
					$profeciency = 'Beginner';
				}
				elseif($percentage >= 85 && $percentage < 90 && $result_status = 'Pass'){
					$profeciency = 'Intermediate';
				}
				elseif($percentage >= 90 && $percentage < 95 && $result_status = 'Pass'){
					$profeciency = 'Advanced';
				}elseif($percentage >=95 && $result_status = 'Pass'){
					$profeciency = 'Expert';
				}
				else{
					$profeciency = 'Fail';
				}
			}
// echo $score; die;
			
			$qcat_id = $value1->cat_id;
			// echo $qcat_id.'<br>';
			$questionid = $value1->questionid;
	
				if($topicid !=0 || $topicid !='' || $topicid !=NULL){
					$sql5 = "SELECT * FROM mdl_question_categories WHERE parent = ".$topicid."";
					//echo $sql5;
					$result5 = $DB->get_records_sql($sql5);
					// echo "<pre>"; print_r($result5); die;					
					foreach($result5 as $res5){
						$cat_id = $res5->id;
						$cat_name = $res5->name;
						$sql6 = "SELECT * FROM mdl_question_categories WHERE parent = '".$cat_id."' ";
						$result6      = $DB->get_records_sql($sql6);
						// echo "<pre>"; print_r($result6); die;
						foreach ($result6 as $res6) {
							$sub_cats_id = $res6->id;
							$sub_cats_name = $res6->name;
							$sql7 = "SELECT * FROM mdl_question_categories WHERE parent = '".$sub_cats_id."' ";
							$result7   = $DB->get_records_sql($sql7);
							// echo "<pre>"; print_r($result7)	; die;
							foreach ($result7 as $res7) {
								$sub_sub_cats_id = $res7->id;
								$sub_sub_cats_name = $res7->name;

								// echo $value->userid.'---'.$sub_sub_cats_id .'---'.$sub_sub_cats_name.'<br>';
								// echo $sub_sub_cats_id .'---'.$qcat_id.'<br>';

								if($sub_sub_cats_id == $qcat_id)
								{
									// echo $cat_id.'-- '.$cat_name.'-- '.$sub_cats_id .'-- '.$sub_cats_name.'--'.$sub_sub_cats_id.'-- '.$sub_sub_cats_name."<br>";


									$check_user ="SELECT quiz_id,user_id,topic_id,cat_id,sub_cat_id FROM mdl_sat_ass_score_report_new1 WHERE quiz_id = '".$value->quizid."' and user_id = '".$value->userid."' and topic_id='".$topicid."' and cat_id='".$cat_id."' and sub_cat_id='".$sub_cats_id."'and sub_sub_cat_id='".$sub_sub_cats_id."' group by user_id" ;
									$fresults  = $DB->get_record_sql($check_user);
									// echo '<pre>' ;print_r($fresults); die;


									// echo $fresults->user_id.' -- '.$value->userid; 
									// if(empty($fresults))
									if($fresults->user_id != $value->userid)
									{
										$sat_ins = "INSERT INTO mdl_sat_ass_score_report_new1 SET quiz_id='".$value->quizid."',quiz_name='".$value->quizname."',topic_id='".$topicid."',topic_name='".$topic."',cat_id='".$cat_id."',cat_name='".$cat_name."',sub_cat_id='".$sub_cats_id."',sub_cat_name='".$sub_cats_name."',sub_sub_cat_id='".$sub_sub_cats_id."',sub_sub_cat_name='".$sub_sub_cats_name."',user_id='".$value->userid."',mspin='".$value->username."',ques_id='".$questionid."',emp_name='".$fullname."',doj='".$value->doj."',designation_id='".$value->desig_id."',designation_name='".$value->desig_name."',region_id='".$value->region_id."',region_name='".$value->region_name."',city_id='".$value->city_id."',city_name='".$value->city."',dealer_id='".$value->outlet_id."',dealer_name='".$value->outlet."',dealer_code='".$value->outletcode."',ass_status='".$status."',ass_result='".$result_status."',ass_score='".$score."',topic_score='".$score."',topic_score_summery='".$topic."',proficiency='".$profeciency."',state_id='".$value->state_id."',state_name='".$value->state."',percentage='".$per."',phone='".$value->phone."',date_of_completion='".$timecompleted."',dealer_group_id='".$value->og_group_id."',dealer_group_name='".$value->og_group_name."',gender='".$value->gender."',profile_photo_upload='".$value->profile_photo_upload."' ";
											// echo $sat_ins.'<br><br>';
											$DB->execute($sat_ins);
										
									}
								}
							}						
							

							

						}
					}
				}
				// exit;
		}

		$i++;
	}

}

// $c_id = $cs_result->course_id;
// $topicid = $cs_result->topic_id;
// $topic = $cs_result->topic_name;

// echo $c_id.'<br>'.$topicid.'<br>'.$topic; die;



// $fdata='';
// $cs_sql = "SELECT id,fullname from mdl_course where is_set = 1 AND is_visible = 1";
// $cs_result = $DB->get_records_sql($cs_sql);
// $fdata='';
// foreach ($cs_result as $vls) {
// 	$fdata .= $vls->id.',';
// }
// $cid =  rtrim($fdata,',');

// echo $cid;exit;


	

echo "success at - ".date('d/m/Y h:i:s a', time());

?>