<?php
/***
Developer Name - Yogita P Ghegadmal
Date           - 21-03-2020
this page is Manage Summary
***/
require_once('../../../config.php');
require_once('report_course_class.php'); 
$systemcontext = context_system::instance();
$url = new moodle_url('/local/pagecontainer/ums/report_course_summery_march.php');
require_login();
$PAGE->set_context($systemcontext);
$PAGE->set_title('Course Summary Report');
$PAGE->set_pagelayout('report');
$PAGE->set_heading('Course Summary Report');
echo $OUTPUT->header();
$id   = $USER->id;
$user = $USER->username;
$regionlist = $obj->regionlist('summary');
$courseList = $obj->course_list();
?>
<div class="row">
	<div class="col-md-12">
	<form name="form1" id="form1" method="post">		
			<div class="panel-body">
				<div class="row">
					<div class="col-sm-6">
						<div class="row">
							<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Course</label>&nbsp;<span style="color: red;font-weight: bolder;">*</span>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select name="course_id" id="course_id"  class="form-control">
										<option value="0">Select Course</option>
										<?php echo $courseList;?>
									</select>
								</div>
							</div>
						</div>

					</div>

					<div class="col-sm-6">
						<div class="row">
							<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Region</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select class="form-control" name="region" id="region">
										<?php  echo $regionlist;?>
									</select>
								</div>
							</div>

						</div>
					</div>

					<div class="col-sm-6">
						<div class="row">
							<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Designation</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select class="form-control filtercl" multiple="true" name="designationid[]" id="designationid" >
										<!--<option value="0" disabled>Select Designation</option>-->
										<?php echo $obj->designationlist('summary'); ?>
									</select>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="row">
							<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label"></label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">

								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="row justify-content-center">
						<div class="col-sm-3">
							<div class="form-group no-margin-hr bottmBtn_sec text-center">
								<input type="button" name="searchbtn" id="searchbtn" value="Search" onclick = "populate()" class="btn btn-primary">
							</div>
						</div>
					</div>

			</div>
		
	</form>
</div>
</div>
	

	<div class="row">
		<div class="col-md-12">
		<div class="table-primary "> <!-- style="overflow: auto;display: block;overflow-x: auto;white-space: nowrap" -->
			<table class="table table-striped table-bordered" id="datatableid" cellspacing="0" width="100%">
				<thead>
					<tr>
						<!--<th>Sr.No</th>-->
						<th>Course Name</th>
						<!--<th>Launch Date(DD/MM/YYYY)</th>-->
						<th>Region</th>
						<th>Alloted</th>
						<th>Completed</th>
						<th>Incomplete</th>
						<th>Not Started</th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
	</div>


<link rel="stylesheet" type="text/css" href="../css/jquery.dataTables.min.css">
<link rel="stylesheet" href="../css/font-awesome.min.css">
<link rel="stylesheet" href="../css/jquery.timepicker.min.css">
<link rel="stylesheet" href="../css/jquery-ui.css">
<script type="text/javascript" language="javascript" src="../js/jquery-1.12.4.js"></script>
<script type="text/javascript" language="javascript" src="../js/jquery.dataTables.min.js"></script>	
<script src="../js/jquery-ui.js"></script>
<script src="../js/jquery.timepicker.min.js"></script>
<script src="../js/jquery-ui-timepicker-addon-i18n.min.js"></script>
<script type="text/javascript" src="../js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="../js/buttons.flash.min.js"></script>
<script type="text/javascript" src="../js/jszip.min.js"></script>
<script type="text/javascript" src="../js/pdfmake.min.js"></script>
<script type="text/javascript" src="../js/vfs_fonts.js"></script>
<script type="text/javascript" src="../js/buttons.html5.min.js"></script>
<script type="text/javascript" src="../js/buttons.print.min.js"></script>
<script type="text/javascript">
	var jq = $.noConflict();
	function populate()
	{
		//$.noConflict();
		var regionid = $("#region").val();
		var course_id = $("#course_id").val();
		var designation_id = $("#designationid").val();
		if(course_id== 0)
		{
			alert('Please select a course');
			return false;
		}
		else
		{
			
			jq('#datatableid').show();
			jq('#datatableid').dataTable().fnDestroy();
			jq(document).ready(function() {
				jq(document).ready(function() {
					jq('#datatableid').DataTable( {
						"bPaginate": false,
						"ajax": {
							"url": "report_course_class.php?__g__=data2&__u__=<?php echo $USER->id;?>&region="+regionid+"&course_id="+course_id+"&designation_id="+designation_id,
							"dataSrc": ""
						},
						"language": {
							"search": "Search",
							"searchPlaceholder":"Type here to search"
						},
						dom: 'Bfrtip',
						buttons: [
						{
							extend: 'csv',
							text: 'Export to CSV',
							className: 'buttons-excel',
							title: '',
							exportOptions: {
								columns: [ 0, 1, 2, 3, 4, 5 ]
							}
						}	
						],
						"columns": [ 

//{ "data": "courseId" },
//{ "data": "sr" },
{ "data": "CourseName" },
//{ "data": "LaunchDate" },
{ "data": "RegionName"},
{ "data": "Alloted" },
{ "data": "Completed" },
{ "data": "Incomplete" },
{ "data": "NotStarted" }
]
} );
				} );

			});
		}
	}
	$(document).ready(function(){
//populate();
});
</script>
<?php
echo $OUTPUT->footer ();
