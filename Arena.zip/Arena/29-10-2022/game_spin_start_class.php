<?php
require_once('../../../../config.php');
class Category
{

	function fetchProduct($selected=""){
		global $DB;
		$list="";
		$sql = "SELECT * FROM {gm_weekly_quiz_product_type} WHERE deleted=0 ORDER BY id ASC";
		$fetch_all=$DB->get_records_sql($sql);
		foreach($fetch_all as $row){
			if($row->id == $selected){ $val='selected';}
			$list .= "<option value=".$row->id.">".ucwords($row->cat_name)."</option>";
			//$list.= "<option value=".$fetch_all->id." selected>".ucwords($fetch_all->cat_name)."</option>";
		}
		return $list;
	}

	function category_find($ucat="")
	{
	  	global $DB;
	  	$list="";
	  	if(@$ucat)
		{
	  		$sql = "SELECT id, category_name, category_desc, status FROM mdl_ums_category WHERE id IN(".$ucat.") AND status = 'active' ORDER BY id ASC";
	  		$fetch_all=$DB->get_records_sql($sql);
	  		foreach($fetch_all as $fetch_all)
			{
	  			$list.= "<option value=".$fetch_all->id." selected>".ucwords($fetch_all->category_name)."</option>";
	  		}
	  	}
		else
		{
	  		$sql = "SELECT id,category_name,category_desc,status FROM mdl_ums_category WHERE status = 'active' ORDER BY id ASC";
	  		$fetch_all=$DB->get_records_sql($sql);
	  		foreach($fetch_all as $fetch_all)
			{
	  			$list.= "<option value=".$fetch_all->id.">".ucwords($fetch_all->category_name)."</option>";
	  		}
	  	}
	  	return $list;
	}
	
	function category_list()
	  {
			global $DB;
			$list="";
			$sql = "SELECT id, category_name, category_desc, status FROM mdl_ums_category WHERE status = 'active' ORDER BY id";
			$all_record=$DB->get_records_sql($sql);
			foreach($all_record as $key=>$all_record_first){
				$list.= "<option value=".$all_record_first->id.">".ucwords($all_record_first->category_name)."</option>";
			}
			return $list;
		}
		
		function outletgrouplist($selected="")
		{
			global $DB;
			$result = $DB->get_records_sql('SELECT id,og_name,og_code,deleted FROM {ums_outlet_group} WHERE deleted =0 ORDER BY og_name ASC', array());
			$list="";
			$selected="";
			foreach($result as $rows)
			{
				$chid         = $rows->id;
				$og_name  = $rows->og_name;	
				//if($rows->id==$selected) $val='selected';	
				$list .= "<option value=".$chid.">".ucwords($og_name)."</option>";
			}
			return $list;
		}
		
		function fetch_all(){
			global $DB;
			$sql = "SELECT pst.*,pt.cat_name FROM mdl_gm_weekly_quiz_product_subcat_type pst
				inner join mdl_gm_weekly_quiz_product_type pt WHERE pst.deleted=0 and pst.cat_id = pt.id";
			$all_record=$DB->get_records_sql($sql);
			$row=array();
			$count=1;
			foreach($all_record as $key=>$all_record_first){
				// $row[]=array('sr'=>$key++, 'category_name'=>$all_record_first->category_name,'category_desc'=>$all_record_first->category_desc,'status'=>ucfirst($all_record_first->status), 'action'=>'<button class="button1 edit_btn" type="button" name="edit" cat-attr="'.$all_record_first->id.'"><i class="fa fa-pencil-square-o"></i></button><button class="button1 deletefn" type="button" name="delete" cat-attr="'.$all_record_first->id.'"><i class="fa fa-trash-o"></i></button>');
				$row[]=array('sr'=>$count++, 
							'cat_name'=>$all_record_first->cat_name,
							'subcat_name'=>$all_record_first->subcat_name,
							'action'=>'<button class="button1 edit_btn" type="button" name="edit" cat-attr="'.$all_record_first->id.'"><i class="fa fa-pencil-square-o"></i></button><button class="button1 deletefn" type="button" name="delete" cat-attr="'.$all_record_first->id.'"><i class="fa fa-trash-o"></i></button>');
			}
			echo json_encode($row);
		}
		function view(){
			global $DB;
			$first_list=array();
			$sql = "SELECT * FROM mdl_gm_weekly_quiz_product_subcat_type WHERE id='".@$_POST['subcategory_id']."'";
			$first=$DB->get_record_sql($sql);
			$first_list['id']=$first->id;
			$first_list['cat_name']=$first->cat_id;
			$first_list['subcat_name']=$first->subcat_name;
			echo json_encode($first_list);
		}
		function add(){
			global $DB;
			$error_notify=array();
			if($_SERVER['REQUEST_METHOD']==='POST'){
			 	if(@$_POST['subcat_name']){
					if(!preg_match("/^[A-Za-z0-9-,& ]+$/", $_POST['subcat_name'])){
					 	$error_notify[]="Special char not allowed";
					}else{
						if(strlen($_POST['subcat_name'])>150){
							$error_notify[]="Category name can't be more than 150 char";
				       	}
					}
			 	}else{
					$error_notify[]="category name required";
			 	}
			/*  if(@$_POST['category_desc']){
				if(strlen($_POST['category_desc'])>100){
					$error_notify[]="Description can't be more than 100 char";
				}
			 }else{
				$error_notify[]="Description required";
			 } */
			  	/*if(!isset($_POST['status'])&& empty($_POST['status'])){
				 	$error_notify[]="Select status required";
			 	}*/
			}else{
				$error_notify[]="Method not allowed";	
			}			

			if(sizeof($error_notify)==0){
				
				$query = "SELECT subcat_name FROM mdl_gm_weekly_quiz_product_subcat_type WHERE subcat_name = '".$_POST['subcat_name']."' and cat_id='".$_POST['cat_name']."'";
				$categoryResult = $DB->get_record_sql($query);

				if ($categoryResult) {
					$this->response['message'] ="<div class='alert alert-danger'>Category Already Exist</div>";
					$this->response['response']=false;
				} else {

					$insert="INSERT INTO `mdl_gm_weekly_quiz_product_subcat_type`(`cat_id`,`subcat_name`, `created`, `deleted`) VALUES ('".@$_POST['cat_name']."','".@$_POST['subcat_name']."','".date("Y-m-d h:i:s")."',0)";
					//echo $insert;exit;
					$DB->execute($insert,array());
					$this->response['message'] ="<div class='alert alert-success'>Sub Category Created Successfully</div>";
					$this->response['response']=true;

				}			

				

			} else{
				$this->response['message'] ="<div class='alert alert-danger'>".implode(',&nbsp;', $error_notify)."</div>";
				$this->response['response']=false;
			}

			echo json_encode($this->response);
		}
		function update(){
			global $DB;
			$error_notify=array();
			if($_SERVER['REQUEST_METHOD']==='POST'){
			 if(@$_POST['subcat_name']){
					if(!preg_match("/^[A-Za-z0-9 ]+$/", $_POST['subcat_name'])){
					 $error_notify[]="Special char not allowed";
					}else{
					if(strlen($_POST['subcat_name'])>100){
					$error_notify[]="Sub Category name can't be more than 100 char";
				       }
					}
			 }else{
				$error_notify[]="sub category name required";
			 }
			/*  if(@$_POST['category_desc']){
				if(strlen($_POST['category_desc'])>100){
					$error_notify[]="Description can't be more than 100 char";
				}
			 }else{
				$error_notify[]="Description required";
			 } */
			 /*if(!isset($_POST['status'])&& empty($_POST['status'])){
				 $error_notify[]="Select status required";
			 }*/
			}else{
			$error_notify[]="Method not allowed";	
			}
			if(sizeof($error_notify)==0){
			$update="update mdl_gm_weekly_quiz_product_subcat_type set cat_id='".@$_POST['cat_name']."', subcat_name='".@$_POST['subcat_name']."', updated='".@date("Y-m-d h:i:s")."' WHERE id='".$_POST['subcategory_id']."'";
			//echo $update;exit;
			$DB->execute($update,array());
			$this->response['message'] ="<div class='alert alert-success'>Sub Category Updated Successfully</div>";
			$this->response['response']=true;
			}else{
			$this->response['message'] ="<div class='alert alert-danger'>".implode(',&nbsp;', $error_notify)."</div>";	
			$this->response['response']=false;
			}
			echo json_encode($this->response);
		}

		function delete(){
		   global $DB;
		   $this->response['response']=false;
		
		   if(@$_POST['subcategory_id']){
		   	$sql = "SELECT id FROM mdl_gm_weekly_quiz_product_subcat_type WHERE id='".@$_POST['subcategory_id']."'";
		   	//echo $sql;exit;
		   	$first=$DB->get_record_sql($sql);
		   	if($first->id){

		   		$sql = "UPDATE mdl_gm_weekly_quiz_product_subcat_type set deleted=1 WHERE id='".$_POST['subcategory_id']."'";
		   		$DB->execute($sql,array());
		   		$this->response['response']=true;
		   		$this->response['message']='Successfully deleted.';
		   		 
		   	}else{
		   		$this->response['message']='Something wrong while deleting';
		   	}
		 }
		 echo json_encode($this->response);
		}
}
$obj_action=new Category;
if(isset($_POST['action_type']) && $_POST['action_type']=='add'){
	$obj_action->add();
}

if(isset($_POST['action_type']) && $_POST['action_type']=='update'){
	$obj_action->update();
}

if(isset($_POST['action_type']) && $_POST['action_type']=='all'){
	$obj_action->fetch_all();
}

if(isset($_POST['action_type']) && $_POST['action_type']=='view'){
	$obj_action->view();
}

if(isset($_POST['action_type']) && $_POST['action_type']=='delete'){
	$obj_action->delete();
}
?>