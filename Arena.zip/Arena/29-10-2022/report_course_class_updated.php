<?php

ini_set('max_execution_time', 0);
ini_set('memory_limit', -1);
require_once('../../../config.php');
include('../class/datatable.php');
require_once('activity_report_class.php');

class Course extends DataTable {

    var $userid;
    var $salesforce_courses = "357,461,360,464,356,459,361,465,358,462,460,359,463";

    function __construct($userid) {
        parent::__construct($userid);
        $this->userid = $userid;
        $this->classObj        = new activityReport();
        // $this->course_list();
    }

    function getPassFailStatus($userid, $scormid) {
        global $DB;
        $total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '" . $userid . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') AND sb.attempt <= 3");
        $courseStatus = '';
        $i = 1;
        foreach ($total_attempt as $val) {
            if ($val->value == 'completed' || $val->value == 'passed') {
                $courseStatus = "Passed";
                break;
            } else {
                $courseStatus = "Failed";
            }
            if ($i >= 3) {
                $courseStatus = "Passed";
            }
            $i++;
        }
        return $courseStatus;
    }

    function getMaxScore($userid, $scormid) {
        global $DB;
        //$result = $DB->get_record_sql("SELECT max(sb.value) as maxscore FROM {scorm_scoes_track} as sb WHERE sb.userid= ? AND sb.scormid = ? AND element = ? AND attempt <= ?",array($userid,$scormid,'cmi.core.score.raw',3));

        $result = $DB->get_record_sql("SELECT MAX(CONVERT(sb.value,UNSIGNED INTEGER)) AS maxscore FROM {scorm_scoes_track} as sb WHERE sb.userid= '" . $userid . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.score.raw' || sb.element = 'cmi.score.raw') AND sb.attempt <= 3");

        // $att = $DB->get_record_sql("SELECT max(attempt) as final_attempt from mdl_scorm_scoes_track WHERE userid= '" . $userid . "' AND scormid = '" . $scormid . "'");
        // if($att->final_attempt >= 3)
        // {
        //     $range = '>=3';
        // }else{
        //     $range = '<=3';
        // }

       
        // $result = $DB->get_record_sql("SELECT MAX(CONVERT(sb.value,UNSIGNED INTEGER)) AS maxscore FROM {scorm_scoes_track} as sb WHERE sb.userid= '" . $userid . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.score.raw' || sb.element = 'cmi.score.raw') AND sb.attempt $range ");
        return $result->maxscore;
    }

    function getJsonData() {
        global $DB, $SESSION;
        $join = "";
        $exWhere = "";

        $courses = $DB->get_records_sql("SELECT * FROM mdl_course WHERE id NOT IN (" . $this->salesforce_courses . ")");

        $data = array();
        $index = 0;
        if (isset($courses) && !empty($courses)) {
            $filter = '';
            if ($this->userid == 2) {
                $filter = '';
            }
            if ($this->userid != 2) { //Apart from Admin user apply cnd below to all other users
                //Below code for displaying data as per login HO, FSDL, TL or HR
                $designationid = $this->getDesignation($this->userid);
                if (count($designationid) > 0 && $designationid['filterby'] != '') {
                    if ($designationid['filterby'] == 'channel') {
                        $channels_id = $designationid['filterid'];
                        $filter .= " AND emp.channels_id=$channels_id";
                    }
                    if ($designationid['filterby'] == 'region') {
                        $region_id = $designationid['filterid'];
                        $filter .= " AND emp.region_id=$region_id";
                    }
                    if ($designationid['filterby'] == 'outlet') {
                        $outlet_id = $designationid['filterid'];
                        $filter .= " AND emp.outlet_id IN($outlet_id)";
                    }
                    if ($designationid['filterby'] == 'tlmspin_no') {
                        $usercode = $designationid['filterid'];
                        $filter .= " AND emp.tl_mspin_no=$usercode";
                    }
                }
                /* if($designationid['filterby'] == 'admin')
                  {
                  $region_id = $designationid['filterid'];
                  $filter .= " AND emp.region_id=$region_id";
                  } */
            }
            $regioncnd = '';
            if (isset($_REQUEST['region']) && trim($_REQUEST['region']) > 0) {
                $regioncnd .= " AND emp.region_id IN (" . $_REQUEST['region'] . ")";
            }


            foreach ($courses as $course) {
                if ($course->visible == 1) {//display only active courses
                    $sql1 = "select count(a.id) as totalenroled from mdl_role_assignments as a
								INNER JOIN mdl_user as u on(a.userid=u.id )
								INNER JOIN mdl_ums_employeemaster as emp on(u.id=emp.userid )
								INNER JOIN mdl_context e ON e.id = a.contextid
								WHERE u.deleted=0 AND u.id <>2 AND e.contextlevel=50 AND emp.designation_id IN(2,3,4,5,6,7,8,9,10,11,23,30,32,33,40,43,44,45,52,54,57,61,63,74,80,90,106,120,128,131,143,153,157,159,166,218,221,222,223,225,226,228,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,259,260,261,262,265,266,289,310)
								AND e.instanceid=" . $course->id . " " . $filter . " " . $regioncnd; //cnd to show 7 designation data (SAE,TL,RSE,RTL,CTL,CSE,INT,STR) + MSIL Users


                    $enrolledusers = $DB->get_records_sql($sql1, array());
                    $alloted = key($enrolledusers);
                    if ($alloted > 0) {
                        $sql = "SELECT
								concat(a.id,'-',u.id) as tempid,
								d.id,
								emp.userid as empuid,
													
							(SELECT 
									sb.value AS lession_status
								FROM
									mdl_scorm AS sa
										INNER JOIN
									mdl_scorm_scoes_track AS sb ON (sa.id = sb.scormid)
								WHERE
									sb.element = 'cmi.core.lesson_status'
										AND sb.attempt = 1
										AND (sb.value = 'completed'
										OR sb.value = 'passed'
										OR sb.value = 'failed'
										OR sb.value = 'incomplete')
										AND sb.userid = u.id
										AND sa.course = $course->id ORDER BY sb.id desc limit 1
							) AS lession_status,
							(SELECT 
									sb.value AS completion_status
								FROM 
									mdl_scorm AS sa
										INNER JOIN
									mdl_scorm_scoes_track AS sb ON (sa.id = sb.scormid)
								WHERE
									sb.element = 'cmi.completion_status'
										AND sb.attempt = 1
										AND (sb.value = 'completed'
										OR sb.value = 'passed'
										OR sb.value = 'failed'
										OR sb.value = 'incomplete')
										AND sb.userid = u.id
										AND sa.course = $course->id ORDER BY sb.id desc limit 1
							) AS completion_status
							
									
							FROM mdl_role_assignments as a
							LEFT JOIN mdl_user as u on(a.userid=u.id)
							INNER JOIN mdl_ums_employeemaster as emp on(u.id=emp.userid )
							INNER JOIN mdl_context as e on (e.id = a.contextid and e.contextlevel=50)
							INNER JOIN mdl_course as d on (d.id=e.instanceid)
							WHERE u.deleted=0 AND u.id <>2 AND emp.designation_id IN(2,3,4,5,6,7,8,9,10,11,23,30,32,33,40,43,44,45,52,54,57,61,63,74,80,90,106,120,128,131,143,153,157,159,166,218,221,222,223,225,226,228,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,259,260,261,262,265,266,300,289,310) AND e.instanceid=$course->id $exWhere $filter $regioncnd"; //cnd to show 13 designation data (SAE,TL,RSE,RTL,CTL,CSE,INT,STR,HRM,CEO,SM,GM,HRE,GMS) + MSIL Users(FSDM, HO)

                        $courseRes = $DB->get_records_sql($sql, array());

                        $completed = 0;
                        $incompleted = 0;
                        $notstarted = 0;
                        if (isset($courseRes) && !empty($courseRes)) {

                            foreach ($courseRes as $res) {
                                //echo '<pre>';print_r($res);exit;
                                $iscomplete = $this->chkIfCourseIsComplete($courseid, $res->empuid);

                                $courseid = $res->id;

                                if (isset($res->lession_status) && !empty($res->lession_status)) {
                                    $status = $res->lession_status;
                                } else if (isset($res->completion_status) && !empty($res->completion_status)) {
                                    $status = $res->completion_status;
                                } else {
                                    $status = "Not Started";
                                }
                                ############ get Status ################
                                if ($status == 'completed' || $status == 'passed' || $status == 'failed' || $iscomplete == 1) {
                                    $completed = $completed + 1;
                                } elseif ($status == 'incomplete') {
                                    $incompleted = $incompleted + 1;
                                } else {
                                    $notstarted = $notstarted + 1;
                                }
                            }
                        }


                        $data[$index]['id'] = $courseid;
                        $data[$index]['sr'] = $index + 1;
                        $data[$index]['CourseName'] = $course->fullname;
                        $data[$index]['Alloted'] = $alloted;
                        $data[$index]['LaunchDate'] = date("d/m/Y", $course->startdate);
                        $data[$index]['Completed'] = $completed;
                        $data[$index]['Incomplete'] = $incompleted;
                        $data[$index]['NotStarted'] = $notstarted;
                        $index++;
                    }
                }
            }//eof for loop
        }
        echo json_encode($data);
    }

    function getRegionCourseJsonData(){
        global $DB, $SESSION, $USER;
        $data = array();
        $index = 0;
        $filter = " AND u.id NOT IN(2,4) AND u.username NOT IN('admin','guest','administrator')";
        if(@$_REQUEST['designation_id']!=0){
            $filter .= " AND emp.designation_id IN (" .$_REQUEST['designation_id']. ") ";
        }
        if(@$_REQUEST['region']!=0){
            $filter .= " AND reg.id IN (" . $_REQUEST['region'] . ") ";
        }
        if(@$_REQUEST['course_id']!=0){
            $filter .= " AND c.id ='".$_REQUEST['course_id']."'";
        }
        $mysql = "SELECT concat(u.id,'',c.id) as tempid,u.id as userid,u.username,u.phone1,u.firstname,u.lastname, emp.dol, emp.region_id, c.id as courseid,out1.o_code,out1.o_code_latest,out1.o_name,reg.r_name,st.s_code,s.id as scormid,ra.timemodified as courseassigndate,desig.d_name, c.fullname as coursename
        FROM {user} u
        INNER JOIN {role_assignments} ra ON ra.userid = u.id
        INNER JOIN {context} ctx ON ctx.id = ra.contextid
        INNER JOIN {course} c ON c.id = ctx.instanceid
        INNER JOIN {scorm} s ON c.id = s.course
        INNER JOIN {course_categories} cat ON cat.id = c.category
        INNER JOIN {ums_employeemaster} emp ON emp.userid = u.id
        LEFT  JOIN {ums_regions} reg ON reg.id = emp.region_id
        LEFT  JOIN {ums_state} st ON st.id  = emp.state_id
        LEFT  JOIN {ums_outlet} out1 ON out1.id = emp.outlet_id
        LEFT  JOIN {ums_designations} desig ON desig.id = emp.designation_id
        WHERE u.deleted = 0 AND ra.roleid = 5 AND ctx.contextlevel = 50 AND emp.designation_id IN(2,3,4,5,6,7,8,9,10,11,23,30,32,33,40,43,44,45,52,54,57,61,63,74,80,90,106,120,128,131,143,153,157,159,166,218,221,222,223,225,226,228,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,259,260,261,262,265,266,295,300,289,198,310) AND cat.id = 3 ".$filter;
        $results = $DB->get_records_sql($mysql);
        $totalloted=$notstartedcount = $incompletedcount =$completedcount = 0;
        foreach($results as $key => $result){
            $sql = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= " . $result->userid . " AND sb.scormid = " . $result->scormid . " AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')  order by sb.attempt DESC LIMIT 1";
            $attemptdetails = $DB->get_record_sql($sql);
            if($this->isLearningPathCourse($result->courseid)){
                $courseModules = $this->classObj->getActivities($result->courseid);
                $LYLIST=[];
                foreach($courseModules as $key => $module){
                    $details =$this->classObj->getActivityInfo($module->instance,$module->module, $result->userid);
                    foreach($details as $key => $details){
                        $LYLIST[$details->status]=$details->status;
                    }
                }

                if(@$LYLIST['Completed'] && @$LYLIST['Incomplete'] && @$LYLIST['Not Started']){
                    $status="Incomplete";
                    $incompletedcount=$incompletedcount+1;
                }elseif(@$LYLIST['Completed'] && @$LYLIST['Incomplete']=="" && @$LYLIST['Not Started']==""){
                    $status="Completed";
                    $completedcount=$completedcount+1;
                }elseif(@$LYLIST['Completed']=="" && @$LYLIST['Incomplete']=="" && @$LYLIST['Not Started']==""){
                    $status="Not Started";
                    $notstartedcount=$notstartedcount+1;
                }elseif(@$LYLIST['Completed'] && @$LYLIST['Incomplete']=="" && @$LYLIST['Not Started']){
                    $status="Incomplete";
                    $incompletedcount=$incompletedcount+1;
                }elseif(@$LYLIST['Completed']=="" && @$LYLIST['Incomplete'] && @$LYLIST['Not Started']){
                    $status="Incomplete";
                    $incompletedcount=$incompletedcount+1;
                }elseif(@$LYLIST['Completed'] && @$LYLIST['Incomplete'] && @$LYLIST['Not Started']==""){
                    $status="Incomplete";
                    $incompletedcount=$incompletedcount+1;
                }elseif(@$LYLIST['Completed']=="" && @$LYLIST['Incomplete']=="" && @$LYLIST['Not Started']){
                    $status="Not Started";
                    $notstartedcount=$notstartedcount+1;
                }
                $totalloted=$notstartedcount+$incompletedcount+$completedcount;
                unset($LYLIST); 
            }else{
               $totalmarksscored = $this->getMaxScore($result->userid, $result->scormid);
               $total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '".$result->userid."' AND sb.scormid = '".$result->scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')");
               $i = 1;
               $fetch_marks_max = $DB->get_record_sql("SELECT sb.value FROM mdl_scorm_scoes_track as sb WHERE userid = '".$result->id."' AND scormid = '".$result->scormid."' AND (sb.element = 'cmi.core.score.raw') ORDER BY sb.attempt DESC LIMIT 1");
               $totalloted=$totalloted+1;
               foreach($total_attempt as $val){
                if(($val->value == 'completed' OR $val->value == 'passed') && $fetch_marks_max->value >=0  && $totalmarksscored <= 80){
                  $status = "Completed";
                  $completedcount=$completedcount+1;
                  break;
              }

              if(($val->value == 'completed' OR $val->value == 'passed') && $totalmarksscored >= 80){
                $status = "Completed";
                $completedcount=$completedcount+1;
                break;
            }else if($val->value == 'failed' OR $val->value == 'incomplete'){
                if($val->attempt >= 3){
                    $marks3 = $DB->get_record_sql("SELECT * FROM maruti_prod.mdl_scorm_scoes_track where scormid='".$result->scormid."' and userid='".$result->userid."' and attempt=3 and element = 'cmi.core.score.raw'");
                    if(empty($marks3)){
                        $status = "Incomplete";
                        $incompletedcount=$incompletedcount+1;
                        break;
                    }elseif (($val->attempt >= 3) && ($totalmarksscored == '' || $totalmarksscored == NULL)){
                        $status = "Incomplete";
                        $incompletedcount=$incompletedcount+1;
                        break;
                    }elseif (($val->attempt >= 3) && ($totalmarksscored >= 0 && $totalmarksscored < 80)){
                     $status = "Completed";
                     $completedcount=$completedcount+1;
                     break;
                 }else{
                    $status = "Incomplete";
                    $incompletedcount=$incompletedcount+1;
                    break;
                }
            }else{
                $status = "Incomplete";
                $incompletedcount=$incompletedcount+1;
                break;
            }
        }else if(($val->value == 'completed' OR $val->value == 'passed') && ($val->attempt >= 3) && ($totalmarksscored >= 0 && $totalmarksscored < 80)){
            $status = "Completed";
            $completedcount=$completedcount+1;
        } else {
            $status = "Incomplete";
            $incompletedcount=$incompletedcount+1;
        }
    }
    $notstartedcount=$totalloted-($incompletedcount+$completedcount);
  }
}

$coursename = $DB->get_field("course", "fullname", array("id" => $_REQUEST['course_id']));
$regionstr = "";

if($_REQUEST['region']!= '' && $_REQUEST['region']!= 0){
    $regionidtemp = explode(",", $_REQUEST['region']);
    $ic=0;
    foreach ($regionidtemp as $rid) {
        $regionname = $DB->get_field("ums_regions", "r_name", array("id" => $rid));
        if($ic==0){
            $regionstr .= $regionname;
        }else{
            $regionstr .=  ", ".$regionname;
        }
        $ic++;
    }
}
if($_REQUEST['region']!= '' && $_REQUEST['region']== 0){
    $regionstr="All";
}
$data[$index]['id'] = 1;
$data[$index]['sr'] = $index + 1;
$data[$index]['CourseName'] = ucfirst(@$coursename);
$data[$index]['Alloted'] = $totalloted;
$data[$index]['LaunchDate'] = date('d/m/Y');
$data[$index]['RegionName'] = @$regionstr;
$data[$index]['Completed']  = $completedcount;
$data[$index]['Incomplete'] = $incompletedcount;
$data[$index]['NotStarted'] = $notstartedcount;
echo json_encode($data);
}

    function chkIfCourseIsComplete($courseid, $userid) {
        global $CFG;
        require_once($CFG->folder . "/lib/completionlib.php");
        $course = new stdClass();
        $course->id = $courseid;
        $cinfo = new completion_info($course);
        $iscomplete = $cinfo->is_course_complete($userid); //this gives status(%) of Course (if completed or not). This is for foll. purpose : even if any user accesses course from History in mobile app then chk only its status(%) and show Completed
        return $iscomplete;
    }

    function getIndividualJsonData() {
        global $DB, $CFG;
        $join = "";
        $data = array();

        $filter = " AND u.id NOT IN(2,4) AND u.username NOT IN('admin','guest','administrator')";

        $empcode = (isset($_REQUEST['empusernamehidden']) && !empty($_REQUEST['empusernamehidden'])) ? $_REQUEST['empusernamehidden'] : '';
        $empname = (isset($_REQUEST['empname']) && !empty($_REQUEST['empname'])) ? $_REQUEST['empname'] : '';
        $empphone = (isset($_REQUEST['empphone']) && !empty($_REQUEST['empphone'])) ? $_REQUEST['empphone'] : '';

        $hmi_status = (isset($_REQUEST['course_status']) && !empty($_REQUEST['course_status'])) ? $_REQUEST['course_status'] : '';

        $emptype = (isset($_REQUEST['emptype']) && !empty($_REQUEST['emptype'])) ? $_REQUEST['emptype'] : '';

        $course_id = (isset($_REQUEST['course_id']) && !empty($_REQUEST['course_id'])) ? $_REQUEST['course_id'] : '';
        $filter .= " AND c.id = " . $course_id . " ";
        if ($course_id == 12) {
            // for 1st scorm
            $filterscorm .= " AND s.id = 10";
        } else if ($course_id == 338) {
            // for 1st scorm
            $filterscorm .= " AND s.id = 258";
        } else {
            $filterscorm .= " ";
        }
        $regionarr = (count($_REQUEST['region']) > 0) ? implode(",", $_REQUEST['region']) : '';

        $statearr = (count($_REQUEST['state']) > 0) ? implode(",", $_REQUEST['state']) : '';

        $cityarr = (count($_REQUEST['city']) > 0) ? implode(",", $_REQUEST['city']) : '';

        $empoutletid = (isset($_REQUEST['outletnm']) && !empty($_REQUEST['outletnm'])) ? $_REQUEST['outletnm'] : '';

        $empoutletcode = (isset($_REQUEST['outletcode']) && !empty($_REQUEST['outletcode'])) ? $_REQUEST['outletcode'] : '';

        $designationarr = (count($_REQUEST['designationid']) > 0) ? implode(",", $_REQUEST['designationid']) : '';

        $emp_status = $_REQUEST['emp_status'];
//        echo $emp_status; die;

        $count = 0;

        $newfilter = '';
//         echo $this->userid; die;
        //Below code for displaying data as per login HO, FSDL, TL or HR
        if ($this->userid != 2) {//Apart from Admin user apply cnd below to all other users
            $designationid = $this->getDesignation($this->userid);
            // echo "<pre>"; print_r($designationid); die;
//            echo 'hello'; die;
            if (count($designationid) > 0 && $designationid['filterby'] != '') {
                if ($designationid['filterby'] == 'channel') {
                    $channels_id = $designationid['filterid'];
                    $newfilter .= " AND emp.channels_id=$channels_id";
                }
                if ($designationid['filterby'] == 'region') {
                    $region_id = $designationid['filterid'];
                    $newfilter .= " AND emp.region_id IN ($region_id)";
                }
                if ($designationid['filterby'] == 'outlet') {
                    $outlet_id = $designationid['filterid'];
                    $newfilter .= " AND emp.outlet_id IN($outlet_id)";
                }
                if ($designationid['filterby'] == 'tlmspin_no') {
                    $usercode = $designationid['filterid'];
                    $newfilter .= " AND emp.tl_mspin_no=$usercode";
                }
                if ($designationid['filterby'] == 'parent_group') {
                    $outlet_id = $designationid['filterid'];
                    $filter = " AND emp.outlet_id IN($outlet_id)";
                }
            }
        }

        /* Dealer Mapping */
        if ($this->checkDealerLogin()) {
            $tempOutletId = $DB->get_field("ums_user_dealer_mapping", "outlet_id", array("user_id" => $this->userid));

            $oCodeLatest = "";
            $tempOutletId = explode(",", $tempOutletId);
            foreach ($tempOutletId as $outletId) {
                $tempOCodeLatest = $DB->get_field("ums_outlet", "o_code_latest", array("id" => $outletId));

                $oCodeLatest .= "'" . $tempOCodeLatest . "',";
            }

            $oCodeLatest = rtrim($oCodeLatest, ",");

            $filter .= " AND out1.o_code_latest IN ($oCodeLatest)";
        }


        $course = $DB->get_record('course', array('id' => $course_id));
//        echo "<pre>" ;print_r($course); die;
        $sql1 = "select count(a.id) as totalenroled from {role_assignments} as a
					INNER JOIN {user} as b on(a.userid=b.id )
					INNER JOIN mdl_ums_employeemaster as emp on(b.id=emp.userid )
					INNER JOIN {context} e ON e.id = a.contextid
					WHERE e.instanceid=" . $course->id . " AND b.id NOT IN(2,4) AND b.username NOT IN('admin','guest','administrator') AND emp.designation_id IN(2,3,4,5,6,7,8,9,10,11,23,30,32,33,40,43,44,45,52,54,57,61,63,74,80,90,106,120,128,131,143,153,157,159,166,218,221,222,223,225,226,228,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,259,260,261,262,265,266,295,310) " . $newfilter . "";
        // echo $sql1;exit;
        $enrolledusers = $DB->get_records_sql($sql1, array());
        $alloted = key($enrolledusers);
        $scorm = $DB->get_record('scorm', array('course' => $course->id));
        $sql2 = "SELECT count(*) as totalscoes
						FROM {scorm} as a INNER JOIN {scorm_scoes} as b ON (a.id=b.scorm)
						WHERE b.scorm=a.id and b.scormtype='sco' AND a.course=$course->id";

        $totalscoes = $DB->count_records_sql($sql2);
        
//        echo $totalscoes;        exit();

        $completed = 0;
        $not_started = 0;
        $incomplete = 0;
        // echo $hmi_status; die;
        if ($hmi_status != "0" && $hmi_status != ""&& $hmi_status != NULL && $hmi_status != 'notstarted') {
            if ($hmi_status == "finished") {
                $filter .= " AND (sst.element = 'cmi.core.lesson_status' || sst.element = 'cmi.completion_status') AND (sst.value='passed' || sst.value='completed') ";
            } else {
                $filter .= " AND (sst.element = 'cmi.core.lesson_status' || sst.element = 'cmi.completion_status') AND (sst.value='incomplete' || sst.value='failed') ";
            }
        }
//        echo $empcode; die;
        if ($empcode != '') {
            $filter .= " AND u.username like '" . $empcode . "'";
        }

        if ($empname != '') {
            $filter .= " AND (u.firstname LIKE '%" . trim($empname) . "%' OR u.lastname LIKE '%" . trim($empname) . "%' OR CONCAT(u.firstname, ' ', u.lastname) LIKE '%" . trim($empname) . "%')";
        }

        if ($empphone != '') {
            $filter .= " AND u.phone1 like '%" . $empphone . "%'";
        }

        if (trim($regionarr) != '') {
            $filter .= " AND emp.region_id IN(" . trim($regionarr) . ")";
        }

        if (trim($statearr) != '') {
            $filter .= " AND emp.state_id IN(" . trim($statearr) . ")";
        }

        if (trim($cityarr) != '') {
            $filter .= " AND emp.city_id IN(" . trim($cityarr) . ")";
        }

        if (trim($empoutletid) != '') {
            $sqloname = $DB->get_record_sql("SELECT o_name FROM mdl_ums_outlet WHERE id ='" . trim($empoutletid) . "' AND deleted = '0' AND status = '0'");

            $filter .= " AND out1.o_name = '" . $sqloname->o_name . "' "; //fetch outlets based on outlet names
        }

        if (trim($empoutletcode) != '') {
            $filter .= " AND out1.o_code_latest ='" . trim($empoutletcode) . "'";
        }


        if (trim($designationarr) != '') {
            $filter .= " AND emp.designation_id IN(" . trim($designationarr) . ")";
        }

        if ($emptype != '' || $emptype != 0) {
            if ($emptype == 'dms') {
                $filter .= " AND emp.user_type_id NOT IN (1,2)";
            } else if ($emptype == 'msil') {
                $filter .= "  AND emp.user_type_id IN (1,2)";
            }
        }
//        echo $filter; die;
//        echo $newfilter; die;
//echo $hmi_status; die;
        if ($hmi_status != 'notstarted') {

            $sql = "SELECT 
						concat(u.id,'',c.id) as tempid,u.id as userid,u.username,u.phone1,u.firstname,u.lastname, emp.dol, emp.region_id, c.id as courseid,out1.o_code,out1.o_code_latest,out1.o_name,reg.r_name,st.s_code,s.id as scormid,ra.timemodified as courseassigndate,desig.d_name, c.fullname as coursename
						FROM {user} u
						INNER JOIN {role_assignments} ra ON ra.userid = u.id
						INNER JOIN {context} ctx ON ctx.id = ra.contextid
						INNER JOIN {course} c ON c.id = ctx.instanceid
						INNER JOIN {scorm} s ON c.id = s.course
						INNER JOIN {course_categories} cat ON cat.id = c.category
						INNER JOIN {ums_employeemaster} emp ON emp.userid = u.id
						LEFT  JOIN {ums_regions} reg ON reg.id = emp.region_id
						LEFT  JOIN {ums_state} st ON st.id  = emp.state_id
						LEFT  JOIN {ums_outlet} out1 ON out1.id = emp.outlet_id
						LEFT  JOIN {ums_designations} desig ON desig.id = emp.designation_id
						WHERE u.deleted = $emp_status AND ra.roleid = 5 AND ctx.contextlevel = 50 AND emp.designation_id IN(2,3,4,5,6,7,8,9,10,11,23,30,32,33,40,43,44,45,52,54,57,61,63,74,80,90,106,120,128,131,143,153,157,159,166,218,221,222,223,225,226,228,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,259,260,261,262,265,266,295,300,289,198,310) AND cat.id = 3 " . $filter . " " . $newfilter; //DMS + MSIL Users
            //echo $sql;exit;
            
            if ($hmi_status == "finished" || $hmi_status == "incomplete") {
                $sql = "SELECT 
					concat(u.id,'',s.id) as tempid,u.id as userid,u.username,u.phone1,u.firstname,u.lastname, emp.dol, emp.region_id, c.id as courseid,out1.o_code,out1.o_code_latest,out1.o_name,reg.r_name,st.s_code,st.s_name as statename,desig.d_name, c.fullname as coursename,s.id as scormid
					FROM {user} u
					INNER JOIN {scorm_scoes_track} sst ON sst.userid = u.id
					INNER JOIN {scorm} s ON s.id = sst.scormid
					INNER JOIN {course} c ON c.id = s.course
					INNER JOIN {ums_employeemaster} emp ON emp.userid = u.id
					LEFT  JOIN {ums_regions} reg ON reg.id = emp.region_id
					LEFT  JOIN {ums_state} st ON st.id  = emp.state_id
					LEFT  JOIN {ums_outlet} out1 ON out1.id = emp.outlet_id 
					LEFT  JOIN {ums_designations} desig ON desig.id = emp.designation_id
					WHERE u.deleted = $emp_status 
					AND emp.designation_id IN(2,3,4,5,6,7,8,9,10,11,23,30,32,33,40,43,44,45,52,54,57,61,63,74,80,90,106,120,128,131,143,153,157,159,166,218,221,222,223,225,226,228,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,259,260,261,262,265,266,300,289,198,310) " . $filter . " " . $filterscorm . " " . $newfilter; //DMS + MSIL Users
                    //echo $sql;exit;
            }
            //echo $sql; exit();
            $data = array();
            $results = $DB->get_records_sql($sql);
            foreach ($results as $key => $result) {

                /*                 * *************new 21 Oct 2019************* */
                require_once("../../../lib/completionlib.php");
                $course = new stdClass();
                $course->id = $result->courseid;
                $cinfo = new completion_info($course);
                $iscomplete = $cinfo->is_course_complete($result->userid);
                /*                 * *************eof new 21 Oct 2019************* */

                $regionstr = "";
                if ($result->region_id != '') {
                    $regionidtemp = explode(",", $result->region_id);
                    foreach ($regionidtemp as $rid) {
                        $regionname = $DB->get_field("ums_regions", "r_name", array("id" => $rid));
                        $regionstr .= $regionname . ", ";
                    }
                }

                $status = "";
                $attempt = "";
                $coursename = $result->coursename;
                $username = $result->username;
                $name = $result->firstname . " " . $result->lastname;
                $phone = $result->phone1;
                $region = $regionstr != '' ? rtrim($regionstr, ", ") : '-';
                $state = $result->s_code;
                $outletname = $result->o_name;
                $outletcode = $result->o_code_latest;
                $designation = $result->d_name;
                $courseassigndate = $this->courseassignDetails($result->userid, $result->courseid);
                $firstaccess = $this->firstaccessDetails($result->userid, $result->scormid);
                $lastaccess = $this->courseLastAccess($result->userid, $result->courseid);
                $lastaccess = $lastaccess == 0 ? '-' : $this->unixToNormalLong($lastaccess);
                $coursecompleted = $this->coursecompletedDetails($result->userid, $result->scormid);
                //echo $coursecompleted;exit;

                /*                 * ************14oct************* */

                $totalmarksarr = $DB->get_record_sql("SELECT value FROM {scorm_scoes_track} WHERE scormid = '" . $result->scormid . "' AND userid = '" . $result->userid . "' AND (element = 'cmi.core.score.max' OR element = 'cmi.score.max') order by attempt DESC LIMIT 1");
                $totalmarks = $totalmarksarr->value;

                $totalmarksscored = '-';
                $per = '-';
                $passfailstatus = '-';
                /*                 * ************eof 14oct************* */
                $status = $this->courseStatus($result->userid, $result->scormid);
                if ($status == "completed" || $status == "passed" || $iscomplete == 1) {
                    $status = "Completed";
                   
                    $scormid = $result->scormid;

                    if ($this->isLearningPathCourse($result->courseid)) {
                        $module = $DB->get_record_sql('SELECT instance as id FROM {course_modules} where course = ? order by  id desc', array($result->courseid));
                        $scormid = $module->id;
                        $view = 'https://ilearn.marutisuzuki.com/local/pagecontainer/lms/activity_report.php?userid=' . $result->userid . '&courseid=' . $result->courseid;
                        $viewlink = '<a href="' . $view . '">View Details</a>';
                    }
                    $total_attempt = $DB->get_record_sql("SELECT max(attempt) as attempt FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '" . $result->userid . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') order by sb.attempt DESC LIMIT 1");
                    $attempt = $total_attempt->attempt;

                    $totalmarksscored = $this->getMaxScore($result->userid, $result->scormid);

                    // if ($totalmarksscored != '' && $totalmarksscored != '-' && $totalmarksscored != 0) {
                    if ($totalmarksscored != '' && $totalmarksscored != '-') {

                        $percentagescored = round(($totalmarksscored * 100) / $totalmarks);
                        //$per = $percentagescored != 0 ? $percentagescored . "%" : '-';
                        $per = $percentagescored >= '' ? $percentagescored . "%" : '-';

                        $passfailstatus = $this->getPassFailStatus($result->userid, $result->scormid);
                        //echo $totalmarksscored.'//'.$per.'/'.$passfailstatus;exit;
                    }
                } else if ($status == "incomplete" || $status == "failed") {
                    //NEED TO RESTRUCTURE CODE
                    /*$total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '" . $result->userid . "' AND sb.scormid = '" . $result->scormid . "' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') AND attempt <=3  order by sb.attempt DESC LIMIT 1");*/
                    
                    $totalmarksscored = $this->getMaxScore($result->userid, $result->scormid);
                    // if ($totalmarksscored != '' && $totalmarksscored != '-' && $totalmarksscored != 0) {
                    if ($totalmarksscored != '' && $totalmarksscored != '-') {

                        $percentagescored = round(($totalmarksscored * 100) / $totalmarks);
                        // $per = $percentagescored != 0 ? $percentagescored . "%" : '-';
                        $per = $percentagescored >= '' ? $percentagescored . "%" : '-';

                        $passfailstatusarr = $DB->get_record_sql("SELECT value FROM {scorm_scoes_track} WHERE scormid = '" . $result->scormid . "' AND userid = '" . $result->userid . "' AND (element = 'cmi.core.lesson_status' OR element = 'cmi.completion_status') order by attempt DESC LIMIT 1");

                        $passfailstatus = $this->getPassFailStatus($result->userid, $result->scormid);
                    }
                    $coursecompleted = "-";
                } else {
                    $status = "Not Started";
                    $coursecompleted = "-";
                    $firstaccess = "-";
                    $lastaccess = "-";
                    $attempt = "-";
                }

                /* if($result->courseid == 338)
                  {
                  $view = 'https://ilearn.marutisuzuki.com/local/pagecontainer/lms/activity_report.php?userid='.$result->userid.'&courseid='.$result->courseid;
                  $viewlink = '<a href="'.$view.'">View Details</a>';

                  $sqlMinScormid = $DB->get_record_sql("SELECT min(id) as scormid FROM mdl_scorm WHERE course = '".$result->courseid."'");
                  $minscormid = $sqlMinScormid->scormid;

                  $sqlMaxScormid = $DB->get_record_sql("SELECT max(id) as scormid FROM mdl_scorm WHERE course = '".$result->courseid."'");
                  $maxscormid = $sqlMaxScormid->scormid;

                  $total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '".$userid."' AND sb.scormid = '".$maxscormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') ");
                  if(!empty($total_attempt))
                  {
                  $status =  $total_attempt->value;
                  if($status=='Completed' || $status=='Passed' )
                  {
                  $status = 'Completed';
                  $coursecompleted  = '-';
                  $passfailstatus = '-';
                  $totalmarks     = '-';
                  $totalmarksscored = '-';
                  $attempt = '-';
                  }
                  else
                  {
                  $status = 'Incompleted';
                  $coursecompleted  = '-';
                  $passfailstatus = '-';
                  $totalmarks     = '-';
                  $totalmarksscored = '-';
                  $attempt = '-';
                  }
                  }
                  else
                  {
                  $sql="SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$result->userid." AND sb.scormid = '".$minscormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') ";
                  $attemptdetails = $DB->get_record_sql($sql);
                  if(empty($attemptdetails->value) || $attemptdetails->value == "")
                  {
                  $status = 'Not Started';
                  $coursecompleted  = '-';
                  $passfailstatus = '-';
                  $totalmarks     = '-';
                  $totalmarksscored = '-';
                  $attempt = '-';
                  }
                  else
                  {
                  $status           = 'Incomplete';
                  $coursecompleted  = '-';
                  $passfailstatus   = '-';
                  $totalmarks       = '-';
                  $totalmarksscored = '-';
                  $attempt          = '-';
                  }
                  }

                  } */
                if ($result->courseid == 12 || $result->courseid == 804  || $result->courseid ==763 || $result->courseid ==777) {
                    $view = 'https://ilearn.marutisuzuki.com/local/pagecontainer/lms/activity_report.php?userid=' . $result->userid . '&courseid=' . $result->courseid;
                    $viewlink = '<a href="' . $view . '">View Details</a>';
                    //------------ For Prabham Course -----------------//
                    $sqlass = $DB->get_record_sql("SELECT quiz.id as quizid,
						quiz.course,
						grade_items.id,
						grade_items.grademax,
						grade_items.grademin,
						grade_items.gradepass,
						grade_items.itemmodule
						FROM mdl_quiz AS quiz 
						INNER JOIN mdl_grade_items AS grade_items 
						ON grade_items.iteminstance = quiz.id
						WHERE quiz.course= '763' AND 
						quiz.id = '24' AND 
						grade_items.itemmodule = 'quiz'");
                    $quizid = $sqlass->quizid;
                    $grademax = $sqlass->grademax;
                    $grademin = $sqlass->grademin;
                    $gradepass = $sqlass->gradepass;

                    $highestattempt = $DB->get_record_sql("SELECT max(attempt) as hattempt FROM mdl_quiz_attempts WHERE quiz = '" . $quizid . "' AND userid = '" . $result->userid . "'");
                    $attempt = $highestattempt->hattempt;
                    if (!empty($attempt)) {
                        $sqlGrade = $DB->get_record_sql("SELECT sumgrades,timefinish FROM mdl_quiz_attempts WHERE quiz = '" . $quizid . "' AND userid = '" . $result->userid . "' AND state = 'finished' AND attempt = '" . $attempt . "'");
                        $resGrade = $sqlGrade->sumgrades;
                        $resFinish = $this->unixToNormalLong($sqlGrade->timefinish);
                        if ($resGrade >= $gradepass) {
                            $state1 = 'pass';
                        } else {
                            $state1 = 'fail';
                        }
                        if ($state1 == 'pass') {
                            $status = 'Completed';
                            $coursecompleted = $resFinish;
                            $passfailstatus = 'Passed';
                            $totalmarks = $grademax;
                            $totalmarksscored = $resGrade;
                            // if ($totalmarksscored != '' && $totalmarksscored != '-' && $totalmarksscored != 0) {
                            if ($totalmarksscored != '' && $totalmarksscored != '-') {
                                $percentagescored = round(($totalmarksscored * 100) / $totalmarks);
                                // $per = $percentagescored != 0 ? $percentagescored . "%" : '-';
                                $per = $percentagescored >= '' ? $percentagescored . "%" : '-';
                            }
                        }
                        if ($state1 == 'fail') {
                            $status = 'Incomplete';
                            $coursecompleted = '-';
                            $passfailstatus = '-';
                            $totalmarks = '-';
                            $totalmarksscored = '-';
                            $attempt = '-';
                        }
                       // echo "1";exit;
                    } else {
                        $sql = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= " . $result->userid . " AND sb.scormid = '10' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')  order by sb.attempt DESC LIMIT 1";
                        $attemptdetails = $DB->get_record_sql($sql);
                        if (empty($attemptdetails->value) || $attemptdetails->value == "") {
                            $status = 'Not Started';
                            $coursecompleted = '-';
                            $passfailstatus = '-';
                            $totalmarks = '-';
                            $totalmarksscored = '-';
                            $attempt = '-';
                        } else {
                            $status = 'Incomplete';
                            $coursecompleted = '-';
                            $passfailstatus = '-';
                            $totalmarks = '-';
                            $totalmarksscored = '-';
                            $attempt = '-';
                        }
                       // echo "2";exit;
                    }
                    //echo $coursecompleted;exit;
                    $courseModules = $this->classObj->getActivities($result->courseid);
                    //print_r($courseModules);exit;
                    $LYLIST=[];
                    $totalmarksscored=0;
                    $totalmarks=0;
                    foreach($courseModules as $key => $module){
                        $details =$this->classObj->getActivityInfo($module->instance,$module->module, $result->userid);
                        foreach($details as $key => $details){
                            $LYLIST[$details->status]=$details->status;
                            if($details->rawgrade!="-"){
                               $totalmarksscored=$details->rawgrade;
                           }
                           if($details->status=="Incomplete"){
                               $totalmarksscored=0;
                           }
                           $totalmarks=$details->grademax;
                       }

                        // $sql001 = "SELECT * FROM mdl_scorm_scoes_track WHERE scormid='".$module->instance."' and userid='".$result->userid."' and (element ='cmi.core.lesson_status' OR element = 'cmi.completion_status')";
                       $sql001 = "SELECT * FROM mdl_scorm_scoes_track WHERE scormid='".$module->instance."' and userid='".$result->userid."' and (element ='cmi.core.lesson_status' OR element = 'cmi.completion_status') order by attempt desc limit 1";
                     

                        $get_last_date = $DB->get_record_sql($sql001);
                        //print_r($get_last_date->value);exit;
                        if($get_last_date->value == 'passed' || $get_last_date->value == 'completed')
                        {
                            $coursecompleted = $this->unixToNormalLong($get_last_date->timemodified);
                            //echo $coursecompleted.'/';
                        }
                        else
                        {
                            $coursecompleted = '-';
                        }

                   }
                   //echo $coursecompleted;exit;
                   // if ($totalmarksscored != '' && $totalmarksscored != '-' && $totalmarksscored != 0) {
                   if ($totalmarksscored != '' && $totalmarksscored != '-') {
                    $percentagescored = round(($totalmarksscored * 100) / $totalmarks);
                    // $per = $percentagescored != 0 ? $percentagescored . "%" : '-';
                    $per = $percentagescored >= '' ? $percentagescored . "%" : '-';
                }
                if(@$LYLIST['Completed'] && @$LYLIST['Incomplete'] && @$LYLIST['Not Started']){
                    $status="Incomplete";
                }elseif(@$LYLIST['Completed'] && @$LYLIST['Incomplete']=="" && @$LYLIST['Not Started']==""){
                    $status="Completed";
                }elseif(@$LYLIST['Completed']=="" && @$LYLIST['Incomplete']=="" && @$LYLIST['Not Started']==""){
                    $status="Not Started";
                }elseif(@$LYLIST['Completed'] && @$LYLIST['Incomplete']=="" && @$LYLIST['Not Started']){
                    $status="Incomplete";
                }elseif(@$LYLIST['Completed']=="" && @$LYLIST['Incomplete'] && @$LYLIST['Not Started']){
                    $status="Incomplete";
                }elseif(@$LYLIST['Completed'] && @$LYLIST['Incomplete'] && @$LYLIST['Not Started']==""){
                    $status="Incomplete";
                }elseif(@$LYLIST['Completed']=="" && @$LYLIST['Incomplete']=="" && @$LYLIST['Not Started']){
                    $status="Not Started";
                }
                
                unset($LYLIST);
                    //----- End of Prabham Course ---------//
                } else if ($this->isLearningPathCourse($result->courseid)){
                    $scormid = '';
                    $view = 'https://ilearn.marutisuzuki.com/local/pagecontainer/lms/activity_report.php?userid=' . $result->userid . '&courseid=' . $result->courseid;
                    $viewlink = '<a href="' . $view . '">View Details</a>';
                } else {
                    $viewlink = '-';
                }

                if($this->isLearningPathCourse($result->courseid)){
                }else{
                 $total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '".$result->userid."' AND sb.scormid = '".$result->scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')");
                 $i = 1;
                 $fetch_marks_max = $DB->get_record_sql("SELECT sb.value FROM mdl_scorm_scoes_track as sb WHERE userid = '".$result->id."' AND scormid = '".$result->scormid."' AND (sb.element = 'cmi.core.score.raw') ORDER BY sb.attempt DESC LIMIT 1");
                 $passedAttempt = 1;
                 foreach($total_attempt as $val){
                    if(($val->value == 'completed' OR $val->value == 'passed') && $fetch_marks_max->value >=0  && $totalmarksscored <= 80){
                      $status = "Completed";
                      $passedAttempt = $val->attempt;
                      break;
                    }

                    if (($val->value == 'completed' OR $val->value == 'passed') && $totalmarksscored >= 80){
                        $status = "Completed";
                        $passedAttempt = $val->attempt;
                        break;
                    }else if ($val->value == 'failed' OR $val->value == 'incomplete'){

                        if($val->attempt >= 3)
                        {
                            $marks3 = $DB->get_record_sql("SELECT * FROM maruti_prod.mdl_scorm_scoes_track where scormid='".$result->scormid."' and userid='".$result->userid."' and attempt=3 and element = 'cmi.core.score.raw'");
                            if(empty($marks3))
                            {
                                $status = "Incomplete";
                                break;
                            }
                            elseif (($val->attempt >= 3) && ($totalmarksscored == '' || $totalmarksscored == NULL))
                            {
                                $status = "Incomplete";
                                break;
                            }
                            elseif (($val->attempt >= 3) && ($totalmarksscored >= 0 && $totalmarksscored < 80)) 
                            {
                               $status = "Completed";
                                break;
                            }else{
                                $status = "Incomplete";
                            }
                        }

                        // if(($val->attempt >= 3) && ($totalmarksscored == '' || $totalmarksscored == NULL)){
                        //     $status = "Incomplete";
                        //     break;
                        //     //new condition for >=3 and score blank
                        // }
                        // if(($val->attempt >= 3) && ($totalmarksscored >= 0 && $totalmarksscored < 80)){
                        //     $status = "Completed";
                        //     break;
                        // }
                        // else {
                        //     $status = "Incomplete";
                        // }
                    }else if(($val->value == 'completed' OR $val->value == 'passed') && ($val->attempt >= 3) && ($totalmarksscored >= 0 && $totalmarksscored < 80)){
                        $status = "Completed";
                    } else {
                        $status = "Incomplete";
                    }
                    $passedAttempt = $i;
                    $i++;
                }
            }
               // echo $status.'/'.$totalmarksscored;exit;

                $data[$count]['Sr'] = $count + intval(1);
                $data[$count]['CourseName'] = $coursename;
                $data[$count]['EmpName'] = $name;
                $data[$count]['Empcode'] = $username;
                $data[$count]['EmpPhone'] = $phone;
                $data[$count]['EmpDol'] = ($result->dol != '' && $result->dol != '0000-00-00') ? date("d/m/Y", strtotime($result->dol)) : '-';
                $data[$count]['Region'] = $region != '' ? $region : '-';
                $data[$count]['State'] = $state != '' ? $state : '-';
                $data[$count]['OutletName'] = $outletname != '' ? $outletname : '-';
                $data[$count]['Outlet'] = $outletcode != '' ? $outletcode : '-';
                $data[$count]['Designation'] = $designation;
                $data[$count]['CourseAssignDate'] = $courseassigndate;
                $data[$count]['CourseFirstAccess'] = $firstaccess;
                $data[$count]['CourseLastAccess'] = $lastaccess;
                $data[$count]['status'] = ucfirst($status);

                // if(ucfirst($status)!="Completed"){
                //     $totalmarksscored=0;
                //     $per=0;
                // }

                //echo $status.'/'.$coursecompleted;exit;
                if (ucfirst($status)!= "Completed") {
                            //$status = 'Not Started';
                            $coursecompleted = '-';
                            $passfailstatus = '-';
                            $totalmarks = '';
                            $totalmarksscored = '';
                            $attempt = '-';
                            $per = '';
                           // $coursecompleted = '-';
                }else{
                	if($totalmarksscored >= 80)
	                {
	                    $passfailstatus = 'Passed';
	                }else{
	                    $passfailstatus = 'Fail';
	                }

	                if($totalmarksscored == '-' || $totalmarksscored == '')
	                {
	                    $passfailstatus = '-';
	                }

                }

                //echo $totalmarksscored.'/'.$passfailstatus;exit;

                // if($totalmarksscored >= 80)
                // {
                //     $passfailstatus = 'Passed';
                // }else{
                //     $passfailstatus = 'Fail';
                // }

                // if($totalmarksscored == '-' || empty($totalmarksscored))
                // {
                //     $passfailstatus = '-';
                // }
                $data[$count]['CourseCompletionDate'] = $coursecompleted;
                $data[$count]['TotalMarks'] = $totalmarks != '' ? (int) $totalmarks : '-';
                // $data[$count]['TotalMarksScored'] = ($totalmarksscored != '' && $totalmarksscored != 0) ? round($totalmarksscored) : '-';
                $data[$count]['TotalMarksScored'] = ($totalmarksscored != '') ? round($totalmarksscored) : '-';
                $data[$count]['PercentageScored'] = $totalmarksscored!=""?$per:'0';
                if($data[$count]['status']=="Incomplete" || $data[$count]['status']=="Not Started"){
                     $data[$count]['PercentageScored'] = "-";
                }
                $data[$count]['PassFail'] = $passfailstatus != '' ? ucfirst($passfailstatus) : '-';
                $data[$count]['view'] = $viewlink;

                $count++;
            }
            
           //echo "<pre>"; print_r($data); die;
            echo json_encode($data);
        } else {

            $data = array();
            $mysql = "SELECT 
						concat(u.id,'',c.id) as tempid,u.id as userid,u.username,u.phone1,u.firstname,u.lastname, emp.dol, emp.region_id, c.id as courseid,out1.o_code,out1.o_code_latest,out1.o_name,reg.r_name,st.s_code,s.id as scormid,desig.d_name, c.fullname as coursename,ra.timemodified as courseassigndate
						FROM {user} u
						INNER JOIN {role_assignments} ra ON ra.userid = u.id
						INNER JOIN {context} ctx ON ctx.id = ra.contextid
						INNER JOIN {course} c ON c.id = ctx.instanceid
						INNER JOIN {scorm} s ON c.id = s.course
						INNER JOIN {course_categories} cat ON cat.id = c.category
						INNER JOIN {ums_employeemaster} emp ON emp.userid = u.id
						LEFT  JOIN {ums_regions} reg ON reg.id = emp.region_id
						LEFT  JOIN {ums_state} st ON st.id  = emp.state_id
						LEFT  JOIN {ums_outlet} out1 ON out1.id = emp.outlet_id
						LEFT  JOIN {ums_designations} desig ON desig.id = emp.designation_id
						WHERE u.deleted = $emp_status AND ra.roleid = 5 AND ctx.contextlevel = 50 AND emp.designation_id IN(2,3,4,5,6,7,8,9,10,11,23,30,32,33,40,43,44,45,52,54,57,61,63,74,80,90,106,120,128,131,143,153,157,159,166,218,221,222,223,225,226,228,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,259,260,261,262,265,266,300,310) AND cat.id = 3 " . $filter . " " . $newfilter; //DMS + MSIL Users

            $results = $DB->get_records_sql($mysql);
            $notstartedcount = 0;
            foreach ($results as $key => $result) {
                $sql = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= " . $result->userid . " AND sb.scormid = " . $result->scormid . " AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')  order by sb.attempt DESC LIMIT 1";
                $attemptdetails = $DB->get_record_sql($sql);
                if (empty($attemptdetails->value) || $attemptdetails->value == "") {

                    $regionstr = "";
                    if ($result->region_id != '') {
                        $regionidtemp = explode(",", $result->region_id);
                        foreach ($regionidtemp as $rid) {
                            $regionname = $DB->get_field("ums_regions", "r_name", array("id" => $rid));
                            $regionstr .= $regionname . ", ";
                        }
                    }

                    $userid = $result->userid;
                    $scormid = $result->scormid;
                    $coursename = $result->coursename;
                    $username = $result->username;
                    $name = $result->firstname . " " . $result->lastname;
                    $phone = $result->phone1;
                    $region = $regionstr != '' ? rtrim($regionstr, ", ") : '-';
                    $state = $result->s_code;
                    $outletname = $result->o_name;
                    $outletcode = $result->o_code_latest;
                    $designation = $result->d_name;
                    $firstaccess = $this->firstaccessDetails($userid, $scormid);
                    $courseassigndate = date('d-m-Y', $result->courseassigndate);
                    $totalmarksarr = $DB->get_record_sql("SELECT value FROM {scorm_scoes_track} WHERE scormid = '" . $result->scormid . "' AND userid = '" . $result->userid . "' AND (element = 'cmi.core.score.max' OR element = 'cmi.score.max')  order by attempt DESC LIMIT 1");
                    $totalmarks = $totalmarksarr->value;
                    if ($result->courseid == 12 || $result->courseid == 338) {
                        $view = 'https://ilearn.marutisuzuki.com/local/pagecontainer/lms/activity_report.php?userid=' . $result->userid . '&courseid=' . $result->courseid;
                        $viewlink = '<a href="' . $view . '">View Details</a>';
                    } else {
                        $viewlink = '';
                    }

                    $data[$count]['Sr'] = $count + intval(1);
                    $data[$count]['CourseName'] = $coursename;
                    $data[$count]['EmpName'] = $name;
                    $data[$count]['Empcode'] = $username;
                    $data[$count]['EmpPhone'] = $phone;
                    $data[$count]['EmpDol'] = ($result->dol != '' && $result->dol != '0000-00-00') ? date("d/m/Y", strtotime($result->dol)) : '-';
                    $data[$count]['Region'] = $region != '' ? $region : '-';
                    $data[$count]['State'] = $state != '' ? $state : '-';
                    $data[$count]['OutletName'] = $outletname != '' ? $outletname : '-';
                    $data[$count]['Outlet'] = $outletcode != '' ? $outletcode : '-';
                    $data[$count]['Designation'] = $designation;
                    $data[$count]['CourseAssignDate'] = $courseassigndate;
                    $data[$count]['CourseFirstAccess'] = "-";
                    $firstaccess;
                    $data[$count]['CourseLastAccess'] = "-";
                    $data[$count]['CourseCompletionDate'] = "-";
                    $data[$count]['status'] = "Not Started";

                    $data[$count]['TotalMarks'] = $totalmarks != '' ? (int) $totalmarks : '-';
                    $data[$count]['TotalMarksScored'] = '-';
                    $data[$count]['PercentageScored'] = '-';
                    $data[$count]['PassFail'] = '-';
                    $data[$count]['view'] = $viewlink;
                    $count++;
                    $notstartedcount++;
                }
            }
            echo json_encode($data);
        }
    }

    function unixToNormalLong($timestamp) {
        if ($timestamp == 0 && $timestamp == NULL) {
            return '-';
        } else {
            return gmdate("d/m/Y", $timestamp + ((3500) * 5.5));
        }
    }

    function courseLastAccess($userid, $courseid) {
        global $DB;

        $sql = "SELECT * FROM mdl_user_lastaccess where userid=$userid and courseid=$courseid";

        $result = $DB->get_records_sql($sql, array());

        $lastaccess = "0";

        foreach ($result as $rows) {
            if (isset($rows->timeaccess)) {

                $lastaccess = $rows->timeaccess;
            }
        }
        return $lastaccess;
    }

    function firstaccessDetails($userid, $scormid) {
        global $DB;

        $sql = "SELECT min(sb.timemodified) as firstaccess FROM  {scorm_scoes_track} as sb WHERE sb.userid= " . $userid . " AND sb.scormid = " . $scormid . " ";
        $getCourse = $DB->get_record_sql('SELECT course FROM {scorm} where id = ?', array($scormid));
        if ($this->isLearningPathCourse($getCourse->course)) {
            $module = $DB->get_record_sql('SELECT instance as id FROM {course_modules} where course = ? order by  id ASC', array($getCourse->course));
            $sql = "SELECT min(sb.timemodified) as firstaccess FROM  {scorm_scoes_track} as sb WHERE sb.userid= " . $userid . " AND sb.scormid = " . $module->id . " ";
            $result = $DB->get_record_sql($sql, array());
            if (empty($result->firstaccess)) {
                $sql = "SELECT timeaccess as firstaccess FROM mdl_user_lastaccess where userid=" . $userid . " and courseid=" . $getCourse->course . "";
            }
        }
        $result = $DB->get_record_sql($sql, array());
        if (!empty($result->firstaccess)) {
            $firstaccess = date('d/m/Y', $result->firstaccess);
        } else {
            $firstaccess = "-";
        }
        return $firstaccess;
    }

    function isLearningPathCourse($courseid) {
        global $DB;
        $courseContext = context_course::instance($courseid);
        $checkTag = $DB->get_record_sql('select t.id from {tag} t JOIN {tag_instance} ti ON t.id = ti.tagid WHERE ti.itemtype = ? AND ti.contextid = ? AND t.name =?', array('course', $courseContext->id, 'learning_path'));

        if (!empty($checkTag)) {
            return true;
        } else {
            return false;
        }
    }

    function courseStatus($userid, $scormid) {
        global $DB;
        $sql = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= " . $userid . " AND sb.scormid = " . $scormid . " AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')";
        $getCourse = $DB->get_record_sql('SELECT course FROM {scorm} where id = ?', array($scormid));

        if ($this->isLearningPathCourse($getCourse->course)) {
            $module = $DB->get_record_sql('SELECT instance as id FROM {course_modules} where course = ? order by  id desc', array($getCourse->course));
            $sql = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= " . $userid . " AND sb.scormid = " . $module->id . " AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') order by sb.attempt DESC limit 1";
        }
        $result = $DB->get_record_sql($sql, array());

        if (empty($result->value) || $result->value == "") {
            $status = "-";
            if ($this->isLearningPathCourse($getCourse->course)) {
                $sql = "SELECT * FROM mdl_user_lastaccess where userid=" . $userid . " and courseid=" . $getCourse->course . "";
                $cStatus = $DB->get_record_sql($sql);
                if (!empty($cStatus)) {
                    $status = 'incomplete';
                }
            }
        } else {
            $total_attempt = $DB->get_records_sql($sql, array());
            $total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '".$userid."' AND sb.scormid = '".$scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')");
            $status = $result->value;
            foreach($total_attempt as $val){
                if($val->value == 'completed' || $val->value == 'passed'){
                  $status = "completed";
                  break;
              }else{
                  $status = "incomplete";
              }

              if($val->attempt >=3){
                  $status = "completed";
              }
              $i++;
          }
      }
        return $status;
    }

    function coursecompletedDetails($userid, $scormid) {
        global $DB;

        $sql = "SELECT sb.timemodified as lastaccess FROM  {scorm_scoes_track} as sb WHERE sb.userid= " . $userid . " AND sb.scormid = " . $scormid . " AND (sb.element = 'cmi.core.lesson_status' || sb.element = 'cmi.completion_status') AND (sb.value = 'passed' || sb.value = 'completed' || sb.value='failed') order by sb.id desc limit 1 ";

        $result = $DB->get_record_sql($sql, array());
        if (!empty($result)) {
            $coursecompleted = date('d/m/Y', $result->lastaccess);
        } else {
            $coursecompleted = "-";
        }
        return $coursecompleted;
    }

    function courseassignDetails($userid, $courseid) {
        global $DB;
        $sql = "SELECT timemodified FROM {role_assignments} ra JOIN {context} ctx ON ctx.id = ra.contextid WHERE ra.userid= " . $userid . " AND ctx.instanceid = " . $courseid . " AND ctx.contextlevel = 50 AND roleid = 5";
        $result = $DB->get_record_sql($sql, array());

        if (!empty($result)) {
            $courseassignDate = date('d/m/Y', $result->timemodified);
        } else {
            $courseassignDate = "-";
        }
        return $courseassignDate;
    }

    function regionlist($pageType = "") {//this func. is specifically changed for 'Course Summary Report' and 'Course Individual Report'
        global $DB, $USER;
        $filter = '';
        $flag = false;

        if ($USER->id != 2 || $USER->id != 4) { //Apart from Admin user apply cnd below to all other users(FSDM)
            $designationid = $this->getDesignation($USER->id);

            if (count($designationid) > 0 && $designationid['filterby'] != '') {
                if ($designationid['filterby'] == 'region') {
                    $region_id = $designationid['filterid'];
                    $filter = " AND id IN ($region_id)";
                    $flag = true;
                }
            }
        }


        //------------ code by yogita on date 25-06-2020 ----//

        $result = $DB->get_records_sql('SELECT * FROM {ums_regions} WHERE deleted = 0 ' . $filter . ' order by r_name ASC', array());

        $list = ''; //if FSDM / Course Indi Report then dont show 'ALL' option
        if ($flag == false) {//if admin login and page is Indi. report then dont show 'ALL' option as this func. is common on summary and indi. report. Show All option only for summary report.
            if ($pageType == 'summary') {
                $list = "<option value='0' selected>All</option>";
            }
        }

        foreach ($result as $rows) {
            $rid = $rows->id;
            $rname = $rows->r_name;
            $list .= "<option value=" . $rid . ">" . ucwords($rname) . "</option>";
        }
        return $list;
    }

    function chaneellist($selected = "") {
        global $DB;
        $result = $DB->get_records_sql('SELECT * FROM {ums_channels} WHERE deleted = 0 order by c_abbr_name ASC', array());
        $list = "";
        $selected = "";
        foreach ($result as $rows) {
            $chid = $rows->id;
            $c_abbr_name = $rows->c_abbr_name;
            //if($rows->id==$selected) $val='selected';	
            $list .= "<option value=" . $chid . ">" . ucwords($c_abbr_name) . "</option>";
        }
        return $list;
    }

    function outletgrouplist($selected = "") {
        global $DB;
        $result = $DB->get_records_sql('SELECT id,og_name,og_code,deleted FROM {ums_outlet_group} where deleted =0 ORDER BY og_name ASC', array());
        $list = "";
        $selected = "";
        foreach ($result as $rows) {
            $chid = $rows->id;
            $og_name = $rows->og_name;
            //if($rows->id==$selected) $val='selected';	
            $list .= "<option value=" . $chid . ">" . ucwords($og_name) . "</option>";
        }
        return $list;
    }

    public function getDesignationId($currUID) {
        global $DB;
        $cnd = '';
        $this->response = array();
        if ($currUID != '' && $currUID > 0) {
            $sqlData = $DB->get_record_sql("SELECT designation_id FROM mdl_ums_employeemaster WHERE userid = '" . $currUID . "'");

            if (count($sqlData) > 0) {
                $desigID = $sqlData->designation_id;
                $this->response = $desigID;
            }
        }
        return $this->response;
    }

    function getDesignationRegions($currUID) {
        global $DB;
        $cnd = '';
        $this->response = array();
        if ($currUID != '' && $currUID > 0) {
            $sqlData = $DB->get_record_sql("SELECT designation_id FROM mdl_ums_employeemaster WHERE userid = '" . $currUID . "'");

            if (count($sqlData) > 0) {
                $desigID = $sqlData->designation_id;
                if ($desigID == 11) {
                    //FSDM - region
                    $getData = $DB->get_record_sql("SELECT region_id FROM mdl_ums_employeemaster WHERE userid = '" . $currUID . "'");
                    $this->response['regions'] = $getData->region_id != '' ? $getData->region_id : 0;
                }
            }
        }
        return $this->response;
    }

    public function checkDealerLogin() {

        global $DB, $USER;

        $isDealerLogin = false;

        if ($DB->record_exists("ums_user_dealer_mapping", array("user_id" => $USER->id, "deleted" => "0"))) {

            $dealer_login = $DB->get_field("ums_employeemaster", "dealer_login", array("userid" => $USER->id));

            if ($dealer_login == "1") {

                $isDealerLogin = true;
            }
        }

        return $isDealerLogin;
    }

    function course_list_Backup($selected = "") {
        global $DB, $USER;
        $filter = "";
        $isDealerLogin = $this->checkDealerLogin();

        /*
          $sqlData = $DB->get_record_sql("SELECT designation_id FROM mdl_ums_employeemaster WHERE userid = '".$USER->id."'");
          $designation_id = $sqlData->designation_id;
          if($designation_id == 237)
          {
          $result = $DB->get_records_sql('SELECT id,fullname FROM {course} WHERE category = '.$categoryId.' AND id IN (305,309,349,356,358,359,360,361) AND visible = 1 ORDER BY fullname ASC', array());
          }
          else
          {
          $result = $DB->get_records_sql('SELECT id,fullname FROM {course} WHERE category = '.$categoryId.' AND visible = 1 ORDER BY fullname ASC', array());
          }
         */




        $result = $DB->get_records_sql('SELECT id,fullname FROM {course} WHERE visible = 1 AND id NOT IN(' . $this->salesforce_courses . ') AND category = 3 ' . $filter . ' ORDER BY fullname ASC', array());

        /* $result = $DB->get_records_sql('SELECT id,fullname FROM {course} WHERE visible = 1 AND id NOT IN('.$this->salesforce_courses.') AND category = 3 ORDER BY fullname ASC', array()); */

        /* $result = $DB->get_records_sql('SELECT a.id,a.fullname FROM {course} a 
          left join mdl_ums_course_archive as um on (um.course_id = a.id)
          WHERE a.visible = 1 AND a.id NOT IN('.$this->salesforce_courses.') AND a.category = 3
          AND um.is_archive = 0 ORDER BY a.fullname ASC', array()); */

        /* $result = $DB->get_records_sql('SELECT a.id,a.fullname FROM {course} a 
          left join mdl_ums_course_archive as um on (um.course_id = a.id)
          WHERE a.id NOT IN('.$this->salesforce_courses.') AND a.category = 3
          AND um.is_archive = 0 ORDER BY a.fullname ASC', array()); */

        $list = "";
        $selected = "";
        foreach ($result as $rows) {
            $cid = $rows->id;
            $coursename = $rows->fullname;
            //if($rows->id==$selected) $val='selected';	
            $list .= "<option value=" . $cid . ">" . ucwords($coursename) . "</option>";
        }
        return $list;
    }

    function course_list($selected = "") {
        global $DB, $USER;
        $filter = "";
        $isDealerLogin = $this->checkDealerLogin();

        /*
          $sqlData = $DB->get_record_sql("SELECT designation_id FROM mdl_ums_employeemaster WHERE userid = '".$USER->id."'");
          $designation_id = $sqlData->designation_id;
          if($designation_id == 237)
          {
          $result = $DB->get_records_sql('SELECT id,fullname FROM {course} WHERE category = '.$categoryId.' AND id IN (305,309,349,356,358,359,360,361) AND visible = 1 ORDER BY fullname ASC', array());
          }
          else
          {
          $result = $DB->get_records_sql('SELECT id,fullname FROM {course} WHERE category = '.$categoryId.' AND visible = 1 ORDER BY fullname ASC', array());
          }
         */


        $designationId = $this->getDesignationId($this->userid);

        if ($designationId == 11) { // fsdm
            $desigRegions = $this->getDesignationRegions($this->userid);

            if (count($desigRegions) > 0 && $desigRegions['regions'] != '') {

                $region_id = $desigRegions['regions'];
                $filter = " AND e.region_id IN($region_id)";

                $allHideCourseStr = "";

                $hideCourseList = $DB->get_records_sql("
							SELECT e.hide_course_list
							FROM mdl_ums_employeemaster e							
							WHERE e.hide_course_list <> ''
							");

                foreach ($hideCourseList as $hideCourses) {
                    $allHideCourseStr .= $hideCourses->hide_course_list . ",";
                }

                $allHideCourseStr = rtrim($allHideCourseStr, ",");

                $allHideCourseStr = $this->salesforce_courses . ',' . $allHideCourseStr;

                $filter .= " AND c.id NOT IN(" . $allHideCourseStr . ")";

                $sql = "SELECT c.id,c.category,c.fullname,c.shortname 
					from mdl_course c
					left join mdl_enrol en on en.courseid = c.id
					left join mdl_user_enrolments ue on ue.enrolid = en.id
					left join mdl_ums_employeemaster e ON e.userid = ue.userid
					WHERE c.visible = 1
					AND c.category = 3 
					
					$filter
					ORDER BY c.fullname ASC";

                $result = $DB->get_records_sql($sql, array());
            }
        }
        /* else if ($designationId == 10) {

          $allHideCourseStr = "";

          $hideCourseList = $DB->get_records_sql("
          SELECT e.hide_course_list
          FROM mdl_ums_employeemaster e
          WHERE e.hide_course_list <> ''
          ");

          foreach ($hideCourseList as $hideCourses){
          $allHideCourseStr .= $hideCourses->hide_course_list. ",";
          }

          $allHideCourseStr = rtrim($allHideCourseStr, ",");

          $allHideCourseStr = $this->salesforce_courses.','.$allHideCourseStr;

          $filter .= " AND c.id NOT IN(".$allHideCourseStr.")";

          $result = $DB->get_records_sql('SELECT id,fullname FROM {course} WHERE visible = 1 AND id NOT IN('.$allHideCourseStr.') AND category = 3 ORDER BY fullname ASC', array());

          } */ else if ($isDealerLogin === true) {

            $outletId = $DB->get_field("ums_user_dealer_mapping", "outlet_id", array("user_id" => $USER->id));

            // get outlet group
            $getOutletGroup = $DB->get_record_sql("SELECT DISTINCT(og.og_name),og.id, o.o_name, o_code_latest
				FROM mdl_ums_employeemaster e
				INNER JOIN mdl_ums_outlet o on o.id = e.outlet_id
				LEFT JOIN mdl_ums_outlet_group og ON og.id = o.outlet_group_id
				WHERE e.userid = $USER->id
				ORDER BY og.og_name ASC
				", array());

            /* Filter hidden courses */

            $allHideCourseStr = "";

            $hideCourseList = $DB->get_records_sql("
					SELECT e.id, e.dealer_hide_course_list
					FROM mdl_ums_employeemaster e							
					WHERE e.dealer_hide_course_list <> '' OR e.dealer_hide_course_list IS NOT NULL
					");
            if (count($hideCourseList) > 0) {

                foreach ($hideCourseList as $hideCourses) {

                    if (!empty($hideCourses->dealer_hide_course_list) ||
                            $hideCourses->dealer_hide_course_list != ""
                    ) {

                        $allHideCourseStr .= $hideCourses->dealer_hide_course_list . ",";
                    }
                }

                $allHideCourseStr = rtrim($allHideCourseStr, ",");

                $allHideCourseStr = $this->salesforce_courses . ',' . $allHideCourseStr;
                $allHideCourseStr = rtrim($allHideCourseStr, ",");

                $filter = " AND og.og_name = '$getOutletGroup->og_name'";

                if (!empty($allHideCourseStr)) {

                    $filter .= " AND c.id NOT IN(" . $allHideCourseStr . ")";
                }
            }

            if (!empty($outletId)) {
                $filter .= " AND e.outlet_id IN ($outletId)";
            }

            $sql = "SELECT DISTINCT c.id,c.category,c.fullname,c.shortname 
					from mdl_course c
					left join mdl_enrol en on en.courseid = c.id
					left join mdl_user_enrolments ue on ue.enrolid = en.id
					left join mdl_ums_employeemaster e ON e.userid = ue.userid

					left join mdl_ums_user_dealer_mapping udm ON e.code = udm.mspin
					LEFT JOIN mdl_ums_outlet o ON o.id = e.outlet_id
					LEFT JOIN mdl_ums_regions r ON r.id = o.region_id
					LEFT JOIN mdl_ums_outlet_group AS og ON o.outlet_group_id = og.id					
					WHERE c.visible = 1
					AND c.category = 3		
					$filter
					ORDER BY c.fullname ASC";
            // echo $sql;exit;
            $result = $DB->get_records_sql($sql, array());
        } else {

            $result = $DB->get_records_sql('SELECT id,fullname FROM {course} WHERE visible = 1 AND id NOT IN(' . $this->salesforce_courses . ') AND category = 3 ' . $filter . ' ORDER BY fullname ASC', array());
        }


        /* $result = $DB->get_records_sql('SELECT id,fullname FROM {course} WHERE visible = 1 AND id NOT IN('.$this->salesforce_courses.') AND category = 3 ORDER BY fullname ASC', array()); */

        /* $result = $DB->get_records_sql('SELECT a.id,a.fullname FROM {course} a 
          left join mdl_ums_course_archive as um on (um.course_id = a.id)
          WHERE a.visible = 1 AND a.id NOT IN('.$this->salesforce_courses.') AND a.category = 3
          AND um.is_archive = 0 ORDER BY a.fullname ASC', array()); */

        /* $result = $DB->get_records_sql('SELECT a.id,a.fullname FROM {course} a 
          left join mdl_ums_course_archive as um on (um.course_id = a.id)
          WHERE a.id NOT IN('.$this->salesforce_courses.') AND a.category = 3
          AND um.is_archive = 0 ORDER BY a.fullname ASC', array()); */

        $list = "";
        $selected = "";
        foreach ($result as $rows) {
            $cid = $rows->id;
            $coursename = $rows->fullname;
            //if($rows->id==$selected) $val='selected';	
            $list .= "<option value=" . $cid . ">" . ucwords($coursename) . "</option>";
        }
        return $list;
    }

    function survey_list($selected = "") {
        global $DB, $USER;
        $categoryId = 11;
        $sqlData = $DB->get_record_sql("SELECT designation_id FROM mdl_ums_employeemaster WHERE userid = '" . $USER->id . "'");
        $designation_id = $sqlData->designation_id;
        if ($designation_id == 237) {
            $result = $DB->get_records_sql('SELECT id,fullname FROM {course} WHERE category = ' . $categoryId . ' AND id IN (305,309,349,356,358,359,360,361) AND visible = 1 ORDER BY fullname ASC', array());
        } else {
            $result = $DB->get_records_sql('SELECT id,fullname FROM {course} WHERE category = ' . $categoryId . ' AND visible = 1 ORDER BY fullname ASC', array());
        }
        $list = "";
        $selected = "";
        foreach ($result as $rows) {
            $cid = $rows->id;
            $coursename = $rows->fullname;
            //if($rows->id==$selected) $val='selected';	
            $list .= "<option value=" . $cid . ">" . ucwords($coursename) . "</option>";
        }
        return $list;
    }

    function getDesignation($currUID) {
        global $DB, $USER;

        $dealerDesingationArray = [3, 5, 6, 8, 9, 30, 45, 63, 218, 295];

        $cnd = '';
        $this->response = array();
        if ($currUID != '' && $currUID > 0) {
            $sqlData = $DB->get_record_sql("SELECT designation_id FROM mdl_ums_employeemaster WHERE userid = '" . $currUID . "'");

            if (count($sqlData) > 0) {
                $desigID = $sqlData->designation_id;
                if ($desigID == 10) {//HO(Head Office) - channel
                    $getData = $DB->get_record_sql("SELECT channels_id FROM mdl_ums_employeemaster WHERE userid = '" . $currUID . "'");
                    if (count($getData) > 0) {
                        $this->response['filterby'] = "channel";
                        $this->response['filterid'] = $getData->channels_id;
                    }
                } else if ($desigID == 11 || $desigID == 237) {//FSDM - region & MSIL-DMS
                    $getData = $DB->get_record_sql("SELECT region_id FROM mdl_ums_employeemaster WHERE userid = '" . $currUID . "'");
                    $this->response['filterby'] = "region";
                    $this->response['filterid'] = $getData->region_id != '' ? $getData->region_id : 0;
                } else if ($DB->record_exists("ums_user_dealer_mapping", array("user_id" => $USER->id, "deleted" => "0"))) {

                    $dealer_login = $DB->get_field("ums_employeemaster", "dealer_login", array("userid" => $USER->id));

                    if ($dealer_login == "1") {

                        $tempOutletId = $DB->get_field("ums_user_dealer_mapping", "outlet_id", array("user_id" => $USER->id));

                        $getData = $DB->get_records_sql("SELECT id, region_id FROM mdl_ums_employeemaster WHERE outlet_id IN ($tempOutletId)");

                        $tempOutletId = explode(",", $tempOutletId);
                        $oCodeLatest = "";
                        foreach ($tempOutletId as $outletId) {
                            $tempOCodeLatest = $DB->get_field("ums_outlet", "o_code_latest", array("id" => $outletId));

                            $oCodeLatest .= "'" . $tempOCodeLatest . "',";
                        }

                        $oCodeLatest = rtrim($oCodeLatest, ",");

                        $regionArray = [];
                        foreach ($getData as $data) {
                            $regionArray[] = $data->region_id;
                        }

                        $regionId = implode(",", array_unique($regionArray));
                        $this->response['filterby'] = "region";
                        $this->response['filterid'] = $regionId != '' ? $regionId : 0;
                        /* $this->response['filterby'] = "dm_outlet";
                          $this->response['filterid'] = $oCodeLatest; */
                    }



                    /* $qry = "SELECT outlet_id FROM mdl_ums_user_dealer_mapping WHERE user_id = '".$currUID."' AND deleted=0";

                      $getData = $DB->get_records_sql($qry);

                      if(count($getData) > 0){
                      $outletStr = '';
                      foreach($getData as $res){
                      $outletStr .= $res->outlet_id.',';
                      }
                      $outletStr = rtrim($outletStr,',');
                      $this->response['filterby'] = "dm_outlet";
                      $this->response['filterid'] = $outletStr;
                      } */
                } else if ($desigID == 8 || $desigID == 9) {//HR, InHouse Trainer - outlet
                    if ($desigID == 8) {
                        $qry = "SELECT ho_outletid as outlet_id FROM mdl_ums_hrm_outlet WHERE ho_userid = '" . $currUID . "' AND deleted=0";
                    } else if ($desigID == 9) {
                        $qry = "SELECT io_outletid as outlet_id FROM mdl_ums_iht_outlet WHERE io_userid = '" . $currUID . "' AND deleted=0";
                    }
                    $getData = $DB->get_records_sql($qry);

                    if (count($getData) > 0) {
                        $outletStr = '';
                        foreach ($getData as $res) {
                            $outletStr .= $res->outlet_id . ',';
                        }
                    }
                    $outletStr = rtrim($outletStr, ',');
                    $this->response['filterby'] = "outlet";
                    $this->response['filterid'] = $outletStr;
                } else if ($desigID == 3 || $desigID == 5 || $desigID == 6) {//All TL's
                    $getData = $DB->get_record_sql("SELECT code FROM mdl_ums_employeemaster WHERE userid = '" . $currUID . "'");
                    if (count($getData) > 0) {
                        $this->response['filterby'] = "tlmspin_no";
                        $this->response['filterid'] = $getData->code;
                    }
                } else {
                    
                }

                /* else if($desigID == 295) // dealer designation
                  {
                  $qry = "SELECT outlet_id FROM mdl_ums_user_dealer_mapping WHERE user_id = '".$currUID."' AND deleted=0";

                  $getData = $DB->get_records_sql($qry);
                  if(count($getData) > 0){
                  $outletStr = '';
                  foreach($getData as $res){
                  $outletStr .= $res->outlet_id.',';
                  }
                  $outletStr = rtrim($outletStr,',');
                  $this->response['filterby'] = "parent_group";
                  $this->response['filterid'] = $outletStr;
                  }
                  } */
            }
        }
        return $this->response;
    }

    //dateFileterFunction
    function getdateFilterJsonData() {
        global $DB;
        $join = "";
        $data = array();
        $filter = "AND u.id NOT IN(2,4) AND u.username NOT IN('admin','guest') AND emp.designation_id IN(2,3,4,5,6,7,8,9,10,11,23,30,32,33,40,43,44,45,52,54,57,61,63,74,80,90,106,120,128,131,143,153,157,159,166,218,221,222,223,225,226,228,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,259,260,261,262,265,266,310)"; //DMS + MSIL Users
        $courseid = (isset($_REQUEST['courseid']) && !empty($_REQUEST['courseid'])) ? $_REQUEST['courseid'] : '';
        $filter .= " AND c.id = " . $courseid . "";
        $date_type = (isset($_REQUEST['date_type']) && !empty($_REQUEST['date_type'])) ? $_REQUEST['date_type'] : '';
        $fromDate = (isset($_REQUEST['starttime']) && !empty($_REQUEST['starttime'])) ? $_REQUEST['starttime'] : '';
        $toDate = (isset($_REQUEST['endtime']) && !empty($_REQUEST['endtime'])) ? $_REQUEST['endtime'] : '';
        //print_r($_REQUEST);
        $fromDate = strtotime($fromDate . "00:00:00");
        $toDate = strtotime($toDate . "23:59:00");
        $flag = 0; //to bypass some entries
        if ($date_type == 1) { //assigned date ie enrollement date
            $flag = 1;
            $sql = "SELECT u.id as userid, c.fullname as coursename,
						ra.timemodified as courseassignDate,u.phone1, u.username,u.firstname,u.lastname, emp.dol, emp.region_id, emp.designation_id, s.id as scormid,out1.o_code,out1.o_code_latest,out1.o_name,reg.r_name,st.s_code,desig.d_name,c.id as courseid
						FROM {user} u 
						INNER JOIN {role_assignments} ra ON ra.userid = u.id
						INNER JOIN {context} ctx ON ctx.id = ra.contextid
						INNER JOIN {course} c ON c.id = ctx.instanceid
						INNER JOIN {scorm} s ON s.course = c.id 
						INNER JOIN {ums_employeemaster} emp ON emp.userid = u.id 
						LEFT  JOIN {ums_regions} reg ON reg.id = emp.region_id
						LEFT  JOIN {ums_state} st ON st.id  = emp.state_id
						LEFT  JOIN {ums_outlet} out1 ON out1.id = emp.outlet_id
						LEFT  JOIN {ums_designations} desig ON desig.id = emp.designation_id
						WHERE u.deleted = 0 AND ra.timemodified BETWEEN " . $fromDate . " AND " . $toDate . " AND ctx.contextlevel = 50 AND ra.roleid = 5 " . $filter . " ";
        } else if ($date_type == 2) { //course first access
            $sql = "SELECT 
					concat(u.id,'',s.id) as tempid,u.id as userid,u.username,u.phone1,u.firstname,u.lastname, emp.dol, emp.region_id, emp.designation_id, c.id as courseid,out1.o_code,out1.o_code_latest,out1.o_name,reg.r_name,st.s_code,desig.d_name,st.s_name as statename,c.fullname as coursename,s.id as scormid
					FROM {user} u
					INNER JOIN {scorm_scoes_track} sst ON sst.userid = u.id
					INNER JOIN {scorm} s ON s.id = sst.scormid
					INNER JOIN {course} c ON c.id = s.course
					INNER JOIN {ums_employeemaster} emp ON emp.userid = u.id
					LEFT  JOIN {ums_regions} reg ON reg.id = emp.region_id
					LEFT  JOIN {ums_state} st ON st.id  = emp.state_id
					LEFT  JOIN {ums_outlet} out1 ON out1.id = emp.outlet_id 
					LEFT  JOIN {ums_designations} desig ON desig.id = emp.designation_id
					WHERE u.deleted = 0 AND (sst.element = 'x.start.time' AND sst.value BETWEEN " . $fromDate . " AND " . $toDate . ")  " . $filter . "";
        } else if ($date_type == 3) { //course completion 
            $sql = "SELECT 
					concat(u.id,'',s.id) as tempid,
					u.id as userid,
					u.username,u.phone1,u.firstname,u.lastname, emp.dol, emp.region_id, emp.designation_id, c.id as courseid,out1.o_code,out1.o_code_latest,out1.o_name,reg.r_name,st.s_code,desig.d_name,st.s_name as statename,c.fullname as coursename,s.id as scormid
					FROM {user} u
					INNER JOIN {scorm_scoes_track} sst ON sst.userid = u.id
					INNER JOIN {scorm} s ON s.id = sst.scormid
					INNER JOIN {course} c ON c.id = s.course
					INNER JOIN {ums_employeemaster} emp ON emp.userid = u.id
					LEFT  JOIN {ums_regions} reg ON reg.id = emp.region_id
					LEFT  JOIN {ums_state} st ON st.id  = emp.state_id
					LEFT  JOIN {ums_outlet} out1 ON out1.id = emp.outlet_id 
					LEFT  JOIN {ums_designations} desig ON desig.id = emp.designation_id
					WHERE u.deleted = 0 AND (sst.element = 'cmi.core.lesson_status' OR sst.element = 'cmi.completion_status') AND (value = 'passed' || value = 'completed') AND sst.timemodified BETWEEN " . $fromDate . " AND " . $toDate . "  " . $filter . "";
        }
        $results = $DB->get_records_sql($sql);
        $count = 0;
        $data = array();
        foreach ($results as $key => $result) {
            $status = "";
            $coursename = $result->coursename;
            $username = $result->username;
            $name = $result->firstname . " " . $result->lastname;
            $phone = $result->phone1;
            $region = $result->r_name;
            $state = $result->s_code;
            $outletname = $result->o_name;
            $outletcode = $result->o_code_latest;
            $designation = $result->d_name;
            $courseassigndate = $this->courseassignDetails($result->userid, $result->courseid);
            //date('d-m-Y',$result->courseassigndate);
            $firstaccess = $this->firstaccessDetails($result->userid, $result->scormid);
            $lastaccess = $this->courseLastAccess($result->userid, $result->courseid);
            $lastaccess = $lastaccess == 0 ? '-' : $this->unixToNormalLong($lastaccess);
            $coursecompleted = $this->coursecompletedDetails($result->userid, $result->scormid);

            $totalmarksarr = $DB->get_record_sql("SELECT value FROM {scorm_scoes_track} WHERE scormid = '" . $result->scormid . "' AND userid = '" . $result->userid . "' AND (element = 'cmi.core.score.max' OR element = 'cmi.score.max')");
            $totalmarks = $totalmarksarr->value;

            $totalmarksscored = '-';
            $per = '-';
            $passfailstatus = '-';

            $status = $this->courseStatus($result->userid, $result->scormid);
            if ($status != "-" || $flag == 1) {
                if ($status == "completed" || $status == "passed" || $status == "failed") {
                    $status = "Completed";

                    $totalmarksscoredarr = $DB->get_record_sql("SELECT value FROM {scorm_scoes_track} WHERE scormid = '" . $result->scormid . "' AND userid = '" . $result->userid . "' AND (element = 'cmi.core.score.raw' OR element = 'cmi.score.raw')");
                    $totalmarksscored = $totalmarksscoredarr->value;

                    if ($totalmarksscored != '' && $totalmarksscored != '-' && $totalmarksscored != 0) {

                        $percentagescored = round(($totalmarksscored * 100) / $totalmarks);
                        $per = $percentagescored != 0 ? $percentagescored . "%" : '-';

                        $passfailstatusarr = $DB->get_record_sql("SELECT value FROM {scorm_scoes_track} WHERE scormid = '" . $result->scormid . "' AND userid = '" . $result->userid . "' AND (element = 'cmi.core.lesson_status' OR element = 'cmi.completion_status')");
                        $passfailstatus = $passfailstatusarr->value;
                    }
                } else if ($status == "incomplete") {
                    $status = "Incomplete";
                    $coursecompleted = "-";
                } else {
                    $status = "Not Started";
                    $coursecompleted = "-";
                    $firstaccess = "-";
                    $lastaccess = "-";
                }

                if ($this->isLearningPathCourse($result->courseid)) {
                    $view = 'https://ilearn.marutisuzuki.com/local/pagecontainer/lms/activity_report_yogitag.php?userid=' . $result->userid . '&courseid=' . $result->courseid;
                    $viewlink = '<a href="' . $view . '">View Details</a>';
                } else {
                    $viewlink = '';
                }

                $data[$count]['Sr'] = $count + intval(1);
                $data[$count]['CourseName'] = $coursename;
                $data[$count]['EmpName'] = $name;
                $data[$count]['Empcode'] = $username;
                $data[$count]['EmpPhone'] = $phone;
                $data[$count]['EmpDol'] = ($result->dol != '' && $result->dol != '0000-00-00') ? date("d/m/Y", strtotime($result->dol)) : '-';
                $data[$count]['Region'] = $region != '' ? $region : '-';
                $data[$count]['State'] = $state != '' ? $state : '-';
                $data[$count]['Designation'] = $designation;
                $data[$count]['OutletName'] = $outletname != '' ? $outletname : '-';
                $data[$count]['Outlet'] = $outletcode != '' ? $outletcode : '-';
                $data[$count]['CourseAssignDate'] = $courseassigndate;
                $data[$count]['CourseFirstAccess'] = $firstaccess;
                $data[$count]['CourseLastAccess'] = $lastaccess;
                $data[$count]['CourseCompletionDate'] = $coursecompleted;
                $data[$count]['status'] = $status;

                $data[$count]['TotalMarks'] = $totalmarks != '' ? (int) $totalmarks : '-';
                $data[$count]['TotalMarksScored'] = ($totalmarksscored != '' && $totalmarksscored != 0) ? round($totalmarksscored) : '-';
                $data[$count]['PercentageScored'] = $per;
                $data[$count]['PassFail'] = $passfailstatus != '' ? ucfirst($passfailstatus) : '-';
                $data[$count]['view'] = $viewlink;
                $count++;
            }
        }
        echo json_encode($data);
    }

    function designationlist($pageType = "") {
        global $DB;

        $result = $DB->get_records_sql("SELECT id, d_name FROM mdl_ums_designations where deleted = 0 AND id!=1 AND d_name IN('SAE', 'TL' , 'CSE' , 'CTL' , 'RSE' , 'RTL' , 'INT', 'STR', 'HRM', 'CEO', 'SM', 'GM', 'HRE', 'GMS', 'QCM', 'QCE','AGM','DGM','VPS','CCM','CCE','LHS','AMS','TCS','CSY','REC','SEA','ASE','ACM','AES','FIM','DDE','DDM') ORDER BY d_name", array());
        $list = "";
        if ($pageType == 'summary') {
            $list = "<option value='0' selected>All</option>";
        }
        foreach ($result as $row) {
            $did1 = $row->id;
            $dname1 = $row->d_name;
            $list .= "<option value=" . $did1 . ">" . ucwords($dname1) . "</option>";
        }
        $list .= "<option value='159' style='font-weight:bold;'><strong>MSIL-AM</strong></option>";
        $list .= "<option value='223' style='font-weight:bold;'><strong>MSIL-CBH</strong></option>";
        $list .= "<option value='11' style='font-weight:bold;'><strong>MSIL-FSDM</strong></option>";
        $list .= "<option value='10' style='font-weight:bold;'><strong>MSIL-SAT-HO</strong></option>";
		$list .= "<option value='310' style='font-weight:bold;'><strong>MSIL-HO</strong></option>";
        $list .= "<option value='222' style='font-weight:bold;'><strong>MSIL-RM</strong></option>";
        $list .= "<option value='221' style='font-weight:bold;'><strong>MSIL-TSM</strong></option>";
        $list .= "<option value='225' style='font-weight:bold;'><strong>MSIL-MKT</strong></option>";
        $list .= "<option value='226' style='font-weight:bold;'><strong>MSIL-RSL</strong></option>";

        $list .= "<option value='228' style='font-weight:bold;'><strong>MSIL-MSL</strong></option>";

        $list .= "<option value='233' style='font-weight:bold;'><strong>MSIL-COMC</strong></option>";
        $list .= "<option value='234' style='font-weight:bold;'><strong>MSIL-MSDS</strong></option>";
        $list .= "<option value='236' style='font-weight:bold;'><strong>MSIL-DD3</strong></option>";
        $list .= "<option value='237' style='font-weight:bold;'><strong>MSIL-DMS</strong></option>";
        $list .= "<option value='238' style='font-weight:bold;'><strong>MSIL-SNP</strong></option>";
        $list .= "<option value='239' style='font-weight:bold;'><strong>MSIL-DFP</strong></option>";
        $list .= "<option value='240' style='font-weight:bold;'><strong>MSIL-NDE</strong></option>";
        $list .= "<option value='241' style='font-weight:bold;'><strong>MSIL-MT</strong></option>";

        $list .= "<option value='242' style='font-weight:bold;'><strong>MSIL-ANMAC2</strong></option>";
        $list .= "<option value='243' style='font-weight:bold;'><strong>MSIL-MMR</strong></option>";
        $list .= "<option value='244' style='font-weight:bold;'><strong>MSIL-PPD</strong></option>";
        $list .= "<option value='245' style='font-weight:bold;'><strong>MSIL-DIGM</strong></option>";
        $list .= "<option value='246' style='font-weight:bold;'><strong>MSIL-CMAJ</strong></option>";
        $list .= "<option value='247' style='font-weight:bold;'><strong>MSIL-AMBAC1</strong></option>";
        $list .= "<option value='248' style='font-weight:bold;'><strong>MSIL-AA</strong></option>";
        $list .= "<option value='249' style='font-weight:bold;'><strong>MSIL-ACS</strong></option>";
        $list .= "<option value='250' style='font-weight:bold;'><strong>MSIL-CRM1</strong></option>";
        $list .= "<option value='251' style='font-weight:bold;'><strong>MSIL-CRM2</strong></option>";
        $list .= "<option value='252' style='font-weight:bold;'><strong>MSIL-DDEV</strong></option>";
        $list .= "<option value='253' style='font-weight:bold;'><strong>MSIL-ISLG</strong></option>";
        $list .= "<option value='254' style='font-weight:bold;'><strong>MSIL-LPD</strong></option>";
        $list .= "<option value='259' style='font-weight:bold;'><strong>MSIL-MEDIA</strong></option>";
        $list .= "<option value='260' style='font-weight:bold;'><strong>MSIL-SMP</strong></option>";
        $list .= "<option value='261' style='font-weight:bold;'><strong>MSIL-SLP</strong></option>";
        $list .= "<option value='262' style='font-weight:bold;'><strong>MSIL-NP</strong></option>";

        $list .= "<option value='265' style='font-weight:bold;'><strong>MSIL-COMNT</strong></option>";
        $list .= "<option value='266' style='font-weight:bold;'><strong>MSIL-ISLC</strong></option>";

        return $list;
    }

}

if (isset($_GET['__u__']) && !empty($_GET['__u__'])) {
    $userid = $_GET['__u__'];
} else {
    $userid = $USER->id;
}
$obj = new Course($USER->id);
if (isset($_GET['__g__']) && $_GET['__g__'] == 'data') {
    $obj->getJsonData();
}
if (isset($_GET['__g__']) && $_GET['__g__'] == 'data1') {
    $obj->getIndividualJsonData();
}
if (isset($_GET['__g__']) && $_GET['__g__'] == 'dateFilter') {
    $obj->getdateFilterJsonData();
}
if (isset($_GET['__g__']) && $_GET['__g__'] == 'data2') {
    $obj->getRegionCourseJsonData();
}
?>