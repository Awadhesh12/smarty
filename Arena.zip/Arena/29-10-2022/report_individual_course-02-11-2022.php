<?php
/* * ********
  Developer Name : Vinod Gadade, Sneha Gaikwad
  Date : 16th September, 2019
 * **** */
require_once('../../../config.php');
require_login();
require_once('report_course_class.php');
$systemcontext = context_system::instance();
$url = new moodle_url('/local/pagecontainer/ums/report_individual_course.php');
$PAGE->set_context($systemcontext);
$PAGE->set_title('Course Individual Report');
$PAGE->set_pagelayout('report');
$PAGE->set_heading('Course Individual Report');
echo $OUTPUT->header();
$id = $USER->id;
$user = $USER->username;
$obj = new Course($id);
$regionlist = $obj->regionlist();
$outletgrouplist = $obj->outletgrouplist();
$courseList = $obj->course_list();
?>
<div class="row">
    <div class="col-md-12">
        <form name="form1" id="form1" method="post">		
            <div class="panel-body">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">Course</label>&nbsp;<span style="color: red;font-weight: bolder;">*</span>
                                </div>
                            </div>

                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <select name="course_id" id="course_id"  class="form-control">
                                        <option value="0">Select Course</option>
                                        <?php echo $courseList; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">Course Status</label>
                                </div>
                            </div>
                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <select name="course_status" id="course_status" class="form-control">
                                        <option value="0">All</option>
                                        <option value="notstarted" <?php echo $select = $hmi_status == 'notstarted' ? 'selected' : '' ?>>Not Started</option>
                                        <option value="finished" <?php echo $select = $hmi_status == 'finished' ? 'selected' : '' ?>>Completed </option>
                                        <option value="incomplete" <?php echo $select = $hmi_status == 'incomplete' ? 'selected' : '' ?>>Incomplete</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">MSPIN</label>
                                </div>
                            </div>

                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <input class="form-control" type="text" name="empcode" id="empcode" placeholder="Employee MSPIN" onkeyup="getEmpCodeTxt(this.value);" />
                                    <input type="hidden" name="empusernamehidden" id="empusernamehidden" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">Employee Name</label>
                                </div>
                            </div>

                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <input class="form-control" type="text" name="empname" id="empname" placeholder="Employee Name" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">Phone</label>
                                </div>
                            </div>

                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <input class="form-control" type="text" name="empphone" id="empphone" placeholder="Employee Phone" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">Employee Type</label>
                                </div>
                            </div>

                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <select class="form-control" name="emptype" id="emptype">
                                        <option value="0">Select Employee Type</option>
                                        <option value="dms">DMS Employee</option>
                                        <option value="msil">MSIL Employee</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">Region</label>
                                </div>
                            </div>

                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <select class="form-control" name="region[]" id="region" onchange="getSTFromRegion();" multiple>
                                        <option value="0" disabled>Select region</option>
                                        <?php echo $regionlist; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">State</label>
                                </div>
                            </div>

                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <select class="form-control" name="state[]" id="state" onchange="getCityFromState();" multiple>
                                        <option value="0" disabled>Select state</option>

                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">City</label>
                                </div>
                            </div>

                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <select class="form-control" name="city[]" id="city" multiple>
                                        <option value="0" disabled>Select city</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">Outlet Name</label>
                                </div>
                            </div>

                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <select class="form-control" name="outletnm" id="outletnm" onchange="getOCodeFromOName();" >
                                        <option value="0">Select outlet name</option>
                                        <?php //echo $outletnamelist; /*NOTE : populated on selection of region changed on 5th July, 2019 */?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">Outlet Code</label>
                                </div>
                            </div>

                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <select class="form-control" name="outletcode" id="outletcode" >
                                        <option value="0">Select outlet code</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">Designation</label>
                                </div>
                            </div>

                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <select class="form-control filtercl" name="designationid[]" id="designationid" multiple >
                                        <option value="0" disabled>Select Designation</option>
                                        <?php echo $obj->designationlist(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group no-margin-hr">
                                    <label class="control-label">Employee Status</label>
                                </div>
                            </div>
                            <div class="col-sm-7">
                                <div class="form-group no-margin-hr">
                                    <select name="emp_status" id="emp_status" class="form-control">
                                        <option value="0" selected>Active</option>
                                        <option value="1">Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="panel-footer bottmBtn_sec text-center">
                        <input type="button" name="searchbtn" id="searchbtn" value="Search" onclick = "populate()" class="btn btn-primary">
                        <input class="btn btn-primary" type="reset" value="Reset"/>
                       <!--  <a href='../cron/daily_course_activity/daily_course_activity-<?=date('Y-m-d')?>.csv' type="button" class="btn btn-primary" style="outline: none">Download</a> -->
                    </div>
                </div>
            </div>
    </div>
</form>
</div>
<div>&nbsp;</div>
<div class="clear" style="clear:both;"></div>
<div class="row">
    <div class="col-md-12">
        <div class = "DateFilterDiv">
            <form class="row" name="form2" id="form2" method="post">
                <div class="col-md-12">
                    <div class="panel-body">
                        <div class= "row">
                            <div class="col-sm-6">
                                <div class= "row">
                                    <div class="col-sm-5">
                                        <div class="form-group no-margin-hr">
                                            <label class="control-label">Choose Date type</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-7">
                                        <div class="form-group no-margin-hr">
                                            <select name="date_type" id="date_type"  class="form-control">
                                                <option value="0">Select Type</option>
                                                <option value="1">Assigned Date</option>
                                                <option value="2">Firstaccess Date</option>
                                                <option value="3">Completed Date</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class= "row">
                                    <div class="col-sm-5">
                                        <div class="form-group no-margin-hr">
                                            <label class="control-label">Start Date</label>
                                        </div>
                                    </div>

                                    <div class="col-sm-7">
                                        <div class="form-group no-margin-hr">
                                            <input type="text" name="starttime" class="form-control" placeholder="Start Date" id="starttime"  autocomplete="off" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class= "row">
                                    <div class="col-sm-5">
                                        <div class="form-group no-margin-hr">
                                            <label class="control-label">End Date</label>
                                        </div>
                                    </div>

                                    <div class="col-sm-7">
                                        <div class="form-group no-margin-hr">
                                            <input type="text" name="endtime" class="form-control" placeholder="End Date" id="endtime"  autocomplete="off" />
                                        </div>
                                    </div>
                                </div>

                            </div>						
                        </div>
                        <div class="row justify-content-center">
                            <div class="col-md-3">
                                <div class="panel-footer bottmBtn_sec text-center">
                                    <input type="button" name="dateSearchbtn" id="dateSearchbtn" value="Search" onclick = "populateDateSearch()" class="btn btn-primary">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div>&nbsp;</div>
        <div class="clear" style="clear:both;"></div>
        <div class="col-md-12">
            <div class="table-primary">
                <table class="table table-striped table-bordered" id="datatableid" cellspacing="0" width="100%" style = "display:none;">
                    <thead>
                        <tr>
                            <th>Sr.No</th>
                            <th>Course Name</th>
                            <th>Employee Name</th>
                            <th>Employee MSPIN</th>
                            <!-- <th>Employee Phone</th> -->
                            <th>Employee DOL</th>
                            <th>Designation</th>
                            <th>Region</th>
                            <th>State</th>
                            <th>Outlet Name</th>
                            <th>Outlet Code</th>
                            <th>Course Assign Date</th>
                            <th>Course First Access</th>
                            <th>Course Last Access</th>
                            <th>Course Completion Date</th>
                            <th>Course Status</th>
                            <!-- Below 4 fields added on 15 October,2019  -->
                            <th>Total Marks</th>
                            <th>Total Marks Scored</th>
                            <th>Percentage Scored</th>
                            <th>Pass/Fail</th>
                            <th>View Details</th>
                            <!--<th>Date & Time of Completion</th>-->
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>


<link rel="stylesheet" type="text/css" href="../css/jquery.dataTables.min.css">
<link rel="stylesheet" href="../css/font-awesome.min.css">
<link rel="stylesheet" href="../css/jquery.timepicker.min.css">
<link rel="stylesheet" href="../css/jquery-ui.css">
<script type="text/javascript" language="javascript" src="../js/jquery-1.12.4.js"></script>
<script type="text/javascript" language="javascript" src="../js/jquery.dataTables.min.js"></script>	
<script src="../js/jquery-ui.js"></script>
<script src="../js/jquery.timepicker.min.js"></script>
<script src="../js/jquery-ui-timepicker-addon-i18n.min.js"></script>
<script type="text/javascript" src="../js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="../js/buttons.flash.min.js"></script>
<script type="text/javascript" src="../js/jszip.min.js"></script>
<script type="text/javascript" src="../js/pdfmake.min.js"></script>
<script type="text/javascript" src="../js/vfs_fonts.js"></script>
<script type="text/javascript" src="../js/buttons.html5.min.js"></script>
<script type="text/javascript" src="../js/buttons.print.min.js"></script>

<script type="text/javascript">
    var jq = $.noConflict();
    function populate()
    {

        var course_id = $("#course_id").val();
        if (course_id == 0)
        {
            alert('Please select a course');
            return false;
        } else {

            jq('#datatableid').show();
            jq('#datatableid').dataTable().fnDestroy();
            jq(document).ready(function ()
            {
                var frmval = $('#form1').serialize();
                jq('#form1')[0].reset();
                jq('#datatableid').DataTable({
                    "ajax": {
                        "url": "report_course_class.php?__g__=data1&__u__=<?php echo $USER->id; ?>&" + frmval,
                        "dataSrc": ""
                    },
                    "language": {
                        "search": "Search",
                        "searchPlaceholder": "Type here to search"
                    },
                    dom: 'Blfrtip',
                    "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, 'All']     ], 
                    
                    buttons: [
                        {
                            extend: 'csv',
                            text: 'Export to CSV',
                            className: 'buttons-excel',
                            title: '',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
                            }
                        }
                    ],
                    "columns": [
                        {"data": "Sr"},
                        {"data": "CourseName"},
                        {"data": "EmpName"},
                        {"data": "Empcode"},
//                                                             { "data": "EmpPhone"},
                        {"data": "EmpDol"},
                        {"data": "Designation"},
                        {"data": "Region"},
                        {"data": "State"},
                        {"data": "OutletName"},
                        {"data": "Outlet"},
                        {"data": "CourseAssignDate"},
                        {"data": "CourseFirstAccess"},
                        {"data": "CourseLastAccess"},
                        {"data": "CourseCompletionDate"},
                        {"data": "status"},

                        {"data": "TotalMarks"},
                        {"data": "TotalMarksScored"},
                        {"data": "PercentageScored"},
                        {"data": "PassFail"},
                        {"data": "view"} /* ,
                         { "data": "DateOfCompletion" } */
                    ]
                });
            });
        }

    }
    $(document).ready(function () {
//populate();
    });

    function getEmpCodeTxt(val)
    {
        $('#empusernamehidden').val(val);
    }

    function getOCodeFromOName()
    {
        var regionids = $.map($("#region option:selected"), function (n, i)
        {
            return n.value;
        }).join(",");

        $.ajax({
            type: "post",
            url: "../ajax/displayOutletCodefromOutletName.php",
            data: {
                "outletid": $("#outletnm").val(),
                "regionids": regionids
            },
            success: function (response) {
                $('#outletcode').find('option:gt(0)').remove();
                $("#outletcode").append(response);

            }
        });
    }

    function getSTFromRegion()
    {
        $.ajax({
            type: "post",
            url: "../ajax/displaymultistatefromregion.php",
            data: {
                "regionid": $("#region").val(),
            },
            success: function (response) {
                $('#state, #city').find('option:gt(0)').remove();
                $("#state").append(response);
                getOutletNames();

            }
        });
    }

    function getCityFromState() {
        $.ajax({
            type: "post",
            url: "../ajax/displaymulticityfromstate.php",
            data: {
                "regionid": $("#region").val(),
                "stateid": $("#state").val(),
            },
            success: function (response) {
                $('#city').find('option:gt(0)').remove();
                $("#city").append(response);
//getOutletNames();not reqd.
            }
        });
    }

    function getOutletNames() {
        var regionids = $.map($("#region option:selected"), function (n, i)
        {
            return n.value;
        }).join(",");

        var stateids = $.map($("#state option:selected"), function (n, i)
        {
            return n.value;
        }).join(",");

        var cityids = $.map($("#city option:selected"), function (n, i)
        {
            return n.value;
        }).join(",");

        $.ajax({
            type: "post",
            url: "../ajax/displayOutletFromRegionStateCity.php",
            data: {

                "regionids": regionids,
                "stateids": stateids,
                "cityids": cityids
            },
            success: function (response) {
                $('#outletnm').find('option:gt(0)').remove();
                $("#outletnm").append(response);
            }
        });

    }

    var date;
    jq('#starttime').datepicker({
        //minDate: 0,
        /* dateFormat: 'dd/mm/yy',//check change
         changeMonth: true,
         changeYear: true, */

        minDate: date,
        dayOfWeekStart: 1,
        lang: 'en',
        closeOnDateSelect: true,
        onShow: function (ct) {
            this.setOptions({
                // minDate: $('#trg_startdate').val()+5
            })
        }

//                                            onSelect: function (selectedDate) {
//                                                date = $(this).datepicker('getDate');
//                                                $('#trg_enddate').datepicker('option', 'minDate', date); // Reset minimum date
//                                                //date.setDate(date.getDate() + parseInt($('#trgdur').val() - parseInt(1))); // Add reqd days
//                                                var enddate = date.toLocaleDateString('en-US');
//                                                $('#endtime').val(enddate); // Set as default
//
//                                            }
    });

    jq('#endtime').datepicker({
        /* 	dateFormat: 'dd/mm/yy',//check change
         changeMonth: true,
         changeYear: true, */
        minDate: date,
        dayOfWeekStart: 1,
        lang: 'en',
        closeOnDateSelect: true,
        onShow: function (ct) {
            this.setOptions({
                // minDate: $('#trg_startdate').val()+5
            })
        }
    });

    function populateDateSearch() {
        var flag = false;

        var date = $('#date_type').val();
        var starttime = $('#starttime').val();
        var endtime = $('#endtime').val();
        var course_id = $("#course_id").val();
        if (date != 0) {
            flag = true;
        } else {
            alert("Please select date type");
            flag = false;
        }

        if (course_id != 0) {
            flag = true;
        } else {
            alert("Please select course");
            flag = false;
        }

        if (starttime != "") {
            flag = true;
        } else {
            alert("Please select Start Date");
            flag = false;
        }

        if (endtime != "") {
            flag = true;
        } else {
            alert("Please select End Date");
            flag = false;
        }

        if (flag) {
            jq('#datatableid').show();
            jq('#datatableid').dataTable().fnDestroy();
            jq(document).ready(function ()
            {
                var frmval = $('#form2').serialize();
                jq('#datatableid').DataTable({
                    "ajax": {
                        "url": "report_course_class.php?__g__=dateFilter&__u__=<?php echo $USER->id; ?>&courseid=" + course_id + "&" + frmval,
                        "dataSrc": ""
                    },
                    "language": {
                        "search": "Search",
                        "searchPlaceholder": "Type here to search"
                    },
                    dom: 'Bfrtip',
                    buttons: [
                        {
                            extend: 'excel',
                            text: 'Export to Excel',
                            className: 'buttons-excel',
                            title: '',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
                            }
                        }
                    ],
                    "columns": [
                        {"data": "Sr"},
                        {"data": "CourseName"},
                        {"data": "EmpName"},
                        {"data": "Empcode"},
//                                                            {"data": "EmpPhone"},
                        {"data": "EmpDol"},
                        {"data": "Designation"},
                        {"data": "Region"},
                        {"data": "State"},
                        {"data": "OutletName"},
                        {"data": "Outlet"},
                        {"data": "CourseAssignDate"},
                        {"data": "CourseFirstAccess"},
                        {"data": "CourseLastAccess"},
                        {"data": "CourseCompletionDate"},
                        {"data": "status"},
                        {"data": "TotalMarks"},
                        {"data": "TotalMarksScored"},
                        {"data": "PercentageScored"},
                        {"data": "PassFail"},
                        {"data": "view"}

                    ]
                });
            });
        }
    }
</script>
<?php
echo $OUTPUT->footer();
