<?php
require_once('../../../../config.php');
require_login();
require_once('sub_category_class.php');
$PAGE->set_title('Gamification Sub Category');
$PAGE->set_pagelayout('report');
$PAGE->set_heading('Gamification Sub Category');
echo $OUTPUT->header();
$id   = $USER->id;
$user = $USER->username;
$weeklyQuiz=new Category;
$pcatlist=$weeklyQuiz->fetchProduct();
?>
<div class="filter_buttons add_btn_div">
	<div class="col-xs-12">
		<div class="text-right">
			<button type="button" class="btn btn-default filteropt viewbutton">Add</button>
		</div>
	</div>
</div>
<div class="clear" style="clear:both;"></div>
<div class="row" style="display:none;" id="filteropt">
	<div class="col-md-12">
	<form method="POST" id="frmcategory">
		<div role="main">
			<span id="maincontent"></span>
			<span id="errormsg"></span>
		</div>
		
			<div>&nbsp;</div>
			<div class="panel-body">
				
				<div class="row">
					<div class="col-sm-3">
						<div class="form-group no-margin-hr">
						</div>
					</div>
					<div class="col-sm-2">
						<div class="form-group no-margin-hr">
							<label class="control-label">Category Name</label>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="form-group no-margin-hr">
							<!-- <input type="text" name="cat_name" class="form-control" placeholder="Category Name"/> -->
							<select name="cat_name" id="cat_name" class="form-control" required="required">
								<option value="0">Select Category</option>
								<?=$pcatlist?>
							</select>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-3">
						<div class="form-group no-margin-hr">
						</div>
					</div>
					<div class="col-sm-2">
						<div class="form-group no-margin-hr">
							<label class="control-label">Sub Category Name</label>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="form-group no-margin-hr">
							<input type="text" name="subcat_name" id="subcat_name" class="form-control" placeholder="Sub Category Name"/>
						</div>
					</div>
				</div>

				<!-- <div class="row" >
					<div class="col-sm-3">
						<div class="form-group no-margin-hr">
						</div>
					</div>
					<div class="col-sm-2">
						<div class="form-group no-margin-hr">
							<label class="control-label" name="color_code">Color Code</label>
						</div>
					</div>

					<div class="col-sm-4">
						<div class="form-group no-margin-hr">
							<input type="color" id="color_code" name="color_code" value="#ff0000">
						</div>
					</div>
				</div>

				<div class="row" >
					<div class="col-sm-3">
						<div class="form-group no-margin-hr">
						</div>
					</div>
					<div class="col-sm-2">
						<div class="form-group no-margin-hr">
							<label class="control-label" name="status">Weightage</label>
						</div>
					</div>

					<div class="col-sm-4">
						<div class="form-group no-margin-hr">
							<input type="number" name="weightage" class="form-control" placeholder="Weightage"/>
						</div>
					</div>
				</div> -->



				<div class="row">
					<div class="col-sm-5">
						<div class="form-group no-margin-hr">
						</div>
					</div>
					<div class="col-sm-4">
						<div class="form-group no-margin-hr bottmBtn_sec">
							<div class="form-group no-margin-hr">
								<input type="hidden" name="action_type" value="add" id="action_type"/>
								<input type="hidden" name="subcategory_id" id="subcategory_id"/>
								<input class="btn btn-primary" type="submit" value="Add" name="edit" id="edit" />
								<input class="btn btn-primary" type="reset" value="Reset"/>
							</div>
						</div>
					</div>
				</div>
			</div>

</form>
</div>
</div>

<div class="row">

	<div class="col-md-12">
		<div class="table-primary">
			<div class="panel-heading-controls">
				<?php if($error_mapped != ''){?>
					<span class="panel-heading-text"><span class="alert alert-danger"><?php echo $error_mapped; ?></span></span>
				<?php }else{} ?>
			</div>
		</div>
	</div>
	<div class="col-md-2"></div>
</div>
<div>&nbsp;</div>
<div class="clear" style="clear:both;"></div>
<div class="row" style="margin-left: 0px;">
	<div class="col-md-12">
		<div class="table-primary footerBtn"> <!-- style="overflow: auto;display: block;overflow-x: auto;white-space: nowrap" -->
			<table class="table table-striped table-bordered" id="datatableid" cellspacing="0" width="100%">
				<thead>
					<tr>
						<th>Sr.No</th>
						<th>Category Name</th>
						<th>Subcategory Name</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody></tbody>
			</table>
		</div>
	</div>
	<div class="col-md-1"></div>
</div>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="../js/buttons.flash.min.js"></script>
<script type="text/javascript" src="../js/jszip.min.js"></script>
<script type="text/javascript" src="../js/pdfmake.min.js"></script>
<script type="text/javascript" src="../js/vfs_fonts.js"></script>
<script type="text/javascript" src="../js/buttons.html5.min.js"></script>
<script type="text/javascript" src="../js/buttons.print.min.js"></script>
<script type="text/javascript">
	$('#datatableid').DataTable({
		"ajax": {
			"url": "sub_category_class.php",
			"dataSrc": "",
			"data":{"action_type":"all"},
			"type":"post"
		},
		"language": {
			"search": "Search",
			"searchPlaceholder":"Type here to search"
		},
		dom: 'lBfrtip', //'Bfrtip',
		buttons: [
		{
			extend: 'excel',
			text: 'Export to Excel',
			className: 'buttons-excel',
			title: '',
			exportOptions: {
				columns: [ 0, 1, 2, 3]
			}
		}	
		],
		"columns": [ 
		{ "data": "sr" },
		{ "data": "cat_name" },
		{ "data": "subcat_name" },
		{ "data": "action" }
		]
		} );
</script>
<script>
	$(document).on('click', '.viewbutton', function(){
		$('#filteropt').toggle();
		$('#frmcategory')[0].reset();
		$('#edit').val('Add');
		$('#action_type').val('add');
		$('#category_id').val('');
	});
</script>
<script>
	$(document).on('submit', '#frmcategory', function(event){
		event.preventDefault();
		$.ajax({
			type: 'POST',
			url: 'sub_category_class.php',
			data: $('#frmcategory').serialize(),
			dataType:'Json',
			success: function(response){
				$("#errormsg").show();
				$("#errormsg").html(response.message).delay(1000).fadeOut(100);
				if(response.response==true){
					if($("#action_type").val()=="add"){
						$('#frmcategory')[0].reset();
					}
					setTimeout(function() {
						location.reload();
					 }, 2000);
					//$('#datatableid').DataTable().ajax.reload();
				}
				$('html, body').animate({scrollTop:0}, 'slow');
			}
		});
	});
	$(document).on('click', '.edit_btn', function(event){
		event.preventDefault();
		$.ajax({
			type: "POST",
			dataType: 'json',
			data: {'action_type':'view', 'subcategory_id':$(this).attr('cat-attr')},	
			url: "sub_category_class.php", 
			success: function(result){
				$('#filteropt').show();
				$('#edit').val('Update');
				$('input[name="action_type"]').val('update');
				//$('input[name="cat_name"]').val(result.cat_name);
				$('input[name="subcat_name"]').val(result.subcat_name);
				$('input[name="subcategory_id"]').val(result.id);
				// $('option:selected').prop('selected',true);
				$('select[name="cat_name"] option[value="'+result.cat_name+'"]').prop('selected',true);
				$('#datatableid').DataTable().ajax.reload();
				$('html, body').animate({scrollTop:0}, 'slow');
			}
		});
	});

	$(document).on('click', '.deletefn', function(event){
		event.preventDefault();

		var result = confirm("Are you sure you want to delete?");

		if(result)
		{
			$.ajax({
				type: "POST",
				dataType: 'json',
				data: {'action_type':'delete', 'subcategory_id':$(this).attr('cat-attr')},	
				url: "sub_category_class.php", 
				success: function(result){
					if(result.response==false){
						alert(result.message);
					}
					if(result.response==true){
						setTimeout(function() {
							location.reload();
						 }, 2000);
						//$('#datatableid').DataTable().ajax.reload();
					}
					$("#errormsg").show();
					$("#errormsg").html(result.message).delay(1000).fadeOut(100);
					$('html, body').animate({scrollTop:0}, 'slow');
				}
			});

		}
	});
</script>
<?php
echo $OUTPUT->footer();