<?php
ini_set('max_execution_time', 300);
require_once('../../../config.php');
include('../class/datatable.php');

require_once('../ums/dealer/DealerTrait.php'); 

class Assessment extends DataTable
{
	use DealerTrait;

		var $userid ;
		function __construct($userid) 
		{
			parent::__construct($userid);
			$this->userid   = $userid;
		}
		
				
		function getJsonData()
		{
			global $DB,$SESSION;
			$join = "";
			$exWhere = "";
			$assesments1 = "";
			$assesments2 = get_courses(2);
			//print_r($assesments2);exit;
			$assesments = (object) array_merge((array) $assesments1, (array) $assesments2);
			
			$newfilter = '';
			//Below code for displaying data as per login
			if($this->userid!=2){//Apart from Admin user apply cnd below to all other users
				$designationid = $this->getDesignation($this->userid);

				if(count($designationid)>0 && $designationid['filterby']!='' && $designationid['filterid']!=''){
					if($designationid['filterby'] == 'outlet'){
						$outlet_id = $designationid['filterid'];
						$newfilter .= " AND emp.outlet_id IN($outlet_id)";
					}
					if($designationid['filterby'] == 'region'){
						$region_id = $designationid['filterid'];
						$newfilter .= " AND emp.region_id IN($region_id)";
					}
				}
			}

			
			
			$regioncnd = '';
			if(isset($_REQUEST['region']) && trim($_REQUEST['region']) > 0){
				$regioncnd .= " AND emp.region_id IN (".$_REQUEST['region'].")";
			}

			$data = array();
			$count = 0;
			$filter=" AND b.id>0 AND b.username!='guest' AND b.id !=2";

			if ($this->isDealerLogin()) {
				
				$outletIdStr = $this->getOutletId();
				$filter .= " AND emp.outlet_id IN ($outletIdStr)";
			}

			$alloted = 0;
			foreach($assesments as $assesment) 
			{
				if($assesment->visible == 1){//display only active Assessments
				$quizid = $DB->get_field('quiz','id', array('course' => $assesment->id));
				$quizname = $DB->get_field('quiz','name', array('course' => $assesment->id));
				if($quizid=="") continue;
				$sql1 = "select count(distinct(a.userid)) as totalenroled from {role_assignments} as a
						INNER JOIN {user} as b on(a.userid=b.id )
						INNER JOIN {ums_employeemaster} as emp on(emp.userid=b.id )
						$join
						INNER JOIN {context} e ON e.id = a.contextid
						WHERE b.deleted =0 AND e.contextlevel = 50 AND a.roleid = 5 AND e.instanceid='".$assesment->id."' ".$filter.$exWhere." ".$newfilter." ".$regioncnd;
				
				$enrolledusers = $DB->get_records_sql($sql1, array());
				
				$alloted = key($enrolledusers);
				
			  $sql = "SELECT a.id,
						a.state as state,
						a.sumgrades as score,
						g.grademax,
						g.grademin,
						g.iteminstance,
						g.itemmodule
						FROM {quiz_attempts} AS a
						INNER JOIN {user} AS b ON(a.userid=b.id)
						INNER JOIN mdl_role_assignments as ra ON ra.userid=b.id
                        INNER JOIN mdl_context e ON e.id = ra.contextid
						INNER JOIN {ums_employeemaster} emp ON emp.userid = b.id
						$join
						INNER JOIN {grade_items} AS g ON g.iteminstance = '".$quizid."'
						AND g.itemmodule='quiz' WHERE a.quiz='".$quizid."' AND a.attempt=(SELECT MAX(attempt) FROM {quiz_attempts} WHERE b.deleted =0 AND quiz = '".$quizid."' AND e.instanceid='".$assesment->id."' AND userid = b.id limit 1)  $filter $exWhere $newfilter $regioncnd";
				
				$quizattempts = $DB->get_records_sql($sql, array());
				$completed = 0;
				$not_started = 0;
				$incomplete = 0;
				$passed     = 0;
				$failed     = 0;
				foreach($quizattempts as $attempt)
				{
					
					if($attempt->state == 'finished')
					{
						$completed++;
					}
					else
					{
						$incomplete++;
					}
					$score       = $attempt->score;
					$grademax    = $attempt->grademax;
					$grademin    = $attempt->grademin;
					$per 		 = round(($score*100)/$grademax);
					$percentage		 = $per==0 ? '-' : $per.'%';
					if($score!='-')
					{
						if($score>=$grademin) 
						{
							$passed++;
						}
						else
						{
							$failed++;
						}										
					}
				   
				}
				$not_started = $alloted - ($completed + $incomplete);
			   
				$modid = $DB->get_field('course_modules','id',array('module'=>6,'instance'=>$quizid));
				$link = 
				"https://ilearn.marutisuzuki.com/nexa/mod/quiz/report.php?id=".$modid."&mode=responses&attempts=enrolled_with&onlygraded&qtext=1&resp=1&right=1&download=csv";
				$data[$count]['Sr']         = $count+1;
				//$data[$count]['quizid']     = $quizid;	
				$data[$count]['Name']       = $quizname;	
				$data[$count]['StartDate']  = date("d/m/Y",$assesment->startdate);	
				$data[$count]['Alloted']    = $alloted;
				$data[$count]['Completed']  = $completed;
				$data[$count]['NotStarted'] = $not_started;	
				$data[$count]['Incomplete'] = $incomplete;	
				$data[$count]['QuestionReport'] = $link;	
				$count++;
				}
				
			}//eof for loop
			echo json_encode($data);
		}
		
		function getIndividualAssessmentJsonData()
		{
			global $DB,$SESSION,$USER;
			$join    = "";
			$exWhere = "";
			$filter  = "";
			$hmi_status = (isset($_REQUEST['quiz_status']) && !empty($_REQUEST['quiz_status'])) ? $_REQUEST['quiz_status']: '';
			$hmi_quiz   = (isset($_REQUEST['quiz_id']) && !empty($_REQUEST['quiz_id'])) ? $_REQUEST['quiz_id']: '';
			$empcode    = (isset($_REQUEST['empcode']) && !empty($_REQUEST['empcode'])) ? $_REQUEST['empcode']: '';
			$empname    = (isset($_REQUEST['empname']) && !empty($_REQUEST['empname'])) ? $_REQUEST['empname']: '';
			$topic      = (isset($_REQUEST['topic']) && !empty($_REQUEST['topic'])) ? $_REQUEST['topic']: '';

			$category   = (isset($_REQUEST['category']) && !empty($_REQUEST['category'])) ? $_REQUEST['category']: '';

			$sub_category= (isset($_REQUEST['subcategory']) && !empty($_REQUEST['subcategory'])) ? $_REQUEST['subcategory']: '';
			$empphone   = (isset($_REQUEST['empphone']) && !empty($_REQUEST['empphone'])) ? $_REQUEST['empphone']: '';
			$region     = (isset($_REQUEST['region']) && !empty($_REQUEST['region'])) ? $_REQUEST['region']: '';
		 	$state      = (isset($_REQUEST['state']) && !empty($_REQUEST['state'])) ? $_REQUEST['state']: '';
			$outletgr   = (isset($_REQUEST['outletgr']) && !empty($_REQUEST['outletgr'])) ? $_REQUEST['outletgr']: '';
			$outlet     = (isset($_REQUEST['outlet']) && !empty($_REQUEST['outlet'])) ? $_REQUEST['outlet']: '';
			$empdesignation      = (isset($_REQUEST['designation']) && !empty($_REQUEST['designation'])) ? $_REQUEST['designation']: '';
			$designation = implode(',',$empdesignation);
			
		    //Below code for displaying data as per login
			if($this->userid!=2)
			{ 
		       //Apart from Admin user apply cnd below to all other users
				$designationid = $this->getDesignation($this->userid);

				if(count($designationid)>0 && $designationid['filterby']!=''){
					if($designationid['filterby'] == 'outlet'){
						$outlet_id = $designationid['filterid'];
						$filter .= " AND emp.outlet_id IN($outlet_id)";
					}
					if($designationid['filterby'] == 'region'){
						$region_id = $designationid['filterid'];
						$filter .= " AND emp.region_id IN($region_id)";
					}
				}
			}

			if ($this->isDealerLogin()) {
				
				$codeLatest = $this->getOutletCode();
				$filter .= " AND out1.o_code_latest IN ('$codeLatest')";
			}
			// echo $hmi_status; die;
			if($hmi_status!="0" && $hmi_status != "" && $hmi_status!='notstarted')
			{
				$filter	.= " AND qa.state='".$hmi_status."'";//This course using as assessment
			}

			if($hmi_quiz!="0" && $hmi_quiz != "")
			{
				$filter	.= " AND q.id ='".$hmi_quiz."'";//This course using as assessment
				// $filter	.= " AND q.id in ($hmi_quiz)";
			}
			
			if($empcode !='')
			{
				$filter	.= " AND u.username like '%".$empcode."%'";
			}
			
			if($empname !='')
			{
				$filter .= " AND (u.firstname LIKE '%" . trim($empname) . "%' OR u.lastname LIKE '%".trim($empname)."%')";
			}

			if($topic != '' || $category !='' || $sub_category != ''){
				$sql = "SELECT * FROM mdl_question_categories WHERE parent = ".$topic."";
				$res = $DB->get_records_sql($sql);
				$prefix = $categoryid = '';
				foreach ($res as $value) {
					$categoryid .= $prefix.' '.$value->id;
					$prefix = ', ';
				}
				$sql1 = "SELECT * FROM mdl_question_categories WHERE parent in ($categoryid)";
				$res1 = $DB->get_records_sql($sql1);
				$prefix = $subcategoryid = '';
				foreach ($res1 as $value) {
					$subcategoryid .= $prefix.' '.$value->id;
					$prefix = ', ';
				}				
			}
			if($subcategoryid ==''){
				$tvar = $topic.','.$categoryid.' '.$subcategoryid;
				$catvar = $topic.','.$category.' '.$subcategoryid;
			}else{
				$tvar = $topic.','.$categoryid.','.$subcategoryid;
				$catvar = $topic.','.$category.','.$subcategoryid;
			}
			
			
			$subcatvar = $topic.','.$category.','.$sub_category;

			if($topic !='0' && $topic !='')
			{
				$filter .= "AND quec.id in ($tvar)";
			}
			
			if($category !='0' && $category !='')
			{
				$filter .= "AND quec.id in ($catvar)";
			}

			if($sub_category !='0' && $sub_category !='')
			{
				$filter .= "AND quec.id in ($subcatvar)";
			}


			if($empphone !='')
			{
				$filter	.= " AND u. phone1 like '%".$empphone."%'";
			}
				
			if($region !='' && $region >0 ) 
			{
				$filter	.= " AND emp.region_id ='".$region."'";
			}
				
			if($state !='' && $state >0 ) 
			{
				$filter	.= " AND emp.state_id ='".$state."'";
			}
				
			if($outlet !='' && $outlet >0 ) 
			{
				$filter	.= " AND emp.outlet_id =".$outlet;
			}
			
			if($outletgr !='' && $outletgr >0 ) 
			{
				$filter	.= " AND out1.outlet_group_id =".$outletgr;
			}
			if($designation !='') 
			{
				$filter	.= " AND emp.designation_id IN (".$designation.")";
			}
				
				
			$data = array();
			if($hmi_status != 'notstarted'){
			
			// $sql = "SELECT 
			// concat(u.id,'',c.id) as tempid,u.id as userid,u.username,u.phone1,u.firstname,u.lastname,c.id as courseid,q.id as quizid, q.name as quizname,out1.o_code,out1.o_code_latest,out1.o_name,desig.d_name,reg.r_name,st.s_code,st.s_name as statename,gi.grademax,emp.region_id
			// FROM {user} u
			// INNER JOIN {role_assignments} ra ON ra.userid = u.id
			// INNER JOIN {context} ctx ON ctx.id = ra.contextid
			// INNER JOIN {course} c ON c.id = ctx.instanceid
			// INNER JOIN {course_categories} cat ON cat.id = c.category
			// INNER JOIN {quiz} q ON q.course = c.id
			// INNER JOIN {grade_items} gi ON q.id = gi.iteminstance
			// INNER JOIN {ums_employeemaster} emp ON emp.userid = u.id
			// LEFT  JOIN {ums_regions} reg ON reg.id = emp.region_id
			// LEFT  JOIN {ums_state} st ON st.id  = emp.state_id
			// LEFT  JOIN {ums_outlet} out1 ON out1.id = emp.outlet_id
			// LEFT  JOIN {ums_designations} desig ON desig.id = emp.designation_id
			// WHERE u.deleted = 0 AND ra.roleid = 5 AND ctx.contextlevel = 50 AND u.id <>2 AND gi.itemmodule = 'quiz' AND cat.id = 2 ".$filter."";

		    $sql = "SELECT concat(u.id,'',c.id) as tempid,u.id as userid,u.username,u.phone1,u.firstname,u.lastname,c.id as courseid,q.id as quizid, q.name as quizname,qs.id,qs.questionid,que.category as que_cat,quec.id as quec_id,quec.name as topic,out1.o_code,out1.o_code_latest,out1.o_name,desig.d_name,reg.r_name,st.s_code,st.s_name as statename,gi.grademax,emp.region_id
			FROM {user} u
			INNER JOIN {role_assignments} ra ON ra.userid = u.id
			INNER JOIN {context} ctx ON ctx.id = ra.contextid
			INNER JOIN {course} c ON c.id = ctx.instanceid
			INNER JOIN {course_categories} cat ON cat.id = c.category
			INNER JOIN {quiz} q ON q.course = c.id
			INNER JOIN {quiz_slots} qs ON qs.quizid = q.id
			INNER JOIN {question} que ON que.id = qs.questionid
			INNER JOIN {question_categories} quec ON quec.id = que.category
			INNER JOIN {grade_items} gi ON q.id = gi.iteminstance
			INNER JOIN {ums_employeemaster} emp ON emp.userid = u.id
			LEFT  JOIN {ums_regions} reg ON reg.id = emp.region_id
			LEFT  JOIN {ums_state} st ON st.id  = emp.state_id
			LEFT  JOIN {ums_outlet} out1 ON out1.id = emp.outlet_id
			LEFT  JOIN {ums_designations} desig ON desig.id = emp.designation_id
			WHERE u.deleted = 0 AND ra.roleid = 5 AND ctx.contextlevel = 50 AND u.id <>2 AND gi.itemmodule = 'quiz' AND c.is_set = 1 AND cat.id = 2 ".$filter." group by u.id, c.id, q.id";

			// echo	 $sql; die;
			
			if($hmi_status === 'finished' || $hmi_status === 'inprogress' || $hmi_status === 'abandoned'){
				$sql = "SELECT 
				concat(u.id,'',q.id) as tempid,u.id as userid,u.username,u.phone1,u.firstname,u.lastname,q.id as quizid, q.name as quizname,qs.id,qs.questionid,que.category as que_cat, quec.id as quec_id, quec.name as topic, out1.o_code,out1.o_code_latest,out1.o_name,desig.d_name,reg.r_name,st.s_code,st.s_name as statename,gi.grademax,emp.region_id
				FROM {user} u
				INNER JOIN {quiz_attempts} qa ON qa.userid = u.id
				INNER JOIN {quiz} q ON qa.quiz = q.id
				INNER JOIN {course} c ON c.id = q.course
				INNER JOIN {quiz_slots} qs ON qs.quizid = q.id
				INNER JOIN {question} que ON que.id = qs.questionid
				INNER JOIN {question_categories} quec ON quec.id = que.category
				INNER JOIN {grade_items} gi ON q.id = gi.iteminstance
				INNER JOIN {ums_employeemaster} emp ON emp.userid = u.id
				LEFT  JOIN {ums_regions} reg ON reg.id = emp.region_id
				LEFT  JOIN {ums_state} st ON st.id  = emp.state_id
				LEFT  JOIN {ums_outlet} out1 ON out1.id = emp.outlet_id
				LEFT  JOIN {ums_designations} desig ON desig.id = emp.designation_id
				WHERE u.deleted = 0 AND u.id <> 2 AND c.is_set = 1 AND gi.itemmodule = 'quiz' ".$filter." group by u.id, c.id, q.id limit 10000";
			}
			// echo $sql; die;
			$result = $DB->get_records_sql($sql);
			$notstartedcount= 0;
			$inprogresscount= 0;
			$completedcount = 0;
			$status = "";
			$data = array();
			$srno = 0;
			$result = array_values($result);
			for($i=0;$i<count($result);$i++){
				
				$regionstr = "";
				if($result[$i]->region_id!='' && $result[$i]->region_id!=0){
					$regionidtemp = explode(",",$result[$i]->region_id);
					foreach($regionidtemp as $rid){
						$regionname	=	$DB->get_field("ums_regions","r_name",array("id"=>$rid));
						$regionstr .= $regionname.", ";
					}
				}
				
				$outletID       = $DB->get_field('ums_outlet','outlet_group_id', array('o_code_latest'=>$result[$i]->o_code_latest));
				$outletgrpname  = $DB->get_field('ums_outlet_group','og_name', array('id'=>$outletID));
				
				$quizid   = $result[$i]->quizid;
				$courseid = $result[$i]->courseid;
				$userid   = $result[$i]->userid;
				$name  	  = $result[$i]->quizname;
				$firstname= $result[$i]->firstname;
				$lastname = $result[$i]->lastname;
				$username = $result[$i]->username;
				$phone    = $result[$i]->phone1;
				$region   = $regionstr!=''?rtrim($regionstr,", "):'-';
				$state     = $result[$i]->statename;
				$outletname = $result[$i]->o_name;
				$outletcode  = $result[$i]->o_code_latest;
				$designation = $result[$i]->d_name;
				// $topic       = $result[$i]->topic;

				// $quec_id  = $result[$i]->quec_id;
				// $sql1     = "SELECT * FROM mdl_question_categories WHERE id = ".$quec_id."";
				// $result1  = $DB->get_record_sql($sql1);
				// $topic    = $result1[$i]->name;
				// $sql2     = "SELECT * FROM mdl_question_categories WHERE id = ".$category."";
				// $result2  = $DB->get_record_sql($sql2);
				// $sub_category = $result2[$i]->name;
				// $sql2     = "SELECT * FROM mdl_question_categories WHERE id = ".$sub_category."";
				// $result2  = $DB->get_record_sql($sql2);
				// $sub_category = $result2[$i]->name;

				$que_cat  = $result[$i]->quec_id;	
				// echo $que_cat; die;			
				$sql1 = "SELECT * FROM mdl_question_categories WHERE id = ".$que_cat."";
				$result1 = $DB->get_records_sql($sql1);
				foreach($result1 as $res1){
					$parent = $res1->parent; 
					// echo $parent; die;
					if($parent == 0){
						$topic = $res1->name;
						$categoryid   = $res1->id;
					}else{
						$sql2 = "SELECT * FROM mdl_question_categories WHERE id = ".$parent."";
						$result2 = $DB->get_records_sql($sql2);
						foreach($result2 as $res2){
							$parent = $res2->parent;
							// echo $parent; die;
							if($parent == 0){
								$topic = $res2->name;
								$categoryid = $res2->id;
							}else{
								$sql3 = "SELECT * FROM mdl_question_categories WHERE id = ".$parent."";
								$result3 = $DB->get_records_sql($sql3);
								foreach($result3 as $res3){
									$parent = $res3->parent;
									// echo $parent; die;
									if($parent == 0){
										$topic = $res3->name;
							    		$categoryid = $res3->id;
									}else{
										$sql4 = "SELECT * FROM mdl_question_categories WHERE id = ".$parent."";
										$result4 = $DB->get_records_sql($sql4);
										foreach($result4 as $res4){
											$parent = $res4->parent;
											// echo $parent; die;
											$topic = $res4->name;
									    	$categoryid = $res4->id;
																			
										}
									}
																	
								}
							}
						}
					}					
				}
				
				if($categoryid !=0 || $categoryid !='' || $categoryid !=NULL){
					$sql2 = "SELECT * FROM mdl_question_categories WHERE parent = ".$categoryid."";
					$result2 = $DB->get_records_sql($sql2);
					$category = array();
					$prefix = $category = '';
					$prefix = $subcategoryid = '';
					foreach($result2 as $res2){
						$category .= $prefix . ' '. $res2->name;
						$subcategoryid   .= $prefix . ' '. $res2->id;
						$prefix = ', ';
					}
				}
				// echo $subcategoryid; die;
				if($subcategoryid !=0 || $subcategoryid !='' || $subcategoryid !=NULL){
					$sql3 = "SELECT * FROM mdl_question_categories WHERE parent in (".$subcategoryid.")";
					$result3      = $DB->get_records_sql($sql3);
					$sub_category = array();
					$prefix = $sub_category = '';
					foreach($result3 as $res3){
						$sub_category .= $prefix . ' '. $res3->name;
						$prefix = ', ';
					}
				} 

				if($topic == ''){
					$topic = '-';
				}
				if($category == ''){
					$category = '-';
				}
				if($sub_category == ''){
					$sub_category = '-';
				}

				$attemptDetails = $DB->get_record_sql('SELECT qa.sumgrades,qa.state,qa.timefinish FROM mdl_quiz_attempts qa WHERE qa.quiz = ? AND qa.userid = ?',array($quizid,$userid));
				$grademax = $result[$i]->grademax;
				if(empty($attemptDetails)){ //notstarted
					$status = "Not Started";
					$timecompleted = '-';
					$result_status = '-';
					$score = '-';
					$per = '-';
					$profeciency = '-';
				}else if($attemptDetails->state == 'inprogress'){//inprogress
					$status = "Incomplete";
					$timecompleted = '-';
					$result_status = '-';
					$score = '-';
					$per = '-';
					$profeciency = '-';
				}elseif($attemptDetails->state == 'finished'){ //finished
					$status = "Completed";
					$timecompleted = date('d/m/Y',$attemptDetails->timefinish);
					$score = round($attemptDetails->sumgrades);
					$percentage = round(($score*100)/$grademax);
					$per		= $percentage."%";
					if($percentage >= 70){
						$result_status = 'Pass';
					}else{
						$result_status = 'Fail';
					}					
					if($percentage >= 70 && $percentage < 80 && $result_status = 'Pass'){
						$profeciency = 'No Band';
					}
					elseif($percentage >= 80 && $percentage < 85 && $result_status = 'Pass') {
						$profeciency = 'Beginner';
					}
					elseif($percentage >= 85 && $percentage < 90 && $result_status = 'Pass'){
						$profeciency = 'Intermediate';
					}
					elseif($percentage >= 90 && $percentage < 95 && $result_status = 'Pass'){
						$profeciency = 'Advanced';
					}elseif($percentage >=95 && $result_status = 'Pass'){
						$profeciency = 'Expert';
					}
					else{
						$profeciency = 'Fail';
					}					
				}

				$data[$i]['Sr']               = $i+1;
				$data[$i]['AssessmentName']   = $name;
				$data[$i]['EmpName']          = $firstname." ".$lastname;
				$data[$i]['Empcode']          = $username;
				$data[$i]['EmpPhone']         = $phone;
				$data[$i]['Designation']      = $designation;
				$data[$i]['Region']           = $region;
				$data[$i]['State']            = $state!=''?$state:'-';
				$data[$i]['OutletGroup']      = $outletgrpname!=''?$outletgrpname:'-';
				$data[$i]['OutletName']       = $outletname!=''?$outletname:'-';
				$data[$i]['Outlet']           = $outletcode!=''?$outletcode:'-';
				$data[$i]['Status']           = ucwords($status);
				$data[$i]['TotalMarks']       = (int)$grademax;
				$data[$i]['TotalMarksScored'] = $score;
				$data[$i]['PercentageScored'] = $per;
				$data[$i]['Topic']            = $topic;
				$data[$i]['Category']         = $category;
				$data[$i]['SubCategory']      = $sub_category;				
				$data[$i]['ProficiencyLevel'] = $profeciency;
				$data[$i]['PassFail']         = $result_status;
				$data[$i]['DateOfCompletion'] = $timecompleted;
			}
			} else{
				$mysql = "SELECT concat(u.id,'',c.id) as tempid,u.id as userid,u.username,u.phone1,u.firstname,u.lastname,c.id as courseid,q.id as quizid, q.name as quizname,qs.id,qs.questionid,que.category as que_cat,quec.id as quec_id,quec.name as topic,out1.o_code,out1.o_code_latest,out1.o_name,desig.d_name,reg.r_name,st.s_code,st.s_name as statename,gi.grademax,emp.region_id
					FROM {user} u
					INNER JOIN {role_assignments} ra ON ra.userid = u.id
					INNER JOIN {context} ctx ON ctx.id = ra.contextid
					INNER JOIN {course} c ON c.id = ctx.instanceid
					INNER JOIN {course_categories} cat ON cat.id = c.category
					INNER JOIN {quiz} q ON q.course = c.id
					INNER JOIN {quiz_slots} qs ON qs.quizid = q.id
					INNER JOIN {question} que ON que.id = qs.questionid
					INNER JOIN {question_categories} quec ON quec.id = que.category
					INNER JOIN {grade_items} gi ON q.id = gi.iteminstance
					INNER JOIN {ums_employeemaster} emp ON emp.userid = u.id
					LEFT  JOIN {ums_regions} reg ON reg.id = emp.region_id
					LEFT  JOIN {ums_state} st ON st.id  = emp.state_id
					LEFT  JOIN {ums_outlet} out1 ON out1.id = emp.outlet_id
					LEFT  JOIN {ums_designations} desig ON desig.id = emp.designation_id
					WHERE u.deleted = 0 AND ra.roleid = 5 AND ctx.contextlevel = 50 AND u.id <>2 AND gi.itemmodule = 'quiz' AND c.is_set = 1 AND cat.id = 2 ".$filter." group by u.id, c.id, q.id limit 10000";
						// echo $mysql; die;
				
				$results = $DB->get_records_sql($mysql);
						// print_r($results); die;
				
				$i= 0;
				$status = "";
				foreach ($results as $key => $result){
					
					$regionstr = "";
					
					if (count($result) == 1) {

						if($result->region_id!='' && $result->region_id!=0){
							$regionidtemp = explode(",",$result->region_id);
							foreach($regionidtemp as $rid){
								$regionname	=	$DB->get_field("ums_regions","r_name",array("id"=>$rid));
								$regionstr .= $regionname.", ";
							}
						}

					} else {

						if($result[$i]->region_id!='' && $result[$i]->region_id!=0){
							$regionidtemp = explode(",",$result[$i]->region_id);
							foreach($regionidtemp as $rid){
								$regionname	=	$DB->get_field("ums_regions","r_name",array("id"=>$rid));
								$regionstr .= $regionname.", ";
							}
						}

					}
					
					
					$quizid   = $result->quizid;
					$courseid = $result->courseid;
					$userid   = $result->userid;
					$name  	  = $result->quizname;
					$firstname= $result->firstname;
					$lastname = $result->lastname;
					$username = $result->username;
					$phone    = $result->phone1;
					$region   = $regionstr!=''?rtrim($regionstr,", "):'-';
					$state    = $result->s_code;
					$outletname = $result->o_name;
					$outletcode  = $result->o_code_latest;
					$designation = $result->d_name;
					// $topic       = $result[$i]->topic;

					$que_cat  = $result->quec_id;
					// echo $que_cat; die;				
					$sql1 = "SELECT * FROM mdl_question_categories WHERE id = ".$que_cat."";
					$result1 = $DB->get_records_sql($sql1);
					foreach($result1 as $res1){
						$parent = $res1->parent; 
						// echo $parent; die;
						if($parent == 0){
							$topic = $res1->name;
							$categoryid   = $res1->id;
						}else{
							$sql2 = "SELECT * FROM mdl_question_categories WHERE id = ".$parent."";
							$result2 = $DB->get_records_sql($sql2);
							foreach($result2 as $res2){
								$parent = $res2->parent;
								// echo $parent; die;
								if($parent == 0){
									$topic = $res2->name;
									$categoryid = $res2->id;
								}else{
									$sql3 = "SELECT * FROM mdl_question_categories WHERE id = ".$parent."";
									$result3 = $DB->get_records_sql($sql3);
									foreach($result3 as $res3){
										$parent = $res3->parent;
										// echo $parent; die;
										$topic = $res3->name;
								    	$categoryid = $res3->id;								
									}
								}
							}
						}					
					}
					
					if($categoryid !=0 || $categoryid !='' || $categoryid !=NULL){
						$sql2 = "SELECT * FROM mdl_question_categories WHERE parent = ".$categoryid."";
						$result2 = $DB->get_records_sql($sql2);
						$category = array();
						$prefix = $category = '';
						foreach($result2 as $res2){
							$category .= $prefix . ' '. $res2->name;
							$prefix = ', ';
							$subcategoryid   = $res2->id;
						}
					}

					if($subcategoryid !=0 || $subcategoryid !='' || $subcategoryid !=NULL){
						$sql3 = "SELECT * FROM mdl_question_categories WHERE parent = ".$subcategoryid."";
						$result3      = $DB->get_records_sql($sql3);
						$sub_category = array();
						$prefix = $sub_category = '';
						foreach($result3 as $res3){
							$sub_category .= $prefix . ' '. $res3->name;
							$prefix = ', ';
						}
					} 

					if($topic ==''){
						$topic = '-';
					}
					if($category == ''){
						$category = '-';
					}
					if($sub_category == ''){
						$sub_category = '-';
					}

					$attemptDetails = $DB->get_record_sql('SELECT count(*) as cnt FROM mdl_quiz_attempts qa WHERE qa.quiz = ? AND qa.userid = ?',array($quizid,$userid));
					
					$outletID       = $DB->get_field('ums_outlet','outlet_group_id', array('o_code_latest'=>$row->o_code_latest));
					$outletgrpname  = $DB->get_field('ums_outlet_group','og_name', array('id'=>$outletID));
					
					if($attemptDetails->cnt == 0){
						$status = "Not Started";
						$timecompleted = '-';
						$result_status = '-';
						$score = '-';
						$per = '-';
						$profeciency = '-';
					}
					if($attemptDetails->cnt == 0){
						$data[$i]['Sr']               = $i+1;
						$data[$i]['AssessmentName']   = $name;
						$data[$i]['EmpName']          = $firstname." ".$lastname;
						$data[$i]['Empcode']          = $username;
						$data[$i]['EmpPhone']         = $phone;
						$data[$i]['Designation']      = $designation;
						$data[$i]['Region']           = $region;
						$data[$i]['State']            = $state;
						$data[$i]['OutletGroup']      = $outletgrpname!=''?$outletgrpname:'-';
						$data[$i]['OutletName']       = $outletname;
						$data[$i]['Outlet']           = $outletcode;
						$data[$i]['Status']           = ucwords($status);
						$data[$i]['TotalMarks']       = (int)$result->grademax;
						$data[$i]['TotalMarksScored'] = $score;
						$data[$i]['PercentageScored'] = $per;
						$data[$i]['Topic']            = $topic;
						$data[$i]['Category']         = $category;
						$data[$i]['SubCategory']      = $sub_category;				
						$data[$i]['ProficiencyLevel'] = $profeciency;
						$data[$i]['PassFail']         = $result_status;
						$data[$i]['DateOfCompletion'] = $timecompleted;	
						$i++;
					}
				}
			} //eof notstarted

			echo json_encode($data);
		}
	   
	    function unixToNormalLong($timestamp)
		{
			if($timestamp==0 && $timestamp==NULL)
			{
				return '-';
			}
			else
			{
				return gmdate("d/m/Y", $timestamp+((3500)*5.5));
			}
		}

		function courseLastAccess($userid,$courseid)
		{
			global $DB;
			$sql="SELECT * FROM mdl_user_lastaccess where userid=$userid and courseid=$courseid";
			$result=$DB->get_records_sql($sql, array());
			$lastaccess	="0";
			foreach($result as $rows)
			{
				if(isset($rows->timecreated)){

					$lastaccess = $rows->timecreated;
				}
			}
			return $lastaccess;
		}
		
		function assessmentList($selected='')
		{
			global $DB;
			
			$mysql = "select
				a.id as id,
				a.fullname as coursename,
				q.name as quizname,
				q.id as quizid
				from {course} as a
				inner join {course_categories} as b on(b.id=a.category)
				inner join {quiz} as q on(q.course=a.id)
				where b.id IN (2) AND a.is_set = 1 ORDER BY a.fullname";// old where b.id IN (2,3) bcoz cat=2 is for assessment and 3=course in mdl_course_categories tbl.
			$result=$DB->get_records_sql($mysql, array());
			$list     = '';
			$selected = '';
			foreach($result as $rows)
			{
				$id 	= $rows->quizid;
				$quizname = $rows->quizname;	
				if($rows->id==$selected) $val='selected';									
				$list .= "<option value=".$id.">".ucwords($quizname)."</option>";
			}
			return $list;
		}
		
				
		function regionlist($selected="")
		{
			global $DB;

			$filter = "";
			if ($this->isDealerLogin()) {
				
				$regionId = $this->getRegionId();
				$filter = " AND id IN ($regionId)";
			}

			$result = $DB->get_records_sql("SELECT * FROM {ums_regions} WHERE deleted = 0 $filter order by r_name ASC", array());
			$list="";
			$selected="";
			foreach($result as $rows)
			{
				$rid = $rows->id;
				$rname  = $rows->r_name;	
				if($rows->id==$selected) $val='selected';	
				$list .= "<option value=".$rid.">".ucwords($rname)."</option>";
			}
			return $list;
		}
		
		function chaneellist($selected="")
		{
			global $DB;
			$result = $DB->get_records_sql('SELECT * FROM {ums_channels} WHERE deleted = 0 order by c_abbr_name ASC', array());
			$list="";
			$selected="";
			foreach($result as $rows)
			{
				$chid         = $rows->id;
				$c_abbr_name  = $rows->c_abbr_name;	
				if($rows->id==$selected) $val='selected';	
				$list .= "<option value=".$chid.">".ucwords($c_abbr_name)."</option>";
			}
			return $list;
		}
		
		function topiclist($selected="")
		{
			global $DB;
			$result = $DB->get_records_sql('SELECT id, name FROM {question_categories} WHERE parent = 0 order by name ASC', array());
			$list="";
			$selected="";
			foreach($result as $rows)
			{
				$resultchk = $DB->get_records_sql('SELECT id FROM {question_categories} WHERE parent = "'.$rows->id.'"');
				if(count($resultchk)>0){
					$chid  = $rows->id;
					$name  = $rows->name;	
					if($rows->id==$selected) $val='selected';	
					$list .= "<option value=".$chid.">".ucwords($name)."</option>";
				}
				
			}
			return $list;
		}

		function outletgrouplist($selected="")
		{
			global $DB;

			$filter = "";
			if ($this->isDealerLogin()) {
				
				$outletGroupId = $this->getOutletGroupId();
				$filter .= " AND id IN ($outletGroupId)";
			}

			$result = $DB->get_records_sql("SELECT id,og_name,og_code,deleted FROM {ums_outlet_group} where deleted =0 $filter ORDER BY og_name ASC", array());
			$list="";
			$selected="";
			foreach($result as $rows)
			{
				$chid         = $rows->id;
				$og_name  = $rows->og_name;	
				if($rows->id==$selected) $val='selected';	
				$list .= "<option value=".$chid.">".ucwords($og_name)."</option>";
			}
			return $list;
		}
		
		function designationlist()
		{
		    global $DB;
			
			/* $result = $DB->get_records_sql("SELECT id, d_name FROM mdl_ums_designations where deleted = 0 AND id NOT IN(1,11,202,203) ORDER BY d_name"); *///hide Admin, FSDM, CBH, RM designations
			
			$result = $DB->get_records_sql("SELECT id, d_name FROM mdl_ums_designations where deleted = 0 AND id!=1 AND d_name IN('NCM' , 'NQM' , 'NRM' , 'NSC' , 'NSM' , 'NSR' , 'NTD','RRM','NMF','NAM','NFM','NAC') ORDER BY d_name", array());
			
			$list="";
			foreach($result as $row)
			{
				$did1 	= $row->id;
				$dname1 = $row->d_name;
				$list .= "<option value=".$did1.">".ucwords($dname1)."</option>";
			}
			
			$list .= "<option value='159' style='font-weight:bold;'><strong>AM</strong></option>";
			$list .= "<option value='202' style='font-weight:bold;'><strong>CBH</strong></option>";
			$list .= "<option value='11' style='font-weight:bold;'><strong>FSDM</strong></option>";
			$list .= "<option value='10' style='font-weight:bold;'><strong>HO</strong></option>";
			$list .= "<option value='209' style='font-weight:bold;'><strong>MSIL-DMS</strong></option>";
			$list .= "<option value='203' style='font-weight:bold;'><strong>RM</strong></option>";
			$list .= "<option value='204' style='font-weight:bold;'><strong>TSM</strong></option>";
			$list .= "<option value='205' style='font-weight:bold;'><strong>Divisional Head</strong></option>";
			$list .= "<option value='206' style='font-weight:bold;'><strong>Department Head</strong></option>";
			$list .= "<option value='208' 
			style='font-weight:bold;'><strong>Field Team</strong></option>";
			return $list;
		}
		
		function getDesignation($currUID){
			global $DB;
			$cnd = '';$this->response = array();
			if($currUID!='' && $currUID > 0){
				$sqlData = $DB->get_record_sql("SELECT designation_id FROM mdl_ums_employeemaster WHERE userid = '".$currUID."'");
				
				if(count($sqlData) > 0){
					$desigID = $sqlData->designation_id;
					if($desigID == 79){//NTD - outlet(dealer)
						$getData = $DB->get_record_sql("SELECT outlet_id FROM mdl_ums_employeemaster WHERE userid = '".$currUID."'");
						if(count($getData) > 0){
							$this->response['filterby'] = "outlet";
							$this->response['filterid'] = $getData->outlet_id;
						}	
					}
					else if($desigID == 11 || $desigID == 159 || $desigID == 202 || $desigID == 203 || $desigID == 204 || $desigID == 205 || $desigID == 206){//FSDM,CBH,RM, TSM, DVM, DPM - region
						$getData = $DB->get_record_sql("SELECT region_id FROM mdl_ums_employeemaster WHERE userid = '".$currUID."'");
							$this->response['filterby'] = "region";
							$this->response['filterid'] = $getData->region_id!=''?$getData->region_id:0;
					}
				}
			}
			return $this->response;
		}
		
}


if(isset($_GET['__u__']) && !empty($_GET['__u__']))
{
	$userid = $_GET['__u__'];
}
else
{
	$userid = $USER->id;
}
$obj = new Assessment($USER->id);
if(isset($_GET['__g__']) && $_GET['__g__'] == 'data')
{
	$obj->getJsonData();
}
if(isset($_GET['__g__']) && $_GET['__g__'] == 'data1')
{
	$obj->getIndividualAssessmentJsonData();
}
?>