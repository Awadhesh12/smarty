<?php

// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External Web Service Template
 *
 * @package    localwstemplate
 * @copyright  2011 Moodle Pty Ltd (http://moodle.com)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
ini_set('max_execution_time', 0);
require_once("$CFG->libdir/externallib.php");
include_once("$CFG->dirroot/course/externallib.php");
include_once("$CFG->folder/local/pagecontainer/getID3/getid3/getid3.php");
require_once("$CFG->dirroot/local/pagecontainer/lms/activity_report_class.php");
//echo '../pagecontainer/custom_methods.php';
//require_once('../pagecontainer/custom_methods.php');
include_once("$CFG->folder/local/pagecontainer/gamification/lms_like_comment_point_update.php");

class mobile_webservices extends external_api {


public static function verify_version_parameters() {
        return new external_function_parameters(
                array('version' => new external_value(PARAM_RAW, 'version'),
                      'platform' => new external_value(PARAM_TEXT, 'platform')
                    )
        );
    }
  
   public static function verify_version($version,$platform) {
        global $DB,$USER;
       
        $v = array();
	
	if($version=='6.1' || $version=='6.2.0' || $version=='6.1.0' || $version=='6.2' || $version=='50.0')
		{

			if($platform=='ios' || $platform=='android'){

				$v['status'] = 'Verified';//commented to crash webservice for android only(ask later to App developer to enable or not)
			}
		}
		else
		{
			if($platform=='ios' || $platform=='android'){
				$v['status'] = 'Not Verified';//commented to crash webservice for android only
			}
			
		}
		
        
       /*
$sql = 'SELECT * FROM {app_version_check} where type = "'.$platform.'" And version = "'.$version.'"';	   
	   $records = $DB->get_record_sql($sql);

        if(!empty($records)){
			if($platform=='ios'){
				$v['status'] = 'Verified';//commented to crash webservice for android only(ask later to App developer to enable or not)
			}
        }else{
			if($platform=='ios'){
				$v['status'] = 'Not Verified';//commented to crash webservice for android only
			}
        }
		$v['v1']=$version;
		$v['p']=$platform;
		*/
        return $v;
    }
  
  public static function verify_version_returns() {
       return  new external_single_structure(
       array('status'=> new external_value(PARAM_RAW, 'mobile app version')
       ));
    }

public static function force_update_parameters() {
        return new external_function_parameters(
                array('version' => new external_value(PARAM_RAW, 'version'),
                      'platform' => new external_value(PARAM_TEXT, 'platform')
                    )
        );
    }
	
	public static function force_update($version,$platform) {
        global $DB,$USER;
       
       
    }
 public static function force_update_returns() {
       return  new external_single_structure(
       array('status'=> new external_value(PARAM_RAW, 'mobile app version')
       ));
    }

 public static function hello_world_parameters()
     {

        return new external_function_parameters(

                array('userid' => new external_value(PARAM_INT, 'Retrieve information based on userid ', VALUE_DEFAULT, 2))
                );

    }

    /**

     * Returns welcome message

     * @return string welcome message

     */

    public static function hello_world() {

        global $USER;
        //Parameter validation

        // $result = new stdClass();

         $subresult = new stdClass();
       $subresult->status = 'true';
      
       return $subresult;

    }

      

      public static function hello_world_returns()
     {

     return new external_single_structure(
                array(
            'status' => new external_value(PARAM_TEXT, 'Name of the cert'),
          )
        );
      }



  public static function get_myupcomingcert_parameters() {

      return new external_function_parameters(
              array()
      );
  }


   public static function get_myupcomingcert() 
   {
	     // function for upcoming
         global $USER, $DB, $CFG;
        
        $params = self::validate_parameters(self::get_myprofile_parameters(), array('welcomemessage' => $welcomemessage));

        
        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);
		
		$result = new stdClass();
        $result->name = 'HStep2 Chassis';
        $result->startdate = '28/11/2017';
        return $result;
		
  }

  public static function get_myupcomingcert_returns() {
    return new external_single_structure(
            array(
        'name' => new external_value(PARAM_TEXT, 'Name of the cert'),
        'startdate' => new external_value(PARAM_TEXT, 'Date')
            )
    );
  }





 public static function get_mycertifications_parameters() {

      return new external_function_parameters(
              array()
      );
  }



    public static function get_mycertifications(){
    global $USER, $DB, $CFG;
        

        // print_r($USER);
        $params = self::validate_parameters(self::get_myprofile_parameters(), array('welcomemessage' => $welcomemessage));

        $userid= $USER->id;
        
        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);

        $allcertificates = $DB->get_records_sql('SELECT * FROM {certificate}');

        // print_r($allcertificates);
        $newresult = array();
        foreach ($allcertificates as $key => $allcertificate) {

              $completedcount = 0;
              $totalcount = 0;
              $coursecompletedcount = 0;
              $totalcoursecount = 0;

          if(!empty($allcertificate->assessment_id) && !empty($allcertificate->course_id)){

            $coursecontext = context_course::instance($allcertificate->course_id);
            $getquizcourseid = $DB->get_record('quiz',array('id'=>$allcertificate->assessment_id));
            $quizcoursecontext = context_course::instance($getquizcourseid->course);
            // $quizcoursecontext = $quizcoursecontext->id;

            $isenrolledin_course = is_enrolled($coursecontext, $userid);

            $isenrolledinassessment_course = is_enrolled($quizcoursecontext, $userid);

            if(!empty($isenrolledin_course) && !empty($isenrolledinassessment_course)){

            $assessment_courseid = $allcertificate->assessment_id;        
            // $quizs = $DB->get_records_sql("SELECT * FROM {quiz} WHERE course =?",array($assessment_courseid));
            // print_r($quizs);
  
              $checkquiz  = $DB->get_records_sql('SELECT * from {quiz_attempts} WHERE  quiz =? AND userid =? AND state = ?',array($allcertificate->assessment_id,$userid,'finished'));
              if(!empty($checkquiz)){
                  $completedcount++;
                $is_assessmentcoursecompleted = "Yes";
              }else{
                  $is_assessmentcoursecompleted = "No";
              }

            $courseid = $allcertificate->course_id;     
            // echo $courseid; 
            $scorms = $DB->get_records('scorm',array('course'=>$courseid));
            // print_r($scorms);
            foreach ($scorms as $key => $scorm) {
              $checkscorm  = $DB->get_record_sql('SELECT * from {scorm_scoes_track} WHERE  scormid =? AND userid =? AND element = ? OR element',array($scorm->id,$userid,'cmi.core.lesson_status','cmi.completion_status'));
              // print_r($checkscorm);
              if($checkscorm->value =="completed" OR $checkscorm->value =="passed"){
                $coursecompletedcount++;
              }
                $totalcoursecount++;
            }
              if($totalcoursecount == $coursecompletedcount){
                  $iscoursecompleted = "Yes";
              }else{
                  $iscoursecompleted = "No";
              }

              if($is_assessmentcoursecompleted == "Yes" && $iscoursecompleted == "Yes"){
                 $coursedetails = $DB->get_record('course',array('id'=>$allcertificate->course_id));

                  $result = new stdClass();
                  $result->courseid = $courseid;
                  $result->coursename = $coursedetails->fullname;
                  $result->assessmentid = $allcertificate->assessment_id;
                  $result->assessmentname =  $getquizcourseid->name;
                  $result->certifacte_name = $allcertificate->certificate_name;
                  $result->startdate = $allcertificate->created;
                  $newresult[] = $result;

              }
              // echo $iscoursecompleted;


            }
           
          }elseif(!empty($allcertificate->assessment_id)){
    

            $getquizcourseid = $DB->get_record('quiz',array('id'=>$allcertificate->assessment_id));

            $quizcoursecontext = context_course::instance($getquizcourseid->course);
            // $coursedetails = $DB->get_record('course',array('id'=>$allcertificate->assessment_id));
            $isenrolledinassessment_course = is_enrolled($quizcoursecontext, $userid);
            if(!empty($isenrolledinassessment_course)){

              $assessment_courseid = $allcertificate->assessment_id;        
                $checkquiz  = $DB->get_record_sql('SELECT * from {quiz_attempts} WHERE  quiz =? AND userid =? AND state = ?',array($allcertificate->assessment_id,$userid,'finished'));
                if(!empty($checkquiz)){
                  $completedcount++;
                
                  $result = new stdClass();
                  $result->assessmentid = $allcertificate->assessment_id;
                  $result->assessmentname =  $getquizcourseid->name;
                  $result->certifacte_name = $allcertificate->certificate_name;
                  $result->startdate = $allcertificate->created;
                  $newresult[] = $result;

              }

            }


          }elseif(!empty($allcertificate->course_id)){



            $coursedetails = $DB->get_record('course',array('id'=>$allcertificate->course_id));

             $coursecontext = context_course::instance($allcertificate->course_id);
             $isenrolledin_course = is_enrolled($coursecontext, $userid);
             if(!empty($isenrolledin_course)){

            $courseid = $allcertificate->course_id;     
            // echo $courseid; 
            $scorms = $DB->get_records('scorm',array('course'=>$courseid));
            // print_r($scorms);
            foreach ($scorms as $key => $scorm) {
              $checkscorm  = $DB->get_record_sql('SELECT * from {scorm_scoes_track} WHERE  scormid =? AND userid =? AND element = ? OR element',array($scorm->id,$userid,'cmi.core.lesson_status','cmi.completion_status'));
              // print_r($checkscorm);
              if($checkscorm->value =="completed" OR $checkscorm->value =="passed"){
                $coursecompletedcount++;
                }
                  $totalcoursecount++;
              }
              if($totalcoursecount == $coursecompletedcount){

                  $result = new stdClass();
                  $result->courseid = $courseid;
                  $result->coursename = $coursedetails->fullname;
                  $result->certifacte_name = $allcertificate->certificate_name;
                  $result->startdate = $allcertificate->created;
                  $newresult[] = $result;

              }

             }

          }
 // die;
        }

        return $newresult;
    
      
  }



      public static function get_mycertifications_returns() {
      return new external_multiple_structure(
        new external_single_structure(
            array(
             'courseid' => new external_value(PARAM_RAW, 'Course id', VALUE_OPTIONAL),
             'coursename' => new external_value(PARAM_RAW, 'Name of the Course', VALUE_OPTIONAL),
             'assessmentid' => new external_value(PARAM_RAW, 'assessment id', VALUE_OPTIONAL),
             'assessmentname' => new external_value(PARAM_RAW, 'Name of the category', VALUE_OPTIONAL),
             'certifacte_name' => new external_value(PARAM_RAW, 'Name of the cert'),
             'startdate' => new external_value(PARAM_RAW, 'Date')
            )
     ));
  }






    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_myprofile_parameters() {

        return new external_function_parameters(
                array('welcomemessage' => new external_value(PARAM_TEXT, 'The welcome message. By default it is "Hello world,"', VALUE_DEFAULT, 'Hello world, '))
        );
    }

        /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function get_myprofile($welcomemessage = 'Hello world') {
        global $USER, $DB, $CFG;
        //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::get_myprofile_parameters(), array('welcomemessage' => $welcomemessage));

        //Context validation
        //OPTIONAL but in most web service it should present
        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);
      
        $employee = $DB->get_record_sql("SELECT ue.*,ud.d_name as designation,usd.sd_name as subdesignation,uch.c_abbr_name as channel,uut.ut_name as usertype ,uo.o_name as outlet,uo.o_code_latest as outletcode,us.s_name as state,uc.c_name as city,ue.tl_mspin_no as tl_mspin,uog.og_name as outletgroupname, ue.points_earned as points_earned, ue.certification_level as certification_level,ue.user_type_id FROM {user} u LEFT JOIN {ums_employeemaster} ue on u.id = ue.userid LEFT JOIN {ums_designations} ud on ue.designation_id = ud.id LEFT JOIN {ums_sub_designations} usd ON ue.sub_designation_id = usd.id LEFT JOIN {ums_channels} uch ON ue.channels_id = uch.id LEFT JOIN {ums_user_type} uut ON ue.user_type_id = uut.id LEFT JOIN {ums_outlet} uo ON ue.outlet_id = uo.id LEFT JOIN {ums_outlet_group} uog ON uog.id = uo.outlet_group_id LEFT JOIN {ums_state} us ON ue.state_id = us.id LEFT JOIN {ums_city} uc ON ue.city_id = uc.id WHERE u.id = $USER->id");

        //print_r($employee->gender);exit;

        $tlname = $DB->get_record('user',array('username'=>$employee->tl_mspin));
     
        $teamlead = $tlname->firstname.' '.$tlname->lastname;
		
		$regionstr = "";
		if($employee->region_id!=''){
			$regionidtemp = explode(",",$employee->region_id);
			foreach($regionidtemp as $rid){
				$regionname	=	$DB->get_field("ums_regions","r_name",array("id"=>$rid));
				$regionstr .= $regionname.", ";
			}
		}
		
		//----------------------------------------------------------//
		if($employee->expression_user ==1)
		{
			$expression = 'Yes';
		}
        else
		{
			$expression = 'No';
		}
		//---------------------------------------------------------//
		if($employee->bestpractice_user ==1)
		{
			$bestpractice = 'Yes';
		}
        else
		{
			$bestpractice = 'No';
		}
		if($employee->user_type_id ==1 || $employee->user_type_id ==2)
		{
			$openhouse = 'No';
		}
        else
		{
			$openhouse = 'Yes';
		}

    /* Modified Date : 14 May 2020
    Added code for Monthly count

    */
    $today  = date("Y-m-d"); // todays date
    $thismonthstart = date('Y-m-01'); // start date of current month
    $thismonth_sql = "SELECT count(*) as total_question FROM mdl_question_of_day WHERE qdate >= '".$thismonthstart."' AND qdate <= '".$today."'"; 
    $sqlData       = $DB->get_record_sql($thismonth_sql);
    $thismonth_total_question = $sqlData->total_question;
      
    $month = date("Y-m");// here we get current month
    $thismonth_sql_ans = "SELECT answer FROM mdl_question_of_day_correct_answer WHERE mspin = '".$USER->username."' AND month = '".$month."'"; 
    $sqlData_1m = $DB->get_record_sql($thismonth_sql_ans);
	//$outletname!=''?$outletname:'-'
    $thismonth_correct_ans = $sqlData_1m->answer!=''?$sqlData_1m->answer:'0';
    $score_this_month = $thismonth_total_question."-".$thismonth_correct_ans;
    // total question and total question answer given
    $rank_this_month  = number_format((($thismonth_correct_ans/$thismonth_total_question)*100),2);
    /* Monthly Count Code End */

       /*$primg=$CFG->wwwroot.'/images/avatar1.png';
       if($employee->profile_photo_upload){
         $primg=$CFG->wwwroot.'/upload/profile/'.$employee->profile_photo_upload;
       }*/

       $primg='';
		if($employee->profile_photo_upload!=null || $employee->profile_photo_upload != '')
		{
			$primg=$CFG->wwwroot.'/upload/profile/'.$employee->profile_photo_upload;
		}else{
			//$primg='https://ilearnnexa.marutisuzuki.com/images/avatar3.png';

	      if($employee->gender == 'M')
	      {
	        $primg='https://ilearn.marutisuzuki.com/images/avatar1.png';
	      }else if($employee->gender == 'F'){
	        $primg='https://ilearn.marutisuzuki.com/images/female-avatar.png';
	      }
		}
		//echo $primg;exit;

       $isdealeravailable=0;
       if($employee->user_type_id==""){
         $isdealeravailable=1;
       }

        $profile = array(
            'id' => $USER->id,
            'empcode' => $USER->username,
            'name' => $USER->firstname.' '.$USER->lastname,
            'contactno' => $USER->phone1,
            'password' => $employee->password,
            // 'empdob' => $empdob,
            'email' => $USER->email,
            'designation' => $employee->designation,
            'subdesignation' => $employee->subdesignation,
            'TL'=>$teamlead,
            'channel' => $employee->channel,
            'usertype' => $employee->usertype,
            'outletid'=>$employee->outletcode,
            'outlet' => $employee->outlet,
            'outletgroupname'=>$employee->outletgroupname,
            'region' => $regionstr!=''?rtrim($regionstr,", "):'--',
            'state' => $employee->state,
            'city' => $employee->city,
            'points_earned' =>  $employee->points_earned,
            'certification_level' =>  $employee->certification_level ,
			'is_Expression' => $expression,
			'is_Bestpractice' => $bestpractice,
			'is_openhouseallowed' => $openhouse,
            // 'mspin' => $employee->mspin
      /* 14 May 2020 */
            'questioncount' => $thismonth_total_question,
      'answercount'   => $thismonth_correct_ans,
      'current_month_question_answer_status' => $thismonth_correct_ans."/".$thismonth_total_question,
      'userpic'=>$primg,
      'isdealeravailable'=>$isdealeravailable
        );

        return $profile;
        // return $params['welcomemessage'] . $USER->firstname .$coursename;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_myprofile_returns() {
        // return new external_value(PARAM_TEXT, 'The welcome message + user first name');
        return new external_single_structure(
                array(
            'id' => new external_value(PARAM_INT, 'id of user'),
            'empcode' => new external_value(PARAM_TEXT, 'Emp Code/GDMS Code'),
            'name' => new external_value(PARAM_TEXT, 'Name'),
            'contactno' => new external_value(PARAM_TEXT, 'Phone number'),
            'password' => new external_value(PARAM_TEXT, 'Password'),
            'email' => new external_value(PARAM_TEXT, 'Email id'),
            'designation' => new external_value(PARAM_TEXT, 'Designation'),
            'subdesignation' => new external_value(PARAM_TEXT, 'Sub Designation'),
            'TL' =>new external_value(PARAM_RAW,'tl_mspin'),
            'channel' => new external_value(PARAM_TEXT, 'Chanel'),
            'usertype' => new external_value(PARAM_TEXT, 'User Type'),
            'outletid' => new external_value(PARAM_RAW,'outletid'),
            'outlet' => new external_value(PARAM_TEXT, 'Outlet'),
            'outletgroupname' => new external_value(PARAM_TEXT,'outletgroupname'),
            'region' => new external_value(PARAM_TEXT, 'Region'),
            'state' => new external_value(PARAM_TEXT,'State'),
            'city' => new external_value(PARAM_TEXT,'City'),
            'points_earned' => new external_value(PARAM_TEXT,'Points Earned'),
            'certification_level' => new external_value(PARAM_TEXT,'Certification Level'),
            'is_Expression' => new external_value(PARAM_TEXT,'Expression'),
            'is_Bestpractice' => new external_value(PARAM_TEXT,'Best Practice'),
            'is_openhouseallowed' => new external_value(PARAM_TEXT,'Open House'),
            'questioncount' => new external_value(PARAM_INT,'questioncount'),
            'answercount'   => new external_value(PARAM_INT,'answercount'),
            'current_month_question_answer_status' => new external_value(PARAM_TEXT,'current_month_question_answer_status'),
            'userpic'=> new external_value(PARAM_TEXT,'userpic'),
            'isdealeravailable'=> new external_value(PARAM_TEXT,'isdealeravailable')
            // 'mspin' => new external_value(PARAM_TEXT,'MSPIN')
                )
        );
    }
//------------------------new profile---------------------------------

    public static function get_myprofilenew_parameters() {

        return new external_function_parameters(
                array('welcomemessage' => new external_value(PARAM_TEXT, 'The welcome message. By default it is "Hello world,"', VALUE_DEFAULT, 'Hello world, '))
        );
    }
    public static function get_myprofilenew($welcomemessage = 'Hello world') {
        global $USER, $DB, $CFG;

    $totalcourses=0;
    $normalcourses=0;
    $learningpathcourses=0;
    $assessments=0;
    $surveys=0;
    $courses = enrol_get_users_courses($USER->id, false, 'id, shortname, fullname, idnumber, visible,
                   summary, summaryformat, format, showgrades, lang, enablecompletion, category, startdate, enddate');
         foreach ($courses as $key => $course) 
         {
           if($course->visible == 1)
           {
               switch($course->category)
               {
                case '2':
                $assessments++;
                break;
                case '3':
                $normalcourses++;
                $totalcourses++;
                break;
                case '4':
                $learningpathcourses++;
                $totalcourses++;
                break;
                case '11':
                $surveys++;
                break;
                  
               }
           }
         }
         //echo $normalcourses;exit;
        //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::get_myprofile_parameters(), array('welcomemessage' => $welcomemessage));

        //Context validation
        //OPTIONAL but in most web service it should present
        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);
      
        $employee = $DB->get_record_sql("SELECT ue.*,ud.d_name as designation,usd.sd_name as subdesignation,uch.c_abbr_name as channel,uut.ut_name as usertype ,uo.o_name as outlet,uo.o_code_latest as outletcode,us.s_name as state,uc.c_name as city,ue.tl_mspin_no as tl_mspin,uog.og_name as outletgroupname, ue.points_earned as points_earned, ue.certification_level as certification_level,ue.user_type_id FROM {user} u LEFT JOIN {ums_employeemaster} ue on u.id = ue.userid LEFT JOIN {ums_designations} ud on ue.designation_id = ud.id LEFT JOIN {ums_sub_designations} usd ON ue.sub_designation_id = usd.id LEFT JOIN {ums_channels} uch ON ue.channels_id = uch.id LEFT JOIN {ums_user_type} uut ON ue.user_type_id = uut.id LEFT JOIN {ums_outlet} uo ON ue.outlet_id = uo.id LEFT JOIN {ums_outlet_group} uog ON uog.id = uo.outlet_group_id LEFT JOIN {ums_state} us ON ue.state_id = us.id LEFT JOIN {ums_city} uc ON ue.city_id = uc.id WHERE u.id = $USER->id");

        $tlname = $DB->get_record('user',array('username'=>$employee->tl_mspin));
     
        $teamlead = $tlname->firstname.' '.$tlname->lastname;
    
    $regionstr = "";
    if($employee->region_id!=''){
      $regionidtemp = explode(",",$employee->region_id);
      foreach($regionidtemp as $rid){
        $regionname = $DB->get_field("ums_regions","r_name",array("id"=>$rid));
        $regionstr .= $regionname.", ";
      }
    }


//new code of dealer 

    //---------------------------------------------------------//


    if($employee->user_type_id == 1 || $employee->user_type_id == 2)
    {
      $is_msil_users = 'Yes';
    }
    else
    {
      $is_msil_users = 'No';
    }
    //---------------------------------------------------------//


    if($employee->user_type_id == 0 || $employee->user_type_id == '')
    {
      $is_dealer = 'Yes';
    }
    else
    {
      $is_dealer = 'No';
    }
    //--------------------------------------------------------//

    if( $is_dealer == 'Yes'){
      // echo $CFG->wwwroot; die;
      $url = $CFG->wwwroot.'/local/pagecontainer/lms/mobile_adl_assessment_report.php?mspin='.$USER->username;
      // $url = 'https://ilearnnexa.marutisuzuki.com/local/pagecontainer/lms/mobile_sat_assessment_report.php';
      $sat_report_name = 'ADL Report';
    }
    else{
      $url = '';
      $sat_report_name = '';
    }


// end here
    
    //----------------------------------------------------------//
    if($employee->expression_user ==1)
    {
      $expression = 'Yes';
    }
        else
    {
      $expression = 'No';
    }
    //---------------------------------------------------------//
    if($employee->bestpractice_user ==1)
    {
      $bestpractice = 'Yes';
    }
        else
    {
      $bestpractice = 'No';
    }
    if($employee->user_type_id ==1 || $employee->user_type_id ==2)
    {
      $openhouse = 'No';
    }
        else
    {
      $openhouse = 'Yes';
    }

    $primg='';
		if($employee->profile_photo_upload!=null || $employee->profile_photo_upload != '')
		{
			$primg=$CFG->wwwroot.'/upload/profile/'.$employee->profile_photo_upload;
		}else{
			//$primg='https://ilearnnexa.marutisuzuki.com/images/avatar3.png';

	      if($employee->gender == 'M')
	      {
	        $primg='https://ilearn.marutisuzuki.com/images/avatar1.png';
	      }else if($employee->gender == 'F'){
	        $primg='https://ilearn.marutisuzuki.com/images/female-avatar.png';
	      }else{
          $primg='https://ilearn.marutisuzuki.com/images/avatar3.png';
        }
		}
    /*if($employee->profile_photo_upload!=null || $employee->profile_photo_upload != '')
    {
      $primg=$CFG->wwwroot.'/upload/profile/'.$employee->profile_photo_upload;
    }else{
      $primg=$CFG->wwwroot.'/images/avatar3.png';
    }*/

    /* Modified Date : 14 May 2020
    Added code for Monthly count

    */
      $today  = date("Y-m-d"); // todays date
      $thismonthstart = date('Y-m-01'); // start date of current month
      $thismonth_sql = "SELECT count(*) as total_question FROM mdl_question_of_day WHERE qdate >= '".$thismonthstart."' AND qdate <= '".$today."'"; 
      $sqlData       = $DB->get_record_sql($thismonth_sql);
      $thismonth_total_question = $sqlData->total_question;
        
      $month = date("Y-m");// here we get current month
      $thismonth_sql_ans = "SELECT answer FROM mdl_question_of_day_correct_answer WHERE mspin = '".$USER->username."' AND month = '".$month."'"; 
      $sqlData_1m = $DB->get_record_sql($thismonth_sql_ans);
    //$outletname!=''?$outletname:'-'
      $thismonth_correct_ans = $sqlData_1m->answer!=''?$sqlData_1m->answer:'0';
      $score_this_month = $thismonth_total_question."-".$thismonth_correct_ans;
      // total question and total question answer given
      $rank_this_month  = number_format((($thismonth_correct_ans/$thismonth_total_question)*100),2);
      /* Monthly Count Code End */

         // $primg=$CFG->wwwroot.'/images/avatar1.png';
         // if($employee->profile_photo_upload){
         //   $primg=$CFG->wwwroot.'/upload/profile/'.$employee->profile_photo_upload;
         // }
      
      $isdealeravailable=0;
      if($employee->user_type_id==""){
        $isdealeravailable=1;
      }

      if($isdealeravailable == 1){
        $url = $CFG->wwwroot.'/local/pagecontainer/lms/mobile_sat_assessment_report.php?mspin='.$USER->username;
        $sat_report_name = 'SAT Report';
      }else{
        $url = '';
        $sat_report_name = '';
      }   

      $profile = array(
      'id' => $USER->id,
      'empcode' => $USER->username,
      'name' => $USER->firstname.' '.$USER->lastname,
      'contactno' => $USER->phone1,
      'password' => $employee->password,
      // 'empdob' => $empdob,
      'email' => $USER->email,
      'designation' => $employee->designation,
      'subdesignation' => $employee->subdesignation,
      'TL'=>$teamlead,
      'channel' => $employee->channel,
      'usertype' => $employee->usertype,
      'outletid'=>$employee->outletcode,
      'outlet' => $employee->outlet,
      'outletgroupname'=>$employee->outletgroupname,
      'region' => $regionstr!=''?rtrim($regionstr,", "):'--',
      'state' => $employee->state,
      'city' => $employee->city,
      'points_earned' =>  $employee->points_earned,
      'certification_level' =>  $employee->certification_level ,
      'is_Expression' => $expression,
      'is_Bestpractice' => $bestpractice,
      'is_openhouseallowed' => $openhouse,
            // 'mspin' => $employee->mspin
      /* 14 May 2020 */
      'questioncount' => $thismonth_total_question,
      'answercount'   => $thismonth_correct_ans,
      'assessments' => $assessments,
      'surveys' => $surveys,
      'totalcourses' => $totalcourses,
      'current_month_question_answer_status' => $thismonth_correct_ans."/".$thismonth_total_question,
      'userpic'=>$primg,
      'photourl'=>$primg,
      'sat_report_url'=>$url,
      'sat_report_name'=>$sat_report_name,
      'is_dealer'=>$is_dealer,
      'is_msil_user'=>$is_msil_users,
      'isdealeravailable'=>$isdealeravailable
        );

      return $profile;
      // return $params['welcomemessage'] . $USER->firstname .$coursename;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_myprofilenew_returns() {
        // return new external_value(PARAM_TEXT, 'The welcome message + user first name');
        return new external_single_structure(
                array(
            'id' => new external_value(PARAM_INT, 'id of user'),
            'empcode' => new external_value(PARAM_TEXT, 'Emp Code/GDMS Code'),
            'name' => new external_value(PARAM_TEXT, 'Name'),
            'contactno' => new external_value(PARAM_TEXT, 'Phone number'),
            'password' => new external_value(PARAM_TEXT, 'Password'),
            'email' => new external_value(PARAM_TEXT, 'Email id'),
            'designation' => new external_value(PARAM_TEXT, 'Designation'),
            'subdesignation' => new external_value(PARAM_TEXT, 'Sub Designation'),
            'TL' =>new external_value(PARAM_RAW,'tl_mspin'),
            'channel' => new external_value(PARAM_TEXT, 'Chanel'),
            'usertype' => new external_value(PARAM_TEXT, 'User Type'),
            'outletid' => new external_value(PARAM_RAW,'outletid'),
            'outlet' => new external_value(PARAM_TEXT, 'Outlet'),
            'outletgroupname' => new external_value(PARAM_TEXT,'outletgroupname'),
            'region' => new external_value(PARAM_TEXT, 'Region'),
            'state' => new external_value(PARAM_TEXT,'State'),
            'city' => new external_value(PARAM_TEXT,'City'),
            'points_earned' => new external_value(PARAM_TEXT,'Points Earned'),
            'certification_level' => new external_value(PARAM_TEXT,'Certification Level'),
            'is_Expression' => new external_value(PARAM_TEXT,'Expression'),
            'is_Bestpractice' => new external_value(PARAM_TEXT,'Best Practice'),
            'is_openhouseallowed' => new external_value(PARAM_TEXT,'Open House'),
            'questioncount' => new external_value(PARAM_INT,'questioncount'),
            'answercount'   => new external_value(PARAM_INT,'answercount'),
            'assessments' => new external_value(PARAM_INT, 'assessments'),
            'surveys' => new external_value(PARAM_INT, 'surveys'),
            'totalcourses' => new external_value(PARAM_INT, 'addition of normal + learningpath'),
            'current_month_question_answer_status' => new external_value(PARAM_TEXT,'current_month_question_answer_status'),
            'userpic'=> new external_value(PARAM_TEXT,'userpic'),
            'photourl'=> new external_value(PARAM_TEXT,'photourl'),
            'isdealeravailable'=> new external_value(PARAM_TEXT,'isdealeravailable'),
            'sat_report_url' => new external_value(PARAM_RAW, 'sat report url'),
            'sat_report_name' => new external_value(PARAM_RAW, 'sat report name'),
            'is_dealer' => new external_value(PARAM_RAW, 'user type'),
            'is_msil_user' => new external_value(PARAM_RAW, 'user type')
            // 'mspin' => new external_value(PARAM_TEXT,'MSPIN')
                )
        );
    }

//--------------------------end here----------------------------------

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_myassessments_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    
    public static function get_myassessments($welcomemessage = 'Hello world, '){
    	global $USER, $DB, $CFG;
    	$user_type_data = $DB->get_record_sql("SELECT user_type_id FROM mdl_ums_employeemaster WHERE userid = '".$USER->id."'");
    	$user_type_id  = $user_type_data->user_type_id;
    	$latitude  = "";
    	$longitude = "";
    	$courses = enrol_get_users_courses($USER->id, false, 'id, shortname, fullname, idnumber, visible,
    		summary, summaryformat, format, showgrades, lang, enablecompletion, category, startdate, enddate, geofencing_enabled');
    	foreach ($courses as $key => $course){
    		if($course->category == 2)
    		{
    			if($course->visible == 1)
    			{
    				$checkenrollmentmethods = $DB->get_records_sql('SELECT * FROM {enrol} WHERE courseid = ?',array($course->id));
    				foreach ($checkenrollmentmethods as $key => $checkenrollmentmethod)
    				{
    					$enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($checkenrollmentmethod->id,$USER->id));
    					if(!empty($enrollmentdate))
    					{
    						$courseenrollmentdate = $enrollmentdate->timecreated;
    						$enrolenddate = $enrollmentdate->timeend;
    					}                                
    				}
    				$progress = null;
    				$pro = null;
    				if ($course->enablecompletion) 
    				{
						/* $pro = \core_completion\progress::get_course_progress_percentage($course);
						if($pro == 100)
						{
						  $progress = "Completed";
						}
						else
						{ */
							$pro = \core_completion\progress::get_course_progress_percentage($course);
							if($pro == 100)
							{
								$progress = "Completed";
							}
							else if(!$DB->record_exists('quiz', array('course' => $course->id)))
							{
								$sql_scorm = $DB->get_records_sql("SELECT * FROM {scorm} s JOIN {scorm_scoes_track} sst ON sst.scormid = s.id WHERE s.course = ? AND sst.userid = ?",array($course->id,$USER->id));
								if(empty($sql_scorm))
								{
									$progress = "Not Started";
								}
								else
								{
									$progress = "Incomplete";
								}
							} 
							else
							{
								$quizrecord  = $DB->get_record('quiz', array('course' => $course->id));
								$quizattempt = $DB->get_field('quiz', 'attempts', array('course' => $course->id));
								$modid = $DB->get_field('modules', 'id', array('name' => 'quiz'));
								$cmid  = $DB->get_field('course_modules', 'id', array('course' => $course->id, 'module' => $modid,'instance' => $quizrecord->id));	
								
								// Here we are checking user latest attempt //
								$user_attempts = $DB->get_record_sql('SELECT MAX(attempt) as user_max_attempt FROM {quiz_attempts} WHERE quiz = '.$quizrecord->id.' AND userid= '.$USER->id.'');
								$latestattempt = $user_attempts->user_max_attempt;
								
								// if the date passed 								
								$attempstatus = $DB->get_field('quiz_attempts','state',array('quiz' =>$quizrecord->id, 'userid' => $USER->id,'attempt' => 1));
								if (empty($attempstatus)) 
								{
									if ($quizrecord->timeclose > time()) 
									{
										$progress = "Expired";
									}
									else
									{
										$progress = "Not Started";
									}
								}
								else
								{
									/// here we are checking user grade of latest attempt ///
									$sumgrade = $DB->get_field('quiz_attempts', 'sumgrades', array('quiz' => $quizrecord->id, 'userid' => $USER->id,'attempt' => $latestattempt));
									
									// here we are checking the user //
									$passgrade = $DB->get_field('grade_items', 'gradepass', array('courseid' => $course->id, 'iteminstance' => $quizrecord->id, 'itemmodule' => 'quiz'));
									
									if($sumgrade >= $passgrade)
									{
										$progress = "Completed";
									}
									else
									{
										$progress = "Incomplete";
									}		
								}	
							}		
						//}//
						}

						$get_time = $DB->get_field('ums_course_duartion','duration',array('course_id' => $course->id));
						if(!empty($get_time))
						{
							$course_duration = $get_time;
						}
						else
						{
							$course_duration = "";
						}
            $geofencing_enabled = $course->geofencing_enabled;
            $sqlgetpoints = $DB->get_record_sql("SELECT * FROM mdl_ums_user_cordinate WHERE userid = '".$USER->id."'");
             $geofencing_enabled = $course->geofencing_enabled;
            if($user_type_id == 1){
              $geofencing_enabled = 'No';
            }else{
              if($geofencing_enabled=="Yes"){
                 $latitude   = $sqlgetpoints->latitude==null?"":$sqlgetpoints->latitude;
                 $longitude  = $sqlgetpoints->longitude==null?"":$sqlgetpoints->longitude;
              }else{
                $latitude   = "";
                $longitude  = "";
              }
            } 
						$url = $CFG->wwwroot.'/course/view.php?id='.$course->id;
						$result[] = array(
							'id' => $course->id,
							'shortname' => $course->shortname,
							'fullname' => $course->fullname,
							'idnumber' => $course->idnumber,
							'visible' => $course->visible,
							'summary' => $course->summary,
							'summaryformat' => $course->summaryformat,
							'format' => $course->format,
							'showgrades' => $course->showgrades,
							'lang' => clean_param($course->lang, PARAM_LANG),
							'enablecompletion' => $course->enablecompletion,
							'category' => $course->category,
							'progress' => $progress,
							'startdate' => $course->startdate,
							'enddate' => $course->enddate,
							'enroldate' => $courseenrollmentdate,
							'enrolenddate' => $enrolenddate,
							'url' => $url,
							'course_duration' => $course_duration,
							'latitude'  => $latitude,
							'longitude' => $longitude,
							'geofencing_enabled' => $geofencing_enabled
						);
					}
				}
			}
			if(empty($result)){
				$result[] = array();
			}
			return $result;

		}

    /**
     * Returns description of method result value
     * @return external_description
     */
    // public static function get_myassessments_returns() {
    //     return new external_multiple_structure(
    //             new external_single_structure(
    //             array(
    //         'courseid' => new external_value(PARAM_INT, 'id of course'),
    //         'name' => new external_value(PARAM_TEXT, 'name of quiz'),
    //         'starttime' => new external_value(PARAM_RAW, 'Start time of quiz'),
    //         'endtime' => new external_value(PARAM_RAW, 'End Quiz time'),
    //         'status' => new external_value(PARAM_TEXT, 'Status'),
    //         'testlink' => new external_value(PARAM_TEXT, 'Test Link'),
    //             )
    //             )
    //     );
    // }

    public static function get_myassessments_returns() {
       return new external_multiple_structure(
            new external_single_structure(
                  array(
                    'id'        => new external_value(PARAM_RAW, 'id of course',VALUE_OPTIONAL),
                    'shortname' => new external_value(PARAM_RAW, 'short name of course',VALUE_OPTIONAL),
                    'fullname'  => new external_value(PARAM_RAW, 'long name of course',VALUE_OPTIONAL),
                    'idnumber'  => new external_value(PARAM_RAW, 'id number of course',VALUE_OPTIONAL),
                    'visible'   => new external_value(PARAM_RAW, '1 means visible, 0 means hidden course',VALUE_OPTIONAL),
                    'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
                                                                VALUE_OPTIONAL),
                    'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate' => new external_value(PARAM_INT, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_INT, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'url' => new external_value(PARAM_RAW,'assessment url', VALUE_OPTIONAL),
                    'course_duration' => new external_value(PARAM_RAW, 'course duration',VALUE_OPTIONAL),
                    'latitude'  => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
                    'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
                    'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL),
                )
            )
        );
    }

  //---------------------get_pending_myassessment-------------------------------

      public static function get_pending_myassessments_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    
    public static function get_pending_myassessments($welcomemessage = 'Hello world, '){
      global $USER, $DB, $CFG;
      $user_type_data = $DB->get_record_sql("SELECT user_type_id FROM mdl_ums_employeemaster WHERE userid = '".$USER->id."'");
      $user_type_id  = $user_type_data->user_type_id;
      $latitude  = "";
      $longitude = "";
      $courses = enrol_get_users_courses($USER->id, false, 'id, shortname, fullname, idnumber, visible,
        summary, summaryformat, format, showgrades, lang, enablecompletion, category, startdate, enddate,is_set, is_visible, geofencing_enabled','is_set DESC');
      foreach ($courses as $key => $course){
        if($course->category == 2)
        {
          if($course->visible == 1)
          {
            $checkenrollmentmethods = $DB->get_records_sql('SELECT * FROM {enrol} WHERE courseid = ?',array($course->id));
            foreach ($checkenrollmentmethods as $key => $checkenrollmentmethod)
            {
              $enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($checkenrollmentmethod->id,$USER->id));
              if(!empty($enrollmentdate))
              {
                $courseenrollmentdate = $enrollmentdate->timecreated;
                $enrolenddate = $enrollmentdate->timeend;
                $created_date = $enrollmentdate->timecreated;
              }                                
            }
            $progress = null;
            $pro = null;
            if ($course->enablecompletion) 
            {
            /* $pro = \core_completion\progress::get_course_progress_percentage($course);
            if($pro == 100)
            {
              $progress = "Completed";
            }
            else
            { */
              $pro = \core_completion\progress::get_course_progress_percentage($course);
              if($pro == 100)
              {
                $progress = "Completed";
              }
              else if(!$DB->record_exists('quiz', array('course' => $course->id)))
              {
                $sql_scorm = $DB->get_records_sql("SELECT * FROM {scorm} s JOIN {scorm_scoes_track} sst ON sst.scormid = s.id WHERE s.course = ? AND sst.userid = ?",array($course->id,$USER->id));
                if(empty($sql_scorm))
                {
                  $progress = "Not Started";
                }
                else
                {
                  $progress = "Incomplete";
                }
              } 
              else
              {
                $quizrecord  = $DB->get_record('quiz', array('course' => $course->id));
                $quizattempt = $DB->get_field('quiz', 'attempts', array('course' => $course->id));
                $modid = $DB->get_field('modules', 'id', array('name' => 'quiz'));
                $cmid  = $DB->get_field('course_modules', 'id', array('course' => $course->id, 'module' => $modid,'instance' => $quizrecord->id));  
                
                // Here we are checking user latest attempt //
                $user_attempts = $DB->get_record_sql('SELECT MAX(attempt) as user_max_attempt FROM {quiz_attempts} WHERE quiz = '.$quizrecord->id.' AND userid= '.$USER->id.'');
                $latestattempt = $user_attempts->user_max_attempt;
                
                // if the date passed                 
                $attempstatus = $DB->get_field('quiz_attempts','state',array('quiz' =>$quizrecord->id, 'userid' => $USER->id,'attempt' => 1));
                if (empty($attempstatus)) 
                {
                  if ($quizrecord->timeclose > time()) 
                  {
                    $progress = "Expired";
                  }
                  else
                  {
                    $progress = "Not Started";
                  }
                }
                else
                {
                  /// here we are checking user grade of latest attempt ///
                  $sumgrade = $DB->get_field('quiz_attempts', 'sumgrades', array('quiz' => $quizrecord->id, 'userid' => $USER->id,'attempt' => $latestattempt));
                  
                  // here we are checking the user //
                  $passgrade = $DB->get_field('grade_items', 'gradepass', array('courseid' => $course->id, 'iteminstance' => $quizrecord->id, 'itemmodule' => 'quiz'));
                  
                  if($sumgrade >= $passgrade)
                  {
                    $progress = "Completed";
                  }
                  else
                  {
                    $progress = "Incomplete";
                  }   
                } 
              }   
            //}//
            }
          

            $get_time = $DB->get_field('ums_course_duartion','duration',array('course_id' => $course->id));
            if(!empty($get_time))
            {
              $course_duration = $get_time;
            }
            else
            {
              $course_duration = "";
            }
            $geofencing_enabled = $course->geofencing_enabled;
            $sqlgetpoints = $DB->get_record_sql("SELECT * FROM mdl_ums_user_cordinate WHERE userid = '".$USER->id."'");
             $geofencing_enabled = $course->geofencing_enabled;

            if($user_type_id == 1){
              $geofencing_enabled = 'No';
            }else{
              if($geofencing_enabled=="Yes"){
                 $latitude   = $sqlgetpoints->latitude==null?"":$sqlgetpoints->latitude;
                 $longitude  = $sqlgetpoints->longitude==null?"":$sqlgetpoints->longitude;
              }else{
                $latitude   = "";
                $longitude  = "";
              }
            }

            if($enrolenddate == 0)
            {
               $final_end_date = "0";  
            }else{
               $final_end_date = date('Y-m-d', $enrolenddate);
            } 

            $url = $CFG->wwwroot.'/course/view.php?id='.$course->id;
            $dates =  date('Y-m-d');

            //for adaptive quiz

            $mdl_sqlcnt   = "SELECT * FROM mdl_quiz where course='".$course->id."'";
            $adpt_quiz  = $DB->get_record_sql($mdl_sqlcnt);
            //print_r($adpt_quiz);


            if($course->is_set==1)
            {
               $viewtype=1;
               $type="ADL";
               $findplay=new core_course_external();
               $playcourse=$findplay->get_course_contents($adpt_quiz->course);
               //$url = $CFG->wwwroot."/mod/quiz/attempt.php?id=".@$playcourse[0]['modules'][0]['id'];
               $url=@$playcourse[0]['modules'][0]['url'];
      
               $status = $DB->get_record_sql("SELECT * FROM mdl_quiz_attempts where quiz='".$adpt_quiz->id."' and userid='".$USER->id."' order by id desc limit 1");
               //echo $sumgrade.'/'.$status->state;exit;

                 if(empty($sumgrade) || $sumgrade=='')
                  {
                    $progress = "Not Started";
                  }
                  elseif (($sumgrade < $passgrade) && ($status->state == 'finished')) {
                    $progress = "Completed";
                  }
                  elseif (($sumgrade >= $passgrade) && ($status->state == 'finished')) {
                    $progress = "Completed";
                  }
                  else
                  {
                    $progress = "Incomplete";
                  }

               // if($sumgrade <= $passgrade)
               //  {
               //    $progress = "Completed";
               //  }
            }else{
               $viewtype=0;
               $type="";
            }
            $subtitle="";

            if($progress != 'Completed' &&  ($final_end_date == 0 || $final_end_date > $dates))
            {
              $start = date("2022-10-06 00:00:01");
              $valid = date('Y-m-d H:i',strtotime('+96 hour',strtotime($start)));
              if(in_array(date('w'), [1,2,3,4,5,6]) && $course->is_set==1 && $course->is_visible==1)
              {
                if(date("Y-m-d H:i:s")>=$start && date("Y-m-d H:i:s")<=$valid)
                {

                  $subtitle=$topicname[$course->id]['topicname'].', '.implode(', ', $cathtml).', '.implode(', ', $subcathtml);
                  $cathtml='';
                  $subcathtml='';

                  $result[] = array(
                    'id' => $course->id,
                    'shortname' => $course->shortname,
                    'fullname' => $course->fullname,
                    'idnumber' => $course->idnumber,
                    'visible' => $course->visible,
                    'summary' => $course->summary,
                    'summaryformat' => $course->summaryformat,
                    'format' => $course->format,
                    'showgrades' => $course->showgrades,
                    'lang' => clean_param($course->lang, PARAM_LANG),
                    'enablecompletion' => $course->enablecompletion,
                    'category' => $course->category,
                    'progress' => $progress,
                    'startdate' => date('Y-m-d',$course->startdate),
                    'enddate' => date('Y-m-d',$course->enddate),
                    'enroldate' => date('Y-m-d',$courseenrollmentdate),
                    'enrolenddate' => date('Y-m-d',$enrolenddate),
                    'created_date' => date('d-m-Y H:i:s',$created_date),
                    'created' => date('d-m-Y H:i:s',$created_date),
                    'url' => $url,
                    'course_duration' => $course_duration,
                    'latitude'  => $latitude,
                    'longitude' => $longitude,
                    'radius' => 100,
                    'geofencing_enabled' => $geofencing_enabled,
                    'totalsubcourses'=>1,
                    'viewtype'=>$viewtype,
                    'type'=>$type,
                    // 'subtitle'=>$subtitle,
                    'subtitle'=>'',
                    'validfor'=>2
                  );
                }
              }
            if($course->is_set==0 && $course->is_visible==0)
             // else
            {
                $result[] = array(
                'id' => $course->id,
                'shortname' => $course->shortname,
                'fullname' => $course->fullname,
                'idnumber' => $course->idnumber,
                'visible' => $course->visible,
                'summary' => $course->summary,
                'summaryformat' => $course->summaryformat,
                'format' => $course->format,
                'showgrades' => $course->showgrades,
                'lang' => clean_param($course->lang, PARAM_LANG),
                'enablecompletion' => $course->enablecompletion,
                'category' => $course->category,
                'progress' => $progress,
                'startdate' => date('Y-m-d',$course->startdate),
                'enddate' => date('Y-m-d',$course->enddate),
                'enroldate' => date('Y-m-d',$courseenrollmentdate),
                'enrolenddate' => date('Y-m-d',$enrolenddate),
                'created_date' => date('d-m-Y H:i:s',$created_date),
                'created' => date('d-m-Y H:i:s',$created_date),
                'url' => $url,
                'course_duration' => $course_duration,
                'latitude'  => $latitude,
                'longitude' => $longitude,
                'radius' => 100,
                'geofencing_enabled' => $geofencing_enabled,
                'totalsubcourses'=>1,
                'viewtype'=>$viewtype,
                'type'=>$type,
                'subtitle'=>$subtitle,
                'subtitle'=>'',
                'validfor'=>2
              );
            } 
           } 
          }
        }
      }
      if(empty($result)){
        $result[] = array();
      }
      return $result;

    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    // public static function get_myassessments_returns() {
    //     return new external_multiple_structure(
    //             new external_single_structure(
    //             array(
    //         'courseid' => new external_value(PARAM_INT, 'id of course'),
    //         'name' => new external_value(PARAM_TEXT, 'name of quiz'),
    //         'starttime' => new external_value(PARAM_RAW, 'Start time of quiz'),
    //         'endtime' => new external_value(PARAM_RAW, 'End Quiz time'),
    //         'status' => new external_value(PARAM_TEXT, 'Status'),
    //         'testlink' => new external_value(PARAM_TEXT, 'Test Link'),
    //             )
    //             )
    //     );
    // }

    public static function get_pending_myassessments_returns() {
       return new external_multiple_structure(
            new external_single_structure(
                  array(
                    'id'        => new external_value(PARAM_RAW, 'id of course',VALUE_OPTIONAL),
                    'shortname' => new external_value(PARAM_RAW, 'short name of course',VALUE_OPTIONAL),
                    'fullname'  => new external_value(PARAM_RAW, 'long name of course',VALUE_OPTIONAL),
                    'idnumber'  => new external_value(PARAM_RAW, 'id number of course',VALUE_OPTIONAL),
                    'visible'   => new external_value(PARAM_RAW, '1 means visible, 0 means hidden course',VALUE_OPTIONAL),
                    'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
                                                                VALUE_OPTIONAL),
                    'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate' => new external_value(PARAM_RAW, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate' => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate' => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_RAW, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'created_date' => new external_value(PARAM_RAW, 'Timestamp when the enrolment date', VALUE_OPTIONAL),
                    'created' => new external_value(PARAM_RAW, 'Timestamp when the enrolment date', VALUE_OPTIONAL),
                    'url' => new external_value(PARAM_RAW,'assessment url', VALUE_OPTIONAL),
                    'course_duration' => new external_value(PARAM_RAW, 'course duration',VALUE_OPTIONAL),
                    'latitude'  => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
                    'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
                    'radius' => new external_value(PARAM_RAW, 'radius point of user location',VALUE_OPTIONAL),
                    'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL),
                    'totalsubcourses' => new external_value(PARAM_RAW,'module count', VALUE_OPTIONAL),
                    'viewtype' => new external_value(PARAM_INT,'viewtype', VALUE_OPTIONAL),
                    'type' => new external_value(PARAM_TEXT,'type', VALUE_OPTIONAL),
                    // 'subtitle' => new external_value(PARAM_TEXT,'subtitle', VALUE_OPTIONAL),
                    'subtitle' => new external_value(PARAM_RAW,'subtitle', VALUE_OPTIONAL),
                    'validfor' => new external_value(PARAM_TEXT,'validfor', VALUE_OPTIONAL)
                
                )
            )
        );
    }

  //--------------------end here------------------------------------------------


  //--------------------get_history_myassessment-------------------------------

    public static function get_history_myassessments_parameters() {

        return new external_function_parameters(
                array('dates' => new external_value(PARAM_RAW, 'version'))
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    
    public static function get_history_myassessments($dates){
      global $USER, $DB, $CFG;
      $user_type_data = $DB->get_record_sql("SELECT user_type_id FROM mdl_ums_employeemaster WHERE userid = '".$USER->id."'");
      $user_type_id  = $user_type_data->user_type_id;
      $latitude  = "";
      $longitude = "";
      $courses = enrol_get_users_courses($USER->id, false, 'id, shortname, fullname, idnumber, visible,
        summary, summaryformat, format, showgrades, lang, enablecompletion, category, startdate, enddate,is_set, is_visible, geofencing_enabled');
      foreach ($courses as $key => $course){
        if($course->category == 2)
        {
          if($course->visible == 1 && $course->is_set == 0)
          {
            $checkenrollmentmethods = $DB->get_records_sql('SELECT * FROM {enrol} WHERE courseid = ?',array($course->id));
            foreach ($checkenrollmentmethods as $key => $checkenrollmentmethod)
            {
              $enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($checkenrollmentmethod->id,$USER->id));
              if(!empty($enrollmentdate))
              {
                $courseenrollmentdate = $enrollmentdate->timecreated;
                $enrolenddate = $enrollmentdate->timeend;
                $created_date = $enrollmentdate->timecreated;
              }                                
            }
            $progress = null;
            $pro = null;
            if ($course->enablecompletion) 
            {
            /* $pro = \core_completion\progress::get_course_progress_percentage($course);
            if($pro == 100)
            {
              $progress = "Completed";
            }
            else
            { */
              $pro = \core_completion\progress::get_course_progress_percentage($course);
              if($pro == 100)
              {
                $progress = "Completed";
              }
              else if(!$DB->record_exists('quiz', array('course' => $course->id)))
              {
                $sql_scorm = $DB->get_records_sql("SELECT * FROM {scorm} s JOIN {scorm_scoes_track} sst ON sst.scormid = s.id WHERE s.course = ? AND sst.userid = ?",array($course->id,$USER->id));
                if(empty($sql_scorm))
                {
                  $progress = "Not Started";
                }
                else
                {
                  $progress = "Incomplete";
                }
              } 
              else
              {
                $quizrecord  = $DB->get_record('quiz', array('course' => $course->id));
                $quizattempt = $DB->get_field('quiz', 'attempts', array('course' => $course->id));
                $modid = $DB->get_field('modules', 'id', array('name' => 'quiz'));
                $cmid  = $DB->get_field('course_modules', 'id', array('course' => $course->id, 'module' => $modid,'instance' => $quizrecord->id));  
                
                // Here we are checking user latest attempt //
                $user_attempts = $DB->get_record_sql('SELECT MAX(attempt) as user_max_attempt FROM {quiz_attempts} WHERE quiz = '.$quizrecord->id.' AND userid= '.$USER->id.'');
                $latestattempt = $user_attempts->user_max_attempt;
                
                // if the date passed                 
                $attempstatus = $DB->get_field('quiz_attempts','state',array('quiz' =>$quizrecord->id, 'userid' => $USER->id,'attempt' => 1));
                if (empty($attempstatus)) 
                {
                  if ($quizrecord->timeclose > time()) 
                  {
                    $progress = "Expired";
                  }
                  else
                  {
                    $progress = "Not Started";
                  }
                }
                else
                {
                  /// here we are checking user grade of latest attempt ///
                  $sumgrade = $DB->get_field('quiz_attempts', 'sumgrades', array('quiz' => $quizrecord->id, 'userid' => $USER->id,'attempt' => $latestattempt));
                  
                  // here we are checking the user //
                  $passgrade = $DB->get_field('grade_items', 'gradepass', array('courseid' => $course->id, 'iteminstance' => $quizrecord->id, 'itemmodule' => 'quiz'));
                  
                  if($sumgrade >= $passgrade)
                  {
                    $progress = "Completed";
                  }
                  else
                  {
                    $progress = "Incomplete";
                  }   
                } 
              }   
            //}//
            }

            $get_time = $DB->get_field('ums_course_duartion','duration',array('course_id' => $course->id));
            if(!empty($get_time))
            {
              $course_duration = $get_time;
            }
            else
            {
              $course_duration = "";
            }
            $geofencing_enabled = $course->geofencing_enabled;
            $sqlgetpoints = $DB->get_record_sql("SELECT * FROM mdl_ums_user_cordinate WHERE userid = '".$USER->id."'");
             $geofencing_enabled = $course->geofencing_enabled;
            if($user_type_id == 1){
              $geofencing_enabled = 'No';
            }else{
              if($geofencing_enabled=="Yes"){
                 $latitude   = $sqlgetpoints->latitude==null?"":$sqlgetpoints->latitude;
                 $longitude  = $sqlgetpoints->longitude==null?"":$sqlgetpoints->longitude;
              }else{
                $latitude   = "";
                $longitude  = "";
              }
            }

            if($enrolenddate == 0)
            {
               $final_end_date = "0";  
            }else{
               $final_end_date = date('Y-m-d', $enrolenddate);
            } 

            $url = $CFG->wwwroot.'/course/view.php?id='.$course->id;
            $dates =  date('Y-m-d');

            // fror adaptive learning

            $mdl_sqlcnt   = "SELECT * FROM mdl_quiz where course='".$course->id."'";
            $adpt_quiz  = $DB->get_record_sql($mdl_sqlcnt);
           // print_r($adpt_quiz);
            if($course->is_set==1)
            {

                 $status = $DB->get_record_sql("SELECT * FROM mdl_quiz_attempts where quiz='".$adpt_quiz->id."' and userid='".$USER->id."' order by id desc limit 1");

                 if(empty($sumgrade) || $sumgrade=='')
                  {
                    $progress = "Not Started";
                  }
                  elseif (($sumgrade < $passgrade) && ($status->state == 'finished')) {
                    $progress = "Completed";
                  }
                  elseif (($sumgrade >= $passgrade) && ($status->state == 'finished')) {
                    $progress = "Completed";
                  }
                  else
                  {
                    $progress = "Incomplete";
                  }

               // if($sumgrade <= $passgrade)
               //  {
               //    $progress = "Completed";
               //  }
            }

            // end here

            if(($final_end_date < $dates && $final_end_date != 0) || ($final_end_date == 0 && $progress == 'Completed') || $progress == 'Completed')
            {
                $result[] = array(
                'id' => $course->id,
                'shortname' => $course->shortname,
                'fullname' => $course->fullname,
                'idnumber' => $course->idnumber,
                'visible' => $course->visible,
                'summary' => $course->summary,
                'summaryformat' => $course->summaryformat,
                'format' => $course->format,
                'showgrades' => $course->showgrades,
                'lang' => clean_param($course->lang, PARAM_LANG),
                'enablecompletion' => $course->enablecompletion,
                'category' => $course->category,
                'progress' => $progress,
                'startdate' => date('Y-m-d',$course->startdate),
                'enddate' => date('Y-m-d',$course->enddate),
                'enroldate' => date('Y-m-d',$courseenrollmentdate),
                'enrolenddate' => date('Y-m-d',$enrolenddate),
                'created_date' => date('d-m-Y H:i:s',$created_date),
                'created' => date('d-m-Y H:i:s',$created_date),
                'url' => $url,
                'course_duration' => $course_duration,
                'latitude'  => $latitude,
                'longitude' => $longitude,
                'radius' => 100,
                'geofencing_enabled' => $geofencing_enabled,
                'totalsubcourses'=>1
              );
            }
            
            
          }
        }
      }
      if(empty($result)){
        $result[] = array();
      }
      return $result;

    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    // public static function get_myassessments_returns() {
    //     return new external_multiple_structure(
    //             new external_single_structure(
    //             array(
    //         'courseid' => new external_value(PARAM_INT, 'id of course'),
    //         'name' => new external_value(PARAM_TEXT, 'name of quiz'),
    //         'starttime' => new external_value(PARAM_RAW, 'Start time of quiz'),
    //         'endtime' => new external_value(PARAM_RAW, 'End Quiz time'),
    //         'status' => new external_value(PARAM_TEXT, 'Status'),
    //         'testlink' => new external_value(PARAM_TEXT, 'Test Link'),
    //             )
    //             )
    //     );
    // }

    public static function get_history_myassessments_returns() {
       return new external_multiple_structure(
            new external_single_structure(
                  array(
                    'id'        => new external_value(PARAM_RAW, 'id of course',VALUE_OPTIONAL),
                    'shortname' => new external_value(PARAM_RAW, 'short name of course',VALUE_OPTIONAL),
                    'fullname'  => new external_value(PARAM_RAW, 'long name of course',VALUE_OPTIONAL),
                    'idnumber'  => new external_value(PARAM_RAW, 'id number of course',VALUE_OPTIONAL),
                    'visible'   => new external_value(PARAM_RAW, '1 means visible, 0 means hidden course',VALUE_OPTIONAL),
                    'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
                                                                VALUE_OPTIONAL),
                    'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate' => new external_value(PARAM_RAW, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate' => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate' => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_RAW, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'created_date' => new external_value(PARAM_RAW, 'Timestamp when the enrolment created', VALUE_OPTIONAL),
                    'created' => new external_value(PARAM_RAW, 'Timestamp when the enrolment created', VALUE_OPTIONAL),
                    'url' => new external_value(PARAM_RAW,'assessment url', VALUE_OPTIONAL),
                    'course_duration' => new external_value(PARAM_RAW, 'course duration',VALUE_OPTIONAL),
                    'latitude'  => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
                    'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
                    'radius' => new external_value(PARAM_INT, 'radius point of user location',VALUE_OPTIONAL),
                    'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL),
                    'totalsubcourses' => new external_value(PARAM_INT,'count of modules', VALUE_OPTIONAL),
                )
            )
        );
    }

  //------------------end here------------------------------------------------

	/***************************************************************************************/
	// Code Developed By - Yogita Ghegadmal
	// Date - 31 oct 2019
	// this is also for testing purpose
	public static function get_assessments_parameters() {

        return new external_function_parameters(array());
    }
	
	public static function get_assessments()
	{
		global $USER, $DB, $CFG;

        $courses = enrol_get_users_courses($USER->id, false, 'id, shortname, fullname, idnumber, visible,
                   summary, summaryformat, format, showgrades, lang, enablecompletion, category, startdate, enddate');
        foreach ($courses as $key => $course)
		{
         
            if($course->category == 2)
			{
				if($course->visible == 1)
				{
					$checkenrollmentmethods = $DB->get_records_sql('SELECT * FROM {enrol} WHERE courseid = ?',array($course->id));
                    foreach ($checkenrollmentmethods as $key => $checkenrollmentmethod)
					{
						$enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($checkenrollmentmethod->id,$USER->id));
						if(!empty($enrollmentdate))
						{
							$courseenrollmentdate = $enrollmentdate->timecreated;
							$enrolenddate = $enrollmentdate->timeend;
						}                                
					}
					$progress = null;
           			$pro = null;
					if ($course->enablecompletion) 
					{
						/* $pro = \core_completion\progress::get_course_progress_percentage($course);
						if($pro == 100)
						{
						  $progress = "Completed";
						}
						else
						{ */
							$pro = \core_completion\progress::get_course_progress_percentage($course);
							if($pro == 100)
							{
							  $progress = "Completed";
							}
							else if(!$DB->record_exists('quiz', array('course' => $course->id)))
							{
								$sql_scorm = $DB->get_records_sql("SELECT * FROM {scorm} s JOIN {scorm_scoes_track} sst ON sst.scormid = s.id WHERE s.course = ? AND sst.userid = ?",array($course->id,$USER->id));
								if(empty($sql_scorm))
								{
									$progress = "Not Started";
								}
								else
								{
									$progress = "Incomplete";
								}
							}
							else
							{
								$quizrecord  = $DB->get_record('quiz', array('course' => $course->id));
								$quizattempt = $DB->get_field('quiz', 'attempts', array('course' => $course->id));
								$modid = $DB->get_field('modules', 'id', array('name' => 'quiz'));
								$cmid  = $DB->get_field('course_modules', 'id', array('course' => $course->id, 'module' => $modid,'instance' => $quizrecord->id));	
								
								// Here we are checking user latest attempt //
								$user_attempts = $DB->get_record_sql('SELECT MAX(attempt) as user_max_attempt FROM {quiz_attempts} WHERE quiz = '.$quizrecord->id.' AND userid= '.$USER->id.'');
								$latestattempt = $user_attempts->user_max_attempt;
								
								// if the date passed 								
								$attempstatus = $DB->get_field('quiz_attempts','state',array('quiz' =>$quizrecord->id, 'userid' => $USER->id,'attempt' => 1));
								if (empty($attempstatus)) 
								{
									if ($quizrecord->timeclose > time()) 
									{
										$progress = "Expired";
									}
									else
									{
										$progress = "Not Started";
									}
								}
								else
								{
									/// here we are checking user grade of latest attempt ///
									$sumgrade = $DB->get_field('quiz_attempts', 'sumgrades', array('quiz' => $quizrecord->id, 'userid' => $USER->id,'attempt' => $latestattempt));
									
									// here we are checking the user //
									$passgrade = $DB->get_field('grade_items', 'gradepass', array('courseid' => $course->id, 'iteminstance' => $quizrecord->id, 'itemmodule' => 'quiz'));
									
									if($sumgrade >= $passgrade)
									{
										$progress = "Completed";
									}
									else
									{
										$progress = "Incomplete";
									}		
								}	
							}		
						//}//
               		}
					$url = $CFG->wwwroot.'/course/view.php?id='.$course->id;
					$result[] = array(
						'id' => $course->id,
						'shortname' => $course->shortname,
						'fullname' => $course->fullname,
						'idnumber' => $course->idnumber,
						'visible' => $course->visible,
						'summary' => $course->summary,
						'summaryformat' => $course->summaryformat,
						'format' => $course->format,
						'showgrades' => $course->showgrades,
						'lang' => clean_param($course->lang, PARAM_LANG),
						'enablecompletion' => $course->enablecompletion,
						'category' => $course->category,
						'progress' => $progress,
						'startdate' => $course->startdate,
						'enddate' => $course->enddate,
						'enroldate' => $courseenrollmentdate,
						'enrolenddate' => $enrolenddate,
						'url' => $url,
					);
				}
			}
        }
        if(empty($result))
		{
            $result[] = array();
        }
        return $result;
    }
	
	public static function get_assessments_returns() 
	{
		return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id'        => new external_value(PARAM_RAW, 'id of course',VALUE_OPTIONAL),
                    'shortname' => new external_value(PARAM_RAW, 'short name of course',VALUE_OPTIONAL),
                    'fullname'  => new external_value(PARAM_RAW, 'long name of course',VALUE_OPTIONAL),
                    'idnumber'  => new external_value(PARAM_RAW, 'id number of course',VALUE_OPTIONAL),
                    'visible'   => new external_value(PARAM_RAW, '1 means visible, 0 means hidden course',VALUE_OPTIONAL),
                    'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
                                                                VALUE_OPTIONAL),
                    'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate' => new external_value(PARAM_INT, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_INT, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'url' => new external_value(PARAM_RAW,'assessment url', VALUE_OPTIONAL),
                )
            )
        );
	}
	/***************************************************************************************/
	
	/*********************** Assessment Final 20/02/2020 **************************************/
	// this is for testing purpose
	public static function get_final_assessments_parameters() {

        return new external_function_parameters(array());
    }
	
	public static function get_final_assessments()
	{
		global $USER, $DB, $CFG;
		$sqlAssessment = $DB->get_records_sql('select 
		c.id as courseid,
		c.fullname as coursename,
		c.summary as summary,
		c.shortname as shortname,
		c.idnumber as idnumber,
		c.visible as visible,
		c.summaryformat as summaryformat,
		c.format,
		c.showgrades,
		c.lang,
		c.enablecompletion,
		c.category,
		c.startdate,
		c.enddate,
		a.timemodified as enrolldate 
		FROM {role_assignments} AS a
		INNER JOIN {context} AS b on(b.id = a.contextid)
		INNER JOIN {course} AS c on(c.id = b.instanceid) WHERE a.userid= ?
		AND c.category = 2 AND c.visible = 1
		ORDER BY c.id DESC', array($USER->id));
		foreach($sqlAssessment as $assessment)
		{
			$id       	   = $assessment->courseid;
			$shortname 	   = $assessment->shortname;
			$fullname  	   = $assessment->coursename;
			$idnumber  	   = $assessment->idnumber;
			$visible   	   = $assessment->visible;
			$summary   	   = $assessment->summary;
			$summaryformat = $assessment->summaryformat;
			$format        = $assessment->format;
			$showgrades    = $assessment->showgrades;
			$lang          = $assessment->lang;
			$enablecompletion = $assessment->enablecompletion;
			$category  = $assessment->category;
			$startdate = $assessment->startdate;
			$enddate   = $assessment->enddate;
			$url       = $CFG->wwwroot.'/course/view.php?id='.$id;	
			
			$checkenrollmentmethods = $DB->get_records_sql('SELECT * FROM {enrol} WHERE courseid = ?',array($id));
			foreach ($checkenrollmentmethods as $key => $checkenrollmentmethod)
			{
				$enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($checkenrollmentmethod->id,$USER->id));
				if(!empty($enrollmentdate))
				{
					$courseenrollmentdate = $enrollmentdate->timecreated;
					$enrolenddate = $enrollmentdate->timeend;
				}                                
			}
			// here we are checking assessment within course only
			if(!$DB->record_exists('quiz', array('course' => $id)))
			{
				$sql_scorm = $DB->get_records_sql("SELECT * FROM {scorm} s JOIN {scorm_scoes_track} sst ON sst.scormid = s.id WHERE s.course = ? AND sst.userid = ?",array($id,$USER->id));
				if(empty($sql_scorm))
				{
					$progress = "Not Started";
				}
				else
				{
					$progress = "Incomplete";
				}
			}
			else
			{
				$quizrecord  = $DB->get_record('quiz', array('course' => $id));
				$quizattempt = $DB->get_field('quiz', 'attempts', array('course' => $id));
				$modid = $DB->get_field('modules', 'id', array('name' => 'quiz'));
				$cmid  = $DB->get_field('course_modules', 'id', array('course' => $id, 'module' => $modid,'instance' => $quizrecord->id));	
				// Here we are checking user latest attempt //
				$user_attempts = $DB->get_record_sql('SELECT MAX(attempt) as user_max_attempt FROM {quiz_attempts} WHERE quiz = '.$quizrecord->id.' AND userid= '.$USER->id.'');
				$latestattempt = $user_attempts->user_max_attempt;
				// if the date passed 								
				$attempstatus = $DB->get_field('quiz_attempts','state',array('quiz' =>$quizrecord->id, 'userid' => $USER->id,'attempt' => $latestattempt));
				if(empty($attempstatus)) 
				{
					if($enrolenddate > time()) 
					{
						$progress = "Expired";
					}
					else
					{
						$progress = "Not Started";
					}
				}
				else
				{
					/// here we are checking user grade of latest attempt ///
					$sumgrade = $DB->get_field('quiz_attempts', 'sumgrades', array('quiz' => $quizrecord->id, 'userid' => $USER->id,'attempt' => $latestattempt));
					//here we are checking the user //
					$passgrade = $DB->get_field('grade_items', 'gradepass', array('courseid' => $id,'iteminstance' => $quizrecord->id, 'itemmodule' => 'quiz'));
					
					if($sumgrade >= $passgrade)
					{
						$progress = "Completed";
					}
					else
					{
						$progress = "Incomplete";
					}	
				}
			}		
			$result[] = array(
				'id' => $id,
				'shortname' => $shortname,
				'fullname'  => $fullname,
				'idnumber'  => $idnumber,
				'visible'   => $visible,
				'summary'   => $summary,
				'summaryformat' => $summaryformat,
				'format' => $format,
				'showgrades' => $showgrades,
				'lang' => $lang,
				'enablecompletion' => $enablecompletion,
				'category' => $category,
				'progress' => $progress,
				'startdate' => $startdate,
				'enddate' => $enddate,
				'enroldate' => $courseenrollmentdate,
				'enrolenddate' => $enrolenddate,
				'url' => $url
			);
		}
		
		if(empty($result))
		{
			$result[] = array();
		}
		return $result;
    }
	
	public static function get_final_assessments_returns() 
	{
		return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id'        => new external_value(PARAM_RAW, 'id of course',VALUE_OPTIONAL),
                    'shortname' => new external_value(PARAM_RAW, 'short name of course',VALUE_OPTIONAL),
                    'fullname'  => new external_value(PARAM_RAW, 'long name of course',VALUE_OPTIONAL),
                    'idnumber'  => new external_value(PARAM_RAW, 'id number of course',VALUE_OPTIONAL),
                    'visible'   => new external_value(PARAM_RAW, '1 means visible, 0 means hidden course',VALUE_OPTIONAL),
                    'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
                                                                VALUE_OPTIONAL),
                    'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate' => new external_value(PARAM_INT, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_INT, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'url' => new external_value(PARAM_RAW,'assessment url', VALUE_OPTIONAL),
                )
            )
        );
	}
	
	/***************************************************************************************/
	
	
    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_mytrainings_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function get_mytrainings($welcomemessage = 'Hello world, ') {
        global $USER, $DB, $CFG;
        //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::get_myprofile_parameters(), array('welcomemessage' => $welcomemessage));

        //Context validation
        //OPTIONAL but in most web service it should present
        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);
        /*
          //Capability checking
          //OPTIONAL but in most web service it should present
          if (!has_capability('moodle/user:viewdetails', $context)) {
          throw new moodle_exception('cannotviewprofile');
          } */
      /*  $trainings = $DB->get_records_sql("
            SELECT b.trgtitle, c.trgtype, DATE_FORMAT(a.trgfromdt,'%D %b %y')as startdate,DATE_FORMAT(a.trgfromdt,'%h:%i %p') as starttime, DATE_FORMAT(a.trgtodt,'%D %b %y')as enddate,DATE_FORMAT(a.trgtodt,'%h:%i %p')as endtime, f.trgdate, d.preasmtscore, d.postasmtscore, d.trgfbkscore
            FROM hmiltp_tms_trainingdetail a
            inner join hmiltp_tms_trainingmaster b
            on b.trgid=a.trgid
            inner join hmiltp_tms_trgtypemaster c
            on c.trgtypecode=a.trgtypecode
            left join hmiltp_tms_trgenrollments d
            on d.trgscheduleid=a.trgscheduleid
            left join hmiltp_user e
            on d.empcode=e.username and e.username=d.empcode
            left join hmiltp_tms_trgattendance f
            on  f.trgscheduleid=a.trgscheduleid and e.username=f.empcode
            where e.id=?
            AND d.status = 2
            order by a.trgfromdt desc limit 5;", array($USER->id));
        //die(print_object($trainings));
        $result = array();
        foreach ($trainings as $training) {*/
            $subresult = new stdClass();
            $subresult->name = 'HStep1 Chassis';
            $subresult->type = 'Certification';
            $subresult->startdate = '28/07/2018';
            $subresult->enddate = '31/07/2018';
            $subresult->starttime = '8:00 AM';
            $subresult->endtime = '9:00 PM';
            $subresult->status = 'Scheduled';
            $subresult->presentdate = "N/A";
            $subresult->score = "N/A";
            $subresult->feedback = "N/A";

            //		die(print_object($subresult));
            $result[] = $subresult;
            $subresult = new stdClass();
            $subresult->name = 'HStep2 Chassis';
            $subresult->type = 'Certification';
            $subresult->startdate = '28/11/2017';
            $subresult->enddate = '31/08/2018';
            $subresult->starttime = '8:00 AM';
            $subresult->endtime = '9:00 PM';
            $subresult->status = 'Present';
            $subresult->presentdate = "N/A";
            $subresult->score = "20";
            $subresult->feedback = "Pass";
            //		die(print_object($subresult));
            $result[] = $subresult;

        /*}*/
        //die(print_object($result));
        //echo $query;
        return $result;
        // return $params['welcomemessage'] . $USER->firstname .$coursename;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_mytrainings_returns() {
        return new external_multiple_structure(
                new external_single_structure(
                array(
            'name' => new external_value(PARAM_TEXT, 'name of training'),
            'type' => new external_value(PARAM_TEXT, 'Type of training'),
            'startdate' => new external_value(PARAM_TEXT, 'Start date of the training'),
            'enddate' => new external_value(PARAM_TEXT, 'End date of the training'),
            'starttime' => new external_value(PARAM_TEXT, 'Start time of the training'),
            'endtime' => new external_value(PARAM_TEXT, 'End time of the training'),
            'status' => new external_value(PARAM_TEXT, 'Status'),
            'presentdate' => new external_value(PARAM_TEXT, 'Employee Present for training'),
            'score' => new external_value(PARAM_TEXT, 'score'),
            'feedback' => new external_value(PARAM_TEXT, 'Feedback'),
                )
                )
        );
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_mycourses_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
  public static function get_mycourses($welcomemessage = 'Hello world, '){
    global $USER, $DB ,$CFG;
    $classObj        = new activityReport();
    $user_type_data = $DB->get_record_sql("SELECT user_type_id FROM mdl_ums_employeemaster WHERE 
    userid = '".$USER->id."'");
    $user_type_id  = $user_type_data->user_type_id;
    $onlinecourses = $DB->get_records_sql("select
        c.id as courseid,
        c.fullname as coursename,
        c.summary as summary,
        c.shortname as shortname,
        c.idnumber as idnumber,
        c.visible as visible,
        c.summaryformat as summaryformat,
        c.format,
        c.showgrades,
        c.lang,
        c.enablecompletion,
        c.category,
        b.path,
        c.geofencing_enabled,
        c.startdate,
        c.enddate,
        (
          select count(sa.id) as totalscorms
            from mdl_scorm_scoes as sa
            inner join mdl_scorm as sb ON(sb.id=sa.scorm)
            where sb.course=c.id and sa.scormtype='sco'
        ) as totalscorms,
        (
          select count(sa.id) as totaltracked
            FROM mdl_scorm_scoes_track as sa
            INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
            INNER JOIN mdl_course as sc on (sc.id=sb.course)
            WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='completed' || value='passed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
        ) as totalcompleted,
        (
          select count(sa.id) as totaltracked
            FROM mdl_scorm_scoes_track as sa
            INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
            INNER JOIN mdl_course as sc on (sc.id=sb.course)
            WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='incomplete' || value='failed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
        ) as totalincomplete,
        'duedate',
        (SELECT timestart FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol  where courseid=c.id and enrol='manual') AND userid=a.userid) as courseenrollmentdate,
        (SELECT timeend FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol where courseid=c.id and enrol='manual') AND userid=a.userid) as enrolenddate

        FROM mdl_role_assignments  as a
        INNER JOIN mdl_context     as b on(b.id=a.contextid)
        INNER JOIN mdl_course      as c on(c.id=b.instanceid)
        left outer join mdl_user   as d on(d.id=a.userid)
        INNER JOIN mdl_course_categories as e on(e.id=c.category)
        where b.contextlevel = 50 and userid = '".$USER->id."' and c.visible=1 and c.category=3 group by c.id ORDER BY c.id DESC");
    //print_r($onlinecourses);exit;
       /*where b.contextlevel = 50 and userid = '".$USER->id."' and c.visible=1 and c.category=3 and e.name<>'assessment container' group by c.id ORDER BY c.id DESC");
        (SELECT archeived_flag FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol where courseid=c.id and enrol='manual') AND userid=a.userid) as ar_flag
       */

      foreach($onlinecourses as $onlinecourse){
          $id        = $onlinecourse->courseid;
          $shortname = $onlinecourse->shortname;
          $fullname  = $onlinecourse->coursename;
          $idnumber  = $onlinecourse->idnumber;
          $visible   = $onlinecourse->visible;
          $summary   = $onlinecourse->summary;
          $summaryformat = $onlinecourse->summaryformat;
          $format     = $onlinecourse->format;
          $showgrades = $onlinecourse->showgrades;
          $lang       = $onlinecourse->lang;
          $enablecompletion = $onlinecourse->enablecompletion;
          $category  = $onlinecourse->category;
          
          $startdate = $onlinecourse->startdate;
          $enddate   = $onlinecourse->enddate;
          $enroldate = $onlinecourse->courseenrollmentdate;
          $enrolenddate = $onlinecourse->enrolenddate;
                    $progress = '';
          if($id == 12 || $id == 763)
          { 
            $sqlass = $DB->get_record_sql("SELECT quiz.id as quizid,
            quiz.course,
            grade_items.id,
            grade_items.grademax,
            grade_items.grademin,
            grade_items.gradepass,
            grade_items.itemmodule
            FROM mdl_quiz AS quiz 
            INNER JOIN mdl_grade_items AS grade_items 
            ON grade_items.iteminstance = quiz.id
            WHERE quiz.course= '12' AND 
            quiz.id = '24' AND 
            grade_items.itemmodule = 'quiz'");
            $quizid     = $sqlass->quizid;
            $grademax   = $sqlass->grademax;
            $grademin   = $sqlass->grademin;
            $gradepass  = $sqlass->gradepass;
            
            $highestattempt = $DB->get_record_sql("SELECT max(attempt) as hattempt FROM mdl_quiz_attempts WHERE quiz = '".$quizid."' AND userid = '".$USER->id."'");
            $attempt = $highestattempt->hattempt;
            if(!empty($attempt))
            { 
              $sqlGrade = $DB->get_record_sql("SELECT sumgrades,timefinish FROM mdl_quiz_attempts WHERE quiz = '".$quizid."' AND userid = '".$USER->id."' AND state = 'finished' AND attempt = '".$attempt."'");
              $resGrade  = $sqlGrade->sumgrades;
              if($resGrade >= $gradepass)
              {
                $state1 = 'pass';
              } 
              else
              {
                $state1 = 'fail';
              }
              if($state1 == 'pass')
              {
                $progress = 'Completed';
                $url       = $CFG->wwwroot.'/course/courseview.php?id='.$id;
                
              }   
              if($state1 == 'fail') 
              {
                $progress = 'Incomplete';
                $url       = $CFG->wwwroot.'/course/view.php?id='.$id;
            
              }
            }
            else
            {
              $sql="SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = '10' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') ";
              $attemptdetails = $DB->get_record_sql($sql);
              if(empty($attemptdetails->value) || $attemptdetails->value == "")
              {
                $progress = 'Not Started';
                $url      = $CFG->wwwroot.'/course/view.php?id='.$id;
              }
              else
              {
                $progress = 'Incomplete';
                $url       = $CFG->wwwroot.'/course/view.php?id='.$id;
            
              }
            } 

            $courseModules = $classObj->getActivities($id);
            $LYLIST=[];
            foreach($courseModules as $key => $module){
              $details =$classObj->getActivityInfo($module->instance,$module->module, $USER->id);
              foreach($details as $key => $details){
                $LYLIST[$details->status]=$details->status;
              }
            }

            if(@$LYLIST['Completed'] && @$LYLIST['Incomplete'] && @$LYLIST['Not Started']){
              $progress="Incomplete";
            }elseif(@$LYLIST['Completed'] && @$LYLIST['Incomplete']=="" && @$LYLIST['Not Started']==""){
              $progress="Completed";
            }elseif(@$LYLIST['Completed']=="" && @$LYLIST['Incomplete']=="" && @$LYLIST['Not Started']==""){
              $progress="Not Started";
            }elseif(@$LYLIST['Completed'] && @$LYLIST['Incomplete']=="" && @$LYLIST['Not Started']){
              $progress="Incomplete";
            }elseif(@$LYLIST['Completed']=="" && @$LYLIST['Incomplete'] && @$LYLIST['Not Started']){
              $progress="Incomplete";
            }elseif(@$LYLIST['Completed'] && @$LYLIST['Incomplete'] && @$LYLIST['Not Started']==""){
              $progress="Incomplete";
            }elseif(@$LYLIST['Completed']=="" && @$LYLIST['Incomplete']=="" && @$LYLIST['Not Started']){
              $progress="Not Started";
            }
            unset($LYLIST);

          }else{
            $sqlScormid = $DB->get_record_sql("SELECT * FROM mdl_scorm WHERE course = '".$id."'");
             $courseContext = context_course::instance($id);
            $checkTag = $DB->get_record_sql('select t.id from {tag} t JOIN {tag_instance} ti ON t.id = ti.tagid WHERE ti.itemtype = ? AND ti.contextid = ? AND t.name =?',array('course',$courseContext->id,'learning_path' ));

            $scormid = $sqlScormid->id;
            $isLearningPathCourse = false;
            if(!empty($checkTag)){
              $module = $DB->get_record_sql('SELECT instance as id FROM {course_modules} where course = ? order by  id desc',array($id));
              $scormid = $module->id;
              $isLearningPathCourse = true;
            }

            // if($arv_flag == 0)
            // {
            //   $sqlScormTrack = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = ".$scormid." AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') order by sb.attempt DESC LIMIT 1";
            // }else{
            //   $sqlScormTrack = "SELECT sb.value FROM {scorm_scoes_track_archeived} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = ".$scormid." AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') order by sb.attempt DESC LIMIT 1";
            // }
               $sqlScormTrack = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= '".$USER->id."' AND sb.scormid = '".$scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') order by sb.attempt DESC LIMIT 1";
               $resultScormTrack = @$DB->get_record_sql($sqlScormTrack);
               if(empty($resultScormTrack->value) || $resultScormTrack->value == "")
            {
              $progress = "Not Started";
              if($isLearningPathCourse){
                  $sql="SELECT * FROM mdl_user_lastaccess where userid=".$USER->id." and courseid=".$id."";
                  $cStatus = $DB->get_record_sql($sql);
                  if(!empty($cStatus)){
                    $progress = 'Incomplete';
                  }
              }
              
              $url       = $CFG->wwwroot.'/course/view.php?id='.$id;
            }
            else
            {
              // todays changes by yogita - 07-03-2020
              //--------------------------------------------------//
              //NEED TO RESTRUCTURE WEBSERVICE 
              $total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '".$USER->id."' AND sb.scormid = '".$scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')");

              $total_marks_max = $DB->get_record_sql("SELECT max(value) as maxscore FROM mdl_scorm_scoes_track as sb WHERE userid = '".$USER->id."' AND scormid = '".$scormid."' AND (sb.element = 'cmi.core.score.raw')");

              $fetch_marks_max = $DB->get_record_sql("SELECT sb.value FROM mdl_scorm_scoes_track as sb WHERE userid = '".$USER->id."' AND scormid = '".$scormid."' AND (sb.element = 'cmi.core.score.raw') ORDER BY sb.attempt DESC LIMIT 1");
              //max score of course
            
			        // $att = $DB->get_record_sql("SELECT max(attempt) as final_attempt from mdl_scorm_scoes_track WHERE userid= '" . $USER->id . "' AND scormid = '" . $scormid . "'");
			        // if($att->final_attempt >= 3)
			        // {
			        //     $range = '>=3';
			        // }else{
			        //     $range = '<=3';
			        // }

			        $resultmax = $DB->get_record_sql("SELECT MAX(CONVERT(sb.value,UNSIGNED INTEGER)) AS maxscore FROM mdl_scorm_scoes_track as sb WHERE sb.userid= '" . $USER->id . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.score.raw' || sb.element = 'cmi.score.raw') AND sb.attempt <=3 ");
              // $resultmax = $DB->get_record_sql("SELECT MAX(CONVERT(sb.value,UNSIGNED INTEGER)) AS maxscore FROM mdl_scorm_scoes_track as sb WHERE sb.userid= '" . $USER->id . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.score.raw' || sb.element = 'cmi.score.raw') AND sb.attempt $range ");
			        $total_marks_max->maxscore = $resultmax->maxscore;
			    
              //end here

              //print_r($total_marks_max->maxscore);
              $i = 1;
              foreach($total_attempt as $val)
              {
                if(($val->value == 'completed' OR $val->value == 'passed') && $fetch_marks_max->value >=0  && $total_marks_max->maxscore <= 80)
                {
                  $progress = "Completed";
                  $url      = $CFG->wwwroot.'/course/courseview.php?id='.$id;
                  break;
                }

                if(($val->value == 'completed' || $val->value == 'passed') && $total_marks_max->maxscore >= 80)
                {
                  $progress = "Completed";
                  $url      = $CFG->wwwroot.'/course/courseview.php?id='.$id;
                  break;
                }
                else
                {
                  $progress = "Incomplete";
                  $url      = $CFG->wwwroot.'/course/view.php?id='.$id;
                }

                if($val->attempt >=3 && ($total_marks_max->maxscore >= 0 )  && $total_marks_max->maxscore < 80)
                {
                  $progress = "Completed";
                  $url = $CFG->wwwroot.'/course/courseview.php?id='.$id;
                }
                if($val->attempt >=3 && ($total_marks_max->maxscore == NULL && $total_marks_max->maxscore == ''))
                {
                  $progress = "Incomplete";
                   $url     = $CFG->wwwroot.'/course/view.php?id='.$id;
                }
                if($val->attempt >=3)
                {
                   $marks3 = $DB->get_record_sql("SELECT * FROM maruti_prod.mdl_scorm_scoes_track where scormid='".$scormid."' and userid='".$USER->id."' and attempt=3 and element = 'cmi.core.score.raw'");
                    if(empty($marks3))
                    {
                        $progress = "Incomplete";
                        //break;
                    }
                   $url     = $CFG->wwwroot.'/course/view.php?id='.$id;
                }
                $i++;
              }
            
            }
          }
           $geofencing_enabled = $onlinecourse->geofencing_enabled;
           $sqlgetpoints = $DB->get_record_sql("SELECT * FROM mdl_ums_user_cordinate WHERE userid = '".$USER->id."'");
           $latitude   = "";
           $longitude  = "";
/*          if($user_type_id == 1){
            $geofencing_enabled = 'No';
          }else{
            if($geofencing_enabled=="Yes"){
              $latitude   = $sqlgetpoints->latitude;
              $longitude  = $sqlgetpoints->longitude;
            }
          }   */       
          $get_time = @$DB->get_field('ums_course_duartion','duration', array('course_id' => $id));
          if(!empty($get_time))
          {
            $course_duration = $get_time;
          }
          else
          {
            $course_duration = "";
          }

           $result[] = array(
            'id' => $id,
            'shortname' => $shortname,
            'fullname'  => $fullname,
            'idnumber'  => $idnumber,
            'visible'   => $visible,
            'summary'   => $summary,
            'summaryformat' => $summaryformat,
            'format' => $format,
            'showgrades' => $showgrades,
            'lang' => $lang,
            'enablecompletion' => $enablecompletion,
            'category' => $category,
            'progress' => $progress,
            'startdate' => $startdate,
            'enddate' => $enddate,
            'enroldate' => $enroldate,
            'enrolenddate' => $enrolenddate,
            'url' => $url,
            'course_duration' => $course_duration,
            'latitude'  => $latitude,
            'longitude' => $longitude,
            'geofencing_enabled' => $geofencing_enabled
          );
        }
        if(empty($result)){
          $result[] = array();
        }
        return $result;
	}

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_mycourses_returns() {
        return new external_multiple_structure(
                new external_single_structure(
                array(
  
      'id'        => new external_value(PARAM_INT, 'id of course', VALUE_OPTIONAL),
      'shortname' => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
      'fullname'  => new external_value(PARAM_RAW, 'long name of course', VALUE_OPTIONAL),
      'idnumber'  => new external_value(PARAM_RAW, 'id number of course', VALUE_OPTIONAL),
      'visible'   => new external_value(PARAM_INT, '1 means visible, 0 means hidden course', VALUE_OPTIONAL),
      'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
      'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
      'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
      'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
      'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
      'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
                            VALUE_OPTIONAL),
      'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
      'progress' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
      'startdate' => new external_value(PARAM_INT, 'Timestamp when the course start', VALUE_OPTIONAL),
      'enddate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
      'enroldate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
      'enrolenddate' => new external_value(PARAM_INT, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
      'url' => new external_value(PARAM_RAW,'course url', VALUE_OPTIONAL),
      'course_duration' => new external_value(PARAM_RAW, 'course duration',VALUE_OPTIONAL),
      'latitude' => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
      'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
      'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL),
                )
                )
        );
    }

  //---------------pending courses------------------------------//

    public static function get_pending_mycourses_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    public static function get_pending_mycourses($welcomemessage = 'Hello world, '){
    global $USER, $DB ,$CFG;
    $user_type_data = $DB->get_record_sql("SELECT user_type_id FROM mdl_ums_employeemaster WHERE 
    userid = '".$USER->id."'");
    $user_type_id  = $user_type_data->user_type_id;
    $onlinecourses = $DB->get_records_sql("select
        c.id as courseid,
        c.fullname as coursename,
        c.summary as summary,
        c.shortname as shortname,
        c.idnumber as idnumber,
        c.visible as visible,
        c.summaryformat as summaryformat,
        c.format,
        c.showgrades,
        c.lang,
        c.enablecompletion,
        c.category,
        b.path,
        c.geofencing_enabled,
        c.startdate,
        c.enddate,
        (
          select count(sa.id) as totalscorms
            from mdl_scorm_scoes as sa
            inner join mdl_scorm as sb ON(sb.id=sa.scorm)
            where sb.course=c.id and sa.scormtype='sco'
        ) as totalscorms,
        (
          select count(sa.id) as totaltracked
            FROM mdl_scorm_scoes_track as sa
            INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
            INNER JOIN mdl_course as sc on (sc.id=sb.course)
            WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='completed' || value='passed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
        ) as totalcompleted,
        (
          select count(sa.id) as totaltracked
            FROM mdl_scorm_scoes_track as sa
            INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
            INNER JOIN mdl_course as sc on (sc.id=sb.course)
            WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='incomplete' || value='failed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
        ) as totalincomplete,
        'duedate',
        (SELECT timestart FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol  where courseid=c.id and enrol='manual') AND userid=a.userid) as courseenrollmentdate,
        (SELECT timecreated FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol  where courseid=c.id and enrol='manual') AND userid=a.userid) as created_date,
        (SELECT timeend FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol where courseid=c.id and enrol='manual') AND userid=a.userid) as enrolenddate

        FROM mdl_role_assignments  as a
        INNER JOIN mdl_context     as b on(b.id=a.contextid)
        INNER JOIN mdl_course      as c on(c.id=b.instanceid)
        left outer join mdl_user   as d on(d.id=a.userid)
        INNER JOIN mdl_course_categories as e on(e.id=c.category)
        where b.contextlevel = 50 and userid = '".$USER->id."' and c.visible=1 and c.category=3 group by c.id ORDER BY c.id DESC");
    //print_r($onlinecourses);exit;
       /*where b.contextlevel = 50 and userid = '".$USER->id."' and c.visible=1 and c.category=3 and e.name<>'assessment container' group by c.id ORDER BY c.id DESC");
        (SELECT archeived_flag FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol where courseid=c.id and enrol='manual') AND userid=a.userid) as ar_flag
       */

      foreach($onlinecourses as $onlinecourse){
          $id        = $onlinecourse->courseid;
          $shortname = $onlinecourse->shortname;
          $fullname  = $onlinecourse->coursename;
          $idnumber  = $onlinecourse->idnumber;
          $visible   = $onlinecourse->visible;
          $summary   = $onlinecourse->summary;
          $summaryformat = $onlinecourse->summaryformat;
          $format     = $onlinecourse->format;
          $showgrades = $onlinecourse->showgrades;
          $lang       = $onlinecourse->lang;
          $enablecompletion = $onlinecourse->enablecompletion;
          $category  = $onlinecourse->category;
          
          $startdate = $onlinecourse->startdate;
          $enddate   = $onlinecourse->enddate;
          $enroldate = $onlinecourse->courseenrollmentdate;
          $enrolenddate = $onlinecourse->enrolenddate;
          $created_date = $onlinecourse->created_date;
          $progress = '';
          if($id == 12)
          { 
            $sqlass = $DB->get_record_sql("SELECT quiz.id as quizid,
            quiz.course,
            grade_items.id,
            grade_items.grademax,
            grade_items.grademin,
            grade_items.gradepass,
            grade_items.itemmodule
            FROM mdl_quiz AS quiz 
            INNER JOIN mdl_grade_items AS grade_items 
            ON grade_items.iteminstance = quiz.id
            WHERE quiz.course= '12' AND 
            quiz.id = '24' AND 
            grade_items.itemmodule = 'quiz'");
            $quizid     = $sqlass->quizid;
            $grademax   = $sqlass->grademax;
            $grademin   = $sqlass->grademin;
            $gradepass  = $sqlass->gradepass;
            
            $highestattempt = $DB->get_record_sql("SELECT max(attempt) as hattempt FROM mdl_quiz_attempts WHERE quiz = '".$quizid."' AND userid = '".$USER->id."'");
            $attempt = $highestattempt->hattempt;
            if(!empty($attempt))
            { 
              $sqlGrade = $DB->get_record_sql("SELECT sumgrades,timefinish FROM mdl_quiz_attempts WHERE quiz = '".$quizid."' AND userid = '".$USER->id."' AND state = 'finished' AND attempt = '".$attempt."'");
              $resGrade  = $sqlGrade->sumgrades;
              if($resGrade >= $gradepass)
              {
                $state1 = 'pass';
              } 
              else
              {
                $state1 = 'fail';
              }
              if($state1 == 'pass')
              {
                $progress = 'Completed';
                $url       = $CFG->wwwroot.'/course/courseview.php?id='.$id;
                
              }   
              if($state1 == 'fail') 
              {
                $progress = 'Incomplete';
                $url       = $CFG->wwwroot.'/course/view.php?id='.$id;
            
              }
            }
            else
            {
              $sql="SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = '10' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') ";
              $attemptdetails = $DB->get_record_sql($sql);
              if(empty($attemptdetails->value) || $attemptdetails->value == "")
              {
                $progress = 'Not Started';
                $url      = $CFG->wwwroot.'/course/view.php?id='.$id;
              }
              else
              {
                $progress = 'Incomplete';
                $url       = $CFG->wwwroot.'/course/view.php?id='.$id;
            
              }
            } 
          }else{
            $sqlScormid = $DB->get_record_sql("SELECT * FROM mdl_scorm WHERE course = '".$id."'");
             $courseContext = context_course::instance($id);
            $checkTag = $DB->get_record_sql('select t.id from {tag} t JOIN {tag_instance} ti ON t.id = ti.tagid WHERE ti.itemtype = ? AND ti.contextid = ? AND t.name =?',array('course',$courseContext->id,'learning_path' ));

            $scormid = $sqlScormid->id;
            $isLearningPathCourse = false;
            if(!empty($checkTag)){
              $module = $DB->get_record_sql('SELECT instance as id FROM {course_modules} where course = ? order by  id desc',array($id));
              $scormid = $module->id;
              $isLearningPathCourse = true;
            }

            // if($arv_flag == 0)
            // {
            //   $sqlScormTrack = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = ".$scormid." AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') order by sb.attempt DESC LIMIT 1";
            // }else{
            //   $sqlScormTrack = "SELECT sb.value FROM {scorm_scoes_track_archeived} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = ".$scormid." AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') order by sb.attempt DESC LIMIT 1";
            // }
               $sqlScormTrack = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= '".$USER->id."' AND sb.scormid = '".$scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') order by sb.attempt DESC LIMIT 1";
               $resultScormTrack = @$DB->get_record_sql($sqlScormTrack);
               if(empty($resultScormTrack->value) || $resultScormTrack->value == "")
            {
              $progress = "Not Started";
              if($isLearningPathCourse){
                  $sql="SELECT * FROM mdl_user_lastaccess where userid=".$USER->id." and courseid=".$id."";
                  $cStatus = $DB->get_record_sql($sql);
                  if(!empty($cStatus)){
                    $progress = 'Incomplete';
                  }
              }
              
              $url       = $CFG->wwwroot.'/course/view.php?id='.$id;
            }
            else
            {
              // todays changes by yogita - 07-03-2020
              //--------------------------------------------------//
              //NEED TO RESTRUCTURE WEBSERVICE 
              // $total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '".$USER->id."' AND sb.scormid = '".$scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')");
              // $ugainScore = $DB->get_record_sql("SELECT max(sb.value) as maxscore FROM {scorm_scoes_track} as sb WHERE sb.userid= '" . $USER->id . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.score.raw' || sb.element = 'cmi.score.raw') AND sb.attempt <= 3");
              // $i = 1;
              // foreach($total_attempt as $val)
              // {
              //   if($val->value == 'completed' || $val->value == 'passed' && $ugainScore->maxscore>=80)
              //   {
              //     $progress = "Completed";
              //     $url      = $CFG->wwwroot.'/course/courseview.php?id='.$id;
              //     break;
              //   }
              //   else
              //   {
              //     $progress = "Incomplete";
              //     $url      = $CFG->wwwroot.'/course/view.php?id='.$id;
              //   }
              //   if(($val->attempt >=3) && ($ugainScore->maxscore >= 0 && $ugainScore->maxscore < 80))
              //   {
              //     $progress = "Completed";
              //     $url = $CFG->wwwroot.'/course/courseview.php?id='.$id;
              //   }

              //   if(($val->attempt >=3) && ($ugainScore->maxscore == Null && $ugainScore->maxscore == ''))
              //   {
              //     $progress = "Incomplete";
              //      $url     = $CFG->wwwroot.'/course/view.php?id='.$id;
              //   }
              //   if($val->attempt >=3)
              //   {
              //      $marks3 = $DB->get_record_sql("SELECT * FROM maruti_prod.mdl_scorm_scoes_track where scormid='".$scormid."' and userid='".$USER->id."' and attempt=3 and element = 'cmi.core.score.raw'");
              //       if(empty($marks3))
              //       {
              //           $progress = "Incomplete";
              //           //break;
              //       }
              //      $url     = $CFG->wwwroot.'/course/view.php?id='.$id;
              //   }
              //   $i++;
              // }


           	//new code
            $total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '".$USER->id."' AND sb.scormid = '".$scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')");

            $total_marks_max = $DB->get_record_sql("SELECT max(value) as maxscore FROM mdl_scorm_scoes_track as sb WHERE userid = '".$USER->id."' AND scormid = '".$scormid."' AND (sb.element = 'cmi.core.score.raw')");

	        $resultmax = $DB->get_record_sql("SELECT MAX(CONVERT(sb.value,UNSIGNED INTEGER)) AS maxscore FROM mdl_scorm_scoes_track as sb WHERE sb.userid= '" . $USER->id . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.score.raw' || sb.element = 'cmi.score.raw') AND sb.attempt <=3 ");
	        $total_marks_max->maxscore = $resultmax->maxscore;
			    
              //end here

              //print_r($total_marks_max->maxscore);
              $i = 1;
              foreach($total_attempt as $val)
              {
                if(($val->value == 'completed' || $val->value == 'passed') && $total_marks_max->maxscore >= 0)
                {
                  $progress = "Completed";
                  $url      = $CFG->wwwroot.'/course/courseview.php?id='.$id;
                  break;
                }

                if(($val->value == 'completed' || $val->value == 'passed') && $total_marks_max->maxscore >= 80)
                {
                  $progress = "Completed";
                  $url      = $CFG->wwwroot.'/course/courseview.php?id='.$id;
                  break;
                }
                else
                {
                  $progress = "Incomplete";
                  $url      = $CFG->wwwroot.'/course/view.php?id='.$id;
                }
                if($val->attempt >=3 && ($total_marks_max->maxscore >= 0 )  && $total_marks_max->maxscore < 80)
                {
                  $progress = "Completed";
                  $url = $CFG->wwwroot.'/course/courseview.php?id='.$id;
                }
                if($val->attempt >=3 && ($total_marks_max->maxscore == NULL && $total_marks_max->maxscore == ''))
                {
                  $progress = "Incomplete";
                   $url     = $CFG->wwwroot.'/course/view.php?id='.$id;
                }
                if($val->attempt >=3)
                {
                   $marks3 = $DB->get_record_sql("SELECT * FROM maruti_prod.mdl_scorm_scoes_track where scormid='".$scormid."' and userid='".$USER->id."' and attempt=3 and element = 'cmi.core.score.raw'");
                    if(empty($marks3))
                    {
                        $progress = "Incomplete";
                        //break;
                    }
                   $url     = $CFG->wwwroot.'/course/view.php?id='.$id;
                }
                $i++;
              }
            }
          }
           $geofencing_enabled = $onlinecourse->geofencing_enabled;
           $sqlgetpoints = $DB->get_record_sql("SELECT * FROM mdl_ums_user_cordinate WHERE userid = '".$USER->id."'");
           $latitude   = "";
           $longitude  = "";
          if($user_type_id == 1){
            $geofencing_enabled = 'No';
          }else{
            if($geofencing_enabled=="Yes"){
              $latitude   = $sqlgetpoints->latitude;
              $longitude  = $sqlgetpoints->longitude;
            }
          }          
          $get_time = @$DB->get_field('ums_course_duartion','duration', array('course_id' => $id));
          if(!empty($get_time))
          {
            $course_duration = $get_time;
          }
          else
          {
            $course_duration = "";
          }

          if($enrolenddate == 0)
          {
             $final_end_date = "0";
             
          }else{
              $final_end_date = date('Y-m-d', $enrolenddate);
          }

          $modulecount=0;
          $list = get_array_of_activities($id);
          if(!empty($list))
          {
            foreach($list as $l)
            {
              if($l->mod=='scorm' && $l->deletioninprogress!=1)
              {
                $modulecount++;
              }           
            }
          }

          //code for emoji count gramx

          $regidsql   = "SELECT * FROM mdl_ums_emoji_responses where menutype='course' and element_id='".$id."'";
          //echo $regidsql;exit;

          $regdata  = $DB->get_records_sql($regidsql);

          $cnt_like = 0;
          $like = 0;
          $cnt_exciting = 0;
          $exciting = 0;
          $cnt_insightful = 0;
          $insightful = 0;
          $cnt_celebrate = 0;
          $celebrate = 0;
          $cnt_support = 0;
          $support = 0;
          $cnt_inquisitive = 0;
          $inquisitive = 0;
          $cnt_view = 0;
          $views = 0;
          foreach($regdata as $reg)
          {
              if($reg->emoji_id == 1)
              {
                  $like = $cnt_like+1;
                  $cnt_like++;
              }
              if($reg->emoji_id == 6)
              {
                  $exciting = $cnt_exciting+1;
                  $cnt_exciting++;
              }
              if($reg->emoji_id == 7)
              {
                  $insightful = $cnt_insightful+1;
                  $cnt_insightful++;
              }
              if($reg->emoji_id == 8)
              {
                  $celebrate = $cnt_celebrate+1;
                  $cnt_celebrate++;
              }
              if($reg->emoji_id == 12)
              {
                  $support = $cnt_support+1;
                  $cnt_support++;
              }
              if($reg->emoji_id == 9)
              {
                  $inquisitive = $cnt_inquisitive+1;
                  $cnt_inquisitive++;
              }
              if($reg->emoji_id == 10)
              {
                  $views = $cnt_view+1;
                  $cnt_view++;
              }
              
          }

          $regidsql1   = "SELECT * FROM mdl_ums_emoji_responses_comments where menutype='course' and element_id='".$id."'";
          //echo $regidsql1;
          $regdata1  = $DB->get_records_sql($regidsql1);
          $cnt_comment = 0;
          $comment = 0;
          foreach($regdata1 as $reg1)
          {
              $comment = $cnt_comment+1;
              $cnt_comment++;
          }

          //end here emoji count gramx

          $dates =  date('Y-m-d');
          //echo $id.'--'.$shortname.'--'.$progress.'<br>';

          if($progress != 'Completed' &&  ($final_end_date == 0 || $final_end_date > $dates))
          {
              $result[] = array(
            'id' => $id,
            'shortname' => $shortname,
            'fullname'  => $fullname,
            'idnumber'  => $idnumber,
            'visible'   => $visible,
            'summary'   => $summary,
            'summaryformat' => $summaryformat,
            'format' => $format,
            'showgrades' => $showgrades,
            'lang' => $lang,
            'enablecompletion' => $enablecompletion,
            'category' => $category,
            'progress' => $progress,
            'startdate' => date('Y-m-d',$startdatedate),
            'enddate' => date('Y-m-d',$enddate),
            'enroldate' => date('Y-m-d',$enroldate),
            'enrolenddate' => date('Y-m-d',$enrolenddate),
            'created_date' => date('d-m-Y H:i:s',$created_date),
            'created' => date('d-m-Y H:i:s',$created_date),
            'url' => $url,
            'totalsubcourses'=>$modulecount,
            'course_duration' => $course_duration,
            'latitude'  => $latitude,
            'longitude' => $longitude,
            'radius' => 100,
            'geofencing_enabled' => $geofencing_enabled,
            'view'=>$views,
            'like'=>$like,
            'comment'=>$comment,
            'exciting'=>$exciting,
            'celebrate'=>$celebrate,
            'insightful'=>$insightful,
            'inquisitive'=>$inquisitive,
            'support'=>$support
          );
          }
  
        }
        if(empty($result)){
          $result[] = array();
        }
        return $result;
  }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_pending_mycourses_returns() {
        return new external_multiple_structure(
                new external_single_structure(
                array(
  
      'id'        => new external_value(PARAM_INT, 'id of course', VALUE_OPTIONAL),
      'shortname' => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
      'fullname'  => new external_value(PARAM_RAW, 'long name of course', VALUE_OPTIONAL),
      'idnumber'  => new external_value(PARAM_RAW, 'id number of course', VALUE_OPTIONAL),
      'visible'   => new external_value(PARAM_INT, '1 means visible, 0 means hidden course', VALUE_OPTIONAL),
      'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
      'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
      'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
      'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
      'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
      'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
                            VALUE_OPTIONAL),
      'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
      'progress' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
      'startdate' => new external_value(PARAM_RAW, 'Timestamp when the course start', VALUE_OPTIONAL),
      'enddate' => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
      'enroldate' => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
      'enrolenddate' => new external_value(PARAM_RAW, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
      'created_date' => new external_value(PARAM_RAW, 'Timestamp when the enrolment date', VALUE_OPTIONAL),
      'created' => new external_value(PARAM_RAW, 'Timestamp when the enrolment date', VALUE_OPTIONAL),
      'totalsubcourses' => new external_value(PARAM_INT,'count of modules', VALUE_OPTIONAL),
      'url' => new external_value(PARAM_RAW,'course url', VALUE_OPTIONAL),
      'course_duration' => new external_value(PARAM_RAW, 'course duration',VALUE_OPTIONAL),
      'latitude' => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
      'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
      'radius' => new external_value(PARAM_INT, 'radius point of user location',VALUE_OPTIONAL),
      'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL),
      'view' => new external_value(PARAM_INT,'total view', VALUE_OPTIONAL),
          'like' => new external_value(PARAM_INT,'total like', VALUE_OPTIONAL),
          'comment' => new external_value(PARAM_INT,'total comment', VALUE_OPTIONAL),
          'exciting' => new external_value(PARAM_INT,'total comment', VALUE_OPTIONAL),
          'celebrate' => new external_value(PARAM_INT,'total comment', VALUE_OPTIONAL),
          'insightful' => new external_value(PARAM_INT,'total comment', VALUE_OPTIONAL),
          'inquisitive' => new external_value(PARAM_INT,'total comment', VALUE_OPTIONAL),
          'support' => new external_value(PARAM_INT,'total comment', VALUE_OPTIONAL),
                )
                )
        );
    }

  //----------- get history courses ----------------------------//

    public static function get_history_mycourses_parameters() {

        return new external_function_parameters(
                array('dates' => new external_value(PARAM_RAW, 'version'))
        );
    }

    public static function get_history_mycourses($dates){
    global $USER, $DB ,$CFG;
    $user_type_data = $DB->get_record_sql("SELECT user_type_id FROM mdl_ums_employeemaster WHERE 
    userid = '".$USER->id."'");
    $user_type_id  = $user_type_data->user_type_id;
    $onlinecourses = $DB->get_records_sql("select
        c.id as courseid,
        c.fullname as coursename,
        c.summary as summary,
        c.shortname as shortname,
        c.idnumber as idnumber,
        c.visible as visible,
        c.summaryformat as summaryformat,
        c.format,
        c.showgrades,
        c.lang,
        c.enablecompletion,
        c.category,
        b.path,
        c.geofencing_enabled,
        c.startdate,
        c.enddate,
        (
          select count(sa.id) as totalscorms
            from mdl_scorm_scoes as sa
            inner join mdl_scorm as sb ON(sb.id=sa.scorm)
            where sb.course=c.id and sa.scormtype='sco'
        ) as totalscorms,
        (
          select count(sa.id) as totaltracked
            FROM mdl_scorm_scoes_track as sa
            INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
            INNER JOIN mdl_course as sc on (sc.id=sb.course)
            WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='completed' || value='passed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
        ) as totalcompleted,
        (
          select count(sa.id) as totaltracked
            FROM mdl_scorm_scoes_track as sa
            INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
            INNER JOIN mdl_course as sc on (sc.id=sb.course)
            WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='incomplete' || value='failed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
        ) as totalincomplete,
        'duedate',
        (SELECT timestart FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol  where courseid=c.id and enrol='manual') AND userid=a.userid) as courseenrollmentdate,
        (SELECT timecreated FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol  where courseid=c.id and enrol='manual') AND userid=a.userid) as created_date,
        (SELECT timeend FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol where courseid=c.id and enrol='manual') AND userid=a.userid) as enrolenddate

        FROM mdl_role_assignments  as a
        INNER JOIN mdl_context     as b on(b.id=a.contextid)
        INNER JOIN mdl_course      as c on(c.id=b.instanceid)
        left outer join mdl_user   as d on(d.id=a.userid)
        INNER JOIN mdl_course_categories as e on(e.id=c.category)
        where b.contextlevel = 50 and userid = '".$USER->id."' and c.visible=1 and c.category=3 group by c.id ORDER BY c.id DESC");
    //print_r($onlinecourses);exit;
       /*where b.contextlevel = 50 and userid = '".$USER->id."' and c.visible=1 and c.category=3 and e.name<>'assessment container' group by c.id ORDER BY c.id DESC");
        (SELECT archeived_flag FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol where courseid=c.id and enrol='manual') AND userid=a.userid) as ar_flag
       */

      foreach($onlinecourses as $onlinecourse){
          $id        = $onlinecourse->courseid;
          $shortname = $onlinecourse->shortname;
          $fullname  = $onlinecourse->coursename;
          $idnumber  = $onlinecourse->idnumber;
          $visible   = $onlinecourse->visible;
          $summary   = $onlinecourse->summary;
          $summaryformat = $onlinecourse->summaryformat;
          $format     = $onlinecourse->format;
          $showgrades = $onlinecourse->showgrades;
          $lang       = $onlinecourse->lang;
          $enablecompletion = $onlinecourse->enablecompletion;
          $category  = $onlinecourse->category;
          
          $startdate = $onlinecourse->startdate;
          $enddate   = $onlinecourse->enddate;
          $enroldate = $onlinecourse->courseenrollmentdate;
          $enrolenddate = $onlinecourse->enrolenddate;
          $created_date = $onlinecourse->created_date;
                    $progress = '';
          if($id == 12)
          { 
            $sqlass = $DB->get_record_sql("SELECT quiz.id as quizid,
            quiz.course,
            grade_items.id,
            grade_items.grademax,
            grade_items.grademin,
            grade_items.gradepass,
            grade_items.itemmodule
            FROM mdl_quiz AS quiz 
            INNER JOIN mdl_grade_items AS grade_items 
            ON grade_items.iteminstance = quiz.id
            WHERE quiz.course= '12' AND 
            quiz.id = '24' AND 
            grade_items.itemmodule = 'quiz'");
            $quizid     = $sqlass->quizid;
            $grademax   = $sqlass->grademax;
            $grademin   = $sqlass->grademin;
            $gradepass  = $sqlass->gradepass;
            
            $highestattempt = $DB->get_record_sql("SELECT max(attempt) as hattempt FROM mdl_quiz_attempts WHERE quiz = '".$quizid."' AND userid = '".$USER->id."'");
            $attempt = $highestattempt->hattempt;
            if(!empty($attempt))
            { 
              $sqlGrade = $DB->get_record_sql("SELECT sumgrades,timefinish FROM mdl_quiz_attempts WHERE quiz = '".$quizid."' AND userid = '".$USER->id."' AND state = 'finished' AND attempt = '".$attempt."'");
              $resGrade  = $sqlGrade->sumgrades;
              if($resGrade >= $gradepass)
              {
                $state1 = 'pass';
              } 
              else
              {
                $state1 = 'fail';
              }
              if($state1 == 'pass')
              {
                $progress = 'Completed';
                $url       = $CFG->wwwroot.'/course/courseview.php?id='.$id;
                
              }   
              if($state1 == 'fail') 
              {
                $progress = 'Incomplete';
                $url       = $CFG->wwwroot.'/course/view.php?id='.$id;
            
              }
            }
            else
            {
              $sql="SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = '10' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') ";
              $attemptdetails = $DB->get_record_sql($sql);
              if(empty($attemptdetails->value) || $attemptdetails->value == "")
              {
                $progress = 'Not Started';
                $url      = $CFG->wwwroot.'/course/view.php?id='.$id;
              }
              else
              {
                $progress = 'Incomplete';
                $url       = $CFG->wwwroot.'/course/view.php?id='.$id;
            
              }
            } 
          }else{
            $sqlScormid = $DB->get_record_sql("SELECT * FROM mdl_scorm WHERE course = '".$id."'");
             $courseContext = context_course::instance($id);
            $checkTag = $DB->get_record_sql('select t.id from {tag} t JOIN {tag_instance} ti ON t.id = ti.tagid WHERE ti.itemtype = ? AND ti.contextid = ? AND t.name =?',array('course',$courseContext->id,'learning_path' ));

            $scormid = $sqlScormid->id;
            $isLearningPathCourse = false;
            if(!empty($checkTag)){
              $module = $DB->get_record_sql('SELECT instance as id FROM {course_modules} where course = ? order by  id desc',array($id));
              $scormid = $module->id;
              $isLearningPathCourse = true;
            }

            // if($arv_flag == 0)
            // {
            //   $sqlScormTrack = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = ".$scormid." AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') order by sb.attempt DESC LIMIT 1";
            // }else{
            //   $sqlScormTrack = "SELECT sb.value FROM {scorm_scoes_track_archeived} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = ".$scormid." AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') order by sb.attempt DESC LIMIT 1";
            // }
               $sqlScormTrack = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= '".$USER->id."' AND sb.scormid = '".$scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') order by sb.attempt DESC LIMIT 1";
               $resultScormTrack = @$DB->get_record_sql($sqlScormTrack);
               if(empty($resultScormTrack->value) || $resultScormTrack->value == "")
            {
              $progress = "Not Started";
              if($isLearningPathCourse){
                  $sql="SELECT * FROM mdl_user_lastaccess where userid=".$USER->id." and courseid=".$id."";
                  $cStatus = $DB->get_record_sql($sql);
                  if(!empty($cStatus)){
                    $progress = 'Incomplete';
                  }
              }
              
              $url       = $CFG->wwwroot.'/course/view.php?id='.$id;
            }
            else
            {
              // todays changes by yogita - 07-03-2020
              //--------------------------------------------------//
              //NEED TO RESTRUCTURE WEBSERVICE 
              // $total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '".$USER->id."' AND sb.scormid = '".$scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')");
              // $ugainScore = $DB->get_record_sql("SELECT max(sb.value) as maxscore FROM {scorm_scoes_track} as sb WHERE sb.userid= '" . $USER->id . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.score.raw' || sb.element = 'cmi.score.raw') AND sb.attempt <= 3");
              // $i = 1;
              // foreach($total_attempt as $val){
              //   if(($val->value == 'completed' || $val->value == 'passed') && $ugainScore->maxscore>80){
              //     $progress = "Completed";
              //     $url      = $CFG->wwwroot.'/course/courseview.php?id='.$id;
              //     break;
              //   }else{
              //     $progress = "Incomplete";
              //     $url      = $CFG->wwwroot.'/course/view.php?id='.$id;
              //   }
              //   if(($val->attempt >=3) && ($ugainScore->maxscore> 0 && $ugainScore->maxscore<80)){
              //     $progress = "Completed";
              //     $url = $CFG->wwwroot.'/course/courseview.php?id='.$id;
              //   }
              //    if(($val->attempt >=3) && ($ugainScore->maxscore == Null && $ugainScore->maxscore == ''))
              //   {
              //     $progress = "Incomplete";
              //      $url     = $CFG->wwwroot.'/course/view.php?id='.$id;
              //   }
              //   $i++;
              // }


           	  // New code 

            $total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '".$USER->id."' AND sb.scormid = '".$scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')");

            $total_marks_max = $DB->get_record_sql("SELECT max(value) as maxscore FROM mdl_scorm_scoes_track as sb WHERE userid = '".$USER->id."' AND scormid = '".$scormid."' AND (sb.element = 'cmi.core.score.raw')");

	        $resultmax = $DB->get_record_sql("SELECT MAX(CONVERT(sb.value,UNSIGNED INTEGER)) AS maxscore FROM mdl_scorm_scoes_track as sb WHERE sb.userid= '" . $USER->id . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.score.raw' || sb.element = 'cmi.score.raw') AND sb.attempt <=3 ");
     
	        $total_marks_max->maxscore = $resultmax->maxscore;
			    
              //end here
            if(!empty($resultScormTrack->value) || $resultScormTrack->value != ""){ 
            if($resultScormTrack->value=="completed" || $val->value == 'passed'){ 
              $progress = "Completed";  
              $url      = $CFG->wwwroot.'/course/courseview.php?id='.$id; 
            }else{  
              $progress = "Incomplete"; 
              $url      = $CFG->wwwroot.'/course/view.php?id='.$id; 
            } 
          } 
/*    
              //print_r($total_marks_max->maxscore);
              $i = 1;
              foreach($total_attempt as $val)
              {
                if(($val->value == 'completed' || $val->value == 'passed') && $total_marks_max->maxscore >= 80)
                {
                  $progress = "Completed";
                  $url      = $CFG->wwwroot.'/course/courseview.php?id='.$id;
                  break;
                }
                else
                {
                  $progress = "Incomplete";
                  $url      = $CFG->wwwroot.'/course/view.php?id='.$id;
                }
                if($val->attempt >=3 && ($total_marks_max->maxscore >= 0 )  && $total_marks_max->maxscore < 80)
                {
                  $progress = "Completed";
                  $url = $CFG->wwwroot.'/course/courseview.php?id='.$id;
                }
                if($val->attempt >=3 && ($total_marks_max->maxscore == NULL && $total_marks_max->maxscore == ''))
                {
                  $progress = "Incomplete";
                   $url     = $CFG->wwwroot.'/course/view.php?id='.$id;
                }
                if($val->attempt >=3)
                {
                   $marks3 = $DB->get_record_sql("SELECT * FROM maruti_prod.mdl_scorm_scoes_track where scormid='".$scormid."' and userid='".$USER->id."' and attempt=3 and element = 'cmi.core.score.raw'");
                    if(empty($marks3))
                    {
                        $progress = "Incomplete";
                        //break;
                    }
                   $url     = $CFG->wwwroot.'/course/view.php?id='.$id;
                }
                $i++;
              }
            
            }
          }
           $geofencing_enabled = $onlinecourse->geofencing_enabled;
           $sqlgetpoints = $DB->get_record_sql("SELECT * FROM mdl_ums_user_cordinate WHERE userid = '".$USER->id."'");
           $latitude   = "";
           $longitude  = "";
          if($user_type_id == 1){
            $geofencing_enabled = 'No';
          }else{
            if($geofencing_enabled=="Yes"){
              $latitude   = $sqlgetpoints->latitude;
              $longitude  = $sqlgetpoints->longitude;
            }
          }          
          $get_time = @$DB->get_field('ums_course_duartion','duration', array('course_id' => $id));
          if(!empty($get_time))
          {
            $course_duration = $get_time;
          }
          else
          {
            $course_duration = "";
          }

          if($enrolenddate == 0)
          {
             $final_end_date = "0";
             
          }else{
              $final_end_date = date('Y-m-d', $enrolenddate);
          }

          $dates =  date('Y-m-d');
          $modulecount=0;
          $list = get_array_of_activities($id);
          if(!empty($list))
          {
            foreach($list as $l)
            {
              if($l->mod=='scorm' && $l->deletioninprogress!=1)
              {
                $modulecount++;
              }           
            }
          }

$Fstatus="NoExpired";       
if($enrolenddate < strtotime(date('Y-m-d'))){
  $Fstatus="Expired";
}
if($Fstatus == "Expired")
{
  $msg ='Enrollment validity is expired, Please contact LMS admin';
}else{
  $msg ='';
}

        if(($final_end_date < $dates && $final_end_date != 0) || ($final_end_date == 0 && $progress == 'Completed') || $progress == 'Completed')
          {             
            $result[] = array(
            'id' => $id,
            'shortname' => $shortname,
            'fullname'  => $fullname,
            'idnumber'  => $idnumber,
            'visible'   => $visible,
            'summary'   => $summary,
            'summaryformat' => $summaryformat,
            'format' => $format,
            'showgrades' => $showgrades,
            'lang' => $lang,
            'enablecompletion' => $enablecompletion,
            'category' => $category,
            'progress' => $progress,
            'startdate' => date('Y-m-d',$startdate),
            'enddate' => date('Y-m-d',$enddate),
            'enroldate' => date('Y-m-d',$enroldate),
            'enrolenddate' => date('Y-m-d',$enrolenddate),
            'created_date' => date('d-m-Y H:i:s',$created_date),
            'created' => date('d-m-Y H:i:s',$created_date),
            'url' => $url,
            'totalsubcourses'=>$modulecount,
            'course_duration' => $course_duration,
            'latitude'  => $latitude,
            'longitude' => $longitude,
            'radius' => 100,
            'status'=>$Fstatus,
            'msg'=>$msg,
            'geofencing_enabled' => $geofencing_enabled
          );
          }
  
        }
        if(empty($result)){
          $result[] = array();
        }
        return $result;
  }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_history_mycourses_returns() {
        return new external_multiple_structure(
                new external_single_structure(
                array(
  
      'id'        => new external_value(PARAM_INT, 'id of course', VALUE_OPTIONAL),
      'shortname' => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
      'fullname'  => new external_value(PARAM_RAW, 'long name of course', VALUE_OPTIONAL),
      'idnumber'  => new external_value(PARAM_RAW, 'id number of course', VALUE_OPTIONAL),
      'visible'   => new external_value(PARAM_INT, '1 means visible, 0 means hidden course', VALUE_OPTIONAL),
      'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
      'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
      'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
      'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
      'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
      'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
                            VALUE_OPTIONAL),
      'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
      'progress' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
      'startdate' => new external_value(PARAM_RAW, 'Timestamp when the course start', VALUE_OPTIONAL),
      'enddate' => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
      'enroldate' => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
      'enrolenddate' => new external_value(PARAM_RAW, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
      'created_date' => new external_value(PARAM_RAW, 'Timestamp when the created enrollment', VALUE_OPTIONAL),
      'created' => new external_value(PARAM_RAW, 'Timestamp when the created enrollment', VALUE_OPTIONAL),
      'url' => new external_value(PARAM_RAW,'course url', VALUE_OPTIONAL),
      'totalsubcourses' => new external_value(PARAM_INT,'count of modules', VALUE_OPTIONAL),
      'course_duration' => new external_value(PARAM_RAW, 'course duration',VALUE_OPTIONAL),
      'latitude' => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
      'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
      'radius' => new external_value(PARAM_INT, 'radius point of user location',VALUE_OPTIONAL),
      'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL),
      'status' => new external_value(PARAM_RAW, 'status',VALUE_OPTIONAL),
      'msg' => new external_value(PARAM_RAW, 'msg',VALUE_OPTIONAL),
                )
                )
        );
    }

	//----------- survey code by yogita 7 sept 2020 --------------//
	
	public static function get_mysurvey_parameters() 
    {
        return new external_function_parameters(
            array()
        );
    }
	
	public static function get_mysurvey() 
	{
          global $USER,$DB,$CFG;
		$onlinesurvey = "select concat(a.id,'_',d.id) as tempid,
							a.id as userid,
							d.id as courseid,
							d.fullname as surveyname,
							d.summary as summary,
							d.shortname as shortname,
							d.idnumber as idnumber,
							d.visible as visible,
							d.summaryformat as summaryformat,
							d.format as cformat,
							d.showgrades,
							d.lang,
							d.enablecompletion,
							d.category,
							d.startdate,
							d.enddate,
							en.timestart,
							en.timeend,
							b.timemodified as courseassigndate,
              	            d.geofencing_enabled
							from mdl_user as a		
							inner join mdl_role_assignments as b  on(b.userid=a.id)
							inner join mdl_context as c on (c.id=b.contextid and c.contextlevel=50)
							inner join mdl_course as d on (d.id=c.instanceid)	
							inner join mdl_course_categories as cat on cat.id = d.category	
							inner join mdl_user_enrolments as en ON (en.userid=b.userid AND en.enrolid in (select id from mdl_enrol where courseid=d.id)) 
							WHERE a.username!='guest' AND a.id>2 AND a.suspended = 0 AND a.deleted = 0
							AND d.category !=0 AND d.visible=1 AND d.is_kca=0 AND cat.id = 11 AND a.id = '".$USER->id."'";
							
		$resultsurvey = $DB->get_records_sql($onlinesurvey, array());
		$user_type_data = $DB->get_record_sql("SELECT user_type_id, code FROM mdl_ums_employeemaster WHERE 
			userid = '".$USER->id."'");
		$user_type_id  = $user_type_data->user_type_id;
        $sqlgetpoints = $DB->get_record_sql("SELECT * FROM mdl_ums_user_cordinate WHERE userid = '".$USER->id."'");
        $latitude   = null;
        $longitude  = null;

        foreach($resultsurvey as $rows)
		{
			$courseid   = $rows->courseid;
			
			$surveyname = (isset($rows->surveyname) && !empty($rows->surveyname)) ? $rows->surveyname : "";
			
			$timestart  = $rows->timestart;
			
			$timeend    = (isset($rows->timeend) && ($rows->timeend!=null)) ? $rows->timeend : "-";
			
			$userid     = $rows->userid;
			$summary    = $rows->summary;
			$shortname  = $rows->shortname;
			
			$idnumber   = $rows->idnumber;
			$visible    = $rows->visible;
			$summaryformat = $rows->summaryformat;
			$format     = $rows->format;
			$showgrades = $rows->showgrades;
			$lang       = $rows->lang;
			$enablecompletion = $rows->enablecompletion;
			$category   = $rows->category;
			$startdate  = $rows->startdate;
			$enddate    = $rows->enddate;  
			$surveyid   = $DB->get_field('questionnaire','id', array('course'=>$courseid));
			// $rid = $DB->get_field("questionnaire_response", "id", array("userid"=>$userid, "survey_id"=>$surveyid));
      $rid = $DB->get_field("questionnaire_response", "id", array("userid"=>$userid, "questionnaireid"=>$surveyid));
			if($rid) 
			{
				$response = $DB->get_record('questionnaire_response',array('id'=>$rid));
				if($response->complete == 'y') 
				{
					$progress = 'Completed';
				}
				else
				{	
					$progress = 'Not completed';
				}
							 
			}
			else
			{
				$progress = 'Not started';
				
			}
			$url = $CFG->wwwroot.'/course/view.php?id='.$courseid;
			$geofencing_enabled = $rows->geofencing_enabled;
			if($user_type_id == 1){
				$geofencing_enabled = 'No';
			}else{
				if($geofencing_enabled=="Yes"){
					$latitude   = $sqlgetpoints->latitude;
					$longitude  = $sqlgetpoints->longitude;
				}
			}
			$result[] = array(
						'id' => $courseid,
						'fullname'  => $surveyname,
						'enroldate' => $timestart,
						'enrolenddate' => $timeend,
						'shortname' => $shortname,
						'summary'   => $summary,
						'idnumber'  => $idnumber,
						'visible'   => $visible,
						'summaryformat' => $summaryformat,
						'format' => $format,
						'showgrades' => $showgrades,
						'lang' => $lang,
						'enablecompletion' => $enablecompletion,
						'category' => $category,
						'progress' => $progress,
						'startdate' => $startdate,
						'enddate' => $enddate,
						'url' => $url,
						'latitude'=>$latitude,
						'longitude'=>$longitude,
						'geofencing_enabled'=>$geofencing_enabled
					);	
		}
		if(empty($result)){
            $result[] = array();
        }
        return $result;
    }
	
	public static function get_mysurvey_returns() 
	{
        return new external_multiple_structure(
                new external_single_structure(
	array(

		'id'            => new external_value(PARAM_INT, 'id of course', VALUE_OPTIONAL),
                    'shortname'     => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
                    'fullname'      => new external_value(PARAM_RAW, 'long name of course', VALUE_OPTIONAL),
                    'idnumber'      => new external_value(PARAM_RAW, 'id number of course', VALUE_OPTIONAL),
                    'visible'       => new external_value(PARAM_INT, '1 means visible, 0 means hidden course', VALUE_OPTIONAL),
                    'summary'       => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'      => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades'  => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'        => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',VALUE_OPTIONAL),
                    'category'     => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress'     => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate'    => new external_value(PARAM_INT, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate'      => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate'    => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_INT, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'url'          => new external_value(PARAM_RAW,'course url', VALUE_OPTIONAL),
					'c'          => new external_value(PARAM_RAW,'count', VALUE_OPTIONAL),
					'latitude' => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
					'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
					'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL),
	)
                )
        );
    }


  //---------------------get_pending_survey---------------------------------

  public static function get_pending_mysurvey_parameters() 
  {
      return new external_function_parameters(
          array()
      );
  }
  
  public static function get_pending_mysurvey() 
  {
          global $USER,$DB,$CFG;
    $onlinesurvey = "select concat(a.id,'_',d.id) as tempid,
              a.id as userid,
              d.id as courseid,
              d.fullname as surveyname,
              d.summary as summary,
              d.shortname as shortname,
              d.idnumber as idnumber,
              d.visible as visible,
              d.summaryformat as summaryformat,
              d.format as cformat,
              d.showgrades,
              d.lang,
              d.enablecompletion,
              d.category,
              d.startdate,
              d.enddate,
              en.timestart,
              en.timeend,
              en.timecreated,
              b.timemodified as courseassigndate,
                            d.geofencing_enabled
              from mdl_user as a    
              inner join mdl_role_assignments as b  on(b.userid=a.id)
              inner join mdl_context as c on (c.id=b.contextid and c.contextlevel=50)
              inner join mdl_course as d on (d.id=c.instanceid) 
              inner join mdl_course_categories as cat on cat.id = d.category  
              inner join mdl_user_enrolments as en ON (en.userid=b.userid AND en.enrolid in (select id from mdl_enrol where courseid=d.id)) 
              WHERE a.username!='guest' AND a.id>2 AND a.suspended = 0 AND a.deleted = 0
              AND d.category !=0 AND d.visible=1 AND d.is_kca=0 AND cat.id = 11 AND a.id = '".$USER->id."'";
              
    $resultsurvey = $DB->get_records_sql($onlinesurvey, array());
    $user_type_data = $DB->get_record_sql("SELECT user_type_id, code FROM mdl_ums_employeemaster WHERE 
      userid = '".$USER->id."'");
    $user_type_id  = $user_type_data->user_type_id;
        $sqlgetpoints = $DB->get_record_sql("SELECT * FROM mdl_ums_user_cordinate WHERE userid = '".$USER->id."'");
        $latitude   = null;
        $longitude  = null;

    foreach($resultsurvey as $rows)
    {

      $courseid   = $rows->courseid;

      //echo $courseid.'-';
      
      $surveyname = (isset($rows->surveyname) && !empty($rows->surveyname)) ? $rows->surveyname : "";
      
      $timestart  = $rows->timestart;
      
      $timeend    = (isset($rows->timeend) && ($rows->timeend!=null)) ? $rows->timeend : "-";
      
      $userid     = $rows->userid;
      $summary    = $rows->summary;
      $shortname  = $rows->shortname;
      
      $idnumber   = $rows->idnumber;
      $visible    = $rows->visible;
      $summaryformat = $rows->summaryformat;
      $format     = $rows->format;
      $showgrades = $rows->showgrades;
      $lang       = $rows->lang;
      $enablecompletion = $rows->enablecompletion;
      $category   = $rows->category;
      $startdate  = $rows->startdate;
      $enddate    = $rows->enddate; 
      $created_date = $rows->timecreated;   
      $surveyid   = $DB->get_field('questionnaire','id', array('course'=>$courseid));
      // $rid = $DB->get_field("questionnaire_response", "id", array("userid"=>$userid, "survey_id"=>$surveyid));
      $rid = $DB->get_field("questionnaire_response", "id", array("userid"=>$userid, "questionnaireid"=>$surveyid));
      //echo "zzz7";exit;
      //echo $rid.'-';exit;
      if($rid) 
      {
        $response = $DB->get_record('questionnaire_response',array('id'=>$rid));
        if($response->complete == 'y') 
        {
          $progress = 'Completed';
        }
        else
        { 
          $progress = 'Not completed';
        }
               
      }
      else
      {
        $progress = 'Not started';
        
      }
      $url = $CFG->wwwroot.'/course/view.php?id='.$courseid;
      $geofencing_enabled = $rows->geofencing_enabled;
      if($user_type_id == 1){
        $geofencing_enabled = 'No';
      }else{
        if($geofencing_enabled=="Yes"){
          $latitude   = $sqlgetpoints->latitude;
          $longitude  = $sqlgetpoints->longitude;
        }
      }

      if($timeend == 0)
      {
         $final_end_date = "0";
      }else{
         $final_end_date = date('Y-m-d', $timeend);
      }

      $dates =  date('Y-m-d');

      if($progress != 'Completed' &&  ($final_end_date == 0 || $final_end_date > $dates))
      {
          $result[] = array(
            'id' => $courseid,
            'fullname'  => $surveyname,
            'enroldate' => date('Y-m-d',$timestart),
            'enrolenddate' => date('Y-m-d',$timeend),
            'shortname' => $shortname,
            'summary'   => $summary,
            'idnumber'  => $idnumber,
            'visible'   => $visible,
            'summaryformat' => $summaryformat,
            'format' => $format,
            'showgrades' => $showgrades,
            'lang' => $lang,
            'enablecompletion' => $enablecompletion,
            'category' => $category,
            'progress' => $progress,
            'startdate' => date('Y-m-d',$startdate),
            'enddate' => date('Y-m-d',$enddate),
            'created_date' => date('d-m-Y H:i:s',$created_date),
            'created' => date('d-m-Y H:i:s',$created_date),
            'url' => $url,
            'latitude'=>$latitude,
            'longitude'=>$longitude,
            'radius'=>100,
            'geofencing_enabled'=>$geofencing_enabled,
            'totalsubcourses'=>1
          );
      }
        
    }

    if(empty($result)){
            $result[] = array();
        }
        return $result;
    }
  
  public static function get_pending_mysurvey_returns() 
  {
        return new external_multiple_structure(
                new external_single_structure(
  array(

    'id'            => new external_value(PARAM_INT, 'id of course', VALUE_OPTIONAL),
                    'shortname'     => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
                    'fullname'      => new external_value(PARAM_RAW, 'long name of course', VALUE_OPTIONAL),
                    'idnumber'      => new external_value(PARAM_RAW, 'id number of course', VALUE_OPTIONAL),
                    'visible'       => new external_value(PARAM_INT, '1 means visible, 0 means hidden course', VALUE_OPTIONAL),
                    'summary'       => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'      => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades'  => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'        => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',VALUE_OPTIONAL),
                    'category'     => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress'     => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate'    => new external_value(PARAM_RAW, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate'      => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate'    => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_RAW, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'created_date' => new external_value(PARAM_RAW, 'Timestamp when the enrolment created_date', VALUE_OPTIONAL),
                    'created' => new external_value(PARAM_RAW, 'Timestamp when the enrolment created_date', VALUE_OPTIONAL),
                    'url'          => new external_value(PARAM_RAW,'course url', VALUE_OPTIONAL),
          'c'          => new external_value(PARAM_RAW,'count', VALUE_OPTIONAL),
          'latitude' => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
          'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
          'radius' => new external_value(PARAM_RAW, 'radius point of user location',VALUE_OPTIONAL),
          'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL),
          'totalsubcourses'          => new external_value(PARAM_RAW,'count of subcourses', VALUE_OPTIONAL)
  )
                )
        );
    }

  //---------------------------end here------------------------------------

  //--------------------------get_history_survey----------------------------

  public static function get_history_mysurvey_parameters() 
  {
      return new external_function_parameters(
          array('dates' => new external_value(PARAM_RAW, 'version'))
      );
  }
  
  public static function get_history_mysurvey($dates) 
  {
          global $USER,$DB,$CFG;
    $onlinesurvey = "select concat(a.id,'_',d.id) as tempid,
              a.id as userid,
              d.id as courseid,
              d.fullname as surveyname,
              d.summary as summary,
              d.shortname as shortname,
              d.idnumber as idnumber,
              d.visible as visible,
              d.summaryformat as summaryformat,
              d.format as cformat,
              d.showgrades,
              d.lang,
              d.enablecompletion,
              d.category,
              d.startdate,
              d.enddate,
              en.timestart,
              en.timeend,
              en.timecreated,
              b.timemodified as courseassigndate,
                            d.geofencing_enabled
              from mdl_user as a    
              inner join mdl_role_assignments as b  on(b.userid=a.id)
              inner join mdl_context as c on (c.id=b.contextid and c.contextlevel=50)
              inner join mdl_course as d on (d.id=c.instanceid) 
              inner join mdl_course_categories as cat on cat.id = d.category  
              inner join mdl_user_enrolments as en ON (en.userid=b.userid AND en.enrolid in (select id from mdl_enrol where courseid=d.id)) 
              WHERE a.username!='guest' AND a.id>2 AND a.suspended = 0 AND a.deleted = 0
              AND d.category !=0 AND d.visible=1 AND d.is_kca=0 AND cat.id = 11 AND a.id = '".$USER->id."'";
              
    $resultsurvey = $DB->get_records_sql($onlinesurvey, array());
    $user_type_data = $DB->get_record_sql("SELECT user_type_id, code FROM mdl_ums_employeemaster WHERE 
      userid = '".$USER->id."'");
    $user_type_id  = $user_type_data->user_type_id;
        $sqlgetpoints = $DB->get_record_sql("SELECT * FROM mdl_ums_user_cordinate WHERE userid = '".$USER->id."'");
        $latitude   = null;
        $longitude  = null;

        foreach($resultsurvey as $rows)
    {
      $courseid   = $rows->courseid;
      
      $surveyname = (isset($rows->surveyname) && !empty($rows->surveyname)) ? $rows->surveyname : "";
      
      $timestart  = $rows->timestart;
      
      $timeend    = (isset($rows->timeend) && ($rows->timeend!=null)) ? $rows->timeend : "-";
      
      $userid     = $rows->userid;
      $summary    = $rows->summary;
      $shortname  = $rows->shortname;
      
      $idnumber   = $rows->idnumber;
      $visible    = $rows->visible;
      $summaryformat = $rows->summaryformat;
      $format     = $rows->format;
      $showgrades = $rows->showgrades;
      $lang       = $rows->lang;
      $enablecompletion = $rows->enablecompletion;
      $category   = $rows->category;
      $startdate  = $rows->startdate;
      $enddate    = $rows->enddate; 
      $created_date   = $rows->timecreated;   
      $surveyid   = $DB->get_field('questionnaire','id', array('course'=>$courseid));
      // $rid = $DB->get_field("questionnaire_response", "id", array("userid"=>$userid, "survey_id"=>$surveyid));
      $rid = $DB->get_field("questionnaire_response", "id", array("userid"=>$userid, "questionnaireid"=>$surveyid));
      if($rid) 
      {
        $response = $DB->get_record('questionnaire_response',array('id'=>$rid));
        if($response->complete == 'y') 
        {
          $progress = 'Completed';
        }
        else
        { 
          $progress = 'Not completed';
        }
               
      }
      else
      {
        $progress = 'Not started';
        
      }
      $url = $CFG->wwwroot.'/course/view.php?id='.$courseid;
      $geofencing_enabled = $rows->geofencing_enabled;
      if($user_type_id == 1){
        $geofencing_enabled = 'No';
      }else{
        if($geofencing_enabled=="Yes"){
          $latitude   = $sqlgetpoints->latitude;
          $longitude  = $sqlgetpoints->longitude;
        }
      }

      if($timeend == 0)
      {
         $final_end_date = "0";
      }else{
         $final_end_date = date('Y-m-d', $timeend);
      }

      $dates =  date('Y-m-d');

      if(($final_end_date < $dates && $final_end_date != 0) || ($final_end_date == 0 && $progress == 'Completed') || $progress == 'Completed')
      {
          $result[] = array(
            'id' => $courseid,
            'fullname'  => $surveyname,
            'enroldate' => date('Y-m-d',$timestart),
            'enrolenddate' => date('Y-m-d',$timeend),
            'shortname' => $shortname,
            'summary'   => $summary,
            'idnumber'  => $idnumber,
            'visible'   => $visible,
            'summaryformat' => $summaryformat,
            'format' => $format,
            'showgrades' => $showgrades,
            'lang' => $lang,
            'enablecompletion' => $enablecompletion,
            'category' => $category,
            'progress' => $progress,
            'startdate' => date('Y-m-d',$startdate),
            'enddate' => date('Y-m-d',$enddate),
            'created_date' => date('d-m-Y H:i:s',$created_date),
            'created' => date('d-m-Y H:i:s',$created_date),
            'url' => $url,
            'latitude'=>$latitude,
            'longitude'=>$longitude,
            'radius' => 100,
            'geofencing_enabled'=>$geofencing_enabled,
            'totalsubcourses'=>1
          );
      }
        
    }
    if(empty($result)){
            $result[] = array();
        }

      //print_r($result);exit;
      return $result;
    }
  
  public static function get_history_mysurvey_returns() 
  {
        return new external_multiple_structure(
                new external_single_structure(
  array(

    'id'            => new external_value(PARAM_INT, 'id of course', VALUE_OPTIONAL),
                    'shortname'     => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
                    'fullname'      => new external_value(PARAM_RAW, 'long name of course', VALUE_OPTIONAL),
                    'idnumber'      => new external_value(PARAM_RAW, 'id number of course', VALUE_OPTIONAL),
                    'visible'       => new external_value(PARAM_INT, '1 means visible, 0 means hidden course', VALUE_OPTIONAL),
                    'summary'       => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'      => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades'  => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'        => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',VALUE_OPTIONAL),
                    'category'     => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress'     => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate'    => new external_value(PARAM_RAW, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate'      => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate'    => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'created_date'    => new external_value(PARAM_RAW, 'Timestamp when the course created', VALUE_OPTIONAL),
                    'created'    => new external_value(PARAM_RAW, 'Timestamp when the course created', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_RAW, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'url'          => new external_value(PARAM_RAW,'course url', VALUE_OPTIONAL),
          'c'          => new external_value(PARAM_RAW,'count', VALUE_OPTIONAL),
          'latitude' => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
          'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
          'radius' => new external_value(PARAM_INT, 'radius point of user location',VALUE_OPTIONAL),
          'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL),
          'totalsubcourses'          => new external_value(PARAM_RAW,'count of subcourses', VALUE_OPTIONAL),
  )
                )
        );
    }


  //-----------------------------end here-----------------------------------
	//-----------------------------------------//
    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_mynotifications_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function get_mynotifications($welcomemessage = 'Hello world, '){
      global $USER, $DB, $CFG;
      $userid = $USER->id; $emp_mspin = $USER->username;
      $device_type = $USER->ostype;
      $newresult = array();
		  $notifation1 = $DB->get_records_sql("SELECT n.*,un.is_read FROM mdl_ums_notifications as n LEFT JOIN mdl_ums_user_notification as un ON n.id = un.notificationid WHERE n.deleted = 0 AND un.deleted = 0 AND un.mspin = '".$emp_mspin."' AND un.userid = '".$userid."' AND un.is_processed = 2 AND is_read=0 GROUP BY un.notificationid ORDER BY n.updated_date DESC");//changed on 23Sept,2019
      
      // $notifation2 = $DB->get_records_sql("SELECT n.*,un.is_read FROM mdl_ums_notifications as n LEFT JOIN mdl_ums_user_notification as un ON n.id = un.notificationid WHERE n.deleted = 0 AND un.deleted = 0 AND un.mspin = '".$emp_mspin."' AND un.userid = '".$userid."' AND un.is_processed = 2 AND is_read=1 GROUP BY un.notificationid ORDER BY n.updated_date DESC");

      // new sql code nitesh

       $notifations = $DB->get_records_sql("SELECT n.*,un.is_read FROM mdl_ums_notifications as n LEFT JOIN mdl_ums_user_notification as un ON n.id = un.notificationid WHERE n.deleted = 0 AND un.deleted = 0 AND un.mspin = '".$emp_mspin."' AND un.userid = '".$userid."' AND un.is_processed = 2 AND is_read in (0,1) GROUP BY un.notificationid ORDER BY n.inserted_date DESC");//changed on 23Sept,2019

      // end here

      //$notifations=array_merge($notifation1,$notifation2);
     // echo "<pre>";print_r($notifations);exit;
      $totalunread=@sizeof($notifation1);
      foreach ($notifations as $key => $notifation){
        if($notifation->n_url == '' || $notifation->n_url == null){
          $video_id1 = '';
        }else{
          $video_id = explode("watch?v=",$notifation->n_url);
          $video_id1 = $video_id[1];
          preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $notifation->n_url, $match);
          $video_id = explode("watch?v=",$notifation->n_url);
          $video_id1 = $match[1];
        }

        if($device_type == 'android' && $notifation->n_url!=''){
          $d_type = 0;
        }else{
          $d_type = $notifation->n_url_type;
        }

        $notifation_msg= 'Total Unread Notifications ('.@$totalunread.')';
        if($notifation->is_read == 0){
          $notifation_status = 'Unread';
        }else{
          $notifation_msg= 'Read message';
          $notifation_status = 'Read';
        }

        $result = new stdClass();
        $result->notifid = $notifation->id;
        $result->name = $notifation->n_title;
        $result->notifation_msg = $notifation_msg;
        $result->description =  $notifation->n_description; 
        $result->date =  $notifation->updated_date; 
        $result->urlname =  $notifation->n_url;
        $result->video_id =  $video_id1;
        $result->urltype =  $d_type;
        $result->status =  $notifation_status;
        $result->totalunread=$totalunread;
        $newresult[]=$result;
      }
      return $newresult;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_mynotifications_returns() {
        return new external_multiple_structure(
                new external_single_structure(
                  array(
                   'notifid' => new external_value(PARAM_INT, 'id of Notification'),
                   'name' => new external_value(PARAM_TEXT, 'name of Notification'),
                   'notifation_msg' => new external_value(PARAM_TEXT, 'notifation_msg'),
                   'description' => new external_value(PARAM_RAW, 'Description of notification'),
                   'date' => new external_value(PARAM_TEXT, 'Date of notification'),
                   'urlname' => new external_value(PARAM_RAW, 'URL of notification'),
                   'video_id' => new external_value(PARAM_TEXT, 'video id'),
                   'urltype' => new external_value(PARAM_RAW, 'URLType of notification'),
                   'status' => new external_value(PARAM_RAW, 'Notification read under by user'),
                   'totalunread' => new external_value(PARAM_RAW, 'totalunread')
                 ),
                )
        );
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */

    public static function get_hello_world_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    public static function get_hello_world() {
        global $USER, $DB;
        $params = self::validate_parameters(self::get_myprofile_parameters(), array('welcomemessage' => $welcomemessage));

        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);

        $profile = array('first' => "Firstapp");
        return $profile;
    }

    public static function get_hello_world_returns() {
        return new external_single_structure(
                array(
            'first' => new external_value(PARAM_TEXT, 'Our First App')
                )
        );
    }

   
     public static function get_myperf_assessments_parameters() {

           return new external_function_parameters(
                   array()
           );
       }


         /**
        * Returns welcome message
        * @return string welcome message
        */
       public static function get_myperf_assessments($welcomemessage = 'Hello world, ') {
           global $USER,$DB,$CFG;
           //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
           //Parameter validation
           //REQUIRED
           $params = self::validate_parameters(self::get_myprofile_parameters(),
                   array('welcomemessage' => $welcomemessage));

           //Context validation
           //OPTIONAL but in most web service it should present
           $context = get_context_instance(CONTEXT_USER, $USER->id);
           self::validate_context($context);
           /*
           //Capability checking
           //OPTIONAL but in most web service it should present
           if (!has_capability('moodle/user:viewdetails', $context)) {
               throw new moodle_exception('cannotviewprofile');
           }*/
       $result = array();
          $userid = $USER->id;
           $assessmentslm = $DB->get_records_sql('select c.id from {role_assignments} as a
          Inner join {context} as b on(b.id = a.contextid)
          Inner join {course} as c on(c.id = b.instanceid) where a.userid= ?
            AND c.category = ?
          AND a.timemodified <= ? AND a.timemodified >= ?',array($userid,2,time(),time() - (30 * 24 * 60 * 60)));

           // print_r($assessmentslm);
           

      $assessmentcountlm = 0;
      $assessmentlmpass  = 0;
      $assessmentlmappeared = 0;
      foreach($assessmentslm as $assessment) {
        $assessmentcountlm++;
        $quizrecord = $DB->get_record('quiz',array('course'=>$assessment->id));
        //echo "Quiz id is ".$quizrecord->id;
        $attemptstatus = $DB->get_field('quiz_attempts','state',array('quiz'=>$quizrecord->id,'userid'=>$userid,'attempt'=>1));
         if(empty($attemptstatus)) {

            }
            else {
              $sumgrade = $DB->get_field('quiz_attempts','sumgrades',array('quiz'=>$quizrecord->id,'userid'=>$userid,'attempt'=>1));
              $passgrade = $DB->get_field('grade_items','gradepass',array('courseid'=>$assessment->id,'iteminstance'=>$quizrecord->id,'itemmodule'=>'quiz'));
              if($sumgrade >= $passgrade){
                $assessmentlmpass++;
                $assessmentlmappeared++;
              }
              else {
                $assessmentlmappeared++;
              }
            }
      }


      $assessments3lm = $DB->get_records_sql('select c.id from {role_assignments} as a
              Inner join {context} as b on(b.id = a.contextid)
              Inner join {course} as c on(c.id = b.instanceid) where a.userid= ?
              AND c.category = ?
              AND a.timemodified <= ? AND a.timemodified >= ?',array($userid,31,time(),time() - (3 * 30 * 24 * 60 * 60)));
      $assessmentcount3lm = 0;
      $assessment3lmpass  = 0;
      $assessment3lmappeared = 0;
      foreach($assessments3lm as $assessment) {
        $assessmentcount3lm++;
        $quizrecord = $DB->get_record('quiz',array('course'=>$assessment->id));
        $attemptstatus = $DB->get_field('quiz_attempts','state',array('quiz'=>$quizrecord->id,'userid'=>$userid,'attempt'=>1));
         if(empty($attemptstatus)) {

            }
            else {
              $sumgrade = $DB->get_field('quiz_attempts','sumgrades',array('quiz'=>$quizrecord->id,'userid'=>$userid,'attempt'=>1));
              $passgrade = $DB->get_field('grade_items','gradepass',array('courseid'=>$assessment->id,'iteminstance'=>$quizrecord->id,'itemmodule'=>'quiz'));
              if($sumgrade >= $passgrade){
                $assessment3lmpass++;
                $assessment3lmappeared++;
              }
              else {
                $assessment3lmappeared++;
              }
            }
      }




      $assessments6lm = $DB->get_records_sql('select c.id from {role_assignments} as a
              Inner join {context} as b on(b.id = a.contextid)
              Inner join {course} as c on(c.id = b.instanceid) where a.userid= ?
              AND c.category = ?
              AND a.timemodified <= ? AND a.timemodified >= ?',array($userid,31,time(),time() - (6 * 30 * 24 * 60 * 60)));
      $assessmentcount6lm = 0;
      $assessment6lmpass  = 0;
      $assessment6lmappeared = 0;
      foreach($assessments6lm as $assessment) {
        $assessmentcount6lm++;
        $quizrecord = $DB->get_record('quiz',array('course'=>$assessment->id));
        $attemptstatus = $DB->get_field('quiz_attempts','state',array('quiz'=>$quizrecord->id,'userid'=>$userid,'attempt'=>1));
         if(empty($attemptstatus)) {

            }
            else {
              $sumgrade = $DB->get_field('quiz_attempts','sumgrades',array('quiz'=>$quizrecord->id,'userid'=>$userid,'attempt'=>1));
              $passgrade = $DB->get_field('grade_items','gradepass',array('courseid'=>$assessment->id,'iteminstance'=>$quizrecord->id,'itemmodule'=>'quiz'));
              if($sumgrade >= $passgrade){
                $assessment6lmpass++;
                $assessment6lmappeared++;
              }
              else {
                $assessment6lmappeared++;
              }
            }
      }

        $subresult = new stdClass();
        $subresult->time = 'Last Month';
        $subresult->numassessments = $assessmentcountlm;
        $subresult->appeared = $assessmentlmappeared;
              $subresult->passed = $assessmentlmpass;
              $result[] = $subresult;
        $subresult = new stdClass();
        $subresult->time = 'Last 3 Months';
        $subresult->numassessments = $assessmentcount3lm;
        $subresult->appeared = $assessment3lmappeared;
              $subresult->passed = $assessment3lmpass;
              $result[] = $subresult;
              $subresult = new stdClass();
        $subresult->time = 'Last 6 Months';
        $subresult->numassessments = $assessmentcount6lm;
        $subresult->appeared = $assessment6lmappeared;
              $subresult->passed = $assessment6lmpass;
        $result[] = $subresult;
              $subresult = new stdClass();
        $subresult->time = 'Calendar Year';
        $subresult->numassessments = $assessmentcount6lm;
        $subresult->appeared = $assessment6lmappeared;
              $subresult->passed = $assessment6lmpass;
              $result[] = $subresult;
         return $result;


       }
       /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_myperf_assessments_returns() {
       return new external_multiple_structure(
            new external_single_structure(
                 array(
                    'time' => new external_value(PARAM_TEXT, 'time duration'),
          'numassessments' => new external_value(PARAM_TEXT, 'Total number of assessments assigned'),
          'appeared' => new external_value(PARAM_TEXT, 'Number of assessments appeared'),
          'passed' => new external_value(PARAM_TEXT, 'Number of assessments passed'),
                )
            )
        );

    }

      /**
        * Returns description of method parameters
        * @return external_function_parameters
        */
       public static function get_myperf_courses_parameters() {

           return new external_function_parameters(
                   array()
           );
       }


         /**
        * Returns welcome message
        * @return string welcome message
        */
       public static function get_myperf_courses($welcomemessage = 'Hello world, ') {
           global $USER,$DB,$CFG;
           //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
           //Parameter validation
           //REQUIRED
           $params = self::validate_parameters(self::get_myprofile_parameters(),
                   array('welcomemessage' => $welcomemessage));

           //Context validation
           //OPTIONAL but in most web service it should present
           $context = get_context_instance(CONTEXT_USER, $USER->id);
           self::validate_context($context);
           /*
           //Capability checking
           //OPTIONAL but in most web service it should present
           if (!has_capability('moodle/user:viewdetails', $context)) {
               throw new moodle_exception('cannotviewprofile');
           }*/


           $onlinecourses=$DB->get_records_sql("select
      c.id as courseid,
      c.fullname as coursename,
      c.summary as summary,
      b.path,
      a.timemodified as enrolldate,
      (
        select count(sa.id) as totalscorms
          from {scorm_scoes} as sa
          inner join {scorm} as sb ON(sb.id=sa.scorm)
          where sb.course=c.id and sa.scormtype='sco'
      ) as totalscorms,
      (
        select count(sa.id) as totaltracked
          FROM {scorm_scoes_track} as sa
          INNER JOIN {scorm} as sb on (sb.id=sa.scormid)
          INNER JOIN {course} as sc on (sc.id=sb.course)
          where sa.element='cmi.core.lesson_status' and (value='completed' OR value='passed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
      ) as totalcompleted,
      (
        select count(sa.id) as totaltracked
          FROM {scorm_scoes_track} as sa
          INNER JOIN {scorm} as sb on (sb.id=sa.scormid)
          INNER JOIN {course} as sc on (sc.id=sb.course)
          where sa.element='cmi.core.lesson_status' and value='incomplete' AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
      ) as totalincomplete,
      'duedate',
      (SELECT timestart FROM {user_enrolments} where enrolid=(select id from {enrol}  where courseid=c.id and enrol='manual') AND userid=a.userid) as timestart,
      (SELECT timeend FROM {user_enrolments} where enrolid=(select id from {enrol}  where courseid=c.id and enrol='manual') AND userid=a.userid) as timeend

    from {role_assignments}  as a
    inner join {context}     as b on(b.id=a.contextid)
    inner join {course}      as c on(c.id=b.instanceid)
    left outer join {user}   as d on(d.id=a.userid)
    inner join {course_categories} as e on(e.id=c.category)
    where b.contextlevel = 50 and userid=?  and c.visible=1 and (category<>0 and e.name<>'assessment container' and e.name<>'polls') order by a.timemodified desc",array($USER->id));

            $result = array();
            $countcourses = 0;
            $countcompleted = 0;
            // print_r($onlinecourses);
            // die;
            foreach($onlinecourses as $onlinecourse) {
        $countcourses++;
        $subresult = new stdClass();
        $subresult->courseid = $onlinecourse->courseid;
        $subresult->name = $onlinecourse->coursename;
        $status = "";
        $totalscorms    = $onlinecourse->totalscorms;
        $totalcompleted   = $onlinecourse->totalcompleted;
        $totalincomplete  = $onlinecourse->totalincomplete;

        $totalcompleted = $totalcompleted>$totalscorms ? $totalscorms : $totalcompleted;

        $per=0;
        if($totalscorms!=0)
        {
          $per = round(($totalcompleted*100)/$totalscorms, 2);

        }


        if($per==100)
        {
          $subresult->status='Completed';
                    $countcompleted++;
        }else if($totalcompleted==0 && $totalincomplete==0){
          $subresult->status='Not Started';
        }else{
          $subresult->status='Incomplete';
        }
        $subresult->courselink = $CFG->wwwroot."/course/view.php?id=".$onlinecourse->courseid;
        $enrolldate = isset($onlinecourse->enrolldate)?$onlinecourse->enrolldate:'0';
            $subresult->startdate = $enrolldate=='enrolldate'?'0':$enrolldate;

        $enrollenddate = $onlinecourse->timeend;
            $subresult->activetill = $enrollenddate==0 ? '-': ($enrollenddate);

      }
           $subresult = new stdClass();
           $subresult->time = 'Last Month';
           $subresult->numcourses = $countcourses;
           $subresult->completed = $countcompleted;
         $result[] = $subresult;
                      $subresult = new stdClass();
           $subresult->time = 'Last 3 Months';
           $subresult->numcourses = $countcourses;
           $subresult->completed = $countcompleted;
         $result[] = $subresult;
                      $subresult = new stdClass();
           $subresult->time = 'Last 6 Months';
           $subresult->numcourses = $countcourses;
           $subresult->completed = $countcompleted;
         $result[] = $subresult;
                      $subresult = new stdClass();
           $subresult->time = 'Calendar Year';
           $subresult->numcourses = $countcourses;
           $subresult->completed = $countcompleted;
         $result[] = $subresult;

           return $result;


       }
       /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_myperf_courses_returns() {
       return new external_multiple_structure(
            new external_single_structure(
                 array(
                    'time' => new external_value(PARAM_TEXT, 'time duration'),
                    'numcourses' => new external_value(PARAM_INT,'number of courses assigned'),
                    'completed' => new external_value(PARAM_INT,'number of completed courses')

                )
            )
        );

    }


   /**
        * Returns description of method parameters
        * @return external_function_parameters
        */
       public static function get_videos_parameters() {

           return new external_function_parameters(
                    array('foldername' => new external_value(PARAM_RAW,'folder name'))
           );
       }


       /**
        * Returns welcome message
        * @return string welcome message
        */
public static function get_videos($foldername) {


global $USER,$DB,$CFG;

$audio_video_hub_id_sql = $DB->get_record_sql('SELECT id FROM  {data} WHERE name = "Audio Video Hub" ');
$audio_video_hub_id = $audio_video_hub_id_sql->id;
// echo $audio_video_hub_id;

$allrecords  =  $DB->get_records_sql('SELECT * FROM {data_content} WHERE content = "Video" ');
// $allrecords  =  $DB->get_records_sql('SELECT * FROM {data_content} WHERE content = "Video" ');

$filefieldid = $DB->get_record_sql('SELECT * FROM {data_fields} WHERE dataid = ? AND type = ?',array($audio_video_hub_id,'file'));
$filenamesql = $DB->get_record_sql('SELECT * FROM {data_fields} WHERE dataid = ? AND type = ?',array($audio_video_hub_id,'text'));
$dd = array();
if(!empty($allrecords)){

    foreach ($allrecords as $key => $allrecord) {

        $getcontents =  $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$allrecord->recordid.' AND content = "'.$foldername.'" ');
            // print_r($getcontents);
        if(!empty($getcontents)){

            $getfilename =  $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$allrecord->recordid.' AND fieldid = '.$filefieldid->id.' ');
            $getfiletitle = $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$allrecord->recordid.' AND fieldid = '.$filenamesql->id.' ');
            $itemid  =$getfilename->id;
            $filename = $getfilename->content;
            $result = new stdClass();
            $result->name = $getfiletitle->content ;
            $filedetails =  $DB->get_record_sql('SELECT * FROM {files} WHERE itemid = '.$itemid.' AND filename = "'.$filename.'" ');
            $fileurl = $CFG->wwwroot.'/pluginfile.php/'.$filedetails->contextid.'/mod_data/content/'.$itemid.'/'.$filename.'';
            $result->filename = $filename;
            $result->mediaurl = $fileurl;
            $newresult[]=$result;

        }else{
             $result = new stdClass();
            $result->name = "";
            $result->filename = "";
            $result->mediaurl = "";
            $dd[]=$result;
        }
      
    }
}else{
            $result = new stdClass();
            $result->name = "No data found";
            $result->filename = "";
            $result->mediaurl = "";
            $newresult[]=$result;


}
        
        if(!empty($dd)){
            $newresult[]=$result;
        }
        return $newresult;


}
       /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_videos_returns() {
       return new external_multiple_structure(
            new external_single_structure(
                array(
                    'name' => new external_value(PARAM_TEXT, 'title of the video'),
					'filename' => new external_value(PARAM_TEXT, 'Filename'),
                    'mediaurl' => new external_value(PARAM_TEXT, 'URL of the video'),
                    // 'thumbnail' => new external_value(PARAM_TEXT, 'Thumbnail'),
                    // 'duration' => new external_value(PARAM_TEXT, 'Duration'),
                )
            )
        );

    }


   /**
        * Returns description of method parameters
        * @return external_function_parameters
        */
       public static function get_audios_parameters() {

           return new external_function_parameters(
            array('foldername' => new external_value(PARAM_RAW,'folder name'))
           );
       }


       /**
        * Returns welcome message
        * @return string welcome message
        */
       public static function get_audios($foldername){
         global $USER,$DB,$CFG;
         $audio_video_hub_id_sql = $DB->get_record_sql('SELECT id FROM  {data} WHERE name = "Audio Video Hub" ');
         $audio_video_hub_id = $audio_video_hub_id_sql->id;
         $allrecords  =  $DB->get_records_sql('SELECT * FROM {data_content} WHERE content = "audio" ');
         $filefieldid = $DB->get_record_sql('SELECT * FROM {data_fields} WHERE dataid = ? AND type = ?',array($audio_video_hub_id,'file'));
         $filenamesql = $DB->get_record_sql('SELECT * FROM {data_fields} WHERE dataid = ? AND type = ?',array($audio_video_hub_id,'text'));
         $dd = array();
         if(!empty($allrecords)){
          foreach ($allrecords as $key => $allrecord){
            $getcontents =  $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$allrecord->recordid.' AND content = "'.$foldername.'" ');
            if(!empty($getcontents)){
              $getfilename =  $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$allrecord->recordid.' AND fieldid = '.$filefieldid->id.' ');
              $getfiletitle = $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$allrecord->recordid.' AND fieldid = '.$filenamesql->id.' ');
              $itemid  =$getfilename->id;
              $filename = $getfilename->content;
              $result = new stdClass();
              $result->name = $getfiletitle->content ;
              $filedetails =  $DB->get_record_sql('SELECT * FROM {files} WHERE itemid = '.$itemid.' AND filename = "'.$filename.'" ');
              $fileurl = $CFG->wwwroot.'/pluginfile.php/'.$filedetails->contextid.'/mod_data/content/'.$itemid.'/'.$filename.'';
              $result->filename = $filename;
              $result->mediaurl = $fileurl;
              $newresult[]=$result;
            }else{
             $result = new stdClass();
             $result->name = "";
             $result->filename = "";
             $result->mediaurl = "";
             $dd[]=$result;
           }
         }
       }else{
        $result = new stdClass();
        $result->name = "";
        $result->filename = "";
        $result->mediaurl = "";
        $newresult[]=$result;
      }
      if(!empty($dd)){
        $newresult[]=$result;
      }
      return $newresult;
    }
       /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_audios_returns() {
       return new external_multiple_structure(
            new external_single_structure(
                array(
                    'name' => new external_value(PARAM_TEXT, 'title of the video'),
                    'mediaurl' => new external_value(PARAM_TEXT, 'URL of the video'),
					// 'duration' => new external_value(PARAM_TEXT, 'Duration'),
					'filename' => new external_value(PARAM_TEXT, 'Filename')
                )
            )
        );

    }


   /**
        * Returns description of method parameters
        * @return external_function_parameters
        */
       public static function get_knowledge_parameters() {

           return new external_function_parameters(
                   array()
           );
       }


       /**
        * Returns welcome message
        * @return string welcome message
        */
       public static function get_knowledge() {
           global $USER,$DB,$CFG;
           //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
           //Parameter validation
           //REQUIRED
             global $DB;
       // $data = array();

       $records = $DB->get_records_sql("SELECT dr.id as recordid FROM {data} d JOIN {data_records} dr ON dr.dataid = d.id WHERE d.name = 'Knowledge Centre'");
       if(!empty($records)){
           // print_r($records);
           foreach ($records as $key => $record) {
               $fields = $DB->get_records_sql("SELECT df.name,df.id  FROM {data_content} dc LEFT JOIN {data_fields} df ON dc.fieldid = df.id WHERE dc.recordid = ? ",array($record->recordid));
               // print_r($fields);
               $data =array();
               foreach ($fields as $key => $field) {
                  $content = $DB->get_record_sql("SELECT content FROM {data_content} WHERE fieldid = ? AND recordid = ? ",array($field->id,$record->recordid));

                  $data[] = array($field->name => $content->content);
               }
               $getfilename12 =  $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$record->recordid.' AND fieldid = 5 ');

                    $getfilename =  $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$record->recordid.' AND fieldid = 4 ');
                    // echo $getfilename->id;
                    $itemid  =$getfilename->id;
                    $filename = $getfilename->content;
                    $filedetails =  $DB->get_record_sql('SELECT * FROM {files} WHERE itemid = '.$itemid.' AND filename = "'.$filename.'" ');
                    // echo $filename; 

                    $fileurl = $CFG->wwwroot.'/pluginfile.php/'.$filedetails->contextid.'/mod_data/content/'.$itemid.'/'.$filename.'';
                    // print_r($fileurl);
                    // die;
                    $data['url']=$fileurl; 
               $newdata[] = $data;
               // $newdata = array("data"=>$data);
               // print_r($newdata);
                  // print_r($data);

           }
       }else{
           $newdata =  array('No Data Found');

       }
     
       print_r(json_encode($newdata));
       die;

       }
       /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_knowledge_returns() {
       return new external_multiple_structure(
            new external_multiple_structure(
            new external_single_structure(
                array(
                    'name' => new external_value(PARAM_TEXT, 'Name of the file'),
                    'folder' => new external_value(PARAM_TEXT, 'Name of the folder of the file'),
                    'url' => new external_value(PARAM_TEXT, 'URL of the resource')
                )
             )
            )
        );
    }


    /**
        * Returns description of method parameters
        * @return external_function_parameters
        */
       public static function get_knowledgetabs_parameters() {

           return new external_function_parameters(
                   array('tab' => new external_value(PARAM_TEXT, 'name of the tab'))
           );
       }


       /**
        * Returns welcome message
        * @return string welcome message
        */
       public static function get_knowledgetabs($tab) {
           global $USER,$DB,$CFG;
           //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
           //Parameter validation
           //REQUIRED
           $params = self::validate_parameters(self::get_knowledgetabs_parameters(),
                   array('tab' => $tab));

           //Context validation
           //OPTIONAL but in most web service it should present
           $context = get_context_instance(CONTEXT_USER, $USER->id);
           self::validate_context($context);
           /*
           //Capability checking
           //OPTIONAL but in most web service it should present
           if (!has_capability('moodle/user:viewdetails', $context)) {
               throw new moodle_exception('cannotviewprofile');
           }*/


$filter = " WHERE  b.intro like '%".$tab."%' AND a.module=(SELECT id FROM {modules} where name='resource') and a.visible=1 AND c.contextlevel = 70
  AND d.component='mod_resource' and length(d.filename)>1 AND (SUBSTRING(d.filename,-3,3) not in ('mp4','mp3','flv','f4v'))
 order by d.sortorder desc ";

$resultarray = array();
$sql = "SELECT
  a.id as id,
  b.name as name,
  b.intro as intro,
  d.filename as filename,
  a.course as courseid,
  SUBSTRING_INDEX(d.filename,'.',-1)  as format,
  DATE_FORMAT(from_unixtime(a.added), '%d-%m-%Y %H:%i:%s') as addeddate,
  c.id as contextid,
  d.sortorder as sortorder,
  d.filepath as filepath

  FROM {course_modules} as a
  INNER JOIN {resource} as b ON (a.instance=b.id)
  INNER JOIN {context}  as c ON (c.instanceid=a.id)
  INNER JOIN {files}    as d ON (d.contextid=c.id) ".$filter ;

//echo $sql;

$index = 0;

$result=$DB->get_recordset_sql($sql, array());
//$result=$DB->get_records_sql($sql, array());
$mediaurl='';
$public = '';
$private = '';


$folders = array();
$folder='';
foreach($result as $rows)
{
	$folders[trim($rows->name)][] = array("filename"=>$rows->filename,
										  "id"=>$rows->id,
										  "courseid"=>$rows->courseid,
										  "format"=>$rows->format,
										  "addeddate"=>$rows->addeddate,
										  "contextid"=>$rows->contextid,
										  "sortorder"=>$rows->sortorder,
										  "filepath"=>$rows->filepath
										  );
}

foreach($folders as $key=>$value){
				$index =1;
				$content='';
				$folder = $key;
		     //  echo "<h1>".$folder."</h1>";
				$subresultarray = array();
				foreach($value as $rows){
                    $fileobj = new stdClass();
					$img_src = $CFG->wwwroot.'/mc_icons/format1/'.$rows['format'].'.png';
					$mediaurl = $CFG->wwwroot.'/mod/resource/view.php?id='.$rows['id'];
					$filename = strip_tags(explode(".",$rows['filename']));
                    $mediaurl = $CFG->wwwroot.'/webservice/pluginfile.php/'.$rows['contextid'].'/mod_resource/content/'.$rows['sortorder'].'/'.rawurlencode($rows['filename']).'?token='.$_REQUEST['wstoken'];
                   // echo $rows['filename']." - ". $mediaurl."<br/>";
                    $fileobj->name = strip_tags($rows['filename']);
                    $fileobj->folder = strip_tags($key);
                    $fileobj->url = $mediaurl;
					$subresultarray[]= $fileobj;
				}
     $resultarray[$key] = $subresultarray;

}
           //die(print_object(json_encode($resultarray)));
           return $resultarray;


       }
       /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_knowledgetabs_returns() {
       return new external_multiple_structure(
            new external_multiple_structure(
            new external_single_structure(
                array(
                    'name' => new external_value(PARAM_TEXT, 'Name of the file'),
                    'folder' => new external_value(PARAM_TEXT, 'Name of the folder of the file'),
                    'url' => new external_value(PARAM_TEXT, 'URL of the resource')
                )
             )
            )
        );
    }


   /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_tabs_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function get_tabs() {
        global $USER,$DB;

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::get_tabs_parameters(),
                array());



        $filter = " WHERE  a.module=(SELECT id FROM {modules} where name='resource') and a.visible=1 AND c.contextlevel = 70
  AND d.component='mod_resource' and length(d.filename)>1 AND (SUBSTRING(d.filename,-3,3) not in ('mp4','mp3','flv','f4v'))
  and b.intro  in ('Facility','Awards','Body n Paint','Initial Quality Service (IQS)','Periodic Maintenance Schedule(PMS)') order by d.sortorder desc ";

$resultarray = array();
$sql = "SELECT
  DISTINCT b.intro as intro


  FROM {course_modules} as a
  INNER JOIN {resource} as b ON (a.instance=b.id)
  INNER JOIN {context}  as c ON (c.instanceid=a.id)
  INNER JOIN {files}    as d ON (d.contextid=c.id) ".$filter;

        $results = $DB->get_records_sql($sql);
        foreach($results as $record)
        {
            $subresult = new stdClass();
            $subresult->name = strip_tags($record->intro);
            $resultarray[] = $subresult;
        }
        return $resultarray;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_tabs_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'name' => new external_value(PARAM_TEXT, 'Name of the tabs')
                )
             )
        );
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function update_password_parameters() {

        return new external_function_parameters(
                array('password' => new external_value(PARAM_TEXT, 'New password to be updated'))
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function update_password($password) {
        global $USER,$DB;

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::update_password_parameters(),
                array('password' => $password));


       // die('Farhan');
        $id = $USER->id;
        $DB->execute("UPDATE {ums_employeemaster} SET password = '".$password."' WHERE userid = ".$id);
		$hashedpassword = hash_internal_user_password($password);
		//if($moodleregid){
			$DB->set_field('user','password', $hashedpassword, array('id'=>$id));

		//}
		$rtn = array();
		$rtn['status'] = 'TRUE';
        return $rtn;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function update_password_returns() {
         return new external_single_structure (
                   array (
                       'status'=>new external_value(PARAM_TEXT, 'true or false')

                   )
                );
    }

 public static function knowledgecenter_parentfolders_parameters(){
        return new external_function_parameters(
            array()
        );

    }

    public static function knowledgecenter_parentfolders(){
        global $DB;
      
         $folders = $DB->get_records_sql('SELECT * FROM {ums_knc_folder} WHERE parent_id = 0 ORDER BY folder ASC');
         $mainfolder = array();
          foreach ($folders as $key => $folder) { 
            $alldd['folders'][] = array('folderid'=>$folder->id,'foldername'=>$folder->folder);
           }
            $aa=$alldd;
 
  
           
            return($aa);
    }


     public static function knowledgecenter_parentfolders_returns(){
         return new external_single_structure(
                array(
                    
                     'folders' => new external_multiple_structure(
                                new external_single_structure(
                                              array(
                            'folderid'=>new external_value(PARAM_INT,'folderid'),

                            'foldername'=>new external_value(PARAM_RAW,'foldername'),

                           
                    ))),
                      

                )
            );

        

     }

     public static function knowledgecenter_subfolders_parameters(){
        return new external_function_parameters(
            array(
              'id' => new external_value(PARAM_INT,'folderid')
            )

        );

    }

    public static function knowledgecenter_subfolders($id){
        global $DB;
       
         #$folders = $DB->get_records('ums_knc_folder',array('parent_id'=>$id));
         $folders = $DB->get_records_sql('SELECT * FROM {ums_knc_folder} WHERE parent_id = '.$id.' ORDER BY folder ASC');
         $mainfolder = array();
         if(!empty($folders)){
          foreach ($folders as $key => $folder) { 
            $alldd['subfolders'][] = array('folderid'=>$folder->id,'foldername'=>$folder->folder);
           }
         }else{
             $alldd['subfolders'][] = array('folderid'=>null,'foldername'=>null);
         }
            $aa=$alldd;
            // print_r($aa);
 
  
           
            return($aa);
    }


     public static function knowledgecenter_subfolders_returns(){
         return new external_single_structure(
                array(
                    
                     'subfolders' => new external_multiple_structure(
                                new external_single_structure(
                                              array(
                            'folderid'=>new external_value(PARAM_INT,'folderid'),

                            'foldername'=>new external_value(PARAM_RAW,'foldername'),

                           
                    ))),
                      

                )
            );

        

     }


    public static function knowledgecenter_folders_parameters(){
        return new external_function_parameters(
            array()
        );

    }

    public static function knowledgecenter_folders(){
    	global $DB,$USER;
    	
    	$aa = array();
    	$dd = array();
    	$kk = array();
    	$ss = array();
    	$user_type_data = $DB->get_record_sql("SELECT user_type_id FROM mdl_ums_employeemaster WHERE userid = '".$USER->id."'");
    	$user_type_id  = $user_type_data->user_type_id;
    	
    	$folders = $DB->get_records_sql('SELECT * FROM {ums_knc_folder} WHERE parent_id = 0 ORDER BY folder ASC');
    	$mainfolder = array();
    	foreach ($folders as $key => $folder){ 
    		$alldd['id'] =$folder->id;
    		$alldd['foldername'] = $folder->folder;
    		$aa[]=$alldd;
    	}
    	$subfolders = $DB->get_records_sql('SELECT * FROM {ums_knc_folder} WHERE parent_id != 0 ORDER BY folder ASC');
    	foreach ($subfolders as $key => $subfolder) 
    	{

    		if($user_type_id == '')
    		{	
    			if($subfolder->id == 33)
    			{
    				$sqlgetpoints = $DB->get_record_sql("select * from mdl_ums_user_cordinate where userid = '".$USER->id."'");
    				if(!empty($sqlgetpoints))
    				{
    					$latitude   = $sqlgetpoints->latitude;
    					$longitude  = $sqlgetpoints->longitude;
    				}
    				else
    				{
    					$latitude   = "";
    					$longitude  = "";
    				}
    			}
    			else
    			{
    				$latitude   = "";
    				$longitude  = "";
    			}
    		}
    		else
    		{
    			$latitude   = "";
    			$longitude  = "";
    		}		

        $geofencing_enabled=$subfolder->geofencing_enabled;
        $sqlgetpoints = $DB->get_record_sql("select * from {ums_user_cordinate} where userid = '".$USER->id."'");
        if(!empty($sqlgetpoints)){
          if($user_type_id == 2){
            if($geofencing_enabled==="Yes"){
              $latitude   = $sqlgetpoints->latitude;
              $longitude  = $sqlgetpoints->longitude;
            }else{
             $latitude   = "";
             $longitude  = "";
           }
         }
      }
    		$bb['subfoldername']= $subfolder->folder;

    		$subfolder = array('id'=>$subfolder->id,'folder_id'=>$subfolder->parent_id,'subfoldername'=>$subfolder->folder,'latitude'  => $latitude,'longitude' => $longitude, 'geofencing_enabled'=>$geofencing_enabled);
    		$kk[]= $subfolder;

    	}
    	
    	$dd['folders']=$aa;
    	$dd['subfolders']=$kk;          
    	return($dd);
    }


    public static function knowledgecenter_folders_returns(){
     return new external_single_structure(
      array(
       'folders' => new external_multiple_structure(
        new external_single_structure(
          array(
            'id' => new external_value(PARAM_INT,'folderid'),
            'foldername'=>new external_value(PARAM_RAW,'foldername'),
            'latitude' => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
            'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),


          ))),
       'subfolders' => new external_multiple_structure(
        new external_single_structure(
          array(
            'id'=>new external_value(PARAM_INT,'subfolderid'),
            'folder_id'=>new external_value(PARAM_INT,'parentfolderid'),
            'subfoldername'=>new external_value(PARAM_RAW,'subfoldername'),
            'latitude' => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
            'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
            'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL), 
          )))
     )
    );
   }




      public static function knowledgecenter_file_parameters(){
        return new external_function_parameters(
            array(
              'id' => new external_value(PARAM_INT,'id'),
            )

        );

    }

  public static function knowledgecenter_file($id)
	{
		 global $DB,$CFG,$USER;
		 $final=Array();
         $aa= array();
         $dd = array();
       
        $filelist = $DB->get_records_sql('SELECT * FROM {ums_knc_files} WHERE knc_folder_id ='.$id.' ORDER BY filename ASC');
		
		$file_allowed=array();
		foreach($filelist as $file)
		{
			$default_access=$file->default_access;
			switch($default_access)
			{
				case 1:
				$checkfile="select * from mdl_ums_knc_file_access where user_id='".$USER->id."' AND file_id='".$file->id."'";
				
				$r=$DB->get_records_sql($checkfile);
				
				if(empty($r))
				{
					array_push($file_allowed,$file->id);
				}
				break;
				case 2:
				$checkfile="select * from mdl_ums_knc_file_access where user_id='".$USER->id."' AND file_id='".$file->id."'";
				$r=$DB->get_records_sql($checkfile);
				if(!empty($r))
				{
					array_push($file_allowed,$file->id);
				}
				
				break;
			}
		}
		
		

       if(!empty($file_allowed))
	   {
		   $allfilesquery="SELECT * FROM {ums_knc_files} WHERE id in (".implode(',',$file_allowed).") ORDER BY filename ASC";
		   $allfiles = $DB->get_records_sql($allfilesquery);
		   foreach ($allfiles as $key => $f) {
                $aa['id'] = $f->id;
                $aa['filename'] = $f->filename;
                $aa['is_downloadable'] = $f->is_downloadable;
                //$aa['url'] = $CFG->wwwroot.$f->local_file_path;
                $aa['createddate'] = $f->created;
				$aa['type'] = $f->type==1?'url':'pdf';
				if($f->type==1)
				{
				$aa['url'] = $f->url;	
				}
				else
				{
				$aa['url'] = $CFG->wwwroot.$f->local_file_path;	
				}

                $dd[]= $aa;
            }
	   }
	   else
	   {
		   $aa['id'] = '';
                $aa['filename'] = '';
                $aa['is_downloadable'] = '';
                $aa['url'] = '';
                $aa['createddate'] = '';
				$aa['type'] = '';

                $dd[]= $aa;
	   }
	   
	   $final['files'] = $dd; 
	   return($final);
      /*
       $final =array();
        
         $files = $DB->get_records_sql('SELECT * FROM {ums_knc_files} WHERE knc_folder_id = '.$id.' ORDER BY filename ASC');
         
		 $aa= array();
         $dd = array();
         if(!empty($files)){
        
            foreach ($files as $key => $file) 
			{
				if($file->filetypes == 1) { $type = 'url'; }
				if($file->filetypes == 2) { $type = 'pdf'; }
                $aa['id'] = $file->id;
                $aa['filename'] = $file->filename;
                $aa['is_downloadable'] = $file->is_downloadable;
                $aa['type'] = $type;
				if($file->filetypes == 1) 
				{
					$aa['url'] = $file->local_file_path;
				}
				if($file->filetypes == 2) 
				{
					$aa['url'] = $CFG->wwwroot.$file->local_file_path;		
				}
                $aa['createddate'] = $file->created;
                $dd[]= $aa;
            }
         }
         
          $final['files'] = $dd;
      
            return($final);
			*/

    }


     public static function knowledgecenter_file_returns(){
        return  new external_single_structure(
          array(
            'files' =>  new external_multiple_structure(
                          new external_single_structure(
                            array(
                            'id'=> new external_value(PARAM_INT,'id'),
                             'filename' => new external_value(PARAM_TEXT,'filename'),
                             'is_downloadable' => new external_value(PARAM_TEXT,'is_downloadable'),
							 'type' => new external_value(PARAM_TEXT,'type'),
                             'url'=>new external_value(PARAM_RAW,'url'),
                             'createddate'=>new external_value(PARAM_RAW,'date'),
                            )
                          )
                        ),
              )
        );

     }



     //function to get audio video folders

    
      public static function audio_video_folders_parameters(){
        return new external_function_parameters(
            array()
        );

    }

    public static function audio_video_folders(){
    	global $DB,$USER;
    	$aa = array();
    	$dd = array();
    	$kk = array();
    	$ss = array();
      $ums = $DB->get_record_sql('SELECT * FROM {ums_employeemaster} WHERE userid='.$USER->id);
    	$folders = $DB->get_records_sql('SELECT * FROM {ums_av_folder} WHERE parent_id = 0 ORDER BY folder ASC');
    	$mainfolder = array();
    	foreach($folders as $key => $folder){ 
    		$alldd['id'] =$folder->id;
    		$alldd['foldername'] =$folder->folder;
    		$aa[]=$alldd;
    	}
    	$subfolders = $DB->get_records_sql('SELECT * FROM {ums_av_folder} WHERE parent_id != 0 ORDER BY folder ASC');
      $latitude   = "";
      $longitude  = "";
      foreach($subfolders as $key => $subfolder){
        $geofencing_enabled=$subfolder->geofencing_enabled;
        $sqlgetpoints = $DB->get_record_sql("select * from {ums_user_cordinate} where userid = '".$USER->id."'");
        if(!empty($sqlgetpoints)){
         if($ums->user_type_id == 2){
          if($geofencing_enabled==="Yes"){
            $latitude   = $sqlgetpoints->latitude;
            $longitude  = $sqlgetpoints->longitude;
          }else{
             $latitude   = "";
             $longitude  = "";
          }
        }
      }
/*        if($subfolder->id == 27){
         $sqlgetpoints = $DB->get_record_sql("select * from {ums_user_cordinate} where userid = '".$USER->id."'");
         if(!empty($sqlgetpoints)){
          $latitude   = $sqlgetpoints->latitude;
          $longitude  = $sqlgetpoints->longitude;
        }
      }*/


      $bb['subfoldername']= $subfolder->folder;
      $subfolder = array('id'=>$subfolder->id,'folder_id'=>$subfolder->parent_id,'subfoldername'=>$subfolder->folder,'latitude'  => $latitude,'longitude' => $longitude, 'geofencing_enabled'=>$geofencing_enabled);
      $kk[]= $subfolder;
    }
    $dd['folders']=$aa;
    $dd['subfolders']=$kk;
    return($dd);
    }


     public static function audio_video_folders_returns(){
       return new external_single_structure(
         array(
           'folders' => new external_multiple_structure(
            new external_single_structure(
             array(
              'id' => new external_value(PARAM_INT,'folderid'),
              'foldername'=>new external_value(PARAM_RAW,'foldername'),
            ))),
           'subfolders' => new external_multiple_structure(
            new external_single_structure(
              array(
                'id'=>new external_value(PARAM_INT,'subfolderid'),
                'folder_id'=>new external_value(PARAM_INT,'parentfolderid'),
                'subfoldername'=>new external_value(PARAM_RAW,'subfoldername'),
                'latitude' => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
                'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
                'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL),
              )))
         )
       );
     }


//------------------new code of audio video --------------


   public static function audio_video_folders_new_parameters(){
        return new external_function_parameters(
            array()
        );

    }

    public static function audio_video_folders_new(){
      global $DB,$USER;
      $aa = array();
      $dd = array();
      $kk = array();
      $ss = array();
      $ak = array();
      $ums = $DB->get_record_sql('SELECT * FROM {ums_employeemaster} WHERE userid='.$USER->id);
      $folders = $DB->get_records_sql('SELECT * FROM {ums_av_folder} WHERE parent_id = 0 and deleted=0 ORDER BY folder ASC');
      $mainfolder = array();
      foreach ($folders as $key => $folder) { 
        $hhmmss="00";
        $alldd['id'] =$folder->id;
        $alldd['foldername'] =$folder->folder;
        $count=0;
        $views = 0;$likes=0;$comment=0;
        $getcount=$DB->count_records_sql("SELECT count(id) FROM {ums_av_folder} WHERE parent_id='".$folder->id."' AND deleted=0");
        if(!empty($getcount))
        {
          $count=$getcount;
        }
        $sfolders = $DB->get_records_sql('SELECT id FROM {ums_av_folder} WHERE parent_id ='.$folder->id.' and deleted=0');
        $sf=array();
        if(!empty($sfolders))
        {

          foreach($sfolders as $sfld)
          {
            array_push($sf,$sfld->id);
          }


          // if(!empty($sf))
          // {
          //   $gettotalseconds=$DB->get_record_sql("SELECT sum(duration) as d FROM {ums_av_files} WHERE av_folder_id IN (".implode(',',$sf).") AND deleted=0");
          //   if(!empty($gettotalseconds))
          //   {
          //     $t=$gettotalseconds->d;
          //     $hhmmss=sprintf('%02d:%02d:%02d', ($t/3600),($t/60%60), $t%60);
          //   }
          // }
        }

        $alldd['duration'] =$hhmmss;
        $alldd['itemcount'] =$count;


        if($alldd['foldername'] == 'Audio')
        {
          
          $alldd['created_date'] =$folder->created." 00:00:00";
        }else{
          
          $alldd['created_date'] =$folder->created." 00:00:00";
          
        }

        //code for emoji count

        $get_like_comment_view=$DB->get_record_sql("SELECT (select count(id) from {ums_emoji_responses} where menutype='avhub' and emoji_id=1) as like_folder,
          (SELECT count(id) FROM {ums_emoji_responses_comments} where menutype='avhub' and deleted=0) as comment_folder,
          (select count(id) from mdl_ums_emoji_responses
          where emoji_id=6 and menutype='avhub') as total_exciting,
          (select count(id) from mdl_ums_emoji_responses
          where emoji_id=8  and menutype='avhub') as total_celebrate,
          (select count(id) from mdl_ums_emoji_responses
          where emoji_id=7  and menutype='avhub') as total_insightful,
          (select count(id) from mdl_ums_emoji_responses
          where emoji_id=12  and menutype='avhub') as total_support,
          (select count(id) from mdl_ums_emoji_responses
          where emoji_id=9  and menutype='avhub') as total_inquisitive,
          count(id) as view_folder FROM {ums_emoji_responses} where emoji_id=10 and menutype='avhub'");

        if(!empty($get_like_comment_view))
        {
          $views = $get_like_comment_view->view_folder;
          $likes = $get_like_comment_view->like_folder;
          $comments = $get_like_comment_view->comment_folder;
          $exciting = $get_like_comment_view->total_exciting;
          $celebrate = $get_like_comment_view->total_celebrate;
          $insightful = $get_like_comment_view->total_insightful;
          $inquisitive = $get_like_comment_view->total_inquisitive;
          $support = $get_like_comment_view->total_support;

        }

        if($alldd['foldername'] == 'Audio')
        {
          $alldd['view'] = 0;
          $alldd['like'] = 0;
          $alldd['comment'] = 0;
          $alldd['exciting'] =0;
          $alldd['celebrate'] =0;
          $alldd['insightful'] =0;
          $alldd['inquisitive'] =0;
          $alldd['support'] =0;
          $alldd['created_date'] =$folder->created;
        }else{
          $alldd['view'] =$views;
          $alldd['like'] =$likes;
          $alldd['comment'] =$comments;
          $alldd['exciting'] =$exciting;
          $alldd['celebrate'] =$celebrate;
          $alldd['insightful'] =$insightful;
          $alldd['inquisitive'] =$inquisitive;
          $alldd['support'] =$support;
          $alldd['created_date'] =$folder->created;
          
        }

        //end here emoji count code

        $aa[]=$alldd;
      }

      //print_r($aa);exit;
      $latitude   = "";
      $longitude  = "";

      $subfolders = $DB->get_records_sql('SELECT * FROM {ums_av_folder} WHERE parent_id != 0 and deleted=0 ORDER BY folder ASC');
      foreach ($subfolders as $key => $subfolder) {


        $geofencing_enabled=$subfolder->geofencing_enabled;
        $sqlgetpoints = $DB->get_record_sql("select * from {ums_user_cordinate} where userid = '".$USER->id."'");
        if(!empty($sqlgetpoints)){
         if($ums->user_type_id == 2){
          if($geofencing_enabled==="Yes"){
            $latitude   = $sqlgetpoints->latitude;
            $longitude  = $sqlgetpoints->longitude;
          }else{
             $latitude   = "";
             $longitude  = "";
          }
        }
      }

        $vlcid['id'] = $subfolder->id;
        $bb['subfoldername']= $subfolder->folder;
        $count=0;
        $getcount=$DB->count_records_sql("SELECT count(id) FROM {ums_av_files} WHERE av_folder_id='".$subfolder->id."' AND deleted=0");
        if(!empty($getcount))
        {
          $count=$getcount;
        }

        //code for eemoji count
        $regidsql   = "SELECT * FROM mdl_ums_emoji_responses where menutype='avhub' and element_id='".$subfolder->id."'";
         
        $regdata  = $DB->get_records_sql($regidsql);

        $cnt_like = 0;
        $like = 0;
        $cnt_exciting = 0;
        $exciting = 0;
        $cnt_insightful = 0;
        $insightful = 0;
        $cnt_celebrate = 0;
        $celebrate = 0;
        $cnt_support = 0;
        $support = 0;
        $cnt_inquisitive = 0;
        $inquisitive = 0;
        $cnt_view = 0;
        $view = 0;
        foreach($regdata as $reg)
        {
          if($reg->emoji_id == 1)
          {
              $like = $cnt_like+1;
              $cnt_like++;
          }
          if($reg->emoji_id == 6)
          {
              $exciting = $cnt_exciting+1;
              $cnt_exciting++;
          }
          if($reg->emoji_id == 7)
          {
              $insightful = $cnt_insightful+1;
              $cnt_insightful++;
          }
          if($reg->emoji_id == 8)
          {
              $celebrate = $cnt_celebrate+1;
              $cnt_celebrate++;
          }
          if($reg->emoji_id == 12)
          {
              $support = $cnt_support+1;
              $cnt_support++;
          }
          if($reg->emoji_id == 9)
          {
              $inquisitive = $cnt_inquisitive+1;
              $cnt_inquisitive++;
          }
          if($reg->emoji_id == 10)
          {
              $view = $cnt_view+1;
              $cnt_view++;
          }
          
        }

        $regidsql1   = "SELECT * FROM mdl_ums_emoji_responses_comments where menutype='avhub' and element_id='".$subfolder->id."'";
        $regdata1  = $DB->get_records_sql($regidsql1);
        $cnt_comment = 0;
        $comment = 0;
        foreach($regdata1 as $reg1)
        {
          $comment = $cnt_comment+1;
          $cnt_comment++;
        }

        //end her emoji count
      
        $gettotalseconds=$DB->get_record_sql("SELECT sum(duration) as d FROM {ums_av_files} WHERE av_folder_id='".$subfolder->id."' AND deleted=0");
        if(!empty($gettotalseconds))
        {
           $t=$gettotalseconds->d;
           $hhmmss=sprintf('%02d:%02d:%02d', ($t/3600),($t/60%60), $t%60);
        }
        $subfolder = array('id'=>$subfolder->id,'folder_id'=>$subfolder->parent_id,'subfoldername'=>$subfolder->folder,'created_date'=>$subfolder->created." 00:00:00",'itemcount'=>$count,'duration'=>$hhmmss,'view'=>$view,'like'=>$like,'comment'=>$comment,'exciting'=>$exciting,'celebrate'=>$celebrate,'insightful'=>$insightful,'inquisitive'=>$inquisitive,'support'=>$support,'latitude'  => $latitude,'longitude' => $longitude,'radius'=>100, 'geofencing_enabled'=>$geofencing_enabled);
        $kk[]= $subfolder;
      }
      $dd['folders']=$aa;
      $dd['subfolders']=$kk;
      //print_r($dd);exit;
      return($dd);
    }


     public static function audio_video_folders_new_returns(){
         return new external_single_structure(
                array(
                    
                     'folders' => new external_multiple_structure(
                                new external_single_structure(
                                              array(
                            'id' => new external_value(PARAM_INT,'folderid'),
                            'foldername'=>new external_value(PARAM_RAW,'foldername'),
              'itemcount'=>new external_value(PARAM_RAW,'count number of files'),
              'duration'=>new external_value(PARAM_RAW,'count number of files'),
              'created_date'=>new external_value(PARAM_RAW,'upload date'),
              'view'=>new external_value(PARAM_TEXT,'count number of files to view'),
              'like'=>new external_value(PARAM_TEXT,'count number of files to like'),
              'comment'=>new external_value(PARAM_TEXT,'count number of files to comment'),
              'exciting'=>new external_value(PARAM_TEXT,'count number of files to comment'),
              'celebrate'=>new external_value(PARAM_TEXT,'count number of files to comment'),
              'insightful'=>new external_value(PARAM_TEXT,'count number of files to comment'),
              'inquisitive'=>new external_value(PARAM_TEXT,'count number of files to comment'),
              'support'=>new external_value(PARAM_TEXT,'count number of files to comment'),
              
              
                           
                    ))),
                    'subfolders' => new external_multiple_structure(
                                  new external_single_structure(
                                              array(
                            'id'=>new external_value(PARAM_INT,'subfolderid'),
                            'folder_id'=>new external_value(PARAM_INT,'parentfolderid'),
                            'subfoldername'=>new external_value(PARAM_RAW,'subfoldername'),
                            'itemcount'=>new external_value(PARAM_RAW,'cound of files'),
              'duration'=>new external_value(PARAM_RAW,'total time'),
              'created_date'=>new external_value(PARAM_RAW,'upload date'),
              'latitude' => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
                'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
                'radius' => new external_value(PARAM_RAW, 'radius point of user location',VALUE_OPTIONAL),
                'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL),
                'view'=>new external_value(PARAM_TEXT,'count number of files to view'),
              'like'=>new external_value(PARAM_TEXT,'count number of files to like'),
              'comment'=>new external_value(PARAM_TEXT,'count number of files to comment'),
              'exciting'=>new external_value(PARAM_TEXT,'count number of files to comment'),
              'celebrate'=>new external_value(PARAM_TEXT,'count number of files to comment'),
              'insightful'=>new external_value(PARAM_TEXT,'count number of files to comment'),
              'inquisitive'=>new external_value(PARAM_TEXT,'count number of files to comment'),
              'support'=>new external_value(PARAM_TEXT,'count number of files to comment')
              
                        )))
       //              'folder_vlc' => new external_multiple_structure(
       //                            new external_single_structure(
       //                                        array(
       //                      'view'=>new external_value(PARAM_RAW,'count number of files to view'),
              // 'like'=>new external_value(PARAM_RAW,'count number of files to like'),
              // 'comment'=>new external_value(PARAM_RAW,'count number of files to comment')
       //                  )))
                      

                )
            

        );

     }


//-----------------end here-------------------------------     


      public static function audio_video_parentfolders_parameters(){
        return new external_function_parameters(
            array()
        );

    }

    public static function audio_video_parentfolders(){
        global $DB;
       
         $folders = $DB->get_records('ums_av_folder',array('parent_id'=>0));
         $folders = $DB->get_records_sql('SELECT * FROM {ums_av_folder} WHERE parent_id = 0 ORDER BY folder ASC');
         $mainfolder = array();
          foreach ($folders as $key => $folder) { 
            $alldd['folders'][] = array('folderid'=>$folder->id,'foldername'=>$folder->folder);
           }
            $aa=$alldd;
 
  
           
            return($aa);
    }


     public static function audio_video_parentfolders_returns(){
         return new external_single_structure(
                array(
                    
                     'folders' => new external_multiple_structure(
                                new external_single_structure(
                                              array(
                            'folderid'=>new external_value(PARAM_INT,'folderid'),

                            'foldername'=>new external_value(PARAM_RAW,'foldername'),

                           
                    ))),
                      

                )
            );
     }

     public static function audio_video_subfolders_parameters(){
        return new external_function_parameters(
            array(
              'id' => new external_value(PARAM_INT,'folderid')
            )

        );
    }

    public static function audio_video_subfolders($id){
        global $DB;
       
         #$folders = $DB->get_records('ums_av_folder',array('parent_id'=>$id));
         $folders =$DB->get_records_sql('SELECT * FROM {ums_av_folder} WHERE parent_id = '.$id.' ORDER BY folder ASC');
         $mainfolder = array();
         if(!empty($folders)){
          foreach ($folders as $key => $folder) { 
            $alldd['subfolders'][] = array('folderid'=>$folder->id,'foldername'=>$folder->folder);
           }
         }else{
             $alldd['subfolders'][] = array('folderid'=>null,'foldername'=>null);
         }
            $aa=$alldd;
            // print_r($aa);
 
  
           
            return($aa);
    }


     public static function audio_video_subfolders_returns(){
         return new external_single_structure(
                array(
                    
                     'subfolders' => new external_multiple_structure(
                                new external_single_structure(
                                              array(
                            'folderid'=>new external_value(PARAM_INT,'folderid'),

                            'foldername'=>new external_value(PARAM_RAW,'foldername'),

                           
                    ))),
                      

                )
            );

        

     }

     public static function audio_video_file_parameters(){
        return new external_function_parameters(
            array(
              'id' => new external_value(PARAM_INT,'id'),
            )

        );

    }

    public static function audio_video_file($id){
        global $DB,$CFG;
        $final =array();
         #$files = $DB->get_records('ums_av_files',array('av_folder_id'=>$id,'deleted'=>0));
         $files = $DB->get_records_sql('SELECT * FROM {ums_av_files} WHERE av_folder_id = '.$id.' AND deleted = 0 ORDER BY filename ASC');
		$aa= array();
        $dd = array();
         if(!empty($files)){
            foreach ($files as $key => $file) {

                $aa['id'] = $file->id;
                $aa['videoname'] = $file->filename;
                $aa['is_downloadable'] = $file->is_downloadable;
                if(!empty($file->external_url)){
                  $aa['video_file_name'] = $file->external_url;
                }else{
                  $new = str_replace(' ', '%20', $file->local_file_path);
                  $aa['video_file_name'] = $CFG->wwwroot.$new;
                }
                $aa['createddate'] = $file->created;

                $dd[]= $aa;
             
            }
         }
         
          $final['Video'] = $dd;
   
		return($final);
    }


     public static function audio_video_file_returns(){
      return new external_single_structure(
          array(
            'Video'=>    new external_multiple_structure(
                          new external_single_structure(
                            array(
                                 'id' => new external_value(PARAM_INT,'fileid'),
                                 'videoname' => new external_value(PARAM_TEXT,'filename'),
                                 'is_downloadable' => new external_value(PARAM_TEXT,'is_downloadable'),
                                 'video_file_name'=>new external_value(PARAM_RAW,'url'),
                                 'createddate'=>new external_value(PARAM_RAW,'date'),
                                
                                )
                      

                          )

                      ),
            )
          );
        

     }

//--------------------audio_video_file_new----------------------

     public static function audio_video_file_new_parameters(){
        return new external_function_parameters(
            array(
              'id' => new external_value(PARAM_INT,'id'),
            )

        );

    }

    public static function audio_video_file_new($id)
    {
        global $DB,$CFG;
        $final =array();
        $files = $DB->get_records_sql('SELECT * FROM {ums_av_files} WHERE av_folder_id = '.$id.' AND deleted = 0 ORDER BY filename ASC');
       // print_r($files);exit;
        $aa= array();
        $dd = array();
        $thumb="";
        if(!empty($files))
        {
            foreach ($files as $key => $file) 
            {

                $aa['id'] = $file->id;
                $aa['videoname'] = $file->filename;
                $aa['is_downloadable'] = $file->is_downloadable;
                
              if(!empty($file->external_url))
                {
                  $aa['video_file_name'] = $file->external_url;
                  parse_str( parse_url( $file->external_url, PHP_URL_QUERY ), $my_array_of_vars );
                  $thumb="https://img.youtube.com/vi/".$my_array_of_vars['v']."/hqdefault.jpg";  

                }
                else
                {
                  $new =$file->local_file_path;
                  $aa['video_file_name'] = $CFG->wwwroot.$new;
                  $thumb = basename($CFG->folder.$new,".mp4");  
                  $filepath=$CFG->folder.$new;
                  $thumbnail=$CFG->folder.'/upload/audio_video/thumbnails/'.$file->id.'.jpg';
                  //echo $thumbnail;exit;

                  $duration=0;
                  if(!file_exists($thumbnail))
                  {
                    $second = 1;  
                    $ffmpeg = "/usr/bin/ffmpeg"; 
                    $cmd = $ffmpeg." -i \"".$filepath."\" -s 250x250 -an -ss ".$second.".001 -y -f mjpeg \"".$thumbnail."\" 2>&1";
                    //$cmd = $ffmpeg." -i ".$filepath." -deinterlace -an -ss ".$second." -t 00:00:01 -r 1 -y -vcodec mjpeg -f mjpeg ".$thumbnail." 2>&1";
                    $output = shell_exec($cmd); 
                  }
                  
                  if($file->duration==NULL || $file->duration=='')
                  {
                    $ffmpeg = "/usr/bin/ffprobe";
                    $cmd = $ffmpeg." -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 '".$filepath."' ";
                    $output = shell_exec($cmd); 
                    $duration=round(trim($output));

                    $getID3 = new getID3;
                    $files = $getID3->analyze($filepath);
                    //echo $file['playtime_string'].'<br>';
                    $duration_new =  floor($files['playtime_seconds']);
                    //echo $file['hours'].'-'.$file['mins'].'-'.$file['secs'];
                    //exit;
                   
                   $DB->execute("UPDATE {ums_av_files} SET duration='".$duration_new."' WHERE id='".$file->id."'");
                  }
                  $hhmmss=sprintf('%02d:%02d:%02d', ($file->duration/3600),($file->duration/60%60), $file->duration%60);
                  // echo $hhmmss;exit;

                  $aa['createddate'] = $file->created." 00:00:00";
                  $aa['thumb'] = $CFG->wwwroot.'/upload/audio_video/thumbnails/'.$file->id.'.jpg';
                  $aa['duration']=$hhmmss;

                  //code for emoji count gramx

              $regidsql   = "SELECT * FROM mdl_ums_emoji_responses where menutype='avhub' and module_id='".$file->id."'";
         
              $regdata  = $DB->get_records_sql($regidsql);

              $cnt_like = 0;
              $like = 0;
              $cnt_exciting = 0;
              $exciting = 0;
              $cnt_insightful = 0;
              $insightful = 0;
              $cnt_celebrate = 0;
              $celebrate = 0;
              $cnt_support = 0;
              $support = 0;
              $cnt_inquisitive = 0;
              $inquisitive = 0;
              $cnt_view = 0;
              $views = 0;
              foreach($regdata as $reg)
              {
                if($reg->emoji_id == 1)
                {
                    $like = $cnt_like+1;
                    $cnt_like++;
                }
                if($reg->emoji_id == 6)
                {
                    $exciting = $cnt_exciting+1;
                    $cnt_exciting++;
                }
                if($reg->emoji_id == 7)
                {
                    $insightful = $cnt_insightful+1;
                    $cnt_insightful++;
                }
                if($reg->emoji_id == 8)
                {
                    $celebrate = $cnt_celebrate+1;
                    $cnt_celebrate++;
                }
                if($reg->emoji_id == 12)
                {
                    $support = $cnt_support+1;
                    $cnt_support++;
                }
                if($reg->emoji_id == 9)
                {
                    $inquisitive = $cnt_inquisitive+1;
                    $cnt_inquisitive++;
                }
                if($reg->emoji_id == 10)
                {
                    $views = $cnt_view+1;
                    $cnt_view++;
                }
                
              }

              $regidsql1   = "SELECT * FROM mdl_ums_emoji_responses_comments where menutype='avhub' and module_id='".$file->id."'";
              $regdata1  = $DB->get_records_sql($regidsql1);
              $cnt_comment = 0;
              $comment = 0;
              foreach($regdata1 as $reg1)
              {
                $comment = $cnt_comment+1;
                $cnt_comment++;
              }


              $aa['view'] = $views;
              $aa['like'] = $like;
              $aa['comment'] = $comment;
              $aa['exciting'] = $exciting;
              $aa['celebrate'] = $celebrate;
              $aa['insightful'] = $insightful;
              $aa['inquisitive'] = $inquisitive;
              $aa['support'] = $support;

                  //end ere code of gramx


                  $dd[]= $aa;
             
            }
         }
        }
          
          $final['Video'] = $dd;
          return($final);
    }


     public static function audio_video_file_new_returns(){
      return new external_single_structure(
          array(
            'Video'=>    new external_multiple_structure(
                          new external_single_structure(
                            array(
                                 'id' => new external_value(PARAM_INT,'fileid'),
                                 'videoname' => new external_value(PARAM_TEXT,'filename'),
                                 'is_downloadable' => new external_value(PARAM_TEXT,'is_downloadable'),
                                 'video_file_name'=>new external_value(PARAM_RAW,'url'),
                                 'createddate'=>new external_value(PARAM_RAW,'date'),
                                'thumb'=>new external_value(PARAM_RAW,'video thumbnail'),
                'duration'=>new external_value(PARAM_RAW,'video duration'),
                'view'=>new external_value(PARAM_INT,'total view'),
                'like'=>new external_value(PARAM_INT,'total like'),
                'comment'=>new external_value(PARAM_INT,'total comment'),
                'exciting'=>new external_value(PARAM_INT,'total comment'),
                'celebrate'=>new external_value(PARAM_INT,'total comment'),
                'insightful'=>new external_value(PARAM_INT,'total comment'),
                'inquisitive'=>new external_value(PARAM_INT,'total comment'),
                'support'=>new external_value(PARAM_INT,'total comment'),
                
                                )
                      

                          )

                      ),
            )
          );
        

     }


//--------------------end here ----------------------------------

       //function to logout

      public static function logout_parameters(){
        return new external_function_parameters(
            array(            
            )
        );

    }

    public static function logout(){
        global $DB,$USER;
		
		/* OLD 11Oct, 2019
		$updatenewtbl = $DB->execute("UPDATE {ums_device_information} SET devicetoken = NULL, ostype= NULL, fcmid=NULL, mobilemodelname=NULL, mobileosname=NULL, currentappversion=NULL, macid=NULL, extraparam1=NULL, extraparam2=NULL, updated = '".date("Y-m-d H:i:s")."' WHERE userid = ".$USER->id."");
		
        $update = $DB->execute("UPDATE {user} set devicetoken = NULL, ostype= NULL, fcmid=NULL, mobilemodelname=NULL, mobileosname=NULL, currentappversion=NULL, macid=NULL, extraparam1=NULL, extraparam2=NULL WHERE id = ".$USER->id.""); */
		
		//Changed on 11Oct,2019
		$update = $DB->execute("UPDATE {ums_device_information} SET logout_date = '".date("Y-m-d H:i:s")."', is_logout = '1' WHERE userid = ".$USER->id."");
        if($update){
          $result = array('status'=>'success');
        }else{
          $result = array('status'=>'failed');
        }
        
        
           
            return($result);
    }


    public static function logout_returns(){
       return new external_single_structure(
                array(
                      'status'=>new external_value(PARAM_RAW,'status'),

                )
            );

    }
	
	// webservice created date - 23/01/2020 
	public static function get_myquestion_parameters() 
	{
		return new external_function_parameters(
			array()
		);
	}
	
	public static function get_myquestion()
	{
	    global $USER,$DB,$CFG;
	    $aa = array();
		$resultarray=array();
        $dd = $dd1 = $dd2 = $dd3 = $dd4 = $dd5 = $dd6 = array();
        $op1 = $op2 = $op3 = $op4 = $op5 = $op6 = array();
			
      $today  = date('Y-m-d');
      //$today  = date('m/d/Y');
	    $res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE deleted ='0' AND qdate = '".$today."'");
      //print_r($res_Question);exit;
		if(!empty($res_Question))
	    {
			$questionid       = $res_Question->id;
			$question_type    = $res_Question->questiontype;
			$question  		  = $res_Question->question;
			$option_a_type    = $res_Question->option_a_type;
			$option_a         = $res_Question->option_a;
			$option_b_type    = $res_Question->option_b_type;
			$option_b         = $res_Question->option_b;
			$option_c_type    = $res_Question->option_c_type;
			$option_c         = $res_Question->option_c;
			$option_d_type    = $res_Question->option_d_type;
			$option_d         = $res_Question->option_d;
			$additional_text  = $res_Question->additional_text;
			if($question_type == 1)
			{
				$q_type = 'Text';
				$question_text  = isset($question) && $question!=''?$question:'--';
				$question_image = "";
			}
			if($question_type == 2)
			{
				$q_type = 'Image';
				$question_text  = "";
				$question_image = $CFG->wwwroot.$question;
			}
			if($question_type == 3)
			{
				$q_type = 'Both';
				$question_text  = $additional_text;
				$question_image = $CFG->wwwroot.$question;
			}
			
			//------------------------------------------------------------//
			if($option_a_type == 1)
			{
				$option_A_type  = 'Text';
				$option_A_text  = isset($option_a) && $option_a!=''?$option_a:'--';
				$option_A_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			}
			if($option_a_type == 2)
			{
				$option_A_type   = 'Image';
				$option_A_text   = "";
				$option_A_image  = $CFG->wwwroot.$option_a;
				
			}
			//----------------------------------------------------------------//
			if($option_b_type == 1)
			{
				$option_B_type  = 'Text';
				$option_B_text  = isset($option_b) && $option_b!=''?$option_b:'--';
				$option_B_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			}
			if($option_b_type == 2)
			{
				$option_B_type   = 'Image';
				$option_B_text   = "";
				$option_B_image  = $CFG->wwwroot.$option_b;
			}
			
			//-------------------------------------------------------------//
			
			if($option_c_type == 1)
			{
				$option_C_type  = 'Text';
				$option_C_text  = isset($option_c) && $option_c!=''?$option_c:'--';
				$option_C_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			}
			if($option_c_type == 2)
			{
				$option_C_type   = 'Image';
				$option_C_text   = "";
				$option_C_image  = $CFG->wwwroot.$option_c;
			}
			
			//-------------------------------------------------------------//
			
			if($option_d_type == 1)
			{
				$option_D_type   = 'Text';
				$option_D_text   = isset($option_d) && $option_d!=''?$option_d:'--';
				$option_D_image  = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				
			}
			if($option_d_type == 2)
			{
				$option_D_type   = 'Image';
				$option_D_text   = "";
				$option_D_image  = $CFG->wwwroot.$option_d;
			}
			
			$option_E_type   = 'Text';
			$option_E_text   = 'All of these';
			$option_E_image  = '-'; //$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				
			$option_F_type   = 'Text';
			$option_F_text   = 'None of these';
			$option_F_image  = '-'; //$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			
			//---------------------------------------------------------------//
			
			$alldd  = array('questionid' => $questionid,
							'questiontype'   => $q_type,
							'question_text'  => $question_text,
							'question_image' => $question_image);
			$aa[]   = $alldd;				
			$option1 = array('option_type'   => $option_A_type,
							 'option_text'   => $option_A_text,
							 'option_image'  => $option_A_image
							);
			$op1[]= $option1;
			
			$option2 = array('option_type'   => $option_B_type,
							 'option_text'   => $option_B_text,
							 'option_image'  => $option_B_image
							);
			$op2[]= $option2;
			
			$option3 = array('option_type'  => $option_C_type,
							 'option_text'   => $option_C_text,
							 'option_image'  => $option_C_image
							);
			$op3[]= $option3;
			
			$option4 = array('option_type'   => $option_D_type,
							 'option_text'   => $option_D_text,
							 'option_image'  => $option_D_image
							);
			$op4[]= $option4;
			
			$option5 = array('option_type'   => $option_E_type,
							 'option_text'   => $option_E_text,
							 'option_image'  => $option_F_image
							);
			$op5[]= $option5;
			
			$option6 = array('option_type'   => $option_F_type,
							 'option_text'   => $option_F_text,
							 'option_image'  => $option_F_image
							);
			$op6[]= $option6;
			$op = array_merge($op1,$op2,$op3,$op4);
			$dd['Question'] = $aa;
			$dd['Options']  = $op;
      $dd['status']   = 1;
      $dd['message']  = '';
		}else{
      $dd['Question'] = [];
      $dd['Options']  = [];
      $dd['status']   = 1;
      $dd['message']  = 'Question Missing';
		}
    return $dd;
	}
	
	public static function get_myquestion_returns()
	{
		return new external_single_structure(
      array(
        'Question' => new external_multiple_structure(
         new external_single_structure(
           array(
            'questionid'      => new external_value(PARAM_INT,'questionid'),
            'questiontype'    => new external_value(PARAM_TEXT,'questiontype'),
            'question_text'   => new external_value(PARAM_TEXT,'question_text'),
            'question_image'  => new external_value(PARAM_TEXT,'question_image'),

          ))),
        'Options' => new external_multiple_structure(
          new external_single_structure(
           array(
             'option_type'   => new external_value(PARAM_TEXT,'option_type'),
             'option_text'   => new external_value(PARAM_TEXT,'option_text'),
             'option_image'  => new external_value(PARAM_TEXT,'option_image')
           ))
        ),
        'status'=>new external_value(PARAM_INT,'status'),
        'message'=>new external_value(PARAM_TEXT,'message')
      )
    );
	}
	
	public static function get_myquestionanwser_parameters() 
	{
		return new external_function_parameters(
            array(
               'questionid' => new external_value(PARAM_INT,'questionid'),
			   'answerid' => new external_value(PARAM_RAW,'answerid'),
            )
        );
	}
	
	public static function get_myquestionanwser($questionid,$answerid)
	{
	    global $USER,$DB,$CFG;

    $todaydt=date('Y-m-d');
    $url="";
    $type="";
    $is_attempted="NA";
    $astatus="";
	$title="";
	$description="";
    $kcacourses=$DB->get_records_sql("SELECT id,type,fullname,summary FROM {course} WHERE is_kca=1 order by id desc");

    if(!empty($kcacourses))
    {
      foreach ($kcacourses as $key => $course) 
      {
		$title=$course->fullname;
		$description=$course->summary;
        $sql = "select id from {enrol} where courseid=".$course->id." and enrol='manual'";
        $obj=$DB->get_record_sql($sql);

        $enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($obj->id,$USER->id));

            if(!empty($enrollmentdate))
            {

            $courseenrollmentdate = $enrollmentdate->timecreated;
 
           // $enrolenddate = $enrollmentdate->timeend;
            $enrolstart=date('Y-m-d',$courseenrollmentdate);

              if($todaydt==$enrolstart)
              {

              switch($course->type)
              {
                case 's':
                $surveyid   = $DB->get_field('questionnaire','id', array('course'=>$course->id));

                $rid = $DB->get_field("questionnaire_response", "id", array("userid"=>$USER->id, "survey_id"=>$surveyid));

                if($rid) 
                {
                  $response = $DB->get_record('questionnaire_response',array('id'=>$rid));
                  if($response->complete == 'y') 
                  {
                    $astatus="Y";
                  }
                  else
                  { 
                    $astatus="N";
                  }
                         
                }
                else
                {
                  $astatus="N";
                }
                
                break;
                case 'a':
                $quizrecord  = $DB->get_record('quiz', array('course' => $course->id));
            
                $attempstatus = $DB->get_field('quiz_attempts','state',array('quiz' =>$quizrecord->id, 'userid' => $USER->id,'attempt' => 1));
                if(!empty($attempstatus))
                {
                  if($attempstatus=='finished')
                 {
                  $astatus="Y";
                 }
                 else
                 {
                  $astatus="N";
                 }
                }
                else
                {
                  $astatus="N";
                }
                break;
                /*
                case 'c':
               
                require_once($CFG->libdir."/completionlib.php");
                $course=$DB->get_records_sql("select * from mdl_course where id='".$course->id."'");
                $cinfo = new completion_info($course);
                $iscomplete = $cinfo->is_course_complete($USER->id);
                if($iscomplete)
                {
                  $astatus="Y";
                }
                else
                {
                  $astatus="N";
                }
               */
              }
              
              if($astatus=='Y')
              {
                $is_attempted="Yes";
              
              }
              else
              {
                $url = $CFG->wwwroot.'/course/view.php?id='.$course->id;
                $is_attempted="No";
                $type=$course->type;
                break;
              }

              }
            }  
            else
            {
              continue;
            }                           

      }

      
    }
   
		$today       = date('Y-m-d H:i:s');
		$resultarray = array();
		$aa = array();
		$dd = $dd1 = $dd2 = $dd3 = $dd4 = $dd5 = $dd6 = array();
        $op1 = $op2 = $op3 = $op4 = $op5 = $op6 = array();
		$sqlResponce = $DB->get_record_sql("SELECT * FROM mdl_question_user_answer WHERE questionid = '".$questionid."' AND userid = '".$USER->id."'");
		if(empty($sqlResponce))
		{
			$sqlQuestion = "SELECT * FROM mdl_question_of_day WHERE id = '".$questionid."'";
			$resQuestion = $DB->get_record_sql($sqlQuestion);
			$qviewdate   = $resQuestion->qdate;
			$correctanswer    = explode(",",$resQuestion->correctanswer);
			$givenanswerarray=array();
			if (strpos($answerid,',') == true) 
			{
				$givenanswerarray = explode(",",$answerid);
				$givenanswerarray=array_filter($givenanswerarray);
			}
			else
			{
				array_push($givenanswerarray, $answerid);
			}
			$noncommon=array_diff($correctanswer,$givenanswerarray);
			if(count($noncommon)==0 && count($givenanswerarray)==count($correctanswer)) 
			{
				
				$is_correct = 1;
			    $insertCorrectResponce = "INSERT mdl_question_user_answer SET 
								questionid = '".$questionid."',
								answerid = '".$answerid."',
								userid = '".$USER->id."',
								mspin = '".$USER->username."',
								attempt_status = 1,
								is_correct = '".$is_correct."',
								qviewdate  = '".$qviewdate."',
								answer_posted_date = '".date("Y-m-d H:i:s")."'";
				if($DB->execute($insertCorrectResponce))
				{	
					$updateUserStatus = "UPDATE mdl_ums_employeemaster SET 	attempted_todays_question_view = 0,
					attempted_todays_question_view_date = '".date('Y-m-d')."' 
					WHERE userid = '".$USER->id."'";
					$DB->execute($updateUserStatus);
					// this is for month wise report for perticular employee
					$month  = date("Y-m");
					$sqlData = $DB->get_record_sql("SELECT id,answer FROM mdl_question_of_day_correct_answer WHERE mspin = '".$USER->username."' AND month = '".$month."'");
					
					if(isset($sqlData->answer) && !empty($sqlData->answer))
					{		
							$answer = $sqlData->answer + 1;
							$record = new stdClass();
							$record->id 	    	= $sqlData->id;
							$record->answer 	    = $answer;
							$record->updated 	    = date("Y-m-d H:i:s");
							$lastinsertid           = $DB->update_record('question_of_day_correct_answer',$record);
					}
					else
					{
						
							$record = new stdClass();
							$record->month 			= $month;
							$record->mspin 	  		= $USER->username;
							$record->answer 	    = 1;
							$record->created 	    = date("Y-m-d H:i:s");
							$lastinsertid           = $DB->insert_record('question_of_day_correct_answer',$record);
					}
				
					$currentDatecurrentDate = date('Y-m-d');
				
					$res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE qdate = '".$currentDatecurrentDate."'");
					
					if(!empty($res_Question))
	    {
			$questionid       = $res_Question->id;
			$question_type    = $res_Question->questiontype;
			$question  		  = strip_tags($res_Question->question);
			$option_a_type    = $res_Question->option_a_type;
			$option_a         = $res_Question->option_a;
			$option_b_type    = $res_Question->option_b_type;
			$option_b         = $res_Question->option_b;
			$option_c_type    = $res_Question->option_c_type;
			$option_c         = $res_Question->option_c;
			$option_d_type    = $res_Question->option_d_type;
			$option_d         = $res_Question->option_d;
			$additional_text  = $res_Question->additional_text;
			$qdate            = date("d-m-Y",strtotime($res_Question->qdate));
			$correctanswerOp  = $res_Question->correctanswer;
			$c_p = explode(',',$correctanswerOp);
			if($question_type == 1)
			{
				$q_type = 'Text';
				$question_text  = isset($question) && $question!=''?$question:'--';
				$question_image = '';
			}
			if($question_type == 2)
			{
				$q_type = 'Image';
				$question_text  = '';
				$question_image = $CFG->wwwroot.$question;
			}
			if($question_type == 3)
			{
				$q_type = 'Both';
				$question_text  = $additional_text;
				$question_image = $CFG->wwwroot.$question;
			}
		
			if($option_a_type == 1)
			{
				$option_A_type  = 'Text';
				$option_A_text  = isset($option_a) && $option_a!=''?$option_a:'--';
				$option_A_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_a_type == 2)
			{
				$option_A_type   = 'Image';
				$option_A_text   = '';
				$option_A_image  = $CFG->wwwroot.$option_a;
				$is_right_answer = '';
				
			}
			
			if($option_b_type == 1)
			{
				$option_B_type  = 'Text';
				$option_B_text  = isset($option_b) && $option_b!=''?$option_b:'--';
				$option_B_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_b_type == 2)
			{
				$option_B_type   = 'Image';
				$option_B_text   = '';
				$option_B_image  = $CFG->wwwroot.$option_b;
				$is_right_answer = '';
			}
			
			if($option_c_type == 1)
			{
				$option_C_type  = 'Text';
				$option_C_text  = isset($option_c) && $option_c!=''?$option_c:'--';
				$option_C_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_c_type == 2)
			{
				$option_C_type   = 'Image';
				$option_C_text   = '';
				$option_C_image  = $CFG->wwwroot.$option_c;
				$is_right_answer = '';
			}
			
		
			if($option_d_type == 1)
			{
				$option_D_type   = 'Text';
				$option_D_text   = isset($option_d) && $option_d!=''?$option_d:'--';
				$option_D_image  = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
				
			}
			if($option_d_type == 2)
			{
				$option_D_type   = 'Image';
				$option_D_text   = '';
				$option_D_image  = $CFG->wwwroot.$option_d;
				$is_right_answer = '';
			}
			
			$option_E_type   = 'Text';
			$option_E_text   = 'All of these';
			$option_E_image  = '-'; 
			$is_right_answer = '';
				
			$option_F_type   = 'Text';
			$option_F_text   = 'None of these';
			$option_F_image  = '-'; 
			$is_right_answer = '';
			
			$alldd  = array('questionid' => $questionid,
							'questiontype'   => $q_type,
							'question_text'  => $question_text,
							'question_image' => $question_image,
							'questiondate'   => $qdate,
              'url'   => $url,
              'is_attempted'   => $is_attempted,
              'type'   => $type,
			  'title' =>$title,
			  'description'=>$description
            );

			$aa[]   = $alldd;	
			$is_right_answer=(in_array("A", $c_p)?'Yes':'No');			
			$option1 = array('option_type'   => $option_A_type,
							 'option_text'   => $option_A_text,
							 'option_image'  => $option_A_image,
							 'is_right_anwser' => $is_right_answer 
							);
			$op1[]= $option1;
			$is_right_answer=(in_array("B", $c_p)?'Yes':'No');
			$option2 = array('option_type'   => $option_B_type,
							 'option_text'   => $option_B_text,
							 'option_image'  => $option_B_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op2[]= $option2;
			$is_right_answer=(in_array("C", $c_p)?'Yes':'No');
			$option3 = array('option_type'  => $option_C_type,
							 'option_text'   => $option_C_text,
							 'option_image'  => $option_C_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op3[]= $option3;
			$is_right_answer=(in_array("D", $c_p)?'Yes':'No');
			$option4 = array('option_type'   => $option_D_type,
							 'option_text'   => $option_D_text,
							 'option_image'  => $option_D_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op4[]= $option4;
			$is_right_answer=(in_array("E", $c_p)?'Yes':'No');
			$option5 = array('option_type'   => $option_E_type,
							 'option_text'   => $option_E_text,
							 'option_image'  => $option_F_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op5[]= $option5;
			$is_right_answer=(in_array("F", $c_p)?'Yes':'No');
			$option6 = array('option_type'   => $option_F_type,
							 'option_text'   => $option_F_text,
							 'option_image'  => $option_F_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op6[]= $option6;
			$op = array_merge($op1,$op2,$op3,$op4);
			$dd['Question'] = $aa;
			$dd['Options']  = $op;
			return($dd);
    
		      }
					
				} 
			} 
			else
			{
				$is_correct = 0;
			    $insertWorngResponce = "INSERT mdl_question_user_answer SET 
								questionid = '".$questionid."',
								answerid = '".$answerid."',
								userid = '".$USER->id."',
								mspin = '".$USER->username."',
								attempt_status = 1,
								is_correct = '".$is_correct."',
								qviewdate  = '".$qviewdate."',
								answer_posted_date = '".date("Y-m-d H:i:s")."'";
								
				if($DB->execute($insertWorngResponce))
				{ 
					$updateUserStatus = "UPDATE mdl_ums_employeemaster 
					SET attempted_todays_question_view = 0,				attempted_todays_question_view_date = '".date('Y-m-d')."'					
					WHERE userid = '".$USER->id."'";
					$DB->execute($updateUserStatus);
					
				}
				
				$currentDatecurrentDate = date('Y-m-d');
				$res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE qdate = '".$currentDatecurrentDate."'");
				if(!empty($res_Question))
				{
					$questionid       = $res_Question->id;
					$question_type    = $res_Question->questiontype;
					$question  		  = strip_tags($res_Question->question);
					$option_a_type    = $res_Question->option_a_type;
					$option_a         = $res_Question->option_a;
					$option_b_type    = $res_Question->option_b_type;
					$option_b         = $res_Question->option_b;
					$option_c_type    = $res_Question->option_c_type;
					$option_c         = $res_Question->option_c;
					$option_d_type    = $res_Question->option_d_type;
					$option_d         = $res_Question->option_d;
					$additional_text  = $res_Question->additional_text;
					$qdate            = date("d-m-Y",strtotime($res_Question->qdate)); 
					$correctanswerOp  = $res_Question->correctanswer;
					$c_p = explode(',',$correctanswerOp);
					if($question_type == 1)
					{
						$q_type = 'Text';
						$question_text  = isset($question) && $question!=''?$question:'--';
						$question_image = '';
					}
					if($question_type == 2)
					{
						$q_type = 'Image';
						$question_text  = '';
						$question_image = $CFG->wwwroot.$question;
					}
					if($question_type == 3)
					{
						$q_type = 'Both';
						$question_text  = $additional_text;
						$question_image = $CFG->wwwroot.$question;
					}
					
					if($option_a_type == 1)
					{
						$option_A_type  = 'Text';
						$option_A_text  = isset($option_a) && $option_a!=''?$option_a:'--';
						$option_A_image = '-';
						$is_right_answer = '';
					}
					if($option_a_type == 2)
					{
						$option_A_type   = 'Image';
						$option_A_text   = '';
						$option_A_image  = $CFG->wwwroot.$option_a;
						$is_right_answer = '';
						
					}
					
					if($option_b_type == 1)
					{
						$option_B_type  = 'Text';
						$option_B_text  = isset($option_b) && $option_b!=''?$option_b:'--';
						$option_B_image = '-';
						$is_right_answer = '';
					}
					if($option_b_type == 2)
					{
						$option_B_type   = 'Image';
						$option_B_text   = '';
						$option_B_image  = $CFG->wwwroot.$option_b;
						$is_right_answer = '';
					}
				
					if($option_c_type == 1)
					{
						$option_C_type  = 'Text';
						$option_C_text  = isset($option_c) && $option_c!=''?$option_c:'--';
						$option_C_image = '-';
						$is_right_answer = '';
					}
					if($option_c_type == 2)
					{
						$option_C_type   = 'Image';
						$option_C_text   = '';
						$option_C_image  = $CFG->wwwroot.$option_c;
						$is_right_answer = '';
					}
			
					if($option_d_type == 1)
					{
						$option_D_type   = 'Text';
						$option_D_text   = isset($option_d) && $option_d!=''?$option_d:'--';
						$option_D_image  = '-';
						$is_right_answer = '';
						
					}
					if($option_d_type == 2)
					{
						$option_D_type   = 'Image';
						$option_D_text   = '';
						$option_D_image  = $CFG->wwwroot.$option_d;
						$is_right_answer = '';
					}
			
					$option_E_type   = 'Text';
					$option_E_text   = 'All of these';
					$option_E_image  = '-'; 
					$is_right_answer = '';
					
					$option_F_type   = 'Text';
					$option_F_text   = 'None of these';
					$option_F_image  = '-'; 
					$is_right_answer = '';
			
					$alldd  = array('questionid' => $questionid,
									'questiontype'   => $q_type,
									'question_text'  => $question_text,
									'question_image' => $question_image,
									'questiondate'   => $qdate,
                  'url'   => $url,
                  'is_attempted'   => $is_attempted,
                  'type'   => $type,
				  'title'=>$title,
				  'description'=>$description
                );
					$aa[]   = $alldd;	

					$is_right_answer=(in_array("A", $c_p)?'Yes':'No');			
					$option1 = array('option_type'   => $option_A_type,
									 'option_text'   => $option_A_text,
									 'option_image'  => $option_A_image,
									 'is_right_anwser' => $is_right_answer 
									);
					$op1[]= $option1;
					$is_right_answer=(in_array("B", $c_p)?'Yes':'No');
					$option2 = array('option_type'   => $option_B_type,
									 'option_text'   => $option_B_text,
									 'option_image'  => $option_B_image,
									 'is_right_anwser' => $is_right_answer
									);
					$op2[]= $option2;
					$is_right_answer=(in_array("C", $c_p)?'Yes':'No');
					$option3 = array('option_type'  => $option_C_type,
									 'option_text'   => $option_C_text,
									 'option_image'  => $option_C_image,
									 'is_right_anwser' => $is_right_answer
									);
					$op3[]= $option3;
					$is_right_answer=(in_array("D", $c_p)?'Yes':'No');
					$option4 = array('option_type'   => $option_D_type,
									 'option_text'   => $option_D_text,
									 'option_image'  => $option_D_image,
									 'is_right_anwser' => $is_right_answer
									);
					$op4[]= $option4;
					$is_right_answer=(in_array("E", $c_p)?'Yes':'No');
					$option5 = array('option_type'   => $option_E_type,
									 'option_text'   => $option_E_text,
									 'option_image'  => $option_F_image,
									 'is_right_anwser' => $is_right_answer
									);
					$op5[]= $option5;
					$is_right_answer=(in_array("F", $c_p)?'Yes':'No');
					$option6 = array('option_type'   => $option_F_type,
									 'option_text'   => $option_F_text,
									 'option_image'  => $option_F_image,
									 'is_right_anwser' => $is_right_answer
									);
					$op6[]= $option6;
					$op = array_merge($op1,$op2,$op3,$op4);
					$dd['Question'] = $aa;
					$dd['Options']  = $op;
					return($dd);
          
				}
				
			}
					

		}	
		else
		{
/*
			$resultarray = array(
									'status'  => 2,
									'message' => 'Already Attemped'
								);
  */

      $alldd  = array('questionid' => '',
                  'questiontype'   => '',
                  'question_text'  =>'',
                  'question_image' => '',
                  'questiondate'   => '',
                  'url'   => '',
                  'is_attempted'   => $is_attempted,
                  'type'   => ''
                );
          $aa[]   = $alldd; 
      $option1 = array('option_type'   => '',
                   'option_text'   => '',
                   'option_image'  => '',
                   'is_right_anwser' => '' 
                  );
          $op1[]= $option1;
          $option2 = array('option_type'   => '',
                   'option_text'   => '',
                   'option_image'  => '',
                   'is_right_anwser' => '' 
                  );
          $op2[]= $option2;
          $op = array_merge($op1,$op2);

          $dd['Question'] = $aa;
          $dd['Options']  = $op;
          return($dd);
		}
   
	}
	
	public static function get_myquestionanwser_returns()
	{
		return new external_single_structure(
            array(
                    
			 'Question' => new external_multiple_structure(
					new external_single_structure(
					array(
						'questionid'      => new external_value(PARAM_INT,'questionid'),
						'questiontype'    => new external_value(PARAM_TEXT,'questiontype'),
						'question_text'   => new external_value(PARAM_TEXT,'question_text'),
						'question_image'  => new external_value(PARAM_TEXT,'question_image'),
						'questiondate'    => new external_value(PARAM_RAW,'questiondate'),
				   'url'    => new external_value(PARAM_RAW,'url'),
           'is_attempted'    => new external_value(PARAM_RAW,'is_attempted'),
           'type'=> new external_value(PARAM_RAW,'type'),
		   'title'    => new external_value(PARAM_RAW,'course name '),
           'description'=> new external_value(PARAM_RAW,'course message')
					))),
			'Options' => new external_multiple_structure(
				    new external_single_structure(
					array(
							'option_type'   => new external_value(PARAM_TEXT,'option_type'),
							'option_text'   => new external_value(PARAM_TEXT,'option_text'),
							'option_image'  => new external_value(PARAM_TEXT,'option_image'),
							'is_right_anwser' => new external_value(PARAM_TEXT,'is_right_anwser')
						))
					)
                )
        );
	}
	
	// this function for user todays question stataus whether attmpted or not 
	public static function get_mytodayquestionstatus_parameters() 
	{
		return new external_function_parameters(
            array(
             	'MSPIN' => new external_value(PARAM_RAW,'MSPIN'),
            )
        );
	}
	
	public static function get_mytodayquestionstatus($MSPIN)
	{
   global $USER,$DB,$CFG;
   $todaydt=date('Y-m-d');
    $url="";
    $type="";
    $is_attempted="NA";
    $astatus="";
	$title="";
	$description="";
    $kcacourses=$DB->get_records_sql("SELECT id,type,fullname,summary FROM {course} WHERE is_kca=1 order by id desc");

    if(!empty($kcacourses))
    {
      foreach ($kcacourses as $key => $course) 
      {
		$title=$course->fullname;
		$description=$course->summary;
        $sql = "select id from {enrol} where courseid=".$course->id." and enrol='manual'";
        $obj=$DB->get_record_sql($sql);

        $enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($obj->id,$USER->id));

            if(!empty($enrollmentdate))
            {

            $courseenrollmentdate = $enrollmentdate->timecreated;
 
           // $enrolenddate = $enrollmentdate->timeend;
            $enrolstart=date('Y-m-d',$courseenrollmentdate);

              /*if($todaydt==$enrolstart)
              {*/

              switch($course->type)
              {
                case 's':
                $surveyid   = $DB->get_field('questionnaire','id', array('course'=>$course->id));

                // $rid = $DB->get_field("questionnaire_response", "id", array("userid"=>$USER->id, "survey_id"=>$surveyid));
                $rid = $DB->get_field("questionnaire_response", "id", array("userid"=>$USER->id, "questionnaireid"=>$surveyid));

                if($rid) 
                {
                  $response = $DB->get_record('questionnaire_response',array('id'=>$rid));
                  if($response->complete == 'y') 
                  {
                    $astatus="Y";
                  }
                  else
                  { 
                    $astatus="N";
                  }
                         
                }
                else
                {
                  $astatus="N";
                }
                
                break;
                case 'a':
                $quizrecord  = $DB->get_record('quiz', array('course' => $course->id));
            
                $attempstatus = $DB->get_field('quiz_attempts','state',array('quiz' =>$quizrecord->id, 'userid' => $USER->id,'attempt' => 1));
                if(!empty($attempstatus))
                {
                 if($attempstatus=='finished')
                 {
                  $astatus="Y";
                 }
                 else
                 {
                  $astatus="N";
                 }
                }
                else
                {
                  $astatus="N";
                }
                break;
                /*
                case 'c':
               
                require_once($CFG->libdir."/completionlib.php");
                $course=$DB->get_records_sql("select * from mdl_course where id='".$course->id."'");
                $cinfo = new completion_info($course);
                $iscomplete = $cinfo->is_course_complete($USER->id);
                if($iscomplete)
                {
                  $astatus="Y";
                }
                else
                {
                  $astatus="N";
                }
               */
              }
              
              if($astatus=='Y')
              {
                $is_attempted="Yes";
              
              }
              else
              {
                $url = $CFG->wwwroot.'/course/view.php?id='.$course->id;
                $is_attempted="No";
                $type=$course->type;
                break;
              }

              /*}*/
            }  
            else
            {
              continue;
            }                           

      }

      
    }
/*  $url = $CFG->wwwroot.'/course/view.php?id=596';
  $is_attempted="No";*/
  $resultarray = array();
  $todaydate   = date('Y-m-d');
  $token = $_REQUEST['wstoken'];
  if(!empty($token))
  {	
   if($MSPIN == $USER->username)
   {

    $sql_qns = $DB->get_record_sql("SELECT * FROM mdl_question_of_day 
      WHERE deleted = 0 AND qdate = '".$todaydate."'");

    if(empty($sql_qns))
    {
        $resultarray = array(
                          'status'  => 3,
                          'message' => 'Question is missing',
                          'url'=>$url,
                          'is_attempted'=>$is_attempted,
                          'type'=>$type,
                          'title'=>$title,
                          'description'=>$description
                        );
    }
    else{

    // }	


    $sqlResponce = $DB->get_record_sql("SELECT * FROM mdl_question_user_answer 
      WHERE mspin = '".$MSPIN."' AND qviewdate = '".$todaydate."'");
      if(!empty($sqlResponce))
      {
  					// change request - 0
       $resultarray = array(
         'status'  => 1,
         'message' => 'Question Attemped',
         'url'=>$url,
         'is_attempted'=>$is_attempted,
         'type'=>$type,
  	   'title'=>$title,
  	   'description'=>$description
       );
     }	
     else
     {
  					// now change to 0
       $resultarray = array(
         'status'  => 0,
         'message' => 'Question Not Attemped',
         'url'=>$url,
         'is_attempted'=>$is_attempted,
         'type'=>$type,
  	   'title'=>$title,
  	   'description'=>$description
       );
     }
    }
 }
 else
 {
  $resultarray = array(
    'status'  => 1,
    'message' => 'Question Not Attemped',
    'url'=>$url,
    'is_attempted'=>$is_attempted,
       'type'=>$type,
	   'title'=>$title,
	   'description'=>$description

  );
}
}
else
{
 $resultarray = array(
  'status'  => 2,
  'message' => 'Question Not Attemped',
  'url'=>$url,
  'is_attempted'=>$is_attempted,
       'type'=>$type,
	   'title'=>$title,
	   'description'=>$description
);
}		

return $resultarray; 
	}
	
	public static function get_mytodayquestionstatus_returns()
	{
		return new external_single_structure(
            array(
				'status' => new external_value(PARAM_INT,'status'),
				'message' => new external_value(PARAM_RAW,'message'),
        'url'=>new external_value(PARAM_RAW,'url'),
        'is_attempted'=>new external_value(PARAM_RAW,'is_attempted'),
        'type'=>new external_value(PARAM_RAW,'type'),
		 'title'=>new external_value(PARAM_RAW,'course name'),
        'description'=>new external_value(PARAM_RAW,'course message')
			)
        );
	}
	
	//----------------------------- 08-05-2020-----------------------------------//
	// Code by Yogita P. Ghegadmal
	
	public static function get_previousdayQuestion_parameters() 
	{
		return new external_function_parameters(
			array()
		);
	}
	
	public static function get_previousdayQuestion()
	{
		global $USER,$DB,$CFG;
	    $aa = array();
		$resultarray=array();
        $dd = $dd1 = $dd2 = $dd3 = $dd4 = $dd5 = $dd6 = array();
        $op1 = $op2 = $op3 = $op4 = $op5 = $op6 = array();
			
        $currentDatecurrentDate = date('Y-m-d');
        $dt1 = strtotime($currentDatecurrentDate);
        $dt2 = date("l", $dt1);
        $dt3 = strtolower($dt2);
		if($dt3 == "monday") // if monday come then show question of sat
		{
			$res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE qdate >= CURDATE() - INTERVAL 2 DAY AND qdate < CURDATE()");
		}
		else
		{
			$res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE qdate >= CURDATE() - INTERVAL 1 DAY AND qdate < CURDATE()");
		}
		if(!empty($res_Question))
	    {
			$questionid       = $res_Question->id;
			$question_type    = $res_Question->questiontype;
			$question  		  = strip_tags($res_Question->question);
			$option_a_type    = $res_Question->option_a_type;
			$option_a         = $res_Question->option_a;
			$option_b_type    = $res_Question->option_b_type;
			$option_b         = $res_Question->option_b;
			$option_c_type    = $res_Question->option_c_type;
			$option_c         = $res_Question->option_c;
			$option_d_type    = $res_Question->option_d_type;
			$option_d         = $res_Question->option_d;
			$additional_text  = $res_Question->additional_text;
			$qdate            = date("d-m-Y",strtotime($res_Question->qdate));  //$res_Question->qdate; 
			$correctanswerOp  = $res_Question->correctanswer;
			$c_p = explode(',',$correctanswerOp);
			if($question_type == 1)
			{
				$q_type = 'Text';
				$question_text  = isset($question) && $question!=''?$question:'--';
				$question_image = '';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			}
			if($question_type == 2)
			{
				$q_type = 'Image';
				$question_text  = '';
				$question_image = $CFG->wwwroot.$question;
			}
			if($question_type == 3)
			{
				$q_type = 'Both';
				$question_text  = $additional_text;
				$question_image = $CFG->wwwroot.$question;
			}
			
			//------------------------------------------------------------//
			if($option_a_type == 1)
			{
				$option_A_type  = 'Text';
				$option_A_text  = isset($option_a) && $option_a!=''?$option_a:'--';
				$option_A_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_a_type == 2)
			{
				$option_A_type   = 'Image';
				$option_A_text   = '';
				$option_A_image  = $CFG->wwwroot.$option_a;
				$is_right_answer = '';
				
			}
			//----------------------------------------------------------------//
			if($option_b_type == 1)
			{
				$option_B_type  = 'Text';
				$option_B_text  = isset($option_b) && $option_b!=''?$option_b:'--';
				$option_B_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_b_type == 2)
			{
				$option_B_type   = 'Image';
				$option_B_text   = '';
				$option_B_image  = $CFG->wwwroot.$option_b;
				$is_right_answer = '';
			}
			
			//-------------------------------------------------------------//
			
			if($option_c_type == 1)
			{
				$option_C_type  = 'Text';
				$option_C_text  = isset($option_c) && $option_c!=''?$option_c:'--';
				$option_C_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_c_type == 2)
			{
				$option_C_type   = 'Image';
				$option_C_text   = '';
				$option_C_image  = $CFG->wwwroot.$option_c;
				$is_right_answer = '';
			}
			
			//-------------------------------------------------------------//
			
			if($option_d_type == 1)
			{
				$option_D_type   = 'Text';
				$option_D_text   = isset($option_d) && $option_d!=''?$option_d:'--';
				$option_D_image  = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
				
			}
			if($option_d_type == 2)
			{
				$option_D_type   = 'Image';
				$option_D_text   = '';
				$option_D_image  = $CFG->wwwroot.$option_d;
				$is_right_answer = '';
			}
			
			$option_E_type   = 'Text';
			$option_E_text   = 'All of these';
			$option_E_image  = '-'; 
			$is_right_answer = '';
			//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				
			$option_F_type   = 'Text';
			$option_F_text   = 'None of these';
			$option_F_image  = '-'; 
			$is_right_answer = '';
			//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			
			//---------------------------------------------------------------//
			
			$alldd  = array('questionid' => $questionid,
							'questiontype'   => $q_type,
							'question_text'  => $question_text,
							'question_image' => $question_image,
							'questiondate'   => $qdate);
			$aa[]   = $alldd;	
      $is_right_answer=(in_array("A", $c_p)?'Yes':'No');			
			$option1 = array('option_type'   => $option_A_type,
							 'option_text'   => $option_A_text,
							 'option_image'  => $option_A_image,
							 'is_right_anwser' => $is_right_answer 
							);
			$op1[]= $option1;
			$is_right_answer=(in_array("B", $c_p)?'Yes':'No');
			$option2 = array('option_type'   => $option_B_type,
							 'option_text'   => $option_B_text,
							 'option_image'  => $option_B_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op2[]= $option2;
			$is_right_answer=(in_array("C", $c_p)?'Yes':'No');
			$option3 = array('option_type'  => $option_C_type,
							 'option_text'   => $option_C_text,
							 'option_image'  => $option_C_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op3[]= $option3;
			$is_right_answer=(in_array("D", $c_p)?'Yes':'No');
			$option4 = array('option_type'   => $option_D_type,
							 'option_text'   => $option_D_text,
							 'option_image'  => $option_D_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op4[]= $option4;
			$is_right_answer=(in_array("E", $c_p)?'Yes':'No');
			$option5 = array('option_type'   => $option_E_type,
							 'option_text'   => $option_E_text,
							 'option_image'  => $option_F_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op5[]= $option5;
			$is_right_answer=(in_array("F", $c_p)?'Yes':'No');
			$option6 = array('option_type'   => $option_F_type,
							 'option_text'   => $option_F_text,
							 'option_image'  => $option_F_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op6[]= $option6;
			$op = array_merge($op1,$op2,$op3,$op4);
			$dd['Question'] = $aa;
			$dd['Options']  = $op;
			return($dd);
		}
		else
		{
			$resultarray = array(
									'status'  => 1,
									'message' => 'Question Missing'
						);	
		}
	}
	
	public static function get_previousdayQuestion_returns()
	{
		return new external_single_structure(
            array(
                    
			 'Question' => new external_multiple_structure(
					new external_single_structure(
					array(
						'questionid'      => new external_value(PARAM_INT,'questionid'),
						'questiontype'    => new external_value(PARAM_TEXT,'questiontype'),
						'question_text'   => new external_value(PARAM_TEXT,'question_text'),
						'question_image'  => new external_value(PARAM_TEXT,'question_image'),
						'questiondate'    => new external_value(PARAM_RAW,'questiondate'),
				   
					))),
			'Options' => new external_multiple_structure(
				    new external_single_structure(
					array(
							'option_type'   => new external_value(PARAM_TEXT,'option_type'),
							'option_text'   => new external_value(PARAM_TEXT,'option_text'),
							'option_image'  => new external_value(PARAM_TEXT,'option_image'),
							'is_right_anwser' => new external_value(PARAM_TEXT,'is_right_anwser')
						))
					)
                )
        );
	}
	
	//----------------------------- 28-09-2020-----------------------------------//
	// Code by Manish P Chavan
	
	public static function get_previousdayQuestionNew_parameters() 
	{
		return new external_function_parameters(
			array()
		);
	}
	
	public static function get_previousdayQuestionNew()
	{
		global $USER,$DB,$CFG;
		
	    $aa = array();
		$resultarray=array();
        $dd = $dd1 = $dd2 = $dd3 = $dd4 = $dd5 = $dd6 = array();
        $op1 = $op2 = $op3 = $op4 = $op5 = $op6 = array();
		 $currentDatecurrentDate = date('Y-m-d');	
       
		for($i=1;$i<=15;$i++)
		{
			$flag=0;
			if($i==1)
			{
				$dt1 = strtotime($currentDatecurrentDate);
		
				$dt2 = date("l", $dt1);
		
				$dt3 = strtolower($dt2);
				if($dt3 == "monday") // if monday come then show question of sat
				{
				$currentDatecurrentDate=date('Y-m-d',strtotime("-2 days"));
			
				}
				else if($dt3 == "sunday") // if sunday come then show question of sat
				{
				$currentDatecurrentDate=date('Y-m-d',strtotime("-1 days"));
			
				}
				else
				{
				$currentDatecurrentDate = date('Y-m-d');
				}				
			}
			else
			{
			$dt1 = strtotime($currentDatecurrentDate);
		
			$dt2 = date("l", $dt1);
		
			$dt3 = strtolower($dt2);
			if($dt3 == "monday") // if monday come then show question of sat
			{
				
			$flag=1;
			}
			else
			{
			
			$currentDatecurrentDate=date('Y-m-d',strtotime($currentDatecurrentDate."-1 days"));
			}
			
			}
			$res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE qdate = '".$currentDatecurrentDate."' ");
			
			if(!empty($res_Question))
			{
			$question_type    = $res_Question->questiontype;
			$qdate            = date("d-m-Y",strtotime($res_Question->qdate)); 
			$question  		  = strip_tags($res_Question->question);
			$option_a_type    = $res_Question->option_a_type;
			$option_a         = $res_Question->option_a;
			$option_b_type    = $res_Question->option_b_type;
			$option_b         = $res_Question->option_b;
			$option_c_type    = $res_Question->option_c_type;
			$option_c         = $res_Question->option_c;
			$option_d_type    = $res_Question->option_d_type;
			$option_d         = $res_Question->option_d;
			$additional_text  = $res_Question->additional_text;			
			$correctanswerOp  = $res_Question->correctanswer;
			$c_p = explode(',',$correctanswerOp);
			if($question_type == 1)
			{
				$q_type = 'Text';
				$question_text  = isset($question) && $question!=''?$question:'--';
				$question_image = '';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			}
			if($question_type == 2)
			{
				$q_type = 'Image';
				$question_text  = '';
				$question_image = $CFG->wwwroot.$question;
			}
			if($question_type == 3)
			{
				$q_type = 'Both';
				$question_text  = $additional_text;
				$question_image = $CFG->wwwroot.$question;
			}
			if($option_a_type == 1)
			{
				$option_A_type  = 'Text';
				$option_A_text  = isset($option_a) && $option_a!=''?$option_a:'--';
				$option_A_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$option_A_right=(in_array("A", $c_p)?'Yes':'No');
			}
			if($option_a_type == 2)
			{
				$option_A_type   = 'Image';
				$option_A_text   = '';
				$option_A_image  = $CFG->wwwroot.$option_a;
				$option_A_right=(in_array("A", $c_p)?'Yes':'No');
				
			}
			if($option_b_type == 1)
			{
				$option_B_type  = 'Text';
				$option_B_text  = isset($option_b) && $option_b!=''?$option_b:'--';
				$option_B_image = '-';
				$option_B_right=(in_array("B", $c_p)?'Yes':'No');
			}
			if($option_b_type == 2)
			{
				$option_B_type   = 'Image';
				$option_B_text   = '';
				$option_B_image  = $CFG->wwwroot.$option_b;
				$option_B_right=(in_array("B", $c_p)?'Yes':'No');
				
			}
			if($option_c_type == 1)
			{
				$option_C_type  = 'Text';
				$option_C_text  = isset($option_c) && $option_c!=''?$option_c:'--';
				$option_C_image = '-';
				$option_C_right=(in_array("C", $c_p)?'Yes':'No');
			}
			if($option_c_type == 2)
			{
				$option_C_type   = 'Image';
				$option_C_text   = '';
				$option_C_image  = $CFG->wwwroot.$option_c;
				$option_C_right=(in_array("C", $c_p)?'Yes':'No');
				
			}
			if($option_d_type == 1)
			{
				$option_D_type  = 'Text';
				$option_D_text  = isset($option_d) && $option_d!=''?$option_d:'--';
				$option_D_image = '-';
				$option_D_right=(in_array("D", $c_p)?'Yes':'No');
			}
			if($option_d_type == 2)
			{
				$option_D_type   = 'Image';
				$option_D_text   = '';
				$option_D_image  = $CFG->wwwroot.$option_d;
				$option_D_right=(in_array("D", $c_p)?'Yes':'No');
				
			}
			 $temp['questions'][]=array(
        
				'questionid'=> $res_Question->id,
				'questiontype'=> $q_type,
				'question_text'=>$question_text,
				'question_image'=>$question_image,
				'questiondate'=>$qdate,
				'option_A_type'=>$option_A_type,
				'option_A_text'=>$option_A_text,
				'option_A_image'=>$option_A_image,
				'option_A_right'=>$option_A_right,
				'option_B_type'=>$option_B_type,
				'option_B_text'=>$option_B_text,
				'option_B_image'=>$option_B_image,
				'option_B_right'=>$option_B_right,
				'option_C_type'=>$option_C_type,
				'option_C_text'=>$option_C_text,
				'option_C_image'=>$option_C_image,
				'option_C_right'=>$option_C_right,
				'option_D_type'=>$option_D_type,
				'option_D_text'=>$option_D_text,
				'option_D_image'=>$option_D_image,
				'option_D_right'=>$option_D_right

        

				);
			}
			if($flag==1)
			{
			$currentDatecurrentDate=date('Y-m-d',strtotime($currentDatecurrentDate."-2 days"));
				
			}
			
		}
		
		$questions=$temp;
		return ($questions);
		/*
        $dt1 = strtotime($currentDatecurrentDate);
		
        $dt2 = date("l", $dt1);
		
        $dt3 = strtolower($dt2);
		if($dt3 == "monday") // if monday come then show question of sat
		{
			$res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE qdate >= CURDATE() - INTERVAL 2 DAY AND qdate < CURDATE()");
		}
		else
		{
			$res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE qdate >= CURDATE() - INTERVAL 1 DAY AND qdate < CURDATE()");
		}
		if(!empty($res_Question))
	    {
			$questionid       = $res_Question->id;
			$question_type    = $res_Question->questiontype;
			$question  		  = strip_tags($res_Question->question);
			$option_a_type    = $res_Question->option_a_type;
			$option_a         = $res_Question->option_a;
			$option_b_type    = $res_Question->option_b_type;
			$option_b         = $res_Question->option_b;
			$option_c_type    = $res_Question->option_c_type;
			$option_c         = $res_Question->option_c;
			$option_d_type    = $res_Question->option_d_type;
			$option_d         = $res_Question->option_d;
			$additional_text  = $res_Question->additional_text;
			$qdate            = date("d-m-Y",strtotime($res_Question->qdate));  //$res_Question->qdate; 
			$correctanswerOp  = $res_Question->correctanswer;
			$c_p = explode(',',$correctanswerOp);
			if($question_type == 1)
			{
				$q_type = 'Text';
				$question_text  = isset($question) && $question!=''?$question:'--';
				$question_image = '';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			}
			if($question_type == 2)
			{
				$q_type = 'Image';
				$question_text  = '';
				$question_image = $CFG->wwwroot.$question;
			}
			if($question_type == 3)
			{
				$q_type = 'Both';
				$question_text  = $additional_text;
				$question_image = $CFG->wwwroot.$question;
			}
			
			//------------------------------------------------------------//
			if($option_a_type == 1)
			{
				$option_A_type  = 'Text';
				$option_A_text  = isset($option_a) && $option_a!=''?$option_a:'--';
				$option_A_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_a_type == 2)
			{
				$option_A_type   = 'Image';
				$option_A_text   = '';
				$option_A_image  = $CFG->wwwroot.$option_a;
				$is_right_answer = '';
				
			}
			//----------------------------------------------------------------//
			if($option_b_type == 1)
			{
				$option_B_type  = 'Text';
				$option_B_text  = isset($option_b) && $option_b!=''?$option_b:'--';
				$option_B_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_b_type == 2)
			{
				$option_B_type   = 'Image';
				$option_B_text   = '';
				$option_B_image  = $CFG->wwwroot.$option_b;
				$is_right_answer = '';
			}
			
			//-------------------------------------------------------------//
			
			if($option_c_type == 1)
			{
				$option_C_type  = 'Text';
				$option_C_text  = isset($option_c) && $option_c!=''?$option_c:'--';
				$option_C_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_c_type == 2)
			{
				$option_C_type   = 'Image';
				$option_C_text   = '';
				$option_C_image  = $CFG->wwwroot.$option_c;
				$is_right_answer = '';
			}
			
			//-------------------------------------------------------------//
			
			if($option_d_type == 1)
			{
				$option_D_type   = 'Text';
				$option_D_text   = isset($option_d) && $option_d!=''?$option_d:'--';
				$option_D_image  = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
				
			}
			if($option_d_type == 2)
			{
				$option_D_type   = 'Image';
				$option_D_text   = '';
				$option_D_image  = $CFG->wwwroot.$option_d;
				$is_right_answer = '';
			}
			
			$option_E_type   = 'Text';
			$option_E_text   = 'All of these';
			$option_E_image  = '-'; 
			$is_right_answer = '';
			//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				
			$option_F_type   = 'Text';
			$option_F_text   = 'None of these';
			$option_F_image  = '-'; 
			$is_right_answer = '';
			//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			
			//---------------------------------------------------------------//
			
			$alldd  = array('questionid' => $questionid,
							'questiontype'   => $q_type,
							'question_text'  => $question_text,
							'question_image' => $question_image,
							'questiondate'   => $qdate);
			$aa[]   = $alldd;	
      $is_right_answer=(in_array("A", $c_p)?'Yes':'No');			
			$option1 = array('option_type'   => $option_A_type,
							 'option_text'   => $option_A_text,
							 'option_image'  => $option_A_image,
							 'is_right_anwser' => $is_right_answer 
							);
			$op1[]= $option1;
			$is_right_answer=(in_array("B", $c_p)?'Yes':'No');
			$option2 = array('option_type'   => $option_B_type,
							 'option_text'   => $option_B_text,
							 'option_image'  => $option_B_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op2[]= $option2;
			$is_right_answer=(in_array("C", $c_p)?'Yes':'No');
			$option3 = array('option_type'  => $option_C_type,
							 'option_text'   => $option_C_text,
							 'option_image'  => $option_C_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op3[]= $option3;
			$is_right_answer=(in_array("D", $c_p)?'Yes':'No');
			$option4 = array('option_type'   => $option_D_type,
							 'option_text'   => $option_D_text,
							 'option_image'  => $option_D_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op4[]= $option4;
			$is_right_answer=(in_array("E", $c_p)?'Yes':'No');
			$option5 = array('option_type'   => $option_E_type,
							 'option_text'   => $option_E_text,
							 'option_image'  => $option_F_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op5[]= $option5;
			$is_right_answer=(in_array("F", $c_p)?'Yes':'No');
			$option6 = array('option_type'   => $option_F_type,
							 'option_text'   => $option_F_text,
							 'option_image'  => $option_F_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op6[]= $option6;
			$op = array_merge($op1,$op2,$op3,$op4);
			$dd['Question'] = $aa;
			$dd['Options']  = $op;
			return($dd);
		}
		else
		{
			$resultarray = array(
									'status'  => 1,
									'message' => 'Question Missing'
						);	
		}
		*/
		
	}
	
	public static function get_previousdayQuestionNew_returns()
	{
		return new external_single_structure(
            array(
                    
			 'questions' => new external_multiple_structure(
					new external_single_structure(
					array(
						'questionid'      => new external_value(PARAM_INT,'questionid'),
						'questiontype'    => new external_value(PARAM_TEXT,'questiontype'),
						'question_text'   => new external_value(PARAM_TEXT,'question_text'),
						'question_image'  => new external_value(PARAM_TEXT,'question_image'),
						'questiondate'    => new external_value(PARAM_RAW,'questiondate'),
						'option_A_type'    => new external_value(PARAM_RAW,'option_A_type'),
						'option_A_text'    => new external_value(PARAM_RAW,'option_A_text'),
						'option_A_image'    => new external_value(PARAM_RAW,'option_A_image'),
						'option_A_right'    => new external_value(PARAM_RAW,'option_A_right'),
						'option_B_type'    => new external_value(PARAM_RAW,'option_B_type'),
						'option_B_text'    => new external_value(PARAM_RAW,'option_B_text'),
						'option_B_image'    => new external_value(PARAM_RAW,'option_B_image'),
						'option_B_right'    => new external_value(PARAM_RAW,'option_B_right'),
						'option_C_type'    => new external_value(PARAM_RAW,'option_C_type'),
						'option_C_text'    => new external_value(PARAM_RAW,'option_C_text'),
						'option_C_image'    => new external_value(PARAM_RAW,'option_C_image'),
						'option_C_right'    => new external_value(PARAM_RAW,'option_C_right'),
						'option_D_type'    => new external_value(PARAM_RAW,'option_D_type'),
						'option_D_text'    => new external_value(PARAM_RAW,'option_D_text'),
						'option_D_image'    => new external_value(PARAM_RAW,'option_D_image'),
						'option_D_right'    => new external_value(PARAM_RAW,'option_D_right'),
				   
					)))
                )
        );
	}
	
	//----------------- code by yogita created date - 09-05-2020---//
	
	public static function get_attemptedQuestionAnswerStatus_parameters() 
	{
		return new external_function_parameters(
			array()
		);
	}
	
	public static function get_attemptedQuestionAnswerStatus()
	{
		global $DB,$USER;
		$resultarray = array();
		$today  = date("Y-m-d"); // todays date
		$thismonthstart = date('Y-m-01'); // start date of current month
		$thismonth_sql = "SELECT count(*) as total_question FROM mdl_question_of_day WHERE qdate >= '".$thismonthstart."' AND qdate <= '".$today."'"; 
		$sqlData       = $DB->get_record_sql($thismonth_sql);
		$thismonth_total_question = $sqlData->total_question;
			
		$month = date("Y-m");// here we get current month
		$thismonth_sql_ans = "SELECT answer FROM mdl_question_of_day_correct_answer WHERE mspin = '".$USER->username."' AND month = '".$month."'"; 
		$sqlData_1m = $DB->get_record_sql($thismonth_sql_ans);
		$thismonth_correct_ans = $sqlData_1m->answer;
		$score_this_month = $thismonth_total_question."-".$thismonth_correct_ans;
		// total question and total question answer given
		$rank_this_month  = number_format((($thismonth_correct_ans/$thismonth_total_question)*100),2);
		if(count($thismonth_total_question) > 0)
		{		
			$resultarray  = array('questioncount' => $thismonth_total_question,
								  'answercount'   => $thismonth_correct_ans,
								  'current_month_question_answer_status' => $thismonth_correct_ans."/".$thismonth_total_question
								);
		}						
	
		return $resultarray;
	}
	
	
	public static function get_attemptedQuestionAnswerStatus_returns()
	{
		return new external_single_structure(
            array(
				'questioncount' => new external_value(PARAM_INT,'questioncount'),
				'answercount'   => new external_value(PARAM_INT,'answercount'),
				'current_month_question_answer_status' => new external_value(PARAM_TEXT,'current_month_question_answer_status'),
			)
        );
	}
	
		
	//-------------------------------------------------------------------------------//
	
	public static function get_QODRanKStatus_parameters() 
	{
		return new external_function_parameters(
			array()
		);
	}
	
	public static function get_QODRanKStatus()
	{
	    global $USER,$DB,$CFG;
		$dd = $resultarray = $current = $last3 = $last6 = $last12 = $overall = array();
		$res_QuestionAnswer = $DB->get_record_sql("SELECT * FROM mdl_question_of_day_rank_report WHERE mspin = '".$USER->username."'");
		if(!empty($res_QuestionAnswer))
	    {	
		
			$id   			  = $res_QuestionAnswer->id;
			$score_this_month = $res_QuestionAnswer->score_this_month;
			$score_3_month    = $res_QuestionAnswer->score_3_month;
			$score_6_month    = $res_QuestionAnswer->score_6_month;
			$score_1_year     = $res_QuestionAnswer->score_1_year;
			$score_overall    = $res_QuestionAnswer->score_overall;
			
        	$alldd   = array('published_quiz'   => $score_this_month,
							 'attempted'  		=> $score_3_month,
							 'my_score'         => $score_6_month,
							 'quiz_rank'        => $score_1_year
							 );
			$current[]   = $alldd;
			
			$option1 = array('published_quiz'   => $score_this_month,
							 'attempted'  		=> $score_3_month,
							 'my_score'         => $score_6_month,
							 'quiz_rank'        => $score_1_year
							);
			$last3[]= $option1;
			
			$option2 = array('published_quiz'   => $score_this_month,
							 'attempted'  		=> $score_3_month,
							 'my_score'         => $score_6_month,
							 'quiz_rank'        => $score_1_year
							);
			$last6[]= $option2;
			
			$option3 = array('published_quiz'   => $score_this_month,
							 'attempted'  		=> $score_3_month,
							 'my_score'         => $score_6_month,
							 'quiz_rank'        => $score_1_year
							);
			$last12[]= $option3;
			
			$option4 = array('published_quiz'   => $score_this_month,
							 'attempted'  		=> $score_3_month,
							 'my_score'         => $score_6_month,
							 'quiz_rank'        => $score_1_year
							);
			$overall[]= $option4;
		
			$dd['Current_Month_Status'] = $current;
			$dd['Last_3_Month_Status']  = $last3;
			$dd['Last_6_Month_Status']  = $last6;
			$dd['Last_12_Month_Status'] = $last12;
			$dd['Overall_Month_Status'] = $overall;
			return($dd);
		}
		else
		{
			$resultarray = array('status'  => 0,'message' => 'You have not attempted questions till now.');	
			return($resultarray);
		}
			
	}
	
	
	public static function get_QODRanKStatus_returns()
	{
		return new external_single_structure
		(
            array(
                    
					 'Current_Month_Status' => new external_multiple_structure(
							new external_single_structure(
							array(
								'published_quiz'   => new external_value(PARAM_TEXT,'published_quiz'),
								'attempted'        => new external_value(PARAM_TEXT,'attempted'),
								'my_score'         => new external_value(PARAM_TEXT,'my_score'),
								'quiz_rank'        => new external_value(PARAM_TEXT,'quiz_rank'),
						   
							))),
					'Last_3_Month_Status' => new external_multiple_structure(
							new external_single_structure(
							array(
								'published_quiz'   => new external_value(PARAM_TEXT,'published_quiz'),
								'attempted'        => new external_value(PARAM_TEXT,'attempted'),
								'my_score'         => new external_value(PARAM_TEXT,'my_score'),
								'quiz_rank'        => new external_value(PARAM_TEXT,'quiz_rank'),
								))),
					'Last_6_Month_Status' => new external_multiple_structure(
							new external_single_structure(
							array(
								'published_quiz'   => new external_value(PARAM_TEXT,'published_quiz'),
								'attempted'        => new external_value(PARAM_TEXT,'attempted'),
								'my_score'         => new external_value(PARAM_TEXT,'my_score'),
								'quiz_rank'        => new external_value(PARAM_TEXT,'quiz_rank'),
								))),	
					'Last_12_Month_Status' => new external_multiple_structure(
							new external_single_structure(
							array(
								'published_quiz'   => new external_value(PARAM_TEXT,'published_quiz'),
								'attempted'        => new external_value(PARAM_TEXT,'attempted'),
								'my_score'         => new external_value(PARAM_TEXT,'my_score'),
								'quiz_rank'        => new external_value(PARAM_TEXT,'quiz_rank'),
								))),	
					'Overall_Month_Status' => new external_multiple_structure(
							new external_single_structure(
							array(
								'published_quiz'   => new external_value(PARAM_TEXT,'published_quiz'),
								'attempted'        => new external_value(PARAM_TEXT,'attempted'),
								'my_score'         => new external_value(PARAM_TEXT,'my_score'),
								'quiz_rank'        => new external_value(PARAM_TEXT,'quiz_rank'),
								)))		
				)
        );
	}
	//-------------------------------------------------------------------------//
	
	
	//------------------------------ New webservice ----------------------------//
	
	public static function get_mylistcourses_parameters()
	{
		return new external_function_parameters(
                array()
        );
    }
	
	public static function get_mylistcourses() 
	{
		global $USER, $DB ,$CFG;
		$onlinecourses = $DB->get_records_sql("select
				c.id as courseid,
				c.fullname as coursename,
				c.summary as summary,
				c.shortname as shortname,
				c.idnumber as idnumber,
				c.visible as visible,
				c.summaryformat as summaryformat,
				c.format,
				c.showgrades,
				c.lang,
				c.enablecompletion,
				c.category,
				b.path,
				c.startdate,
				c.enddate,
				(
				  select count(sa.id) as totalscorms
						from mdl_scorm_scoes as sa
						inner join mdl_scorm as sb ON(sb.id=sa.scorm)
						where sb.course=c.id and sa.scormtype='sco'
				) as totalscorms,
				(
				  select count(sa.id) as totaltracked
						FROM mdl_scorm_scoes_track as sa
						INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
						INNER JOIN mdl_course as sc on (sc.id=sb.course)
						WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='completed' || value='passed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
				) as totalcompleted,
				(
				  select count(sa.id) as totaltracked
						FROM mdl_scorm_scoes_track as sa
						INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
						INNER JOIN mdl_course as sc on (sc.id=sb.course)
						WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='incomplete' || value='failed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
				) as totalincomplete,
			  'duedate',
			  (SELECT timestart FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol  where courseid=c.id and enrol='manual') AND userid=a.userid) as courseenrollmentdate,
			  (SELECT timeend FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol where courseid=c.id and enrol='manual') AND userid=a.userid) as enrolenddate

			  FROM mdl_role_assignments  as a
			  INNER JOIN mdl_context     as b on(b.id=a.contextid)
			  INNER JOIN mdl_course      as c on(c.id=b.instanceid)
			  left outer join mdl_user   as d on(d.id=a.userid)
			  INNER JOIN mdl_course_categories as e on(e.id=c.category)
			  where b.contextlevel = 50 and userid = '".$USER->id."' and c.visible=1 and c.category>0 and e.name<>'assessment container' group by c.id ORDER BY c.id DESC");
			foreach ($onlinecourses as $onlinecourse) 
		    {
				    $id        = $onlinecourse->courseid;
				    $shortname = $onlinecourse->shortname;
					$fullname  = $onlinecourse->coursename;
					$idnumber  = $onlinecourse->idnumber;
					$visible   = $onlinecourse->visible;
					$summary   = $onlinecourse->summary;
					$summaryformat = $onlinecourse->summaryformat;
					$format     = $onlinecourse->format;
					$showgrades = $onlinecourse->showgrades;
					$lang       = $onlinecourse->lang;
					$enablecompletion = $onlinecourse->enablecompletion;
					$category  = $onlinecourse->category;
					
					$startdate = $onlinecourse->startdate;
					$enddate   = $onlinecourse->enddate;
					$enroldate = $onlinecourse->courseenrollmentdate;
					$enrolenddate = $onlinecourse->enrolenddate;
					$url       = $CFG->wwwroot.'/course/view.php?id='.$id;
					$progress = '';
					if($id == 12)
					{	
						$sqlass = $DB->get_record_sql("SELECT quiz.id as quizid,
						quiz.course,
						grade_items.id,
						grade_items.grademax,
						grade_items.grademin,
						grade_items.gradepass,
						grade_items.itemmodule
						FROM mdl_quiz AS quiz 
						INNER JOIN mdl_grade_items AS grade_items 
						ON grade_items.iteminstance = quiz.id
						WHERE quiz.course= '12' AND 
						quiz.id = '24' AND 
						grade_items.itemmodule = 'quiz'");
						$quizid     = $sqlass->quizid;
						$grademax   = $sqlass->grademax;
						$grademin   = $sqlass->grademin;
						$gradepass  = $sqlass->gradepass;
						
						$highestattempt = $DB->get_record_sql("SELECT max(attempt) as hattempt FROM mdl_quiz_attempts WHERE quiz = '".$quizid."' AND userid = '".$USER->id."'");
						$attempt = $highestattempt->hattempt;
						if(!empty($attempt))
						{	
							$sqlGrade = $DB->get_record_sql("SELECT sumgrades,timefinish FROM mdl_quiz_attempts WHERE quiz = '".$quizid."' AND userid = '".$USER->id."' AND state = 'finished' AND attempt = '".$attempt."'");
							$resGrade  = $sqlGrade->sumgrades;
							if($resGrade >= $gradepass)
							{
								$state1 = 'pass';
							}	
							else
							{
								$state1 = 'fail';
							}
							if($state1 == 'pass')
							{
								$progress = 'Completed';
								
							}		
							if($state1 == 'fail') 
							{
								$progress = 'Incomplete';
						
							}
						}
						else
						{
							$sql="SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = '10' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') ";
							$attemptdetails = $DB->get_record_sql($sql);
							if(empty($attemptdetails->value) || $attemptdetails->value == "")
							{
								$progress = 'Not Started';
								
							}
							else
							{
								$progress = 'Incomplete';
						
							}
						}	
					}
					else
					{
						$sqlScormid = $DB->get_record_sql("SELECT * FROM mdl_scorm WHERE course = '".$id."'");
						$scormid = $sqlScormid->id;
						$sqlScormTrack = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = ".$scormid." AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') ";
						$resultScormTrack = $DB->get_record_sql($sqlScormTrack);
						if(empty($resultScormTrack->value) || $resultScormTrack->value == "")
						{
							$progress = "Not Started";
						}
						else
						{
							$status =  $resultScormTrack->value;
							if($status == 'completed' || $status == 'passed')
							{
								$progress = "Completed";
							}
                            if($status == 'incomplete' || $status == 'failed')
							{
								$progress = "Incomplete";
							}		
						}
					}	
					
					
					$result[] = array(
						'id' => $id,
						'shortname' => $shortname,
						'fullname'  => $fullname,
						'idnumber'  => $idnumber,
						'visible'   => $visible,
						'summary'   => $summary,
						'summaryformat' => $summaryformat,
						'format' => $format,
						'showgrades' => $showgrades,
						'lang' => $lang,
						'enablecompletion' => $enablecompletion,
						'category' => $category,
						'progress' => $progress,
						'startdate' => $startdate,
						'enddate' => $enddate,
						'enroldate' => $enroldate,
						'enrolenddate' => $enrolenddate,
						'url' => $url
					);
				   
		    }
			if(empty($result))
			{
				$result[] = array();
			}
			return $result;	
			  
	}

    public static function get_mylistcourses_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
					          'id'   => new external_value(PARAM_INT, 'id of course', VALUE_OPTIONAL),
                    'shortname' => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
                    'fullname'  => new external_value(PARAM_RAW, 'long name of course', VALUE_OPTIONAL),
                    'idnumber'  => new external_value(PARAM_RAW, 'id number of course', VALUE_OPTIONAL),
                    'visible'   => new external_value(PARAM_INT, '1 means visible, 0 means hidden course', VALUE_OPTIONAL),
                    'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',VALUE_OPTIONAL),
                    'category'     => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress'     => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate'    => new external_value(PARAM_INT, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate'      => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate'    => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_INT, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'url' => new external_value(PARAM_RAW,'course url', VALUE_OPTIONAL),
                )
            )
        );
    }
    	
	
	//-----------------------------------------------------------//

      
  //--------------- Expression Webservices done by yogita ------------------//
  
  public function expressioncategory_parameters()
  {
    return new external_function_parameters(
      array( )
    );
  }
    
  public function expressioncategory()
  {
    global $DB,$USER;
    $catlists = $DB->get_records_sql("SELECT * FROM mdl_ums_category WHERE status = 'active' ORDER BY id ASC");
    $mainfolder = array();
    foreach ($catlists as $key => $cats) 
    { 
      $alldd['Category'][] = array('categoryid'=>$cats->id,'categoryname'=>$cats->category_name);
    }
    $aa = $alldd;
    return($aa);
  }
    
  public function expressioncategory_returns()
  {
    return new external_single_structure(
      array(
        
         'Category' => new external_multiple_structure(
              new external_single_structure(
                      array(
            'categoryid'=>new external_value(PARAM_INT,'categoryid'),

            'categoryname'=>new external_value(PARAM_RAW,'categoryname'),

             
        ))),
          

      )
    );
  }
  
  public function expressionsubcategory_parameters()
  {
    return new external_function_parameters(
      array(
        'id' => new external_value(PARAM_INT,'categoryid')
      )

    );  
  }
    
  public function expressionsubcategory($id)
  {
    global $DB;
    $subcats = $DB->get_records_sql("SELECT * FROM mdl_ums_sub_category WHERE category_id = '".$id."' AND status = 'active' ORDER BY id ASC");
    $mainfolder = array();
    $subcatid   = '-';
      $subcatname = '-';
    if(!empty($subcats))
    {
      foreach ($subcats as $key => $subcat)
      { 
        $alldd['Category'][] = array('subcatid'=>$subcat->id,
                      'subcatname'=>$subcat->sub_category_name
                      );
      }
    }
    else
    {
      // here we are checking a empty parameter
      
      $alldd['Category'][] = array('subcatid'=>0,'subcatname'=>'-');
    }
    $aa = $alldd;
    return($aa);
  }
    
  public function expressionsubcategory_returns()
  {
    return new external_single_structure(
      array(
        
         'Category' => new external_multiple_structure(
              new external_single_structure(
                      array(
            'subcatid'=>new external_value(PARAM_INT,'subcatid'),

            'subcatname'=>new external_value(PARAM_RAW,'subcatname'),

             
        ))),
          

      )
    );
  }

  public function expressionfeedback_parameters()
  {
    return new external_function_parameters(
      array('catid'    => new external_value(PARAM_INT, 'catid'),
          'subcatid' => new external_value(PARAM_INT, 'subcatid'),
          'feedback' => new external_value(PARAM_RAW, 'feedback')
        )
    );
  }
  
  public function expressionfeedback($catid,$subcatid,$feedback)
  {
    global $DB,$USER;   

    // $feedback = htmlspecialchars($feedback);
    // $feedback = addslashes($feedback);
    // $feedback = addslashes(str_replace("'","",$feedback));
    // $feedback = str_replace( array( '\'', '"',',' , ';', '<', '>' ), ' ', $feedback);    

    $insert = $DB->execute("INSERT INTO mdl_ums_feedback SET category_id = '".$catid."',
    sub_category_id = '".$subcatid."',user_id = '".$USER->id."',feedback = '".$feedback."',
    status = 'active',created_at = '".date("Y-m-d H:i:s")."'");
    if($insert)
    {
      $result = array('status'=>'Feedback Sent Successfully');
    }
    else
    {
      $result = array('status'=>'failed');
    }
    return($result);
  }
  
  public function expressionfeedback_returns()
  {
    return new external_single_structure(
      array('status'=> new external_value(PARAM_RAW, 'Success')
       ));
  }


  /*
   *  create log for last access knc file
   *  Developer : Shoaib Qureshi
   *  Date : 20 Aug 2020
   * 
   */
  
  public static function knc_user_tracking_parameters()
     {

        return new external_function_parameters(

                array('fileid' => new external_value(PARAM_INT, 'file id to create log entry', VALUE_DEFAULT))
                );

    }

   
    public static function knc_user_tracking($fileid) {

        global $USER, $DB;

      if (!isset($fileid) || empty($fileid)) {
           $response = ['response' => 'missing file id parameter'];
      } else {

        $sqlRecord = $DB->get_record_sql("select * from mdl_ums_knc_files where id = ".$fileid." ");
         if(!empty($sqlRecord)) 
        { 
        $logRecord = $DB->get_record_sql("select * from mdl_ums_knc_tracking where file_id = ".$fileid." AND user_id=".$USER->id." ");
		 if(empty($logRecord)) 
        { 
        // build payload
        $data = [
          'file_id' => $fileid,
          'user_id' => $USER->id,
          'datetime' => date("Y-m-d H:i:s")
        ];


       $id = $DB->insert_record("ums_knc_tracking",  $data);

        if (!empty($id)) {
          $response = ['response' => 'record inserted successfully'];
        } else {
          $response = ['response' => 'cannot insert record'];
        }
		}
		else
		{
			$DB->execute("update mdl_ums_knc_tracking set datetime='".date("Y-m-d H:i:s")."' where file_id = ".$fileid." AND user_id=".$USER->id."");
           $response = ['response' => 'record updated successfuly'];
		}
      }
      else
       {
		 
           $response = ['response' => 'file id missing'];
       } 

      }

        
       return $response;

    }

      

      public static function knc_user_tracking_returns()
     {

     return new external_single_structure(
                array(
            
            'response' => new external_value(PARAM_RAW, 'true if record created'),
          )
        );
      }


  
  //---------Expression Web service End---------------------//

      //------BESTPRACTICE POST : Developer Name : Manish Chavan--24/06/2020---//  
  
  public function bestpracticepost_parameters()
  {
    return new external_function_parameters(
      array(  
          'catid'    => new external_value(PARAM_INT, 'catid'),
            'subcatid' => new external_value(PARAM_INT, 'subcatid',VALUE_DEFAULT,NULL),
            'desc' => new external_value(PARAM_RAW, 'desc'),
            'res' => new external_value(PARAM_RAW, 'res'),
         
            'file_name' => new external_value(PARAM_RAW, 'file_name',VALUE_DEFAULT,NULL),
            'file_type' => new external_value(PARAM_RAW, 'file_type',VALUE_DEFAULT,NULL),
            'file_blob' => new external_value(PARAM_RAW, 'file_blob',VALUE_DEFAULT,NULL)
            
        )
    );
  }
  
  
  public function bestpracticepost($catid,$subcatid,$desc,$res,$file_name,$file_type,$file_blob)
  {
    global $DB,$USER,$CFG;

    $datafilter='';
    
    if($subcatid!='')
    {
      $datafilter.=" ,subcategory_id = '".$subcatid."' ";

    }
    
    if($file_name!='' and $file_type!='' and $file_blob!='')
    {
      
      $fname=$file_name.time().'.'.$file_type;

      $filepath=$CFG->folder.'/upload/bestpractice/'.$fname;

      $thumbnail=$CFG->folder.'/upload/bestpractice/thumbnails/'.$fname;
	  
	  $decodedstring=base64_decode(str_replace(' ', '+', trim($file_blob)));
    
      if(file_put_contents($filepath,$decodedstring))
      {

        switch ($file_type) 
        {
          case 'jpg':
                case 'jpeg':
          case 'png':
          case 'gif':
          $thumb_width=500;
          $thumb_height=500;
         
       
       
            switch($file_type)
            {
                case 'jpg':
                    $source = imagecreatefromjpeg($filepath);
                    break;
                case 'jpeg':
                    $source = imagecreatefromjpeg($filepath);
                    break;

                case 'png':
                    $source = imagecreatefrompng($filepath);
                    break;
                case 'gif':
                    $source = imagecreatefromgif($filepath);
                    break;
                default:
                    $source = imagecreatefromjpeg($filepath);
            }

            list($width,$height) = getimagesize($filepath);

            $thumb_create = imagecreatetruecolor($thumb_width,$thumb_height);

            imagecopyresized($thumb_create,$source,0,0,0,0,$thumb_width,$thumb_height,$width,$height);
            switch($file_type)
            {
                case 'jpg':
                case 'jpeg':
                    imagejpeg($thumb_create,$thumbnail,100);
                    break;
                case 'png':
                    imagepng($thumb_create,$thumbnail,100);
                    break;

                case 'gif':
                    imagegif($thumb_create,$thumbnail,100);
                    break;
                default:
                    imagejpeg($thumb_create,$thumbnail,100);
            }
            
            break;
          case 'mp4':
           $ffmpeg = "/usr/bin/ffmpeg";  
           $second = 0;  
           $name=$file_name.time();
           $fname=$name.'.'.$file_type;
           $tname=$name.'.jpg';
           $filepath=$CFG->folder.'/upload/bestpractice/'.$fname;

              $thumbnail=$CFG->folder.'/upload/bestpractice/thumbnails/'.$tname;
           $cmd = $ffmpeg." -i \"".$filepath."\" -s 500x500 -an -ss ".$second.".001 -y -f mjpeg \"".$thumbnail."\" 2>&1";
           $output = shell_exec($cmd);
          //echo "<pre>".$output."</pre>";


          break;
          case 'pdf':
          $name=$file_name.time();
           $fname=$name.'.'.$file_type;
           $tname=$name.'.jpg';
          $filepath=$CFG->folder.'/upload/bestpractice/'.$fname;

              $thumbnail=$CFG->folder.'/upload/bestpractice/thumbnails/'.$tname;
          /*
          $im = new imagick($filepath);
          $im->setImageFormat('jpg');
          $im->setResolution( 500, 500 );
          header('Content-Type: image/jpeg');
          echo $im;
          */

          break;
            
          
          default:
            
            break;
        }
      $datafilter.=" ,file_type = '".$file_type."' ";
      $datafilter.=" ,file_path = '".$filepath."' ";
      $datafilter.=" ,file_name = '".$file_name."' ";
      $datafilter.=" ,thumb_path = '".$thumbnail."' ";
	  

        $insert = $DB->execute("INSERT INTO mdl_ums_best_practice_post SET category_id = '".$catid."',user_id = '".$USER->id."',description = '".$desc."',result = '".$res."',created_date = '".time()."' ".$datafilter." ");
        if($insert)
        {
      
          $result = array('status'=>'success');
        }
        else
        {
          $result = array('status'=>'failed');
        }

      }
      else
      {
        
        $result = array('status'=>'ufailed');

      }
      


    }
    else
    {
      
      $insert = $DB->execute("INSERT INTO mdl_ums_best_practice_post SET category_id = '".$catid."',user_id = '".$USER->id."',description = '".$desc."',result = '".$res."',created_date = '".time()."'  ");
      if($insert)
      {
      
        $result = array('status'=>'Success');
      }
      else
      {
        $result = array('status'=>'failed');
      }
    }
    return($result);
  }
  
  public function bestpracticepost_returns()
  {
    return new external_single_structure(
      array('status'=> new external_value(PARAM_RAW, 'Success')
       ));
  }

  
  public function bestpracticewall_parameters()
  {
    return new external_function_parameters(
      array(  
          
            'month'    => new external_value(PARAM_RAW, 'month'),
            'year' => new external_value(PARAM_INT, 'year')
            
        )
    );
  }
  
  
  public function bestpracticewall($month,$year)
  {
    global $DB,$USER,$CFG;
    
    
    
    $sql="SELECT up.id as post_id,
    u.id as emp_id,
    up.is_approved_fsdm,
    up.is_approved_ho,
    m.code,
    m.user_type_id,
    m.profile_photo_upload,
    u.firstname,
    u.lastname, 
    
    m.region_id ,
    upc.category_name,
    ups.sub_category_name,
    up.description,
    up.result,
    up.file_type,
    up.file_path,
    up.file_name,
    up.is_top,
    up.created_date,
    up.thumb_path,
	o.o_name,
	c.c_name,
	o.o_code
    FROM mdl_ums_best_practice_post  up
    LEFT JOIN mdl_user as u ON up.user_id=u.id
    LEFT JOIN mdl_ums_employeemaster as  m ON up.user_id=m.userid
    LEFT JOIN mdl_ums_best_practice_category as  upc ON up.category_id=upc.id
    LEFT JOIN mdl_ums_best_practice_sub_category as ups ON up.subcategory_id=ups.id
    LEFT JOIN mdl_ums_outlet as o ON m.outlet_id = o.id
	LEFT JOIN mdl_ums_city as c ON m.city_id = c.id

    WHERE  u.deleted = 0 AND is_top is not null order by post_id desc ";
    $post_records=$DB->get_records_sql($sql);
   
    if(!empty($post_records)){
    foreach ($post_records as $key=>$post_data) 
      {

       
        $checklike="SELECT * from mdl_ums_best_practice_likes WHERE user_id='".$USER->id."' and post_id='".$post_data->post_id."'";

        $like_data=$DB->get_record_sql($checklike);
        if($like_data->id>0)
        {
          if($like_data->status==0)
          {
          $post_button='0';
          }
          else
          {
          $post_button='1';

          }


        }
      else
        {
       $post_button='0';
        }
 
  if($post_data->sub_category_name=='')
  {
    $sub_category_name='';

  }
  else
  {
    $sub_category_name=$post_data->sub_category_name;

  }

    switch($post_data->file_type){
                       case 'mp4':
                      case 'jpg':
                      case 'jpeg':
                      case 'png':
                      case 'gif':
                    
                      $thumb_n=basename($post_data->thumb_path);
                      $t_path="https://ilearn.marutisuzuki.com/upload/bestpractice/thumbnails/".$thumb_n;
                       if($post_data->thumb_path=='')
                  {
              $thumb_path='';

                  }
                else
                   {
                  $thumb_path=$t_path;

                    }
                     /*
                     $thumb_path="https://ilearn.marutisuzuki.com/local/pagecontainer/bestpract/placeholder/image.png";
                        break;
                       
                        $thumb_path="https://ilearn.marutisuzuki.com/local/pagecontainer/bestpract/placeholder/video.png";
                        break;
                        */
                        break;
                      case 'pdf':
                      $thumb_path="https://ilearn.marutisuzuki.com/local/pagecontainer/bestpract/placeholder/pdfi.png";
                        break;
                      
                      default:
                      $thumb_path="https://ilearn.marutisuzuki.com/local/pagecontainer/bestpract/placeholder/ima.png";
                      } 
if($post_data->file_path=='')
                  {
                  	$path="https://ilearn.marutisuzuki.com/local/pagecontainer/bestpract/placeholder/ima.png";
                  }
                  else
                  {
  $file_n=basename($post_data->file_path);
  $path="https://ilearn.marutisuzuki.com/upload/bestpractice/".$file_n;
					}

  if($post_data->profile_photo_upload == '' || $post_data->profile_photo_upload == null)
  {
    $photourl=$CFG->wwwroot.'/images/avatar3.png';  
  }else{
    $photourl=$CFG->wwwroot.'/upload/profile/'.$post_data->profile_photo_upload;
  }

  if($post_data->file_type == NULL || $post_data->file_type == '')
  {
      $file_type = '';
  }
  else{
      $file_type = $post_data->file_type;
  }
  $getlikesql="SELECT count(*) as likes FROM mdl_ums_best_practice_likes WHERE post_id='".$post_data->post_id."' and status=1";
  $like_count_data=$DB->get_record_sql($getlikesql);
 
      $temp['posts'][]=array(
        'post_id'=>$post_data->post_id,
        'post_empname'=>$post_data->firstname.' '.$post_data->lastname,
       
        'post_like_status'=>$post_button,
        'post_category'=>$post_data->category_name,
        'post_sub_category'=>$sub_category_name,
        'post_description'=>$post_data->description,
        'post_result'=>$post_data->result,
        'post_file_path'=>$path,
        'post_file_name'=>$post_data->file_name,
        'post_file_type'=>$file_type,
        'post_created_date'=>date('Y-m-d H:i:s',substr($post_data->created_date, 0, 10)),
        'post_likes'=>$like_count_data->likes,
        'post_thumb_path'=>$thumb_path,
		'post_dealer_code'=>$post_data->o_code,
		'post_dealer_name'=>$post_data->o_name,
		'post_dealer_city'=>$post_data->c_name,
    'profile_pic' => $photourl

      );
     
      }
    }
    else
    {
      
      $temp['posts'][]=array(
        'post_id'=>'',
        'post_empname'=>'',
         'post_like_status'=>'',
         'post_category'=>'',
         'post_sub_category'=>'',
          'post_description'=>'',
        'post_result'=>'',
         'post_file_path'=>'',
          'post_file_name'=>'',
          'post_file_type'=>'',
           'post_created_date'=>'',
            'post_likes'=>'',
            'post_thumb_path'=>'',
			'post_dealer_code'=>'',
			'post_dealer_name'=>'',
			'post_dealer_city'=>'',
      'profile_pic'=>'',



     );

    }
    
    
    $posts=$temp;
    return($posts);

  }
  
  public function bestpracticewall_returns()
  {
     return new external_single_structure(
                array(
                    
                     'posts' => new external_multiple_structure(
                                new external_single_structure(
                                              array(
                            'post_id'=>new external_value(PARAM_INT,'post_id'),

                            'post_empname'=>new external_value(PARAM_RAW,'post_empname'),
                            'post_like_status'=>new external_value(PARAM_RAW,'post_like_status'),
                            'post_category'=>new external_value(PARAM_RAW,'post_category'),
                            'post_sub_category'=>new external_value(PARAM_RAW,'post_sub_category'),
                            'post_description'=>new external_value(PARAM_RAW,'post_description'),
                            'post_result'=>new external_value(PARAM_RAW,'post_result'),
                            'post_file_path'=>new external_value(PARAM_RAW,'post_file_path'),
                            'post_file_name'=>new external_value(PARAM_RAW,'post_file_name'),
                            'post_file_type'=>new external_value(PARAM_RAW,'post_file_type'),
                            'post_created_date'=>new external_value(PARAM_RAW,'post_created_date'),
                            'post_likes'=>new external_value(PARAM_RAW,'post_likes'),
                            'post_thumb_path'=>new external_value(PARAM_RAW,'post_thumb_path'),
							'post_dealer_code'=>new external_value(PARAM_RAW,'post_dealer_code'),
							'post_dealer_name'=>new external_value(PARAM_RAW,'post_dealer_name'),
							'post_dealer_city'=>new external_value(PARAM_RAW,'post_dealer_city'),
              'profile_pic'=>new external_value(PARAM_RAW,'user_profile_pic',VALUE_OPTIONAL)

                           
                    ))),
                      

                )
            );

        
  }

  public function bestpracticelikeunlike_parameters()
  {
    return new external_function_parameters(
      array(  
          'id'    => new external_value(PARAM_INT, 'id'),
          'action' => new external_value(PARAM_RAW, 'action')
           
            
        )
    );
  }

  public function bestpracticelikeunlike($id,$action)
  {
    global $DB,$USER,$CFG;
    if($action=='like')
    {
      $checklike="SELECT * from mdl_ums_best_practice_likes WHERE user_id='".$USER->id."' and post_id='".$id."'";

      $like_data=$DB->get_record_sql($checklike);
      if(!empty($like_data))
      {
        $usql = "UPDATE mdl_ums_best_practice_likes SET status=1 WHERE post_id='".$id."' and user_id='".$USER->id."'";
      }
      else
      {
        $usql = "INSERT INTO mdl_ums_best_practice_likes(post_id,user_id,status) VALUES('".$id."','".$USER->id."',1)";
      }
      $DB->execute($usql,array());
      $result=array('status'=>'success');
  
    }
    else if($action=='unlike')
    {
      $usql = "UPDATE mdl_ums_best_practice_likes SET status=0 WHERE post_id='".$id."' and user_id='".$USER->id."'";
      $DB->execute($usql,array());
      $result=array('status'=>'success');
    }
    else
    {
      $result=array('status'=>'invalid');

    }
    
    //$result=array('status'=>'success');
    return $result;
  }

  public function bestpracticelikeunlike_returns()
  {
    return new external_single_structure(
      array('status'=> new external_value(PARAM_RAW, 'status')
       ));
  }
  //-------------- Best Practice Webservice done by yogita -----------------------//
    
  public function bestpracticecategory_parameters()
  {
    return new external_function_parameters(
      array( )
    );
  }
    
  public function bestpracticecategory()
  {
    global $DB,$USER;
    $catlists = $DB->get_records_sql("SELECT * FROM mdl_ums_best_practice_category WHERE inactive=0 ORDER BY id ASC");
    $mainfolder = array();
    foreach ($catlists as $key => $cats) 
    { 
      $alldd['Category'][] = array('categoryid'=>$cats->id,'categoryname'=>$cats->category_name);
    }
    $aa = $alldd;
    return($aa);
  }
    
  public function bestpracticecategory_returns()
  {
    return new external_single_structure(
      array(
        
         'Category' => new external_multiple_structure(
              new external_single_structure(
                      array(
            'categoryid'=>new external_value(PARAM_INT,'categoryid'),

            'categoryname'=>new external_value(PARAM_RAW,'categoryname'),

             
        ))),
          

      )
    );
  }
  
  public function bestpracticesubcategory_parameters()
  {
    return new external_function_parameters(
      array(
        'id' => new external_value(PARAM_INT,'categoryid')
      )

    );  
  }
    
  public function bestpracticesubcategory($id)
  {
    global $DB;
    $subcats = $DB->get_records_sql('SELECT * FROM mdl_ums_best_practice_sub_category WHERE category_id = '.$id.' ORDER BY id ASC');
    $mainfolder = array();
    if(!empty($subcats))
    {
      foreach ($subcats as $key => $subcat)
      { 
        $alldd['Category'][] = array('subcatid'=>$subcat->id,
                      'subcatname'=>$subcat->sub_category_name
                      );
      }
    }
    else
    {
      $alldd['Category'][] = array('subcatid'=>null,'subcatname'=>null);
    }
    $aa = $alldd;
    return($aa);
  }
    
  public function bestpracticesubcategory_returns()
  {
    return new external_single_structure(
      array(
        
         'Category' => new external_multiple_structure(
              new external_single_structure(
                      array(
            'subcatid'=>new external_value(PARAM_INT,'subcatid'),

            'subcatname'=>new external_value(PARAM_RAW,'subcatname'),

             
        ))),
          

      )
    );
  }
  
  

  /* END OF BESTPRACTICE SERVICE */

  /* START KNOWLEDGE CHECK ASSESSMENT WEBSRVICE */
  public function kc_assessment_parameters()
  {
    return new external_function_parameters(
      array(
        
      )

    );  
  }
    
  public function kc_assessment()
  {
    global $DB,$USER,$CFG;
    
    $data=array();
  
    $today=date('Y-m-d');
    $url="";
    $type="";
    $is_attempted="";
    $kcacourses=$DB->get_records_sql("SELECT id,type FROM {course} WHERE is_kca=1");
    if(!empty($kcacourses))
    {
      foreach ($kcacourses as $key => $course) 
      {
        $sql = "select id from {enrol} where courseid=".$course->id." and enrol='manual'";
        $obj=$DB->get_record_sql($sql);

        $enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($obj->id,$USER->id));
            if(!empty($enrollmentdate))
            {
            $courseenrollmentdate = $enrollmentdate->timecreated;

            $enrolenddate = $enrollmentdate->timeend;
            $enrolstart=date('Y-m-d',$courseenrollmentdate);

              if($today==$enrolstart)
              {
              $quizrecord  = $DB->get_record('quiz', array('course' => $course->id));
            
              $attempstatus = $DB->get_field('quiz_attempts','state',array('quiz' =>$quizrecord->id, 'userid' => $USER->id,'attempt' => 1));
              if(!empty($attempstatus))
              {
                $is_attempted="Yes";
              }
              else
              {
                $url = $CFG->wwwroot.'/course/view.php?id='.$course->id;
                $is_attempted="No";
                $type=$course->type;
                break;
              }

              }
            }  
            else
            {
              continue;
            }                           

      }

       $data['assessment'][]=array(
        'is_attempted'=>$is_attempted,
        'url'=>$url,
        'type'=>$type
      );
    }
    else
    {
      $data['assessment'][]=array(
        'is_attempted'=>$is_attempted,
        'url'=>$url,
        'type'=>$type
      );
     
    }
   $posts=$data;
    return($posts);
  }
    
  public function kc_assessment_returns()
  {
    return new external_single_structure(
      array(
        
         'assessment' => new external_multiple_structure(
              new external_single_structure(
                      array(
            'is_attempted'=>new external_value(PARAM_RAW,'is_attempted'),

            'url'=>new external_value(PARAM_RAW,'url'),
            'type'=>new external_value(PARAM_RAW,'url')
             
        ))),
          

      )
    );
  }

  /************* USER LOCATION : MANISH CHAVAN***************/
    public static function location_parameters()
  {
    return new external_function_parameters(
        array(
        'latitude' => new external_value(PARAM_RAW,'lat'),
        'longitude' => new external_value(PARAM_RAW,'long')
        )
    );
  }
  public static function location($latitude,$longitude)
  {
    
    global $USER, $DB ,$CFG;
    $status="";
    $message="";
    $userquery="SELECT code,outlet_id FROM mdl_ums_employeemaster WHERE userid='".$USER->id."'";
    $userqueryresult=$DB->get_record_sql($userquery);
    
    $checkquery="SELECT latitude,longitude FROM mdl_ums_user_cordinate WHERE userid='".$USER->id."'";
    
    $checkqueryresult=$DB->get_record_sql($checkquery);
    if(!empty($checkqueryresult))
    {
      $updatequery="UPDATE mdl_ums_user_cordinate SET latitude='".$latitude."',longitude='".$longitude."',outlet_id='".$userqueryresult->outlet_id."' WHERE userid='".$USER->id."'";
      $DB->execute($updatequery);
      $status="true";
      $message="location updated successfully";
    }
    else
    {
      $insertquery="INSERT INTO mdl_ums_user_cordinate(userid,mspin,latitude,longitude,outlet_id) VALUES('".$USER->id."','".$userqueryresult->code."','".$latitude."','".$longitude."','".$userqueryresult->outlet_id."')";
      $DB->execute($insertquery);
      $status="true";
      $message="location inserted successfully";
    }
    
    $selectresult=$DB->get_record_sql($checkquery);
    $result = array(
            'latitude'        => $selectresult->latitude,
            'longitude'       => $selectresult->longitude,
             'status'        => $status,
            'message'       => $message
          );
          
      return $result;   
  } 
  public static function location_returns()
  {
    return new external_single_structure(
    array(
        'latitude'  => new external_value(PARAM_RAW, 'Latitude ', VALUE_OPTIONAL),
      'longitude' => new external_value(PARAM_RAW, 'Longitude', VALUE_OPTIONAL),
       'status' => new external_value(PARAM_RAW, 'Status', VALUE_OPTIONAL),
        'message' => new external_value(PARAM_RAW, 'Message', VALUE_OPTIONAL)
      )
        );
  }
  

###GAMIFICATION WEB SERVICE

###START DAILY LOGIN
public function dailyLoginPoint_parameters(){
  return new external_function_parameters(
    array(
      'mspin' => new external_value(PARAM_INT, 'mspin')
    )
  );  
}
public function dailyLoginPoint($mspin){
  global $DB;
  $dailypoint=[];
  $sqlf="SELECT attempt_type, bonus_point FROM {gm_bonus_point_master} WHERE status='active' AND attempt_type='daily_login_point'";
  $bonus_point_val=$DB->get_record_sql($sqlf);
  $bp_arr = array();
  $bp_arr[$bonus_point_val->attempt_type] = $bonus_point_val->bonus_point;
  $date =date('Y-m-d');
  $dsql="SELECT lp.bonus_point AS total, lp.user_id FROM {gm_login_points} AS lp INNER JOIN {ums_employeemaster} AS ums ON ums.userid=lp.user_id WHERE ums.code=$mspin AND lp.date='".$date."'";
  $dbonus = $DB->get_record_sql($dsql);
  $dailypoint['status']=false;
  $dailypoint['total_creditbonus']=0;
  $dailypoint['daily_creditbouns']=0;
  $dailypoint['daily_creditbouns']= $dailypoint['daily_creditbouns']+$dbonus->total;
  $usql="SELECT userid FROM {ums_employeemaster} WHERE code=$mspin";
  $u_result = $DB->get_record_sql($usql);
  if($dbonus->total==0){
    $dailyinst=new stdClass();
    $dailyinst->user_id=$u_result->userid;
    $dailyinst->date=$date;
    $attempt_type ='daily_login_point';
    $bonus_point = $bp_arr[$attempt_type]; 
    $dailyinst->bonus_point=$bonus_point;
    $DB->insert_record('gm_login_points', $dailyinst);
    $dailypoint['daily_creditbouns']= $dailypoint['daily_creditbouns']+$dailyinst->bonus_point;
  }
  $tsql="SELECT SUM(lp.bonus_point) AS total FROM {gm_login_points} AS lp INNER JOIN {ums_employeemaster} AS ums ON ums.userid=lp.user_id WHERE ums.code=$mspin";
  $tbonus = $DB->get_record_sql($tsql);

  $dailypoint['total_creditbonus']= $dailypoint['total_creditbonus']+$tbonus->total;
  if($dailypoint['total_creditbonus']>0){
    $dailypoint['status']=true;
  }
  return $dailypoint;
}
public function dailyLoginPoint_returns(){
  return new external_single_structure(
  array(
      'status'=> new external_value(PARAM_RAW, 'status'),
      'total_creditbonus'=> new external_value(PARAM_RAW, 'total_creditbonus'),
      'daily_creditbouns'=> new external_value(PARAM_RAW, 'daily_creditbouns')
    )
  );
}
###END DAILY LOGIN

###START MY PERFORMANCE
  public static function myPerformance_parameters(){
    return new external_function_parameters(
        array()
    );
  }
  public static function myPerformance(){
    global $USER, $DB ,$CFG;
    //------------------------------------------------------------------------------------------------//
    $totalassignedcourse = "select count(a.id) as totalenroled 
            FROM mdl_role_assignments as a
            INNER JOIN mdl_user as u on(a.userid=u.id )
            INNER JOIN mdl_ums_employeemaster as emp on(u.id=emp.userid )
            INNER JOIN mdl_context e ON e.id = a.contextid
            INNER JOIN mdl_course as d on (d.id=e.instanceid)
            WHERE u.deleted=0 AND u.id = '".$USER->id."' AND d.category = 3 AND e.contextlevel=50 AND  d.visible = 1 ";
    $enrolledcourse = $DB->get_records_sql($totalassignedcourse);
    $allotedcourse = key($enrolledcourse);
    if($allotedcourse > 0){
      $sqlStatus = "SELECT
        concat(a.id,'-',u.id) as tempid,
        d.id,
        d.fullname,
        d.startdate,
        emp.userid as empuid,
        emp.region_id,
        emp.dol,
              
      (SELECT 
          sb.value AS lession_status
        FROM
          mdl_scorm AS sa
            INNER JOIN
          mdl_scorm_scoes_track AS sb ON (sa.id = sb.scormid)
        WHERE
          sb.element = 'cmi.core.lesson_status'
            AND sb.attempt = 1
            AND (sb.value = 'completed'
            OR sb.value = 'passed'
            OR sb.value = 'failed'
            OR sb.value = 'incomplete')
            AND sb.userid = u.id
            AND sa.course = d.id ORDER BY sb.id desc limit 1
      ) AS lession_status,
      (SELECT 
          sb.value AS completion_status
        FROM 
          mdl_scorm AS sa
            INNER JOIN
          mdl_scorm_scoes_track AS sb ON (sa.id = sb.scormid)
        WHERE
          sb.element = 'cmi.completion_status'
            AND sb.attempt = 1
            AND (sb.value = 'completed'
            OR sb.value = 'passed'
            OR sb.value = 'failed'
            OR sb.value = 'incomplete')
            AND sb.userid = u.id
            AND sa.course = d.id ORDER BY sb.id desc limit 1
      ) AS completion_status
      
      FROM mdl_role_assignments as a
      LEFT JOIN mdl_user as u on(a.userid=u.id)
      INNER JOIN mdl_ums_employeemaster as emp on(u.id=emp.userid )
      INNER JOIN mdl_context as e on (e.id = a.contextid and e.contextlevel=50)
      INNER JOIN mdl_course as d on (d.id=e.instanceid) WHERE u.id = '".$USER->id."' AND d.category = 3 AND d.visible = 1";
      $courseRes = $DB->get_records_sql($sqlStatus, array()); 
      $completed = 0;
      $incompleted = 0;
      $notstarted = 0;
      if(isset($courseRes) && !empty($courseRes)){
        foreach ($courseRes as $res){ 
          if(isset($res->lession_status) && !empty($res->lession_status)){
            $status =  $res->lession_status;
          }else if(isset($res->completion_status) && !empty($res->completion_status)){
            $status =  $res->completion_status;
          }else{
            $status = "Not Started";  
          }
          ############ get Status ################
          if($status=='completed' || $status=='passed' ){
            $completed = $completed + 1;
          }else if($status=='incomplete' || $status=='failed'){
            $incompleted = $incompleted + 1;
          }else{
            $notstarted = $notstarted + 1;
          } 
        }
      }
      $total_enrolled_course     = $allotedcourse;
      $incompleted_course_count  = $incompleted;
      $completed_course_count    = $completed;
      $not_started_course_count  = $notstarted; 
    }else{
      $total_enrolled_course     = 0;
      $incompleted_course_count  = 0;
      $completed_course_count    = 0;
      $not_started_course_count  = 0;
    }
    $totalassignedassess = "select count(a.id) as totalenroled 
            FROM mdl_role_assignments as a
            INNER JOIN mdl_user as u on(a.userid=u.id )
            INNER JOIN mdl_ums_employeemaster as emp on(u.id=emp.userid )
            INNER JOIN mdl_context e ON e.id = a.contextid
            INNER JOIN mdl_course as d on (d.id=e.instanceid)
            WHERE u.deleted=0 AND u.id = '".$USER->id."' AND d.category = 2 AND e.contextlevel=50 AND d.visible = 1 ";
    $enrolledassessment = $DB->get_records_sql($totalassignedassess);
    $allotedassessement = key($enrolledassessment);
    if($allotedassessement > 0){
      $assesments = $DB->get_records_sql("SELECT * FROM mdl_course WHERE category = 2 AND visible = 1");
      $complete = 0;
      $not_started = 0;
      $incomplete = 0;
      foreach($assesments as $assesment){
        $quizid   = $DB->get_field('quiz','id', array('course' => $assesment->id));
        $quizname = $DB->get_field('quiz','name', array('course' => $assesment->id));
        $sql = "SELECT a.id,
            a.state as state,
            a.sumgrades as score,
            g.grademax,
            g.grademin,
            g.iteminstance,
            g.itemmodule,
            a.attempt
            FROM mdl_quiz_attempts AS a
            INNER JOIN mdl_user AS b ON(a.userid=b.id)
            INNER JOIN mdl_role_assignments as ra ON ra.userid=b.id
                        INNER JOIN mdl_context e ON e.id = ra.contextid
            INNER JOIN mdl_ums_employeemaster emp ON emp.userid = b.id
            INNER JOIN mdl_grade_items AS g ON g.iteminstance = '".$quizid."'
            AND g.itemmodule='quiz' WHERE a.quiz='".$quizid."' AND a.userid = '".$USER->id."' ORDER BY a.attempt DESC LIMIT 1" ;
        
        $quizattempts = $DB->get_records_sql($sql, array());
        foreach($quizattempts as $attempt){
          if($attempt->state == 'inprogress' || $attempt->state == 'abandoned'){
            $incomplete = $incomplete + 1;
          }else{
            $complete = $complete + 1;
          } 
        }
      }
      
      $not_started = $allotedassessement - ($complete + $incomplete);
      $total_enrolled_assessment     = $allotedassessement;
      $completed_assessment_count    = $complete;
      $incompleted_assessment_count  = $incomplete;
      $not_started_assessment_count  = $not_started ;
    }else{
      $total_enrolled_assessment     = 0;
      $completed_assessment_count    = 0;
      $incompleted_assessment_count  = 0;
      $not_started_assessment_count  = 0;
      
    }     
    $result = array(
            'total_enrolled_course'        => $total_enrolled_course,
            'completed_course_count'       => $completed_course_count,
            'incompleted_course_count'     => $incompleted_course_count,
            'not_started_course_count'     => $not_started_course_count,
            'total_enrolled_assessment'    => $total_enrolled_assessment,
            'completed_assessment_count'   => $completed_assessment_count,
            'incompleted_assessment_count' => $incompleted_assessment_count,
            'not_started_assessment_count' => $not_started_assessment_count,
            'total_enrolled_survey'        => 0,
            'not_started_survey_count'     => 0,
            'completed_survey_count'       => 0
          );
      return $result;   
  } 

  public static function myPerformance_returns(){
    return new external_single_structure(
    array(
          'total_enrolled_course'  => new external_value(PARAM_RAW, 'Total Enrolled Course Count ', VALUE_OPTIONAL),
          'completed_course_count' => new external_value(PARAM_RAW, 'Total Completed Course Count', 
          VALUE_OPTIONAL),
          'incompleted_course_count'=> new external_value(PARAM_RAW, 'Total Incompleted Course Count', VALUE_OPTIONAL),
          'not_started_course_count' => new external_value(PARAM_RAW, 'Total Not Started Course Count', VALUE_OPTIONAL),
          'total_enrolled_assessment'=> new external_value(PARAM_RAW, 'Total Enrolled Assessment Count ', VALUE_OPTIONAL),
          'completed_assessment_count' => new external_value(PARAM_RAW, 'Total Completed Assessment Count', VALUE_OPTIONAL),
          'incompleted_assessment_count'=> new external_value(PARAM_RAW, 'Total Incompleted Assessment Count', VALUE_OPTIONAL),
          'not_started_assessment_count'=> new external_value(PARAM_RAW, 'Total Not Started Assessment Count', VALUE_OPTIONAL),
          'total_enrolled_survey'=> new external_value(PARAM_RAW, 'Total Enrolled Survey Count', VALUE_OPTIONAL),
          'not_started_survey_count'=> new external_value(PARAM_RAW, 'Total Not Started Survey Count', VALUE_OPTIONAL),
          'completed_survey_count'=> new external_value(PARAM_RAW, 'Total Completed Survey Count', 
          VALUE_OPTIONAL)
      )
    );
  }
###END MY PERFORMANCE

###START SAT RANKING LEADERBOARD  
  public function satRankingLeaderBoard_parameters(){
    return new external_function_parameters(
      array(
        'mspin' => new external_value(PARAM_INT, 'mspin')
      )
    );  
  }
  public function satRankingLeaderBoard($mspin){
    global $DB, $CFG;
    // echo $mspin; die;

  ##for userInfo
    $sqlu="SELECT id, user_id, emp_name AS fullname, dealer_id as outlet_id, region_id, mspin,
          sum(distinct final_score) as ass_score, percentage, designation_id, profile_photo_upload, gender
          FROM mdl_sat_ass_score_report_new1
          WHERE mspin = $mspin group by quiz_id";
     // echo $sqlu; die;
    $urslt=$DB->get_record_sql($sqlu);

    $fullname = $urslt->fullname;

    $urslt1=$DB->get_records_sql($sqlu);
    // print_r($urslt1);
    // $ass_score = array();
    $prefix = $ass_score = '';
    $prefix1 = $percentage = '';
    foreach ($urslt1 as $value) {
      $ass_score .= $prefix.''.$value->ass_score;
      $prefix = ' ';
      $percentage .=$prefix1.''.rtrim($value->percentage, '%');
      $prefix1 = ' ';
      // $ass_score = $value->ass_score;
    }
    
    $percentage = explode(" ", $percentage);
    // print_r($percentage); die;
    // $ave = count($percentage);
    $ass_count_que = "SELECT * FROM mdl_sat_assessment_user_enrol WHERE mspin = '".$urslt->mspin."'";
    $ass_count_res = $DB->get_record_sql($ass_count_que);
    $ass_count = $ass_count_res->ass_count;
    $scoreoutof = $ass_count*150;

    $ass_count_que = "SELECT * FROM mdl_sat_assessment_user_enrol WHERE mspin = $urslt->mspin";
    $ass_count_res = $DB->get_record_sql($ass_count_que);
    $ass_count = $ass_count_res->ass_count;
    // echo $ass_count; die;

    $fpercentage = array_sum($percentage);
    $proficiency = $fpercentage/$ass_count;
    // echo $proficiency; die;

    //print_r($urslt);exit;
    if($urslt->profile_photo_upload != '' || $urslt->profile_photo_upload != null)
    {
      //$userprofile='https://ilearnnexa.marutisuzuki.com/upload/profile/'.$urslt->profile_photo_upload;
      $userprofile = $CFG->wwwroot.'/upload/profile/'.$urslt->profile_photo_upload;
    }else{
      //$userprofile='https://ilearnnexa.marutisuzuki.com/images/avatar3.png';
       if($urslt->gender == 'M')
        {
          //$userprofile='https://ilearnnexa.marutisuzuki.com/images/avatar3.png';
          $userprofile = $CFG->wwwroot.'/images/avatar1.png';
        }else{
          //$userprofile='https://ilearnnexa.marutisuzuki.com/images/female-avatar.png';
          $userprofile = $CFG->wwwroot.'/images/female-avatar.png';
        }
    }

      if($proficiency < 60){
        $profeciencylavel = 'Learner';
        $badgeimg = $userprofile;
      }
      elseif($proficiency >= 60 && $proficiency < 90){
         $profeciencylavel = 'Proficient';
         $badgeimg = $CFG->wwwroot.'/upload/CertificateBadge/Advanced.png';
      }
      elseif($proficiency >= 90){
        $profeciencylavel = 'Master';
        $badgeimg = $CFG->wwwroot.'/upload/CertificateBadge/Expert.png';
      }

  // echo $CFG->wwwroot.'/upload/CertificateBadge/s211212_gold_badge_seal_quality_label_e09.jpg';die;

    $ass_score = explode(" ", $ass_score);
    $total_points = array_sum($ass_score); 
    // echo $total_points;

    ////////////////////////////////////////////// start not maped data ///////////////////////////////////////
    $usercnt = count($urslt1);
    if($usercnt == 0){
      $sql = "SELECT u.id, u.firstname, u.lastname, em.gender, em.profile_photo_upload, em.outlet_id, 
      em.region_id, em.designation_id 
      FROM mdl_user u
      INNER JOIN mdl_ums_employeemaster em ON em.code = u.username 
      where u.username = $mspin";
      $res = $DB->get_record_sql($sql);
      $fullname = $res->firstname.' '.$res->lastname;
      $gender = $res->gender;
      $profile_pic = $res->profile_photo_upload;
      $outlet_id = $res->outlet_id;
      $region_id = $res->region_id;
      $dealer_rank = 0;
      $region_rank = 0;
      $country_rank = 0;
      $total_points = 0;


      $percentage = explode(" ", $percentage);
      $ave = count($percentage);
      $fpercentage = array_sum($percentage);
      $proficiency = $fpercentage/$ave;
      // echo $proficiency; die;

      //print_r($urslt);exit;
      if($res->profile_photo_upload != '' || $res->profile_photo_upload != null)
      {
        //$userprofile='https://ilearnnexa.marutisuzuki.com/upload/profile/'.$urslt->profile_photo_upload;
        $userprofile = $CFG->wwwroot.'/upload/profile/'.$res->profile_photo_upload;
      }else{
        //$userprofile='https://ilearnnexa.marutisuzuki.com/images/avatar3.png';
         if($res->gender == 'M')
          {
            //$userprofile='https://ilearnnexa.marutisuzuki.com/images/avatar3.png';
            $userprofile = $CFG->wwwroot.'/images/avatar1.png';
          }else{
            //$userprofile='https://ilearnnexa.marutisuzuki.com/images/female-avatar.png';
            $userprofile = $CFG->wwwroot.'/images/female-avatar.png';
          }
      }

      if($proficiency < 60){
        $profeciencylavel = 'Learner';
        $badgeimg = $userprofile;
      }
      elseif($proficiency >= 60 && $proficiency < 90){
         $profeciencylavel = 'Proficient';
         $badgeimg = $CFG->wwwroot.'/upload/CertificateBadge/Advanced.png';
      }
      elseif($proficiency > 90){
        $profeciencylavel = 'Expert';
        $badgeimg = $CFG->wwwroot.'/upload/CertificateBadge/Expert.png';
      }


      if($res->designation_id != 10){
        $profeciencylavel = '';
        $badgeimg = $userprofile;
      }

      $rank=0;
      $leaderboardpoint=[];
      $leaderboardpoint['uInfo']['status']             ='true';
      $leaderboardpoint['uInfo']['rank_dealer']        =$dealer_rank;
      $leaderboardpoint['uInfo']['dealer_rankimg']     ='https://ilearnnexa.marutisuzuki.com/images/rank/icon3.png';
      $leaderboardpoint['uInfo']['rank_region']        =$region_rank;
      $leaderboardpoint['uInfo']['region_rankimg']     ='https://ilearnnexa.marutisuzuki.com/images/rank/icon3.png';
      $leaderboardpoint['uInfo']['rank_country']       =$country_rank;
      $leaderboardpoint['uInfo']['country_rankimg']    ='https://ilearnnexa.marutisuzuki.com/images/rank/icon3.png';
      $leaderboardpoint['uInfo']['total_dailypoint']   =0;
      // $leaderboardpoint['uInfo']['total_points']       =$rank+$total_bonus_point->total_bonus_point;
      $leaderboardpoint['uInfo']['total_points']       =$total_points;
      $leaderboardpoint['uInfo']['reward_point']       =0;
      $leaderboardpoint['uInfo']['fullname']           =$profeciencylavel;
      // $primg=$CFG->wwwroot.'/images/avatar1.png';
      // if($res->profile_photo_upload){
      // $primg=$CFG->wwwroot.'/upload/profile/'.$res->profile_photo_upload;
      // }
      $leaderboardpoint['uInfo']['userpic']            =$badgeimg;
      // $leaderboardpoint['uInfo']['proficiency']          ='Fail';
      $leaderboardpoint['uInfo']['mspin']              ="".$mspin."";
      $leaderboardpoint['uInfo']['total_points_final'] =$total_points.' / '.$scoreoutof;

      ##for Latest 10 record Country Level Rank
        $cclist_sql="SELECT id, user_id, sum(distinct final_score) AS total_points, emp_name AS fullname, mspin, region_name AS region, gender, profile_photo_upload, dense_rank()
          OVER (ORDER BY total_points DESC) 
          AS 'rank' FROM mdl_sat_ass_score_report_new1 
          -- Where region_id = 2
          group by user_id limit 10";

        // echo $cclist_sql; die;
        $country_rank_list= $DB->get_records_sql($cclist_sql);
        // print_r($country_rank_list); die;
        $crank=[];
        $cint=1;
        foreach($country_rank_list as $key => $value){
          if($value->rank <= 10){
             //$primg=$CFG->wwwroot.'/images/avatar3.png';
             if($value->profile_photo_upload){
                $primg=$CFG->wwwroot.'/upload/profile/'.$value->profile_photo_upload;
              }
            else{
                if($value->gender == 'M')
                {
                  $primg=$CFG->wwwroot.'/images/avatar3.png';
                }else{
                  $primg=$CFG->wwwroot.'/images/female-avatar.png';
                }
              }
            $value->total_points=intval($value->total_points);
            $value->userpic=$primg;
            $value->rankimg='https://ilearnnexa.marutisuzuki.com/images/rank/icon3.png';
            $value->region=$value->region==''?'':@$value->region;
            $crank[]=$value;
          }else{
            break;
        }
        $cint++;
      }
      ##End Latest 10 record Region Level Rank

      if($region_id !='')
      {
        ##for Latest 10 record Region Level Rank
        $rrlist_sql="SELECT id, user_id, sum(distinct final_score) AS total_points, emp_name AS fullname, mspin, region_name AS region, gender, profile_photo_upload, dense_rank()
            OVER (ORDER BY total_points DESC) 
            AS 'rank' FROM mdl_sat_ass_score_report_new1 
            Where region_id = '".$region_id."'
            group by user_id limit 10";
          // echo $rrlist_sql; die;
          $region_rank_list= $DB->get_records_sql($rrlist_sql);
          $cint=1;
          $rrank=[];
          foreach($region_rank_list as $key => $value){
            if($value->rank<=10){
             //$primg=$CFG->wwwroot.'/images/avatar3.png';
             if($value->profile_photo_upload){
                $primg=$CFG->wwwroot.'/upload/profile/'.$value->profile_photo_upload;
              }
              else{
                if($value->gender == 'M')
                {
                  $primg=$CFG->wwwroot.'/images/avatar3.png';
                }else{
                  $primg=$CFG->wwwroot.'/images/female-avatar.png';
                }
              }
            $value->total_points=intval($value->total_points);  
            $value->userpic=$primg;
            $value->rankimg='https://ilearnnexa.marutisuzuki.com/images/rank/icon3.png';
            $value->region=$value->region==''?'':@$value->region;
            $rrank[]=$value;
             }else{
              break;
            }
            $cint++;
        }
        ##End Latest 10 record Region Level Rank
      }else{
        $rrank = [];
      }

      if($outlet_id !='')
      {
        ##for Latest 10 record Dealer Level Rank
        $ddlist_sql="SELECT id, user_id, sum(distinct final_score) AS total_points, emp_name AS fullname, mspin, region_name AS region, gender, profile_photo_upload, dense_rank()
          OVER (ORDER BY total_points DESC) 
          AS 'rank' FROM mdl_sat_ass_score_report_new1 
          WHERE dealer_id='".$outlet_id."'
          group by user_id limit 10";   
        // echo $ddlist_sql; die;
        $drank=[];
        $cint=1;
        $dealer_rank_list= $DB->get_records_sql($ddlist_sql);
        foreach($dealer_rank_list as $key => $value){
          if($value->rank<=10){
           //$primg=$CFG->wwwroot.'/images/avatar3.png';
           if($value->profile_photo_upload){
              $primg=$CFG->wwwroot.'/upload/profile/'.$value->profile_photo_upload;
            }
          else{
              if($value->gender == 'M')
              {
                $primg=$CFG->wwwroot.'/images/avatar3.png';
              }else{
                $primg=$CFG->wwwroot.'/images/female-avatar.png';
              }
            }
          $value->userpic=$primg;
          $value->mspin=$value->mspin;
          $value->rankimg='https://ilearnnexa.marutisuzuki.com/images/rank/icon3.png';
          $value->region=$value->region==''?'':@$value->region;
          $drank[]=$value;
            }else{
             break;
        }
          $cint++;
        }
      ##End Latest 10 record Dealer Level Rank
      }else{
        $drank = [];
      }

      if($region_id =='' || $region_id == 0){
        $leaderboardpoint['uTabs']['regions'] =$crank;
      }else{
        $leaderboardpoint['uTabs']['regions'] = $rrank;
      }

      $leaderboardpoint['uTabs']['dealers'] = $drank;
      // $leaderboardpoint['uTabs']['regions'] = $rrank;
      $leaderboardpoint['uTabs']['country'] = $crank;

      return $leaderboardpoint;

    }
    /////////////////////////////////// end for not maped data ////////////////////////////////////////


    

  ##End for userInfo

   if($total_points != 0){
    ##for Country Level Rank
    $csql="SELECT id, user_id, dealer_rank, region_rank, country_rank, total_score FROM mdl_sat_score_rank_info";
    // echo $csql; die;
    $rank_info= $DB->get_records_sql($csql);
    foreach ($rank_info as $key => $value) {
      $user_id = $value->user_id;
      if($urslt->user_id == $user_id){
        $country_rank = $value->country_rank;
        $dealer_rank = $value->dealer_rank;
        $region_rank = $value->region_rank;
      }
    }  
  ##End for Country Level Rank
    }else{
      $country_rank = 0;
      $dealer_rank  = 0;
      $region_rank  = 0;
    }

    $rank=0;
    $leaderboardpoint=[];
    $leaderboardpoint['uInfo']['status']             ='true';
    $leaderboardpoint['uInfo']['rank_dealer']        =$dealer_rank;
    $leaderboardpoint['uInfo']['dealer_rankimg']     ='https://ilearnnexa.marutisuzuki.com/images/rank/icon3.png';
    $leaderboardpoint['uInfo']['rank_region']        =$region_rank;
    $leaderboardpoint['uInfo']['region_rankimg']     ='https://ilearnnexa.marutisuzuki.com/images/rank/icon3.png';
    $leaderboardpoint['uInfo']['rank_country']       =$country_rank;
    $leaderboardpoint['uInfo']['country_rankimg']    ='https://ilearnnexa.marutisuzuki.com/images/rank/icon3.png';
    $leaderboardpoint['uInfo']['total_dailypoint']   =0;
    // $leaderboardpoint['uInfo']['total_points']       =$rank+$total_bonus_point->total_bonus_point;
    $leaderboardpoint['uInfo']['total_points']       =$total_points;
    $leaderboardpoint['uInfo']['reward_point']       =0;
    $leaderboardpoint['uInfo']['fullname']           =$profeciencylavel;
    // $primg=$CFG->wwwroot.'/images/avatar1.png';
    // if($urslt->profile_photo_upload){
    // $primg=$CFG->wwwroot.'/upload/profile/'.$urslt->profile_photo_upload;
    // }
    $leaderboardpoint['uInfo']['userpic']            =$badgeimg;
    // $leaderboardpoint['uInfo']['proficiency']        ='Expert';
    $leaderboardpoint['uInfo']['mspin']              ="".$mspin."";
    $leaderboardpoint['uInfo']['total_points_final'] =$total_points.' / '.$scoreoutof;

  ##for Latest 10 record Country Level Rank
    $cclist_sql="SELECT s.id, s.user_id as user_id, ri.total_score AS total_points, s.emp_name AS fullname, s.mspin as mspin, s.region_name AS region, s.gender as gender, s.profile_photo_upload as profile_photo_upload, ri.country_rank as rank  
      FROM mdl_sat_ass_score_report_new1 s
      INNER JOIN mdl_sat_score_rank_info ri ON ri.user_id = s.user_id
      group by s.user_id order by ri.total_score DESC limit 10";
    
    // echo $cclist_sql; die;
    $country_rank_list= $DB->get_records_sql($cclist_sql);
    // print_r($country_rank_list); die;
    $crank=[];
    $cint=1;
    foreach($country_rank_list as $key => $value){
      if($value->rank <= 10){
         //$primg=$CFG->wwwroot.'/images/avatar3.png';
         if($value->profile_photo_upload){
            $primg=$CFG->wwwroot.'/upload/profile/'.$value->profile_photo_upload;
          }
        else{
            if($value->gender == 'M')
            {
              $primg=$CFG->wwwroot.'/images/avatar3.png';
            }else{
              $primg=$CFG->wwwroot.'/images/female-avatar.png';
            }
          }
        $value->total_points=intval($value->total_points);
        $value->userpic=$primg;
        $value->rankimg='https://ilearnnexa.marutisuzuki.com/images/rank/icon3.png';
        $value->region=$value->region==''?'':@$value->region;
        $value->total_points_final=$value->total_points.' / '.$scoreoutof;
        $crank[]=$value;
      }else{
        break;
    }
    $cint++;
  }

  // print_r($crank); die;
  ##End Latest 10 record Country Level Rank

  ##for Latest 10 record Region Level Rank
    $rrlist_sql="SELECT s.id, s.user_id as user_id, ri.total_score AS total_points, s.emp_name AS fullname, s.mspin as mspin, s.region_name AS region, s.gender as gender, s.profile_photo_upload as profile_photo_upload, ri.region_rank as rank  
      FROM mdl_sat_ass_score_report_new1 s
      INNER JOIN mdl_sat_score_rank_info ri ON ri.user_id = s.user_id 
      Where s.region_id = '".$urslt->region_id."'
      group by s.user_id order by ri.total_score DESC limit 10";
    // echo $rrlist_sql; die;
    $region_rank_list= $DB->get_records_sql($rrlist_sql);
    $cint=1;
    $rrank=[];
    foreach($region_rank_list as $key => $value){
      if($value->rank<=10){
       //$primg=$CFG->wwwroot.'/images/avatar3.png';
       if($value->profile_photo_upload){
          $primg=$CFG->wwwroot.'/upload/profile/'.$value->profile_photo_upload;
        }
        else{
          if($value->gender == 'M')
          {
            $primg=$CFG->wwwroot.'/images/avatar3.png';
          }else{
            $primg=$CFG->wwwroot.'/images/female-avatar.png';
          }
        }
      $value->total_points=intval($value->total_points);  
      $value->userpic=$primg;
      $value->rankimg='https://ilearnnexa.marutisuzuki.com/images/rank/icon3.png';
      $value->region=$value->region==''?'':@$value->region;
      $value->total_points_final=$value->total_points.' / '.$scoreoutof;
      $rrank[]=$value;
       }else{
        break;
    }
    $cint++;
  }
  ##End Latest 10 record Region Level Rank

  ##for Latest 10 record Dealer Level Rank
    $ddlist_sql="SELECT s.id, s.user_id as user_id, ri.total_score AS total_points, s.emp_name AS fullname, s.mspin as mspin, s.region_name AS region, s.gender as gender, s.profile_photo_upload as profile_photo_upload, ri.dealer_rank as rank  
      FROM mdl_sat_ass_score_report_new1 s
      INNER JOIN mdl_sat_score_rank_info ri ON ri.user_id = s.user_id
      WHERE s.dealer_id='".$urslt->outlet_id."'
      group by s.user_id order by ri.total_score DESC limit 10";   
    // echo $ddlist_sql; die;
    $drank=[];
    $cint=1;
    $dealer_rank_list= $DB->get_records_sql($ddlist_sql);
    foreach($dealer_rank_list as $key => $value){
      if($value->rank<=10){
       //$primg=$CFG->wwwroot.'/images/avatar3.png';
       if($value->profile_photo_upload){
          $primg=$CFG->wwwroot.'/upload/profile/'.$value->profile_photo_upload;
        }
      else{
          if($value->gender == 'M')
          {
            $primg=$CFG->wwwroot.'/images/avatar3.png';
          }else{
            $primg=$CFG->wwwroot.'/images/female-avatar.png';
          }
        }
      $value->userpic=$primg;
      $value->mspin=$value->mspin;
      $value->rankimg='https://ilearnnexa.marutisuzuki.com/images/rank/icon3.png';
      $value->region=$value->region==''?'':@$value->region;
      $value->total_points_final=$value->total_points.' / '.$scoreoutof;
      $drank[]=$value;
        }else{
         break;
    }
      $cint++;
    }

  ##End Latest 10 record Dealer Level Rank

  #condition for black data
      if(empty($rrank)){
        $rrank []=[ 'fullname'=>'', 'mspin' => "0", 'region'=>'', 'userpic'=>'', 'rank'=>0, 'rankimg'=>'', 'total_points'=>0 ];
      }
      if(empty($crank)){
        $crank []=[ 'fullname'=>'', 'mspin' => "0", 'region'=>'', 'userpic'=>'', 'rank'=>0, 'rankimg'=>'', 'total_points'=>0 ];
      }
  #end here
     if($urslt->designation_id == 10)
     {
        $leaderboardpoint['uTabs']['regions']        = $crank;
     }else{
        $leaderboardpoint['uTabs']['regions']        = $rrank;
     }

    $leaderboardpoint['uTabs']['dealers']            =$drank;
    // $leaderboardpoint['uTabs']['regions']            =$rrank;
    $leaderboardpoint['uTabs']['country']            =$crank;
    return $leaderboardpoint;
  }

  public function satRankingLeaderBoard_returns(){
    return new external_single_structure(
      array(
        'uInfo'=> new external_single_structure(
          array(
            'status'            => new external_value(PARAM_RAW, 'status'),
            'rank_dealer'       => new external_value(PARAM_INT, 'rank_dealer'),
            'dealer_rankimg'    => new external_value(PARAM_RAW, 'dealer_rankimg'),
            'rank_region'       => new external_value(PARAM_INT, 'rank_region'),
            'region_rankimg'    => new external_value(PARAM_RAW, 'region_rankimg'),
            'rank_country'      => new external_value(PARAM_INT, 'rank_country'),
            'country_rankimg'   => new external_value(PARAM_RAW, 'country_rankimg'),
            'total_dailypoint'  => new external_value(PARAM_INT, 'total_dailypoint'),
            'reward_point'      => new external_value(PARAM_INT, 'reward_point'),
            'total_points'      => new external_value(PARAM_INT, 'total_points'),
            'fullname'          => new external_value(PARAM_RAW, 'fullname'),
            'userpic'           => new external_value(PARAM_RAW, 'userpic'),
            'mspin'             => new external_value(PARAM_RAW, 'mspin'),
            'total_points_final'             => new external_value(PARAM_RAW, 'total_points_final')
          )
        ),
        'uTabs'=> new external_single_structure(
          array(
            'dealers' => new external_multiple_structure(
              new external_single_structure(
                array(
                  'fullname'      =>new external_value(PARAM_RAW,'fullname'),
                  'mspin'         =>new external_value(PARAM_RAW,'mspin'),
                  'region'        =>new external_value(PARAM_RAW,'region'),
                  'userpic'       =>new external_value(PARAM_RAW,'userpic'),
                  'rank'          =>new external_value(PARAM_INT,'rank'),
                  'rankimg'       =>new external_value(PARAM_RAW,'rankimg'),
                  'total_points'  =>new external_value(PARAM_INT,'total_points'),
                  'total_points_final'  =>new external_value(PARAM_RAW,'total_points_final')

                )
              )
            ),
            'regions' => new external_multiple_structure(
              new external_single_structure(
                 array(
                  'fullname'      =>new external_value(PARAM_RAW,'fullname'),
                  'mspin'         =>new external_value(PARAM_RAW,'mspin'),
                  'region'        =>new external_value(PARAM_RAW,'region'),
                  'userpic'       =>new external_value(PARAM_RAW,'userpic'),
                  'rank'          =>new external_value(PARAM_INT,'rank'),
                  'rankimg'       =>new external_value(PARAM_RAW,'rankimg'),
                  'total_points'  =>new external_value(PARAM_INT,'total_points'),
                  'total_points_final'  =>new external_value(PARAM_RAW,'total_points_final')

                )
              )
            ),
            'country' => new external_multiple_structure(
              new external_single_structure(
                array(
                  'fullname'      =>new external_value(PARAM_RAW,'fullname'),
                  'mspin'         =>new external_value(PARAM_RAW,'mspin'),
                  'region'        =>new external_value(PARAM_RAW,'region'),
                  'userpic'       =>new external_value(PARAM_RAW,'userpic'),
                  'rank'          =>new external_value(PARAM_INT,'rank'),
                  'rankimg'       =>new external_value(PARAM_RAW,'rankimg'),
                  'total_points'  =>new external_value(PARAM_INT,'total_points'),
                  'total_points_final'  =>new external_value(PARAM_RAW,'total_points_final')

                )
              )
            )
          )
        )
      )
    );
  }

###END SAT RANKING LEADERBOARD

###START SAT PERFORMANCE
public function satPerformancePoint_parameters(){
  return new external_function_parameters(
    array(
      'mspin' => new external_value(PARAM_RAW, 'mspin')
    )
  );  
}
public function satPerformancePoint($mspin){
  //echo $mspin;exit;
  global $DB,$CFG;
  $dailypoints=[];
  $dailypoints['status']=false;
  $point=0;
  $outof = 150;
  
  $sqla="SELECT id, quiz_id, quiz_name, user_id, 
  final_score as points, ass_status as status, topic_id, topic_name as topic, topic_score, proficiency  
  FROM 
  mdl_sat_ass_score_report_new1
  WHERE mspin = $mspin GROUP BY quiz_id ORDER BY quiz_id DESC";
  // echo $sqla; die;
  $atabs = $DB->get_records_sql($sqla); 
  foreach ($atabs as $key => $value) {
    $quiz_name = $value->quiz_name;
    $points = $value->points;
    $status = $value->status;
    $topic = $value->topic;
    $topic_score = $value->topic_score;
    $topic_id = $value->topic_id;
    $quiz_id = $value->quiz_id;
    $proficiency = $value->proficiency;
    $user_id = $value->user_id;

    // echo $proficiency; die;

    $dailypoints['myPerformance'][]=[
      'activity' => $quiz_name,
      'count' => $points,
      'total' => $points.' / '.$outof,
      'type' => 'head',
      'ctype' => 'A'
    ];
    $dailypoints['myPerformance'][]=[
      'activity' => $quiz_name,
      'count' => $points,
      'total' => $points.' / '.$outof,
      'type' => 'row',
      'ctype' => 'A'
    ];    
    // $dailypoints['myPerformance'][]=[
    //   'activity' => $topic,
    //   'count' => $topic_score,
    //   'total' => $topic_score.' / 150',
    //   'type' => 'row',
    //   'ctype' => 'T'
    // ]; 

    $tsql="SELECT id, quiz_id, topic_id, topic_name as topic, topic_score, question_type_score
    FROM mdl_sat_ass_score_report_new1
    WHERE mspin = $mspin AND quiz_id = $quiz_id GROUP BY topic_id";
    // echo $tsql; die;
    $tres = $DB->get_records_sql($tsql); 
    foreach ($tres as $key => $trs) {
      $topic = $trs->topic;
      $topic_id = $trs->topic_id;
      $topic_score = $trs->question_type_score;

      $topicsql = "SELECT id, parent FROM mdl_question_categories where parent = '".$topic_id ."'";
      $topictres = $DB->get_records_sql($topicsql);
      $queid = $prefix = ''; 
      foreach ($topictres as $key => $value1) {
        $cat_id = $value1->id;
        $subcatsql = "SELECT id, parent FROM mdl_question_categories where parent = '".$cat_id ."'";
        $subcatres = $DB->get_records_sql($subcatsql);
        foreach ($subcatres as $key => $value2) {
          $subcatid = $value2->id;         
          $subsubcatsql = "SELECT id, parent FROM mdl_question_categories where parent = '".$subcatid ."'";
          $subsubcatres = $DB->get_records_sql($subsubcatsql);
          foreach ($subsubcatres as $key => $value3) {
            $subsubcatid = $value3->id;
             // echo $subsubcatid;
            $quecountsql = "SELECT q.id as qid,qa.userid,qa.quiz,q.category,qcat.name as sub_cat_name,qcat.id as qat_id,qcat.parent,que.slot,
              que.questionsummary,que.rightanswer,que.responsesummary 
              from mdl_quiz_attempts qa
              inner join mdl_question_attempts que on que.questionusageid = qa.uniqueid
              inner join mdl_question q on que.questionid = q.id
              inner join mdl_question_categories qcat on q.category = qcat.id
              where qa.quiz='".$value->quiz_id."' and qa.userid='".$user_id."' AND q.category ='".$subsubcatid."'";
              // WHERE qs.quizid = '".$value->quiz_id."' AND quec.id = '".$subsubcatid."'";
                // echo $quecountsql.' -- ';
              $quecountres = $DB->get_records_sql($quecountsql);

              foreach ($quecountres as $key => $value4) {
                  $queid .= $prefix.''.$value4->qid;
                  $prefix = ', ';
              }          
           }         
         }
      } 

      $queidarr = explode(' ', $queid);
      $totalcatscore = count($queidarr);
      
      $topic = trim($topic, '.');

      $dailypoints['myPerformance'][]=[
      'activity' => $topic,
      'count' => $topic_score,
      'total' => $topic_score.' / '.$totalcatscore*5,
      'type' => 'row',
      'ctype' => 'T'
      ];

      // category-------------

      $sqla1="SELECT id, cat_id, cat_name, quiz_id, 
      sum(distinct cat_score) as cat_score, topic_score 
      FROM 
      mdl_sat_ass_score_report_new1
      WHERE mspin = $mspin AND quiz_id = $quiz_id AND topic_id = $topic_id group by cat_id";
      // echo $sqla1 . " --/n-- ";
      $atabs1 = $DB->get_records_sql($sqla1);  

      // $nomofcat = count($atabs1);  
      // $totalcatscore1 = 30/$nomofcat;
      // $totalcatscore1 = intval($totalcatscore1);
      // echo $nomofcat.' '; 
         
      $cat_details = array();
      // $cat_id = $prefix = '';    
        foreach ($atabs1 as $key => $value1) {      
         $cat_name  = $value1->cat_name;
         $cat_score = $value1->cat_score;
         $cat_id    = $value1->cat_id;
         
         $subcatsql = "SELECT id, parent FROM mdl_question_categories where parent = '".$cat_id ."'";
         $subcatres = $DB->get_records_sql($subcatsql);
         $queid = $prefix = '';
         foreach ($subcatres as $key => $value2) {
           $subcatid = $value2->id;         
           $subsubcatsql = "SELECT id, parent FROM mdl_question_categories where parent = '".$subcatid ."'";
           $subsubcatres = $DB->get_records_sql($subsubcatsql);
           foreach ($subsubcatres as $key => $value3) {
             $subsubcatid = $value3->id;
             // echo $subsubcatid;
             $quecountsql = "SELECT q.id as qid,qa.userid,qa.quiz,q.category,qcat.name as sub_cat_name,qcat.id as qat_id,qcat.parent,que.slot,
                que.questionsummary,que.rightanswer,que.responsesummary 
                from mdl_quiz_attempts qa
                inner join mdl_question_attempts que on que.questionusageid = qa.uniqueid
                inner join mdl_question q on que.questionid = q.id
                inner join mdl_question_categories qcat on q.category = qcat.id
                where qa.quiz='".$value->quiz_id."' and qa.userid='".$user_id."' AND q.category ='".$subsubcatid."'";
              // WHERE qs.quizid = '".$value->quiz_id."' AND quec.id = '".$subsubcatid."'";
                // echo $quecountsql.' -- ';
              $quecountres = $DB->get_records_sql($quecountsql);

              foreach ($quecountres as $key => $value4) {
                  $queid .= $prefix.''.$value4->qid;
                  $prefix = ', ';
              }          
           }         
         }  
         $queidarr = explode(' ', $queid);
         $totalcatscore = count($queidarr);   
         // print_r($queidarr);

         if($value1->quiz_id == 176 || $value1->quiz_id == 177 || $value1->quiz_id == 178 || $value1->quiz_id == 179){
          $cat_name = $topic.' - '.$cat_name;
         }else{
          $cat_name  = $value1->cat_name;
         }
                

         if($value1->quiz_id == 126){
          
         }
         else{
          $dailypoints['myPerformance'][]=[
            'activity' => $cat_name,
            'count' => $cat_score,
            'total' => $cat_score.' / '.$totalcatscore*5,
            'type' => 'row',
            'ctype' => 'C'
          ];
         }              
       }
       
    }
    
    // $sqla1="SELECT id, cat_id, cat_name, 
    // sum(distinct cat_score) as cat_score, topic_score 
    // FROM 
    // mdl_sat_ass_score_report_new1
    // WHERE mspin = $mspin AND quiz_id = $quiz_id group by cat_name";
    // // echo $sqla1 . " --/n-- ";
    // $atabs1 = $DB->get_records_sql($sqla1);    
       
    // $cat_details = array();
    // foreach ($atabs1 as $key => $value1) {      
    //    $cat_name = $value1->cat_name;
    //    $cat_score = $value1->cat_score;

    //     $dailypoints['myPerformance'][]=[
    //       'activity' => $cat_name,
    //       'count' => $cat_score,
    //       'total' => $cat_score,
    //       'type' => 'row',
    //       'ctype' => 'C'
    //     ];      
    //  }

     // $sqla2="SELECT id, sub_cat_id, sub_cat_name, 
     //  sum(distinct sub_cat_score) as sub_cat_score
     //  FROM 
     //  mdl_sat_ass_score_report_new1
     //  WHERE mspin = $mspin AND quiz_id = $quiz_id group by sub_cat_name";
     //  // echo $sqla2.' --- ';
     //  $atabs2 = $DB->get_records_sql($sqla2);
     //  $sub_cat_details = array();
     //  foreach ($atabs2 as $key => $value2) {
     //      $sub_cat_name = $value2->sub_cat_name;
     //      $sub_cat_score = $value2->sub_cat_score;
          
     //      $sqlsub = "Select id FROM mdl_sat_ass_score_report_new1 
     //      WHERE mspin = '".$mspin."' AND quiz_id = '".$quiz_id."' AND sub_cat_name = '".$sub_cat_name."' group by cat_name, sub_cat_name";
     //      $listImp=[];
     //      $RSUB=$DB->get_records_sql($sqlsub);
     //      foreach($RSUB as $key => $valuef){
     //        $listImp[$valuef->id]=$valuef->id;
     //      }
     //      $listImp=implode(',', $listImp);
     //      $sqlsub1 = "SELECT sub_cat_name, sum(sub_cat_score) AS scorefinaly
     //      FROM mdl_sat_ass_score_report_new1 WHERE id IN($listImp)";
     //      $RSUB1=$DB->get_record_sql($sqlsub1);
     //      $dailypoints['myPerformance'][]=[
     //        'activity' => $sub_cat_name,
     //        'count' => $RSUB1->scorefinaly,
     //        'total' => $RSUB1->scorefinaly,
     //        'type' => 'row',
     //        'ctype' => 'SC'
     //      ];         
     //  }

      // print_r($dailypoints1); die;
      // $sqla3="SELECT id, sub_sub_cat_id, sub_sub_cat_name, topic_score,
      //   sum(sub_sub_cat_score) as sub_sub_cat_score
      //   FROM 
      //   mdl_sat_ass_score_report_new1
      //   WHERE mspin = $mspin AND quiz_id = $quiz_id  AND sub_sub_cat_id != '-'  GROUP BY sub_sub_cat_name";
      //   $atabs3 = $DB->get_records_sql($sqla3);
      //   // echo $sqla3.' ---- ';
      //   $sub_sub_cat_details = array();
      //   foreach ($atabs3 as $key => $value3) {
      //     $sub_sub_cat_id = $value3->sub_sub_cat_id;
      //     $sub_sub_cat_name = $value3->sub_sub_cat_name;
      //     $sub_sub_cat_score = $value3->sub_sub_cat_score; 

      //     $dailypoints['myPerformance'][]=[
      //      'activity' => $sub_sub_cat_name,
      //      'count' => $sub_sub_cat_score,
      //      'total' => $sub_sub_cat_score,
      //      'type' => 'row',
      //      'ctype' => 'SSC'
      //     ];
      //   }
  }
// print_r($dailypoints);
  $dailypoints['status']=true;

  // print_r($dailypoints); die;
  return $dailypoints;
}

public function satPerformancePoint_returns(){
  return new external_single_structure(
    array(
      'status'=> new external_value(PARAM_RAW, 'status'),            
      'myPerformance' => new external_multiple_structure(
         new external_single_structure(
          array(
            'activity'           => new external_value(PARAM_RAW, 'activity'),
            'count'              => new external_value(PARAM_INT, 'count'),
            'total'              => new external_value(PARAM_RAW, 'count'),
            'type'               => new external_value(PARAM_RAW, 'type'),
            'ctype'              => new external_value(PARAM_RAW, 'ctype')          
          )
        )
      )
    )
  );
}
###END SAT PERFORMANCE  


###START MY PERFORMANCE
public function myPerformancePoint_parameters(){
  return new external_function_parameters(
    array(
      'mspin' => new external_value(PARAM_INT, 'mspin')
    )
  );  
}
public function myPerformancePoint($mspin){
  global $DB,$CFG,$USER;
  $dailypoints=[];
  $dailypoints['status']=false;
  $point=0;
  $dsql="SELECT 
  IFNULL(SUM(fr.daily_login_point), 0) AS total_dailypoint,
  IFNULL(SUM(fr.qod_bonus_point), 0) AS total_qodpoint,
  IFNULL(SUM(fr.course_bonus_point), 0) AS total_coursepoint,
  IFNULL(SUM(fr.assessment_bonus_point), 0) AS total_assessmentpoint,
  IFNULL(SUM(fr.survey_bonus_point), 0) AS total_surveypoint,
  IFNULL(SUM(fr.toptwenty_winner_point), 0) AS total_toptwenty_winner_point,
  IFNULL(SUM(fr.weekly_quiz_marks_point), 0) AS total_weekly_quiz_marks_point,
  fr.user_id
  FROM {gm_final_report} AS fr 
  INNER JOIN {ums_employeemaster} AS ums ON ums.userid=fr.user_id WHERE ums.code=$mspin GROUP BY fr.user_id";
  $dresult = $DB->get_record_sql($dsql);

  /*$dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Summery Points',
    'points'   =>0,
    'type'     =>'head'

  ];*/

  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Daily Points',
    'points'   =>$point+$dresult->total_dailypoint,
    'type'     =>'row'

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total QOD Points',
    'points'   =>$point+$dresult->total_qodpoint,
    'type'     =>'row'

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Course Points',
    'points'   =>$point+$dresult->total_coursepoint,
    'type'     =>'row'

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Assessment Points',
    'points'   =>$point+$dresult->total_assessmentpoint,
    'type'     =>'row'

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Survey Points',
    'points'   =>$point+$dresult->total_surveypoint,
    'type'     =>'row'

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Weekly Quiz Points',
    'points'   =>$point+$dresult->total_weekly_quiz_marks_point,
    'type'     =>'row'

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Points',
    'points'   =>$point+$dresult->total_surveypoint+$dresult->total_dailypoint+$dresult->total_qodpoint+$dresult->total_coursepoint+$dresult->total_assessmentpoint+$dresult->total_weekly_quiz_marks_point,
    'type'     =>'row'

  ];
/*  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Top20 Winner (open house) Points',
    'points'   =>$point+$dresult->total_toptwenty_winner_point

  ];*/

  // myDailyActivity
  $Total_assessment_enrolled= 0;
  $Total_course_enrolled= 0;
  $Total_survey_enrolled= 0;
  $Total_knc = 0;
  $Total_av = 0;

  $userrr_id01="SELECT * FROM mdl_ums_employeemaster WHERE code='".$mspin."'";

  $userrr_id02=$DB->get_record_sql($userrr_id01);

  $userrr_id = $userrr_id02->userid;
  //echo $userrr_id;exit;


  $sqlaaen01="SELECT count(ue.id) AS totalassess,ue.userid,c.id as cid,c.category, c.fullname
			from mdl_user_enrolments ue
			left join mdl_enrol en on en.id = ue.enrolid
			left join mdl_user u on u.id = ue.userid
			left join mdl_course c on c.id = en.courseid
			where c.visible=1 and ue.userid=$userrr_id and c.category=2";
   //echo $sqlaaen01;exit;
  $Taenrolledd01=$DB->get_record_sql($sqlaaen01);
  $Total_assessment_enrolled=$Total_assessment_enrolled+$Taenrolledd01->totalassess;

  $sql_course="SELECT count(ue.id) AS total_c,ue.userid,c.id as cid,c.category, c.fullname
			from mdl_user_enrolments ue
			left join mdl_enrol en on en.id = ue.enrolid
			left join mdl_user u on u.id = ue.userid
			left join mdl_course c on c.id = en.courseid
			where c.visible=1 and ue.userid=$userrr_id and c.category=3";
   //echo $sqlaaen01;exit;
  $res_course=$DB->get_record_sql($sql_course);
  $Total_course_enrolled=$Total_course_enrolled+$res_course->total_c;

  $sql_survey="SELECT count(ue.id) AS total_s,ue.userid,c.id as cid,c.category, c.fullname
			from mdl_user_enrolments ue
			left join mdl_enrol en on en.id = ue.enrolid
			left join mdl_user u on u.id = ue.userid
			left join mdl_course c on c.id = en.courseid
			where c.visible=1 and ue.userid=$userrr_id and c.category=11";
   //echo $sql_survey;exit;
  $res_survey=$DB->get_record_sql($sql_survey);
  $Total_survey_enrolled=$Total_survey_enrolled+$res_survey->total_s;

  	$knc_sql = "SELECT count(*) as total_knc FROM mdl_ums_knc_folder WHERE parent_id = 0 AND deleted=0";
	$result_knc = $DB->get_record_sql($knc_sql);
	$Total_knc=$Total_knc+$result_knc->total_knc;

	$av_sql = "SELECT count(*) as total_av FROM mdl_ums_av_folder WHERE parent_id = 1 AND deleted=0";
	$result_av = $DB->get_record_sql($av_sql);
	$Total_av=$Total_av+$result_av->total_av;


  //echo $Total_av;exit;

    $dailypoints['myDailyActivity'][]=['activity'=>'Course',
   'count'=>$Total_course_enrolled];
   $dailypoints['myDailyActivity'][]=['activity'=>'Assessment',
   'count'=>$Total_assessment_enrolled];
   $dailypoints['myDailyActivity'][]=['activity'=>'Digital Library',
   'count'=>$Total_knc];
   $dailypoints['myDailyActivity'][]=['activity'=>'Video Hub',
   'count'=>$Total_av];
   $dailypoints['myDailyActivity'][]=['activity'=>'Survey',
   'count'=>$Total_survey_enrolled];




  // end here

  $sqla="SELECT c.id, c.fullname as name, gm.bonus_point as points, gm.id as status  FROM 
  mdl_gm_assessment_attempt gm
  INNER JOIN 
  mdl_course c ON c.id = gm.course_id
  INNER JOIN
  mdl_ums_employeemaster emp ON emp.userid = gm.user_id
  WHERE emp.code = $mspin";
  $atabs = $DB->get_records_sql($sqla);
  $atabs = json_decode(json_encode($atabs), true);
  $dailypoints['Assessment_Tab']=array_values($atabs);

  $sqlc="SELECT c.id, c.fullname as name, gm.bonus_point as points, gm.id as status  FROM 
  mdl_gm_course_attempt gm
  INNER JOIN 
  mdl_course c ON c.id = gm.course_id
  INNER JOIN
  mdl_ums_employeemaster emp ON emp.userid = gm.user_id
  WHERE emp.code = $mspin";
  $ctabs = $DB->get_records_sql($sqlc);
  $ctabs = json_decode(json_encode($ctabs), true);
  $dailypoints['Course_Tab']=array_values($ctabs);

  $sqls="SELECT c.id, c.fullname as name, gm.bonus_point as points, gm.id as status  FROM 
  mdl_gm_survey_attempt gm
  INNER JOIN 
  mdl_course c ON c.id = gm.course_id
  INNER JOIN
  mdl_ums_employeemaster emp ON emp.userid = gm.user_id
  WHERE emp.code = $mspin";
  $stabs = $DB->get_records_sql($sqls);
  $stabs = json_decode(json_encode($stabs), true);
  $dailypoints['Survey_Tab']=array_values($stabs);

  ##for userInfo
  $sqlu="SELECT u.id as user_id, um.profile_photo_upload, d.d_name, o.o_name, o.o_code_latest, um.region_id, um.outlet_id, CONCAT(u.firstname, ' ', u.lastname) AS fullname, um.user_type_id
  FROM {ums_employeemaster} AS um 
  INNER JOIN mdl_user AS u ON um.userid=u.id
  INNER JOIN mdl_ums_designations AS d ON um.designation_id=d.id 
  LEFT  JOIN mdl_ums_outlet AS o ON um.outlet_id=o.id
  WHERE um.code=$mspin";
  $urslt=$DB->get_record_sql($sqlu);
  ##End for userInfo

 ##for Level Rank
  $ranksql="SELECT dealer_rank, region_rank, country_rank 
  FROM mdl_gm_gamification_activity_report WHERE user_id='".$USER->id."'";
  $uRankInfo= $DB->get_record_sql($ranksql);
##End for Level Rank
  $primg=$CFG->wwwroot.'/images/avatar1.png';
  if($urslt->profile_photo_upload){
   $primg=$CFG->wwwroot.'/upload/profile/'.$urslt->profile_photo_upload;
  }

  $rank=0;
  $dailypoints['Rank_Info'][]=[
    'rank'=>$rank+@$uRankInfo->country_rank,
    'name'=>$urslt->fullname,
    'userpic'=>$primg,
    'mspin'=>$mspin,
    'designation'=>@$urslt->d_name,
    'dealer_code'=>@$urslt->o_code_latest==""?"":$urslt->o_code_latest, 
    'dealer_name'=>@$urslt->o_name==""?"":$urslt->o_name,
    'level'=> 'Country Level Rank'
  ];
  $dailypoints['Rank_Info'][]=[
    'rank'=>$rank+@$uRankInfo->region_rank,
    'name'=>$urslt->fullname, 
    'userpic'=>$primg,
    'mspin'=>$mspin, 
    'designation'=>@$urslt->d_name,
    'dealer_code'=>@$urslt->o_code_latest==""?"":$urslt->o_code_latest, 
    'dealer_name'=>@$urslt->o_name==""?"":$urslt->o_name,
    'level'=> 'Region Level Rank'
  ];
if(@$urslt->user_type_id==""){
  $dailypoints['Rank_Info'][]=[
    'rank'=>$rank+@$uRankInfo->dealer_rank,
    'name'=>$urslt->fullname, 
    'userpic'=>$primg,
    'mspin'=>$mspin,    
    'designation'=>@$urslt->d_name,
    'dealer_code'=>@$urslt->o_code_latest==""?"":$urslt->o_code_latest, 
    'dealer_name'=>@$urslt->o_name==""?"":$urslt->o_name,
    'level'=> 'Dealer Level Rank'
  ];
}
##Myperformance
  ##course start
  $subsql="(SELECT 
  sb.value AS lession_status
  FROM
  mdl_scorm AS sa
  INNER JOIN
  mdl_scorm_scoes_track AS sb ON (sa.id = sb.scormid)
  WHERE
  sb.element = 'cmi.core.lesson_status'
  AND sb.attempt = 1
  AND (sb.value = 'completed'
  OR sb.value = 'passed'
  OR sb.value = 'failed'
  OR sb.value = 'incomplete')
  AND sb.userid = u.id
  AND sa.course = d.id
  ORDER BY sb.id DESC
  LIMIT 1) AS lession_status";
  $sqlcc="SELECT 
  a.id,
  $subsql
  FROM
  mdl_role_assignments AS a
  LEFT JOIN
  mdl_user AS u ON (a.userid = u.id)
  INNER JOIN
  mdl_ums_employeemaster AS emp ON (u.id = emp.userid)
  INNER JOIN
  mdl_context AS e ON (e.id = a.contextid
  AND e.contextlevel = 50)
  INNER JOIN
  mdl_course AS d ON (d.id = e.instanceid)
  WHERE
  u.id = $urslt->user_id AND d.category = 3";
  $rccc=$DB->get_records_sql($sqlcc);
  $Tenrolled=$Notstarted=$Tincomplted=$Tcomplted=0;
  if(@$rccc && count($rccc)>0){
    foreach($rccc as $key => $cc){
     if($cc->lession_status==""){
      $Notstarted=$Notstarted+1;
    }
    if($cc->lession_status=="passed" || $cc->lession_status=="completed"){
      $Tcomplted=$Tcomplted+1;
    }
    if($cc->lession_status=="incomplete"){
      $Tincomplted=$Tincomplted+1;
    }
  }
}
  $Tenrolled=$Notstarted+$Tcomplted+$Tincomplted;
  ##course end

  ##assessment start
  $Taenrolled=$Taincomplted=$Tacomplted=$aNotstarted=0;
  $sqlaaen="SELECT count(a.id) AS totalenroled 
            FROM mdl_role_assignments a
            INNER JOIN mdl_user u on a.userid=u.id
            INNER JOIN mdl_ums_employeemaster emp on u.id=emp.userid
            INNER JOIN mdl_context e ON e.id = a.contextid
            INNER JOIN mdl_course  d ON d.id=e.instanceid
            WHERE u.deleted=0 AND u.id = $urslt->user_id AND d.category = 2 AND e.contextlevel=50";
  $Taenrolledd=$DB->get_record_sql($sqlaaen);
  $Taenrolled=$Taenrolled+$Taenrolledd->totalenroled;

  /*$sqlaincom="SELECT count(id) as taincomp FROM mdl_quiz_attempts 
            WHERE userid=$urslt->user_id AND quiz IN(SELECT q.id
            FROM mdl_role_assignments a
            INNER JOIN mdl_user u on a.userid=u.id
            INNER JOIN mdl_ums_employeemaster emp on u.id=emp.userid
            INNER JOIN mdl_context e ON e.id = a.contextid
            INNER JOIN mdl_course  d ON d.id=e.instanceid
            INNER JOIN mdl_quiz q ON d.id=q.course
            WHERE u.deleted=0 AND u.id = $urslt->user_id AND d.category = 2 AND e.contextlevel=50 AND d.visible = 1) 
            AND state IN('inprogress', 'abandoned') GROUP BY quiz ORDER BY attempt DESC";*/
            $sqlaaa="SELECT CONCAT((SELECT state
            FROM mdl_quiz_attempts AS a
            INNER JOIN mdl_user AS b ON(a.userid=b.id)
            INNER JOIN mdl_role_assignments as ra ON ra.userid=b.id
            INNER JOIN mdl_context e ON e.id = ra.contextid
            INNER JOIN mdl_ums_employeemaster emp ON emp.userid = b.id
            WHERE a.quiz=q.id AND a.userid =$urslt->user_id ORDER BY a.attempt DESC LIMIT 1),'-', c.id) AS state FROM mdl_course c
            INNER JOIN 
            mdl_quiz q ON c.id=q.course
            WHERE c.category = 2";       
            $raaa=$DB->get_records_sql($sqlaaa);
            if(@$raaa && count($raaa)>0){
              foreach($raaa as $key => $aa){
               $aa=explode('-', $aa->state);
               if(@$aa[0]=='inprogress'){
                $Taincomplted=$Taincomplted+1;
              }
              if(@$aa[0]=='finished'){
                $Tacomplted=$Tacomplted+1;
              }
            }
          }
  $aNotstarted=$Taenrolled-($Tacomplted+$Taincomplted);
  ##assessment end
  ##survey start
  $Tsenrolled=$Tscomplted=$sNotcompleted=$sNotstarted=0;
  $tsenrollssql="SELECT d.id, a.id as userid FROM
  mdl_user AS a
  INNER JOIN
  mdl_role_assignments AS b ON (b.userid = a.id)
  INNER JOIN
  mdl_context AS c ON (c.id = b.contextid
  AND c.contextlevel = 50)
  INNER JOIN
  mdl_course AS d ON (d.id = c.instanceid)
  INNER JOIN
  mdl_course_categories AS cat ON cat.id = d.category
  INNER JOIN
  mdl_user_enrolments AS en ON (en.userid = b.userid
  AND en.enrolid IN (SELECT id FROM mdl_enrol WHERE courseid = d.id))
  INNER JOIN
  mdl_ums_employeemaster AS ums ON ums.userid = en.userid
  WHERE
  a.username != 'guest' AND a.id > 2
  AND a.suspended = 0
  AND a.deleted = 0
  AND d.category != 0
  -- AND d.visible = 1
  -- AND d.is_kca = 0
  AND cat.id = 11
  AND a.id = $urslt->user_id";
  $alls=$DB->get_records_sql($tsenrollssql);
  $Tsenrolled=@count($alls);
  foreach($alls as $key => $s){
    $surveyid   = $DB->get_field('questionnaire', 'id', ['course'=>$s->id]);
    $rid        = $DB->get_field('questionnaire_response','id',['userid'=>@$s->userid, 'survey_id'=>@$surveyid]);
    $response   = $DB->get_record('questionnaire_response', ['id'=>$rid]);
    if(isset($response->complete) && @$response->complete== 'y'){
      $Tscomplted=$Tscomplted+1;
    }else{ 
      $sNotcompleted=$sNotcompleted+1;
    }
  }
  ##survey end
  ##Myperformance
  $year = date('Y');
  $allotedq = $DB->get_record_sql("SELECT count(*) as alloted FROM mdl_question_of_day WHERE qdate IN ($year)");
  $allotedcount = $allotedq->alloted;

  $attemptedq = $DB->get_record_sql("SELECT count(*) AS attempt FROM mdl_question_user_answer WHERE year(qviewdate) IN($year) AND userid=$urslt->user_id");
  $attempted = $attemptedq->attempt;

  $inattemptedscore = $DB->get_record_sql("SELECT count(*) AS score FROM mdl_question_user_answer WHERE year(qviewdate) IN($year)  AND userid=$urslt->user_id AND is_correct = 0");
  $incorrect = $inattemptedscore->score;

  $attemptedscore = $DB->get_record_sql("SELECT count(*) AS score FROM mdl_question_user_answer WHERE year(qviewdate) IN($year)  AND userid=$urslt->user_id AND is_correct = 1");
  $correct = $attemptedscore->score;

  #weekly quiz point
  $totalQuiz=$totalattemptQuiz=$totalCorrectQuiz=$totalWrongQuiz=0;
  //echo "SELECT * FROM mdl_gm_weekly_quiz_attempt_report WHERE user_id=$urslt->user_id";exit;
  $allotquiz = $DB->get_record_sql("SELECT * FROM mdl_gm_weekly_quiz_attempt_report WHERE user_id=$urslt->user_id");
  $totalQuiz = $totalQuiz+$allotquiz->total_question;
  $totalattemptQuiz = $totalattemptQuiz+$allotquiz->correct_answer+$allotquiz->wrong_answer;
  $totalCorrectQuiz = $totalCorrectQuiz+$allotquiz->correct_answer;
  $totalWrongQuiz = $totalWrongQuiz+$allotquiz->wrong_answer;


  $dailypoints['myPerformance'][]=['activity'=>'Course Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Enrolled', 
  'count'=>$Tenrolled , 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Not Started', 
  'count'=>@$Notstarted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Incomplete', 
  'count'=>@$Tincomplted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Completed', 
  'count'=>@$Tcomplted, 'type'=>'row'];

  $dailypoints['myPerformance'][]=['activity'=>'Assessment Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Enrolled', 
  'count'=>@$Taenrolled, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Not Started', 
  'count'=>@$aNotstarted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Incomplete', 
  'count'=>@$Taincomplted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Completed', 
  'count'=>@$Tacomplted, 'type'=>'row'];

  $dailypoints['myPerformance'][]=['activity'=>'Survey Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Enrolled', 
  'count'=>@$Tsenrolled, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Not Started', 
  'count'=>@$sNotcompleted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Completed', 
  'count'=>@$Tscomplted, 'type'=>'row'];

  $dailypoints['myPerformance'][]=['activity'=>'QOD Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Allotted', 
  'count'=>@$allotedcount, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Attempted', 
  'count'=>@$attempted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Correct', 
  'count'=>@$correct, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Incorrect', 
  'count'=>@$incorrect, 'type'=>'row'];
  $dailypoints['status']=true;

  $dailypoints['myPerformance'][]=['activity'=>'Weekly Quiz Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Allotted', 
  'count'=>@$totalQuiz, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Attempted', 
  'count'=>@$totalattemptQuiz, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Correct', 
  'count'=>@$totalCorrectQuiz, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Incorrect', 
  'count'=>@$totalWrongQuiz, 'type'=>'row'];
  $dailypoints['status']=true;

  return $dailypoints;
}
public function myPerformancePoint_returns(){
  return new external_single_structure(
    array(
      'status'=> new external_value(PARAM_RAW, 'status'),
      'Summary_Tab' => new external_multiple_structure(
        new external_single_structure(
        array(
          'activity'     => new external_value(PARAM_RAW, 'activity'),
          'points'       => new external_value(PARAM_INT, 'points'),
          'type'         => new external_value(PARAM_RAW, 'type')
        )
      )
      ),
      'myDailyActivity' => new external_multiple_structure(
        new external_single_structure(
        array(
          'activity'     => new external_value(PARAM_RAW, 'activity'),
          'count'       => new external_value(PARAM_INT, 'count')
        )
      )
      ), 
      'Course_Tab' => new external_multiple_structure(
        new external_single_structure(
        array(
          'name'     => new external_value(PARAM_RAW, 'name'),
          'points'       => new external_value(PARAM_INT, 'points'),
          'status'       => new external_value(PARAM_RAW, 'status')
        )
      )
      ), 
      'Assessment_Tab' => new external_multiple_structure(
        new external_single_structure(
        array(
          'name'     => new external_value(PARAM_RAW, 'name'),
          'points'       => new external_value(PARAM_INT, 'points'),
          'status'       => new external_value(PARAM_RAW, 'status')
        )
      )
      ),
      'Survey_Tab' => new external_multiple_structure(
        new external_single_structure(
        array(
          'name'     => new external_value(PARAM_RAW, 'name'),
          'points'       => new external_value(PARAM_INT, 'points'),
          'status'       => new external_value(PARAM_RAW, 'status')
        )
      )
      ),
      'Rank_Info' => new external_multiple_structure(
       new external_single_structure(
        array(
          'rank'       =>  new external_value(PARAM_INT, 'rank'),
          'name'       =>  new external_value(PARAM_RAW, 'name'),
          'mspin'      =>  new external_value(PARAM_RAW, 'mspin'),
          'userpic'    =>  new external_value(PARAM_RAW, 'userpic'),
          'designation'=>  new external_value(PARAM_RAW, 'designation'),
          'dealer_code'=>  new external_value(PARAM_RAW, 'dealer_code'), 
          'dealer_name'=>  new external_value(PARAM_RAW, 'dealer_name'),
          'level'   => new external_value(PARAM_RAW, 'level')
        )
      )
     ),
      'myPerformance' => new external_multiple_structure(
       new external_single_structure(
        array(
          'activity'     => new external_value(PARAM_RAW, 'activity'),
          'count'        => new external_value(PARAM_INT, 'count'),
          'type'         => new external_value(PARAM_RAW, 'type')
        )
      )
     )
    )
  );
}
###END MY PERFORMANCE

###START MY PERFORMANCE - UPDATED
public function myPerformancePoint_updated_parameters(){
  return new external_function_parameters(
    array(
      'mspin' => new external_value(PARAM_INT, 'mspin')
    )
  );  
}
public function myPerformancePoint_updated($mspin){
  global $DB,$CFG,$USER;
  $dailypoints=[];
  $dailypoints['status']=false;
  $point=0;
  $dsql="SELECT 
  IFNULL(SUM(fr.daily_login_point), 0) AS total_dailypoint,
  IFNULL(SUM(fr.qod_bonus_point), 0) AS total_qodpoint,
  IFNULL(SUM(fr.course_bonus_point), 0) AS total_coursepoint,
  IFNULL(SUM(fr.assessment_bonus_point), 0) AS total_assessmentpoint,
  IFNULL(SUM(fr.survey_bonus_point), 0) AS total_surveypoint,
  IFNULL(SUM(fr.toptwenty_winner_point), 0) AS total_toptwenty_winner_point,
  IFNULL(SUM(fr.weekly_quiz_marks_point), 0) AS total_weekly_quiz_marks_point,
  fr.user_id
  FROM {gm_final_report} AS fr 
  INNER JOIN {ums_employeemaster} AS ums ON ums.userid=fr.user_id WHERE ums.code=$mspin GROUP BY fr.user_id";
  $dresult = $DB->get_record_sql($dsql);

  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Daily Points',
    'points'   =>$point+$dresult->total_dailypoint,
    'type'     =>'row'

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total QOD Points',
    'points'   =>$point+$dresult->total_qodpoint,
    'type'     =>'row'

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Course Points',
    'points'   =>$point+$dresult->total_coursepoint,
    'type'     =>'row'

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Assessment Points',
    'points'   =>$point+$dresult->total_assessmentpoint,
    'type'     =>'row'

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Survey Points',
    'points'   =>$point+$dresult->total_surveypoint,
    'type'     =>'row'

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Weekly Quiz Points',
    'points'   =>$point+$dresult->total_weekly_quiz_marks_point,
    'type'     =>'row'

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Points',
    'points'   =>$point+$dresult->total_surveypoint+$dresult->total_dailypoint+$dresult->total_qodpoint+$dresult->total_coursepoint+$dresult->total_assessmentpoint+$dresult->total_weekly_quiz_marks_point,
    'type'     =>'row'

  ];

  // myDailyActivity
  $Total_assessment_enrolled= 0;
  $Total_course_enrolled= 0;
  $Total_survey_enrolled= 0;
  $Total_knc = 0;
  $Total_av = 0;

  $userrr_id01="SELECT * FROM mdl_ums_employeemaster WHERE code='".$mspin."'";
  $userrr_id02=$DB->get_record_sql($userrr_id01);
  $userrr_id = $userrr_id02->userid;
  

  $sqlaaen01="SELECT count(ue.id) AS totalassess,ue.userid,c.id as cid,c.category, c.fullname
      from mdl_user_enrolments ue
      left join mdl_enrol en on en.id = ue.enrolid
      left join mdl_user u on u.id = ue.userid
      left join mdl_course c on c.id = en.courseid
      where c.visible=1 and ue.userid=$userrr_id and c.category=2";
  $Taenrolledd01=$DB->get_record_sql($sqlaaen01);
  $Total_assessment_enrolled=$Total_assessment_enrolled+$Taenrolledd01->totalassess;

  $sql_course="SELECT count(ue.id) AS total_c,ue.userid,c.id as cid,c.category, c.fullname
      from mdl_user_enrolments ue
      left join mdl_enrol en on en.id = ue.enrolid
      left join mdl_user u on u.id = ue.userid
      left join mdl_course c on c.id = en.courseid
      where c.visible=1 and ue.userid=$userrr_id and c.category=3";
  $res_course=$DB->get_record_sql($sql_course);
  $Total_course_enrolled=$Total_course_enrolled+$res_course->total_c;

  $sql_survey="SELECT count(ue.id) AS total_s,ue.userid,c.id as cid,c.category, c.fullname
      from mdl_user_enrolments ue
      left join mdl_enrol en on en.id = ue.enrolid
      left join mdl_user u on u.id = ue.userid
      left join mdl_course c on c.id = en.courseid
      where c.visible=1 and ue.userid=$userrr_id and c.category=11";
  $res_survey=$DB->get_record_sql($sql_survey);
  $Total_survey_enrolled=$Total_survey_enrolled+$res_survey->total_s;

    $knc_sql = "SELECT count(*) as total_knc FROM mdl_ums_knc_folder WHERE parent_id = 0 AND deleted=0";
  $result_knc = $DB->get_record_sql($knc_sql);
  $Total_knc=$Total_knc+$result_knc->total_knc;

  $av_sql = "SELECT count(*) as total_av FROM mdl_ums_av_folder WHERE parent_id = 1 AND deleted=0";
  $result_av = $DB->get_record_sql($av_sql);
  $Total_av=$Total_av+$result_av->total_av;

  $dailypoints['myDailyActivity'][]=['activity'=>'Course',
   'count'=>$Total_course_enrolled];
  $dailypoints['myDailyActivity'][]=['activity'=>'Assessment',
   'count'=>$Total_assessment_enrolled];
  $dailypoints['myDailyActivity'][]=['activity'=>'Digital Library',
   'count'=>$Total_knc];
  $dailypoints['myDailyActivity'][]=['activity'=>'Video Hub',
   'count'=>$Total_av];
  $dailypoints['myDailyActivity'][]=['activity'=>'Survey',
   'count'=>$Total_survey_enrolled];

  // end here
  $sqla="SELECT c.id, c.fullname as name, gm.bonus_point as points, gm.id as status  FROM 
  mdl_gm_assessment_attempt gm
  INNER JOIN 
  mdl_course c ON c.id = gm.course_id
  INNER JOIN
  mdl_ums_employeemaster emp ON emp.userid = gm.user_id
  WHERE emp.code = $mspin";
  $atabs = $DB->get_records_sql($sqla);
  $atabs = json_decode(json_encode($atabs), true);
  $dailypoints['Assessment_Tab']=array_values($atabs);

  $sqlc="SELECT c.id, c.fullname as name, gm.bonus_point as points, gm.id as status  FROM 
  mdl_gm_course_attempt gm
  INNER JOIN 
  mdl_course c ON c.id = gm.course_id
  INNER JOIN
  mdl_ums_employeemaster emp ON emp.userid = gm.user_id
  WHERE emp.code = $mspin";
  $ctabs = $DB->get_records_sql($sqlc);
  $ctabs = json_decode(json_encode($ctabs), true);
  $dailypoints['Course_Tab']=array_values($ctabs);

  $sqls="SELECT c.id, c.fullname as name, gm.bonus_point as points, gm.id as status  FROM 
  mdl_gm_survey_attempt gm
  INNER JOIN 
  mdl_course c ON c.id = gm.course_id
  INNER JOIN
  mdl_ums_employeemaster emp ON emp.userid = gm.user_id
  WHERE emp.code = $mspin";
  $stabs = $DB->get_records_sql($sqls);
  $stabs = json_decode(json_encode($stabs), true);
  $dailypoints['Survey_Tab']=array_values($stabs);

  ##for userInfo
  $sqlu="SELECT u.id as user_id, um.profile_photo_upload, d.d_name, o.o_name, o.o_code_latest, um.region_id, um.outlet_id, CONCAT(u.firstname, ' ', u.lastname) AS fullname, um.user_type_id
  FROM {ums_employeemaster} AS um 
  INNER JOIN mdl_user AS u ON um.userid=u.id
  INNER JOIN mdl_ums_designations AS d ON um.designation_id=d.id 
  LEFT  JOIN mdl_ums_outlet AS o ON um.outlet_id=o.id
  WHERE um.code=$mspin";
  $urslt=$DB->get_record_sql($sqlu);
  ##End for userInfo

 ##for Level Rank
  $ranksql="SELECT dealer_rank, region_rank, country_rank 
  FROM mdl_gm_gamification_activity_report WHERE user_id='".$USER->id."'";
  $uRankInfo= $DB->get_record_sql($ranksql);
##End for Level Rank
  $primg=$CFG->wwwroot.'/images/avatar1.png';
  if($urslt->profile_photo_upload){
   $primg=$CFG->wwwroot.'/upload/profile/'.$urslt->profile_photo_upload;
  }

  $rank=0;
  $dailypoints['Rank_Info'][]=[
    'rank'=>$rank+@$uRankInfo->country_rank,
    'name'=>$urslt->fullname,
    'userpic'=>$primg,
    'mspin'=>$mspin,
    'designation'=>@$urslt->d_name,
    'dealer_code'=>@$urslt->o_code_latest==""?"":$urslt->o_code_latest, 
    'dealer_name'=>@$urslt->o_name==""?"":$urslt->o_name,
    'level'=> 'Country Level Rank'
  ];
  $dailypoints['Rank_Info'][]=[
    'rank'=>$rank+@$uRankInfo->region_rank,
    'name'=>$urslt->fullname, 
    'userpic'=>$primg,
    'mspin'=>$mspin, 
    'designation'=>@$urslt->d_name,
    'dealer_code'=>@$urslt->o_code_latest==""?"":$urslt->o_code_latest, 
    'dealer_name'=>@$urslt->o_name==""?"":$urslt->o_name,
    'level'=> 'Region Level Rank'
  ];
if(@$urslt->user_type_id==""){
  $dailypoints['Rank_Info'][]=[
    'rank'=>$rank+@$uRankInfo->dealer_rank,
    'name'=>$urslt->fullname, 
    'userpic'=>$primg,
    'mspin'=>$mspin,    
    'designation'=>@$urslt->d_name,
    'dealer_code'=>@$urslt->o_code_latest==""?"":$urslt->o_code_latest, 
    'dealer_name'=>@$urslt->o_name==""?"":$urslt->o_name,
    'level'=> 'Dealer Level Rank'
  ];
}
##Myperformance
  ##course start
  $subsql="(SELECT 
  sb.value AS lession_status
  FROM
  mdl_scorm AS sa
  INNER JOIN
  mdl_scorm_scoes_track AS sb ON (sa.id = sb.scormid)
  WHERE
  sb.element = 'cmi.core.lesson_status'
  AND sb.attempt = 1
  AND (sb.value = 'completed'
  OR sb.value = 'passed'
  OR sb.value = 'failed'
  OR sb.value = 'incomplete')
  AND sb.userid = u.id
  AND sa.course = d.id
  ORDER BY sb.id DESC
  LIMIT 1) AS lession_status";
  $sqlcc="SELECT 
  a.id,
  $subsql
  FROM
  mdl_role_assignments AS a
  LEFT JOIN
  mdl_user AS u ON (a.userid = u.id)
  INNER JOIN
  mdl_ums_employeemaster AS emp ON (u.id = emp.userid)
  INNER JOIN
  mdl_context AS e ON (e.id = a.contextid
  AND e.contextlevel = 50)
  INNER JOIN
  mdl_course AS d ON (d.id = e.instanceid)
  WHERE
  u.id = $urslt->user_id AND d.category = 3";
  $rccc=$DB->get_records_sql($sqlcc);
  $Tenrolled=$Notstarted=$Tincomplted=$Tcomplted=0;
  if(@$rccc && count($rccc)>0){
    foreach($rccc as $key => $cc){
     if($cc->lession_status==""){
      $Notstarted=$Notstarted+1;
    }
    if($cc->lession_status=="passed" || $cc->lession_status=="completed"){
      $Tcomplted=$Tcomplted+1;
    }
    if($cc->lession_status=="incomplete"){
      $Tincomplted=$Tincomplted+1;
    }
  }
}
  $Tenrolled=$Notstarted+$Tcomplted+$Tincomplted;
  ##course end

  ##assessment start
  $Taenrolled=$Taincomplted=$Tacomplted=$aNotstarted=0;
  $sqlaaen="SELECT count(a.id) AS totalenroled 
            FROM mdl_role_assignments a
            INNER JOIN mdl_user u on a.userid=u.id
            INNER JOIN mdl_ums_employeemaster emp on u.id=emp.userid
            INNER JOIN mdl_context e ON e.id = a.contextid
            INNER JOIN mdl_course  d ON d.id=e.instanceid
            WHERE u.deleted=0 AND u.id = $urslt->user_id AND d.category = 2 AND e.contextlevel=50";
  $Taenrolledd=$DB->get_record_sql($sqlaaen);
  $Taenrolled=$Taenrolled+$Taenrolledd->totalenroled;

            $sqlaaa="SELECT CONCAT((SELECT state
            FROM mdl_quiz_attempts AS a
            INNER JOIN mdl_user AS b ON(a.userid=b.id)
            INNER JOIN mdl_role_assignments as ra ON ra.userid=b.id
            INNER JOIN mdl_context e ON e.id = ra.contextid
            INNER JOIN mdl_ums_employeemaster emp ON emp.userid = b.id
            WHERE a.quiz=q.id AND a.userid =$urslt->user_id ORDER BY a.attempt DESC LIMIT 1),'-', c.id) AS state FROM mdl_course c
            INNER JOIN 
            mdl_quiz q ON c.id=q.course
            WHERE c.category = 2";       
            $raaa=$DB->get_records_sql($sqlaaa);
            if(@$raaa && count($raaa)>0){
              foreach($raaa as $key => $aa){
               $aa=explode('-', $aa->state);
               if(@$aa[0]=='inprogress'){
                $Taincomplted=$Taincomplted+1;
              }
              if(@$aa[0]=='finished'){
                $Tacomplted=$Tacomplted+1;
              }
            }
          }
  $aNotstarted=$Taenrolled-($Tacomplted+$Taincomplted);
  ##assessment end
  ##survey start
  $Tsenrolled=$Tscomplted=$sNotcompleted=$sNotstarted=0;
  $tsenrollssql="SELECT d.id, a.id as userid FROM
  mdl_user AS a
  INNER JOIN
  mdl_role_assignments AS b ON (b.userid = a.id)
  INNER JOIN
  mdl_context AS c ON (c.id = b.contextid
  AND c.contextlevel = 50)
  INNER JOIN
  mdl_course AS d ON (d.id = c.instanceid)
  INNER JOIN
  mdl_course_categories AS cat ON cat.id = d.category
  INNER JOIN
  mdl_user_enrolments AS en ON (en.userid = b.userid
  AND en.enrolid IN (SELECT id FROM mdl_enrol WHERE courseid = d.id))
  INNER JOIN
  mdl_ums_employeemaster AS ums ON ums.userid = en.userid
  WHERE
  a.username != 'guest' AND a.id > 2
  AND a.suspended = 0
  AND a.deleted = 0
  AND d.category != 0
  -- AND d.visible = 1
  -- AND d.is_kca = 0
  AND cat.id = 11
  AND a.id = $urslt->user_id";
  $alls=$DB->get_records_sql($tsenrollssql);
  $Tsenrolled=@count($alls);
  foreach($alls as $key => $s){
    $surveyid   = $DB->get_field('questionnaire', 'id', ['course'=>$s->id]);
    $rid        = $DB->get_field('questionnaire_response','id',['userid'=>@$s->userid, 'survey_id'=>@$surveyid]);
    $response   = $DB->get_record('questionnaire_response', ['id'=>$rid]);
    if(isset($response->complete) && @$response->complete== 'y'){
      $Tscomplted=$Tscomplted+1;
    }else{ 
      $sNotcompleted=$sNotcompleted+1;
    }
  }
  ##survey end
  ##Myperformance
  $year = date('Y');
  $allotedq = $DB->get_record_sql("SELECT count(*) as alloted FROM mdl_question_of_day WHERE qdate IN ($year)");
  $allotedcount = $allotedq->alloted;

  $attemptedq = $DB->get_record_sql("SELECT count(*) AS attempt FROM mdl_question_user_answer WHERE year(qviewdate) IN($year) AND userid=$urslt->user_id");
  $attempted = $attemptedq->attempt;

  $inattemptedscore = $DB->get_record_sql("SELECT count(*) AS score FROM mdl_question_user_answer WHERE year(qviewdate) IN($year)  AND userid=$urslt->user_id AND is_correct = 0");
  $incorrect = $inattemptedscore->score;

  $attemptedscore = $DB->get_record_sql("SELECT count(*) AS score FROM mdl_question_user_answer WHERE year(qviewdate) IN($year)  AND userid=$urslt->user_id AND is_correct = 1");
  $correct = $attemptedscore->score;

  #weekly quiz point
  $totalQuiz=$totalattemptQuiz=$totalCorrectQuiz=$totalWrongQuiz=0;
  $allotquiz = $DB->get_record_sql("SELECT * FROM mdl_gm_weekly_quiz_attempt_report WHERE user_id=$urslt->user_id");
  $totalQuiz = $totalQuiz+$allotquiz->total_question;
  $totalattemptQuiz = $totalattemptQuiz+$allotquiz->correct_answer+$allotquiz->wrong_answer;
  $totalCorrectQuiz = $totalCorrectQuiz+$allotquiz->correct_answer;
  $totalWrongQuiz = $totalWrongQuiz+$allotquiz->wrong_answer;


  $dailypoints['myPerformance'][]=['activity'=>'Course Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Enrolled', 
  'count'=>$Tenrolled , 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Not Started', 
  'count'=>@$Notstarted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Incomplete', 
  'count'=>@$Tincomplted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Completed', 
  'count'=>@$Tcomplted, 'type'=>'row'];

  $dailypoints['myPerformance'][]=['activity'=>'Assessment Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Enrolled', 
  'count'=>@$Taenrolled, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Not Started', 
  'count'=>@$aNotstarted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Incomplete', 
  'count'=>@$Taincomplted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Completed', 
  'count'=>@$Tacomplted, 'type'=>'row'];

  $dailypoints['myPerformance'][]=['activity'=>'Survey Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Enrolled', 
  'count'=>@$Tsenrolled, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Not Started', 
  'count'=>@$sNotcompleted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Completed', 
  'count'=>@$Tscomplted, 'type'=>'row'];

  $dailypoints['myPerformance'][]=['activity'=>'QOD Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Allotted', 
  'count'=>@$allotedcount, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Attempted', 
  'count'=>@$attempted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Correct', 
  'count'=>@$correct, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Incorrect', 
  'count'=>@$incorrect, 'type'=>'row'];
  $dailypoints['status']=true;

  $dailypoints['myPerformance'][]=['activity'=>'Weekly Quiz Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Allotted', 
  'count'=>@$totalQuiz, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Attempted', 
  'count'=>@$totalattemptQuiz, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Correct', 
  'count'=>@$totalCorrectQuiz, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Incorrect', 
  'count'=>@$totalWrongQuiz, 'type'=>'row'];
  $dailypoints['status']=true;

  return $dailypoints;
}
public function myPerformancePoint_updated_returns(){
  return new external_single_structure(
    array(
      'status'=> new external_value(PARAM_RAW, 'status'),
      'Summary_Tab' => new external_multiple_structure(
        new external_single_structure(
        array(
          'activity'     => new external_value(PARAM_RAW, 'activity'),
          'points'       => new external_value(PARAM_TEXT, 'points'),
          'type'         => new external_value(PARAM_RAW, 'type')
        )
      )
      ),
      'myDailyActivity' => new external_multiple_structure(
        new external_single_structure(
        array(
          'activity'     => new external_value(PARAM_RAW, 'activity'),
          'count'       => new external_value(PARAM_TEXT, 'count')
        )
      )
      ), 
      'Course_Tab' => new external_multiple_structure(
        new external_single_structure(
        array(
          'name'     => new external_value(PARAM_RAW, 'name'),
          'points'       => new external_value(PARAM_TEXT, 'points'),
          'status'       => new external_value(PARAM_RAW, 'status')
        )
      )
      ), 
      'Assessment_Tab' => new external_multiple_structure(
        new external_single_structure(
        array(
          'name'     => new external_value(PARAM_RAW, 'name'),
          'points'       => new external_value(PARAM_TEXT, 'points'),
          'status'       => new external_value(PARAM_RAW, 'status')
        )
      )
      ),
      'Survey_Tab' => new external_multiple_structure(
        new external_single_structure(
        array(
          'name'     => new external_value(PARAM_RAW, 'name'),
          'points'       => new external_value(PARAM_TEXT, 'points'),
          'status'       => new external_value(PARAM_RAW, 'status')
        )
      )
      ),
      'Rank_Info' => new external_multiple_structure(
       new external_single_structure(
        array(
          'rank'       =>  new external_value(PARAM_TEXT, 'rank'),
          'name'       =>  new external_value(PARAM_RAW, 'name'),
          'mspin'      =>  new external_value(PARAM_RAW, 'mspin'),
          'userpic'    =>  new external_value(PARAM_RAW, 'userpic'),
          'designation'=>  new external_value(PARAM_RAW, 'designation'),
          'dealer_code'=>  new external_value(PARAM_RAW, 'dealer_code'), 
          'dealer_name'=>  new external_value(PARAM_RAW, 'dealer_name'),
          'level'      => new external_value(PARAM_RAW, 'level')
        )
      )
     ),
      'myPerformance' => new external_multiple_structure(
       new external_single_structure(
        array(
          'activity'     => new external_value(PARAM_RAW, 'activity'),
          'count'        => new external_value(PARAM_TEXT, 'count'),
          'type'         => new external_value(PARAM_RAW, 'type')
        )
      )
     )
    )
  );
}
###END MY PERFORMANCE - UPDATED

//-----------------my performance new-------------------------
public function myPerformancePoint_new_parameters(){
  return new external_function_parameters(
    array(
      'mspin' => new external_value(PARAM_INT, 'mspin')
    )
  );  
}
public function myPerformancePoint_new($mspin){
  global $DB,$CFG;
  $dailypoints=[];
  $dailypoints['status']=false;
  $point=0;
  $dsql="SELECT 
  IFNULL(SUM(fr.daily_login_point), 0) AS total_dailypoint,
  IFNULL(SUM(fr.qod_bonus_point), 0) AS total_qodpoint,
  IFNULL(SUM(fr.course_bonus_point), 0) AS total_coursepoint,
  IFNULL(SUM(fr.assessment_bonus_point), 0) AS total_assessmentpoint,
  IFNULL(SUM(fr.survey_bonus_point), 0) AS total_surveypoint,
  IFNULL(SUM(fr.toptwenty_winner_point), 0) AS total_toptwenty_winner_point,
  fr.user_id
  FROM {gm_final_report} AS fr 
  INNER JOIN {ums_employeemaster} AS ums ON ums.userid=fr.user_id WHERE ums.code=$mspin GROUP BY fr.user_id";
  $dresult = $DB->get_record_sql($dsql);

  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Daily Points',
    'points'   =>$point+$dresult->total_dailypoint

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total QOD Points',
    'points'   =>$point+$dresult->total_qodpoint

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Course Points',
    'points'   =>$point+$dresult->total_coursepoint

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Assessment Points',
    'points'   =>$point+$dresult->total_assessmentpoint

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Survey Points',
    'points'   =>$point+$dresult->total_surveypoint

  ];
  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Points',
    'points'   =>$point+$dresult->total_surveypoint+$dresult->total_dailypoint+$dresult->total_qodpoint+$dresult->total_coursepoint+$dresult->total_assessmentpoint

  ];
/*  $dailypoints['Summary_Tab'][]=[
    'activity' =>'Total Top20 Winner (open house) Points',
    'points'   =>$point+$dresult->total_toptwenty_winner_point

  ];*/

  // pie chart graph value start here

  $Total_assessment_enrolled= 0;
  $Total_course_enrolled= 0;
  $Total_survey_enrolled= 0;
  $Total_knc = 0;
  $Total_av = 0;

  $userrr_id01="SELECT * FROM mdl_ums_employeemaster WHERE code='".$mspin."'";

  $userrr_id02=$DB->get_record_sql($userrr_id01);

  $userrr_id = $userrr_id02->userid;
  //echo $userrr_id;exit;


  $sqlaaen01="SELECT count(ue.id) AS totalassess,ue.userid,c.id as cid,c.category, c.fullname
      from mdl_user_enrolments ue
      left join mdl_enrol en on en.id = ue.enrolid
      left join mdl_user u on u.id = ue.userid
      left join mdl_course c on c.id = en.courseid
      where c.visible=1 and ue.userid=$userrr_id and c.category=2";
   //echo $sqlaaen01;exit;
  $Taenrolledd01=$DB->get_record_sql($sqlaaen01);
  $Total_assessment_enrolled=$Total_assessment_enrolled+$Taenrolledd01->totalassess;

  $sql_course="SELECT count(ue.id) AS total_c,ue.userid,c.id as cid,c.category, c.fullname
      from mdl_user_enrolments ue
      left join mdl_enrol en on en.id = ue.enrolid
      left join mdl_user u on u.id = ue.userid
      left join mdl_course c on c.id = en.courseid
      where c.visible=1 and ue.userid=$userrr_id and c.category=3";
   //echo $sqlaaen01;exit;
  $res_course=$DB->get_record_sql($sql_course);
  $Total_course_enrolled=$Total_course_enrolled+$res_course->total_c;

  $sql_survey="SELECT count(ue.id) AS total_s,ue.userid,c.id as cid,c.category, c.fullname
      from mdl_user_enrolments ue
      left join mdl_enrol en on en.id = ue.enrolid
      left join mdl_user u on u.id = ue.userid
      left join mdl_course c on c.id = en.courseid
      where c.visible=1 and ue.userid=$userrr_id and c.category=11";
   //echo $sql_survey;exit;
  $res_survey=$DB->get_record_sql($sql_survey);
  $Total_survey_enrolled=$Total_survey_enrolled+$res_survey->total_s;

    $knc_sql = "SELECT count(*) as total_knc FROM mdl_ums_knc_folder WHERE parent_id = 0 AND deleted=0";
  $result_knc = $DB->get_record_sql($knc_sql);
  $Total_knc=$Total_knc+$result_knc->total_knc;

  $av_sql = "SELECT count(*) as total_av FROM mdl_ums_av_folder WHERE parent_id = 1 AND deleted=0";
  $result_av = $DB->get_record_sql($av_sql);
  $Total_av=$Total_av+$result_av->total_av;


  //echo $Total_av;exit;

    $dailypoints['myDailyActivity'][]=['activity'=>'Course',
   'count'=>$Total_course_enrolled];
   $dailypoints['myDailyActivity'][]=['activity'=>'Assessment',
   'count'=>$Total_assessment_enrolled];
   $dailypoints['myDailyActivity'][]=['activity'=>'Knowledge Center',
   'count'=>$Total_knc];
   $dailypoints['myDailyActivity'][]=['activity'=>'Audio Video Hub',
   'count'=>$Total_av];
   $dailypoints['myDailyActivity'][]=['activity'=>'Survey',
   'count'=>$Total_survey_enrolled]; 

  // pie chart end here

  $sqla="SELECT c.id, c.fullname as name, gm.bonus_point as points, gm.id as status  FROM 
  mdl_gm_assessment_attempt gm
  INNER JOIN 
  mdl_course c ON c.id = gm.course_id
  INNER JOIN
  mdl_ums_employeemaster emp ON emp.userid = gm.user_id
  WHERE emp.code = $mspin";
  $atabs = $DB->get_records_sql($sqla);
  $atabs = json_decode(json_encode($atabs), true);
  $dailypoints['Assessment_Tab']=array_values($atabs);

  $sqlc="SELECT c.id, c.fullname as name, gm.bonus_point as points, gm.id as status  FROM 
  mdl_gm_course_attempt gm
  INNER JOIN 
  mdl_course c ON c.id = gm.course_id
  INNER JOIN
  mdl_ums_employeemaster emp ON emp.userid = gm.user_id
  WHERE emp.code = $mspin";
  $ctabs = $DB->get_records_sql($sqlc);
  $ctabs = json_decode(json_encode($ctabs), true);
  $dailypoints['Course_Tab']=array_values($ctabs);

  $sqls="SELECT c.id, c.fullname as name, gm.bonus_point as points, gm.id as status  FROM 
  mdl_gm_survey_attempt gm
  INNER JOIN 
  mdl_course c ON c.id = gm.course_id
  INNER JOIN
  mdl_ums_employeemaster emp ON emp.userid = gm.user_id
  WHERE emp.code = $mspin";
  $stabs = $DB->get_records_sql($sqls);
  $stabs = json_decode(json_encode($stabs), true);
  $dailypoints['Survey_Tab']=array_values($stabs);

  ##for userInfo
  $sqlu="SELECT u.id as user_id, um.profile_photo_upload, d.d_name, o.o_name, o.o_code_latest, um.region_id, um.outlet_id, CONCAT(u.firstname, ' ', u.lastname) AS fullname, um.user_type_id
  FROM {ums_employeemaster} AS um 
  INNER JOIN mdl_user AS u ON um.userid=u.id
  INNER JOIN mdl_ums_designations AS d ON um.designation_id=d.id 
  LEFT  JOIN mdl_ums_outlet AS o ON um.outlet_id=o.id
  WHERE um.code=$mspin";
  $urslt=$DB->get_record_sql($sqlu);
  ##End for userInfo

 ##for Country Level Rank
  $csql="SELECT
  (SELECT user_id
  FROM mdl_user
  WHERE id=fn1.user_id AND fn1.user_id=$urslt->user_id limit 1) AS user_id,
  CASE
  WHEN @prev_total_bonus_point  = fn1.total_bonus_point THEN @rank
  WHEN @prev_total_bonus_point := fn1.total_bonus_point THEN @rank := @rank + 1
  END AS rank
  FROM mdl_gm_total_final_report fn1,
  (SELECT @prev_total_bonus_point:=0, @rank:=0) r
  ORDER BY fn1.total_bonus_point DESC, fn1.user_id ASC";
  $country_rank= $DB->get_records_sql($csql);
  $country_rank= @$country_rank[$urslt->user_id];
##End for Country Level Rank

##for Region Level Rank
  $rsql="SELECT
  (SELECT user_id
  FROM mdl_user
  WHERE id=fn1.user_id AND fn1.user_id=$urslt->user_id limit 1) AS user_id,
  CASE
  WHEN @prev_total_bonus_point  = fn1.total_bonus_point THEN @rank
  WHEN @prev_total_bonus_point := fn1.total_bonus_point THEN @rank := @rank + 1
  END AS rank
  FROM mdl_gm_total_final_report fn1,
  (SELECT @prev_total_bonus_point:=0, @rank:=0) r
  WHERE fn1.region_id='".$urslt->region_id."'
  ORDER BY fn1.total_bonus_point DESC, fn1.user_id ASC";
  $region_rank= $DB->get_records_sql($rsql);
  $region_rank= @$region_rank[$urslt->user_id];
##End for Region Level Rank

##for Dealer Level Rank
  $dsql="SELECT
  (SELECT user_id
  FROM mdl_user
  WHERE id=fn1.user_id AND fn1.user_id=$urslt->user_id limit 1) AS user_id,
  CASE
  WHEN @prev_total_bonus_point  = fn1.total_bonus_point THEN @rank
  WHEN @prev_total_bonus_point := fn1.total_bonus_point THEN @rank := @rank + 1
  END AS rank
  FROM mdl_gm_total_final_report fn1,
  (SELECT @prev_total_bonus_point:=0, @rank:=0) r
  WHERE fn1.outlet_id='".$urslt->outlet_id."'
  ORDER BY fn1.total_bonus_point DESC, fn1.user_id ASC";
  $dealer_rank= $DB->get_records_sql($dsql);
  $dealer_rank= @$dealer_rank[$urslt->user_id];
##End for Dealer Level Rank
  $primg=$CFG->wwwroot.'/images/avatar1.png';
  if($urslt->profile_photo_upload){
   $primg=$CFG->wwwroot.'/upload/profile/'.$urslt->profile_photo_upload;
  }

  $rank=0;
  $dailypoints['Rank_Info'][]=[
    'rank'=>$rank+$country_rank->rank,
    'name'=>$urslt->fullname,
    'userpic'=>$primg,
    'mspin'=>$mspin,
    'designation'=>@$urslt->d_name,
    'dealer_code'=>@$urslt->o_code_latest==""?"":$urslt->o_code_latest, 
    'dealer_name'=>@$urslt->o_name==""?"":$urslt->o_name,
    'level'=> 'Country Level Rank'
  ];
  $dailypoints['Rank_Info'][]=[
    'rank'=>$rank+$region_rank->rank,
    'name'=>$urslt->fullname, 
    'userpic'=>$primg,
    'mspin'=>$mspin, 
    'designation'=>@$urslt->d_name,
    'dealer_code'=>@$urslt->o_code_latest==""?"":$urslt->o_code_latest, 
    'dealer_name'=>@$urslt->o_name==""?"":$urslt->o_name,
    'level'=> 'Region Level Rank'
  ];
if(@$urslt->user_type_id==""){
  $dailypoints['Rank_Info'][]=[
    'rank'=>$rank+$dealer_rank->rank,
    'name'=>$urslt->fullname, 
    'userpic'=>$primg,
    'mspin'=>$mspin,    
    'designation'=>@$urslt->d_name,
    'dealer_code'=>@$urslt->o_code_latest==""?"":$urslt->o_code_latest, 
    'dealer_name'=>@$urslt->o_name==""?"":$urslt->o_name,
    'level'=> 'Dealer Level Rank'
  ];
}
##Myperformance
  ##course start
  $subsql="(SELECT 
  sb.value AS lession_status
  FROM
  mdl_scorm AS sa
  INNER JOIN
  mdl_scorm_scoes_track AS sb ON (sa.id = sb.scormid)
  WHERE
  sb.element = 'cmi.core.lesson_status'
  AND sb.attempt = 1
  AND (sb.value = 'completed'
  OR sb.value = 'passed'
  OR sb.value = 'failed'
  OR sb.value = 'incomplete')
  AND sb.userid = u.id
  AND sa.course = d.id
  ORDER BY sb.id DESC
  LIMIT 1) AS lession_status";
  $sqlcc="SELECT 
  a.id,
  $subsql
  FROM
  mdl_role_assignments AS a
  LEFT JOIN
  mdl_user AS u ON (a.userid = u.id)
  INNER JOIN
  mdl_ums_employeemaster AS emp ON (u.id = emp.userid)
  INNER JOIN
  mdl_context AS e ON (e.id = a.contextid
  AND e.contextlevel = 50)
  INNER JOIN
  mdl_course AS d ON (d.id = e.instanceid)
  WHERE
  u.id = $urslt->user_id AND d.category = 3
  AND d.visible = 1";
  $rccc=$DB->get_records_sql($sqlcc);
  $Tenrolled=$Notstarted=$Tincomplted=$Tcomplted=0;
  if(@$rccc && count($rccc)>0){
    foreach($rccc as $key => $cc){
     if($cc->lession_status==""){
      $Notstarted=$Notstarted+1;
    }
    if($cc->lession_status=="passed" || $cc->lession_status=="completed"){
      $Tcomplted=$Tcomplted+1;
    }
    if($cc->lession_status=="incomplete"){
      $Tincomplted=$Tincomplted+1;
    }
  }
}
  $Tenrolled=$Notstarted+$Tcomplted+$Tincomplted;
  ##course end

  ##assessment start
  $Taenrolled=$Taincomplted=$Tacomplted=$aNotstarted=0;
  $sqlaaen="SELECT count(a.id) AS totalenroled 
            FROM mdl_role_assignments a
            INNER JOIN mdl_user u on a.userid=u.id
            INNER JOIN mdl_ums_employeemaster emp on u.id=emp.userid
            INNER JOIN mdl_context e ON e.id = a.contextid
            INNER JOIN mdl_course  d ON d.id=e.instanceid
            WHERE u.deleted=0 AND u.id = $urslt->user_id AND d.category = 2 AND e.contextlevel=50 AND d.visible = 1";
  $Taenrolledd=$DB->get_record_sql($sqlaaen);
  $Taenrolled=$Taenrolled+$Taenrolledd->totalenroled;

  /*$sqlaincom="SELECT count(id) as taincomp FROM mdl_quiz_attempts 
            WHERE userid=$urslt->user_id AND quiz IN(SELECT q.id
            FROM mdl_role_assignments a
            INNER JOIN mdl_user u on a.userid=u.id
            INNER JOIN mdl_ums_employeemaster emp on u.id=emp.userid
            INNER JOIN mdl_context e ON e.id = a.contextid
            INNER JOIN mdl_course  d ON d.id=e.instanceid
            INNER JOIN mdl_quiz q ON d.id=q.course
            WHERE u.deleted=0 AND u.id = $urslt->user_id AND d.category = 2 AND e.contextlevel=50 AND d.visible = 1) 
            AND state IN('inprogress', 'abandoned') GROUP BY quiz ORDER BY attempt DESC";*/
            $sqlaaa="SELECT CONCAT((SELECT state
            FROM mdl_quiz_attempts AS a
            INNER JOIN mdl_user AS b ON(a.userid=b.id)
            INNER JOIN mdl_role_assignments as ra ON ra.userid=b.id
            INNER JOIN mdl_context e ON e.id = ra.contextid
            INNER JOIN mdl_ums_employeemaster emp ON emp.userid = b.id
            WHERE a.quiz=q.id AND a.userid =$urslt->user_id ORDER BY a.attempt DESC LIMIT 1),'-', c.id) AS state FROM mdl_course c
            INNER JOIN 
            mdl_quiz q ON c.id=q.course
            WHERE c.category = 2 AND c.visible = 1";       
            $raaa=$DB->get_records_sql($sqlaaa);
            if(@$raaa && count($raaa)>0){
              foreach($raaa as $key => $aa){
               $aa=explode('-', $aa->state);
               if(@$aa[0]=='inprogress'){
                $Taincomplted=$Taincomplted+1;
              }
              if(@$aa[0]=='finished'){
                $Tacomplted=$Tacomplted+1;
              }
            }
          }
  $aNotstarted=$Taenrolled-($Tacomplted+$Taincomplted);
  ##assessment end
  ##survey start
  $Tsenrolled=$Tscomplted=$sNotcompleted=$sNotstarted=0;
  $tsenrollssql="SELECT d.id, a.id as userid FROM
  mdl_user AS a
  INNER JOIN
  mdl_role_assignments AS b ON (b.userid = a.id)
  INNER JOIN
  mdl_context AS c ON (c.id = b.contextid
  AND c.contextlevel = 50)
  INNER JOIN
  mdl_course AS d ON (d.id = c.instanceid)
  INNER JOIN
  mdl_course_categories AS cat ON cat.id = d.category
  INNER JOIN
  mdl_user_enrolments AS en ON (en.userid = b.userid
  AND en.enrolid IN (SELECT id FROM mdl_enrol WHERE courseid = d.id))
  INNER JOIN
  mdl_ums_employeemaster AS ums ON ums.userid = en.userid
  WHERE
  a.username != 'guest' AND a.id > 2
  AND a.suspended = 0
  AND a.deleted = 0
  AND d.category != 0
  AND d.visible = 1
  AND d.is_kca = 0
  AND cat.id = 11
  AND a.id = $urslt->user_id";
  $alls=$DB->get_records_sql($tsenrollssql);
  $Tsenrolled=@count($alls);
  foreach($alls as $key => $s){
    $surveyid   = $DB->get_field('questionnaire', 'id', ['course'=>$s->id]);
    $rid        = $DB->get_field('questionnaire_response','id',['userid'=>@$s->userid, 'survey_id'=>@$surveyid]);
    $response   = $DB->get_record('questionnaire_response', ['id'=>$rid]);
    if(isset($response->complete) && @$response->complete== 'y'){
      $Tscomplted=$Tscomplted+1;
    }else{ 
      $sNotcompleted=$sNotcompleted+1;
    }
  }
  ##survey end
  ##Myperformance
  $year = date('Y');
  $allotedq = $DB->get_record_sql("SELECT count(*) as alloted FROM mdl_question_of_day WHERE qdate IN ($year)");
  $allotedcount = $allotedq->alloted;

  $attemptedq = $DB->get_record_sql("SELECT count(*) AS attempt FROM mdl_question_user_answer WHERE year(qviewdate) IN($year) AND userid=$urslt->user_id");
  $attempted = $attemptedq->attempt;

  $inattemptedscore = $DB->get_record_sql("SELECT count(*) AS score FROM mdl_question_user_answer WHERE year(qviewdate) IN($year)  AND userid=$urslt->user_id AND is_correct = 0");
  $incorrect = $inattemptedscore->score;

  $attemptedscore = $DB->get_record_sql("SELECT count(*) AS score FROM mdl_question_user_answer WHERE year(qviewdate) IN($year)  AND userid=$urslt->user_id AND is_correct = 1");
  $correct = $attemptedscore->score;


  $dailypoints['myPerformance'][]=['activity'=>'Course Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Enrolled', 
  'count'=>$Tenrolled , 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Not Started', 
  'count'=>@$Notstarted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Incompleted', 
  'count'=>@$Tincomplted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Completed', 
  'count'=>@$Tcomplted, 'type'=>'row'];

  $dailypoints['myPerformance'][]=['activity'=>'Assessment Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Enrolled', 
  'count'=>@$Taenrolled, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Not Started', 
  'count'=>@$aNotstarted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Incompleted', 
  'count'=>@$Taincomplted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Completed', 
  'count'=>@$Tacomplted, 'type'=>'row'];

  $dailypoints['myPerformance'][]=['activity'=>'Survey Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Enrolled', 
  'count'=>@$Tsenrolled, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Not Completed', 
  'count'=>@$sNotcompleted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Completed', 
  'count'=>@$Tscomplted, 'type'=>'row'];

  $dailypoints['myPerformance'][]=['activity'=>'QOD Performance', 
  'count'=>0, 'type'=>'head'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Alloted', 
  'count'=>@$allotedcount, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Attemped', 
  'count'=>@$attempted, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total Correct', 
  'count'=>@$correct, 'type'=>'row'];
  $dailypoints['myPerformance'][]=['activity'=>'Total InCorrect', 
  'count'=>@$incorrect, 'type'=>'row'];
  $dailypoints['status']=true;
  return $dailypoints;
}
public function myPerformancePoint_new_returns(){
  return new external_single_structure(
    array(
      'status'=> new external_value(PARAM_RAW, 'status'),
      'Summary_Tab' => new external_multiple_structure(
        new external_single_structure(
        array(
          'activity'     => new external_value(PARAM_RAW, 'activity'),
          'points'       => new external_value(PARAM_INT, 'points')
        )
      )
      ), 
      'myDailyActivity' => new external_multiple_structure(
        new external_single_structure(
        array(
          'activity'     => new external_value(PARAM_RAW, 'activity'),
          'count'       => new external_value(PARAM_INT, 'count')
        )
      )
      ),
      'Course_Tab' => new external_multiple_structure(
        new external_single_structure(
        array(
          'name'     => new external_value(PARAM_RAW, 'name'),
          'points'       => new external_value(PARAM_INT, 'points'),
          'status'       => new external_value(PARAM_RAW, 'status')
        )
      )
      ), 
      'Assessment_Tab' => new external_multiple_structure(
        new external_single_structure(
        array(
          'name'     => new external_value(PARAM_RAW, 'name'),
          'points'       => new external_value(PARAM_INT, 'points'),
          'status'       => new external_value(PARAM_RAW, 'status')
        )
      )
      ),
      'Survey_Tab' => new external_multiple_structure(
        new external_single_structure(
        array(
          'name'     => new external_value(PARAM_RAW, 'name'),
          'points'       => new external_value(PARAM_INT, 'points'),
          'status'       => new external_value(PARAM_RAW, 'status')
        )
      )
      ),
      'Rank_Info' => new external_multiple_structure(
       new external_single_structure(
        array(
          'rank'       =>  new external_value(PARAM_INT, 'rank'),
          'name'       =>  new external_value(PARAM_RAW, 'name'),
          'mspin'      =>  new external_value(PARAM_RAW, 'mspin'),
          'userpic'    =>  new external_value(PARAM_RAW, 'userpic'),
          'designation'=>  new external_value(PARAM_RAW, 'designation'),
          'dealer_code'=>  new external_value(PARAM_RAW, 'dealer_code'), 
          'dealer_name'=>  new external_value(PARAM_RAW, 'dealer_name'),
          'level'   => new external_value(PARAM_RAW, 'level')
        )
      )
     ),
      'myPerformance' => new external_multiple_structure(
       new external_single_structure(
        array(
          'activity'     => new external_value(PARAM_RAW, 'activity'),
          'count'        => new external_value(PARAM_INT, 'count'),
          'type'         => new external_value(PARAM_RAW, 'type')
        )
      )
     )
    )
  );
}
//------------------end my performance new------------------------

###START MY LEADERBOARD
public function myLeaderBoardPoint_parameters(){
  return new external_function_parameters(
    array(
      'mspin' => new external_value(PARAM_INT, 'mspin')
    )
  );  
}
public function myLeaderBoardPoint($mspin){
  global $DB, $CFG, $USER;
##for userInfo
  $sqlu="SELECT u.id as user_id, CONCAT(u.firstname, ' ', u.lastname) AS fullname, outlet_id, region_id, profile_photo_upload, um.gender FROM {ums_employeemaster} AS um INNER JOIN mdl_user AS u ON um.userid=u.id WHERE um.code=$mspin";
  $urslt=$DB->get_record_sql($sqlu);
  if($urslt->profile_photo_upload != '' || $urslt->profile_photo_upload != null)
  {
    $userprofile = $CFG->wwwroot.'/upload/profile/'.$urslt->profile_photo_upload;
  }else{
     if($urslt->gender == 'M')
      {
        $userprofile = $CFG->wwwroot.'/images/avatar1.png';
      }else{
        $userprofile = $CFG->wwwroot.'/images/female-avatar.png';
      }
  }
##End for userInfo

## Daily Bonus
  $dbsql="SELECT IFNULL(SUM(fr.daily_login_point), 0) AS dailypoint, IFNULL(SUM(fr.course_bonus_point + fr.assessment_bonus_point + fr.survey_bonus_point + fr.qod_bonus_point), 0) AS reward_point
  FROM {gm_final_report} AS fr
  INNER JOIN
  {ums_employeemaster} AS ums ON ums.userid = fr.user_id
  WHERE ums.code=$mspin";
  $total_points = $DB->get_record_sql($dbsql);
## Daily Bonus

## Total Bonus
  $tsql="SELECT IFNULL(fr.total_bonus_point, 0) AS total_bonus_point
  FROM {gm_total_final_report} AS fr
  INNER JOIN
  {ums_employeemaster} AS ums ON ums.userid = fr.user_id
  WHERE ums.code=$mspin";
  $total_bonus_point = $DB->get_record_sql($tsql);
## Total Bonus

##for Country Level Rank
  $ranksql="SELECT dealer_rank, region_rank, country_rank 
  FROM mdl_gm_gamification_activity_report WHERE user_id='".$USER->id."'";
  $uRankInfo= $DB->get_record_sql($ranksql);
##End for Country Level Rank
  $rank=0;
  $leaderboardpoint=[];
  $leaderboardpoint['uInfo']['status']             =true;
  $leaderboardpoint['uInfo']['rank_dealer']        =$rank+@$uRankInfo->dealer_rank;
  $leaderboardpoint['uInfo']['dealer_rankimg']     ='https://ilearn.marutisuzuki.com/images/rank/icon3.png';
  $leaderboardpoint['uInfo']['rank_region']        =$rank+@$uRankInfo->region_rank;
  $leaderboardpoint['uInfo']['region_rankimg']     ='https://ilearn.marutisuzuki.com/images/rank/icon3.png';
  $leaderboardpoint['uInfo']['rank_country']       =$rank+@$uRankInfo->country_rank;
  $leaderboardpoint['uInfo']['country_rankimg']    ='https://ilearn.marutisuzuki.com/images/rank/icon3.png';
  $leaderboardpoint['uInfo']['total_dailypoint']   =$rank+$total_points->dailypoint;
  $leaderboardpoint['uInfo']['total_points']       =$rank+$total_bonus_point->total_bonus_point;
  $leaderboardpoint['uInfo']['reward_point']       =$total_points->reward_point;
  $leaderboardpoint['uInfo']['fullname']           =$urslt->fullname;
  if($urslt->profile_photo_upload){
        $primg=$CFG->wwwroot.'/upload/profile/'.$urslt->profile_photo_upload;
      }
    else{
        if($urslt->gender == 'M')
        {
          $primg=$CFG->wwwroot.'/images/avatar3.png';
        }else{
          $primg=$CFG->wwwroot.'/images/female-avatar.png';
        }
      }
  /*$primg=$CFG->wwwroot.'/images/avatar1.png';
  if($urslt->profile_photo_upload){
  $primg=$CFG->wwwroot.'/upload/profile/'.$urslt->profile_photo_upload;
  }*/
  $leaderboardpoint['uInfo']['userpic']            =$primg;
  $leaderboardpoint['uInfo']['mspin']              =$mspin;

##for Latest 10 record Country Level Rank
  $cc_sql="SELECT g.id, g.country_rank AS rank, g.total_bonus_point AS total_points, e.gender, r.r_name AS region, e.profile_photo_upload,g.fullname,g.mspin
  FROM mdl_gm_gamification_activity_report g 
  INNER JOIN mdl_ums_employeemaster e ON g.user_id=e.userid 
  INNER  JOIN mdl_ums_regions r ON g.region_id=r.id WHERE g.country_rank!=0 AND g.country_rank<=20 ORDER BY g.country_rank ASC, g.fullname ASC";
  $country_rank_list= $DB->get_records_sql($cc_sql);
  $crank=[];
  foreach($country_rank_list as $key => $value){
    if($value->profile_photo_upload){
      $primg=$CFG->wwwroot.'/upload/profile/'.$value->profile_photo_upload;
    }else{
      if($value->gender == 'M'){
        $primg=$CFG->wwwroot.'/images/avatar3.png';
      }else{
        $primg=$CFG->wwwroot.'/images/female-avatar.png';
      }
    }
    $value->userpic=$primg;
    $value->rankimg='https://ilearn.marutisuzuki.com/images/rank/icon3.png';
    $value->region=$value->region==''?'':@$value->region;
    $crank[]=$value;
  }
##End Latest 10 record Country Level Rank

##for Latest 10 record Region Level Rank
  $rr_sql="SELECT g.id, g.region_rank AS rank, g.total_bonus_point AS total_points, e.gender, r.r_name AS region, e.profile_photo_upload,g.fullname,g.mspin
  FROM mdl_gm_gamification_activity_report g 
  INNER JOIN mdl_ums_employeemaster e ON g.user_id=e.userid 
  INNER JOIN mdl_ums_regions r ON g.region_id=r.id 
  WHERE g.region_id='".$urslt->region_id."' AND g.region_rank!=0 AND g.region_rank<=20 ORDER BY g.region_rank ASC, g.fullname ASC";
  $region_rank_list= $DB->get_records_sql($rr_sql);
  $rrank=[];
  foreach($region_rank_list as $key => $value){
    if($value->profile_photo_upload){
      $primg=$CFG->wwwroot.'/upload/profile/'.$value->profile_photo_upload;
    }else{
      if($value->gender == 'M'){
        $primg=$CFG->wwwroot.'/images/avatar3.png';
      }else{
        $primg=$CFG->wwwroot.'/images/female-avatar.png';
      }
    }
    $value->userpic=$primg;
    $value->rankimg='https://ilearn.marutisuzuki.com/images/rank/icon3.png';
    $value->region=$value->region==''?'':@$value->region;
    $rrank[]=$value;
  }
##End Latest 10 record Region Level Rank

##for Latest 10 record Dealer Level Rank
  $dd_sql="SELECT g.id, g.dealer_rank AS rank, g.total_bonus_point AS total_points, e.gender, r.r_name AS region, e.profile_photo_upload,g.fullname,g.mspin
  FROM mdl_gm_gamification_activity_report g 
  INNER JOIN mdl_ums_employeemaster e ON g.user_id=e.userid 
  INNER JOIN mdl_ums_regions r ON g.region_id=r.id 
  WHERE g.outlet_id='".$urslt->outlet_id."' AND g.dealer_rank!=0 AND g.dealer_rank<=20 ORDER BY g.dealer_rank ASC, g.fullname ASC";
  $dealer_rank_list= $DB->get_records_sql($dd_sql);
  $drank=[];
  foreach($dealer_rank_list as $key => $value){
    if($value->profile_photo_upload){
      $primg=$CFG->wwwroot.'/upload/profile/'.$value->profile_photo_upload;
    }else{
      if($value->gender == 'M'){
        $primg=$CFG->wwwroot.'/images/avatar3.png';
      }else{
        $primg=$CFG->wwwroot.'/images/female-avatar.png';
      }
    }
    $value->userpic=$primg;
    $value->rankimg='https://ilearn.marutisuzuki.com/images/rank/icon3.png';
    $value->region=$value->region==''?'':@$value->region;
    $drank[]=$value;
  }
##End Latest 10 record Dealer Level Rank

  $leaderboardpoint['uTabs']['dealers']            =$drank;
  $leaderboardpoint['uTabs']['regions']            =$rrank;
  $leaderboardpoint['uTabs']['country']            =$crank;
  return $leaderboardpoint;
}
public function myLeaderBoardPoint_returns(){
  return new external_single_structure(
    array(
      'uInfo'=> new external_single_structure(
        array(
          'status'            => new external_value(PARAM_RAW, 'status'),
          'rank_dealer'       => new external_value(PARAM_INT, 'rank_dealer'),
          'dealer_rankimg'    => new external_value(PARAM_RAW, 'dealer_rankimg'),
          'rank_region'       => new external_value(PARAM_INT, 'rank_region'),
          'region_rankimg'    => new external_value(PARAM_RAW, 'region_rankimg'),
          'rank_country'      => new external_value(PARAM_INT, 'rank_country'),
          'country_rankimg'   => new external_value(PARAM_RAW, 'country_rankimg'),
          'total_dailypoint'  => new external_value(PARAM_INT, 'total_dailypoint'),
          'reward_point'      => new external_value(PARAM_INT, 'reward_point'),
          'total_points'      => new external_value(PARAM_INT, 'total_points'),
          'fullname'          => new external_value(PARAM_RAW, 'fullname'),
          'userpic'           => new external_value(PARAM_RAW, 'userpic'),
          'mspin'             => new external_value(PARAM_RAW, 'mspin')
        )
      ),
      'uTabs'=> new external_single_structure(
        array(
          'dealers' => new external_multiple_structure(
            new external_single_structure(
              array(
                'fullname'      =>new external_value(PARAM_RAW,'fullname'),
                'mspin'         =>new external_value(PARAM_INT,'mspin'),
                'region'        =>new external_value(PARAM_RAW,'region'),
                'userpic'       =>new external_value(PARAM_RAW,'userpic'),
                'rank'          =>new external_value(PARAM_INT,'rank'),
                'rankimg'       =>new external_value(PARAM_RAW,'rankimg'),
                'total_points'  =>new external_value(PARAM_INT,'total_points')
              )
            )
          ),
          'regions' => new external_multiple_structure(
            new external_single_structure(
              array(
                'fullname'      =>new external_value(PARAM_RAW,'fullname'),
                'mspin'         =>new external_value(PARAM_INT,'mspin'),
                'region'        =>new external_value(PARAM_RAW,'region'),
                'userpic'       =>new external_value(PARAM_RAW,'userpic'),
                'rank'          =>new external_value(PARAM_INT,'rank'),
                'rankimg'       =>new external_value(PARAM_RAW,'rankimg'),
                'total_points'  =>new external_value(PARAM_INT,'total_points')
              )
            )
          ),
          'country' => new external_multiple_structure(
            new external_single_structure(
              array(
                'fullname'      =>new external_value(PARAM_RAW,'fullname'),
                'mspin'         =>new external_value(PARAM_INT,'mspin'),
                'region'        =>new external_value(PARAM_RAW,'region'),
                'userpic'       =>new external_value(PARAM_RAW,'userpic'),
                'rank'          =>new external_value(PARAM_INT,'rank'),
                'rankimg'       =>new external_value(PARAM_RAW,'rankimg'),
                'total_points'  =>new external_value(PARAM_INT,'total_points')
              )
            )
          )
        )
      )
    )
  );
}
###END MY LEADERBOARD

###START MY LEADERBOARD - UPDATED
public function myLeaderBoardPoint_updated_parameters(){
  return new external_function_parameters(
    array(
      'mspin' => new external_value(PARAM_INT, 'mspin')
    )
  );  
}
public function myLeaderBoardPoint_updated($mspin){
  global $DB, $CFG, $USER;
##for userInfo
  $sqlu="SELECT u.id as user_id, CONCAT(u.firstname, ' ', u.lastname) AS fullname, outlet_id, region_id, profile_photo_upload, um.gender FROM {ums_employeemaster} AS um INNER JOIN mdl_user AS u ON um.userid=u.id WHERE um.code=$mspin";
  $urslt=$DB->get_record_sql($sqlu);
  if($urslt->profile_photo_upload != '' || $urslt->profile_photo_upload != null)
  {
    $userprofile = $CFG->wwwroot.'/upload/profile/'.$urslt->profile_photo_upload;
  }else{
     if($urslt->gender == 'M')
      {
        $userprofile = $CFG->wwwroot.'/images/avatar1.png';
      }else{
        $userprofile = $CFG->wwwroot.'/images/female-avatar.png';
      }
  }
##End for userInfo

## Daily Bonus
  $dbsql="SELECT IFNULL(SUM(fr.daily_login_point), 0) AS dailypoint, IFNULL(SUM(fr.course_bonus_point + fr.assessment_bonus_point + fr.survey_bonus_point + fr.qod_bonus_point), 0) AS reward_point
  FROM {gm_final_report} AS fr
  INNER JOIN
  {ums_employeemaster} AS ums ON ums.userid = fr.user_id
  WHERE ums.code=$mspin";
  $total_points = $DB->get_record_sql($dbsql);
## Daily Bonus

## Total Bonus
  $tsql="SELECT IFNULL(fr.total_bonus_point, 0) AS total_bonus_point
  FROM {gm_total_final_report} AS fr
  INNER JOIN
  {ums_employeemaster} AS ums ON ums.userid = fr.user_id
  WHERE ums.code=$mspin";
  $total_bonus_point = $DB->get_record_sql($tsql);
## Total Bonus

##for Country Level Rank
  $ranksql="SELECT dealer_rank, region_rank, country_rank 
  FROM mdl_gm_gamification_activity_report WHERE user_id='".$USER->id."'";
  $uRankInfo= $DB->get_record_sql($ranksql);
##End for Country Level Rank
  $rank=0;
  $leaderboardpoint=[];
  $leaderboardpoint['uInfo']['status']             =true;
  $leaderboardpoint['uInfo']['rank_dealer']        =$rank+@$uRankInfo->dealer_rank;
  $leaderboardpoint['uInfo']['dealer_rankimg']     ='https://ilearn.marutisuzuki.com/images/rank/icon3.png';
  $leaderboardpoint['uInfo']['rank_region']        =$rank+@$uRankInfo->region_rank;
  $leaderboardpoint['uInfo']['region_rankimg']     ='https://ilearn.marutisuzuki.com/images/rank/icon3.png';
  $leaderboardpoint['uInfo']['rank_country']       =$rank+@$uRankInfo->country_rank;
  $leaderboardpoint['uInfo']['country_rankimg']    ='https://ilearn.marutisuzuki.com/images/rank/icon3.png';
  $leaderboardpoint['uInfo']['total_dailypoint']   =$rank+$total_points->dailypoint;
  $leaderboardpoint['uInfo']['total_points']       =$rank+$total_bonus_point->total_bonus_point;
  $leaderboardpoint['uInfo']['reward_point']       =$total_points->reward_point;
  $leaderboardpoint['uInfo']['fullname']           =$urslt->fullname;
  if($urslt->profile_photo_upload){
        $primg=$CFG->wwwroot.'/upload/profile/'.$urslt->profile_photo_upload;
      }
    else{
        if($urslt->gender == 'M')
        {
          $primg=$CFG->wwwroot.'/images/avatar3.png';
        }else{
          $primg=$CFG->wwwroot.'/images/female-avatar.png';
        }
      }

  $leaderboardpoint['uInfo']['userpic']            =$primg;
  $leaderboardpoint['uInfo']['mspin']              =$mspin;

##for Latest 10 record Country Level Rank
  $cc_sql="SELECT g.id, g.country_rank AS rank, g.total_bonus_point AS total_points, e.gender, r.r_name AS region, e.profile_photo_upload,g.fullname,g.mspin
  FROM mdl_gm_gamification_activity_report g 
  INNER JOIN mdl_ums_employeemaster e ON g.user_id=e.userid 
  INNER  JOIN mdl_ums_regions r ON g.region_id=r.id WHERE g.country_rank!=0 AND g.country_rank<=20 ORDER BY g.country_rank ASC, g.fullname ASC";
  $country_rank_list= $DB->get_records_sql($cc_sql);
  $crank=[];
  foreach($country_rank_list as $key => $value){
    if($value->profile_photo_upload){
      $primg=$CFG->wwwroot.'/upload/profile/'.$value->profile_photo_upload;
    }else{
      if($value->gender == 'M'){
        $primg=$CFG->wwwroot.'/images/avatar3.png';
      }else{
        $primg=$CFG->wwwroot.'/images/female-avatar.png';
      }
    }
    $value->userpic=$primg;
    $value->rankimg='https://ilearn.marutisuzuki.com/images/rank/icon3.png';
    $value->region=$value->region==''?'':@$value->region;
    $crank[]=$value;
  }
##End Latest 10 record Country Level Rank

##for Latest 10 record Region Level Rank
  $rr_sql="SELECT g.id, g.region_rank AS rank, g.total_bonus_point AS total_points, e.gender, r.r_name AS region, e.profile_photo_upload,g.fullname,g.mspin
  FROM mdl_gm_gamification_activity_report g 
  INNER JOIN mdl_ums_employeemaster e ON g.user_id=e.userid 
  INNER JOIN mdl_ums_regions r ON g.region_id=r.id 
  WHERE g.region_id='".$urslt->region_id."' AND g.region_rank!=0 AND g.region_rank<=20 ORDER BY g.region_rank ASC, g.fullname ASC";
  $region_rank_list= $DB->get_records_sql($rr_sql);
  $rrank=[];
  foreach($region_rank_list as $key => $value){
    if($value->profile_photo_upload){
      $primg=$CFG->wwwroot.'/upload/profile/'.$value->profile_photo_upload;
    }else{
      if($value->gender == 'M'){
        $primg=$CFG->wwwroot.'/images/avatar3.png';
      }else{
        $primg=$CFG->wwwroot.'/images/female-avatar.png';
      }
    }
    $value->userpic=$primg;
    $value->rankimg='https://ilearn.marutisuzuki.com/images/rank/icon3.png';
    $value->region=$value->region==''?'':@$value->region;
    $rrank[]=$value;
  }
##End Latest 10 record Region Level Rank

##for Latest 10 record Dealer Level Rank
  $dd_sql="SELECT g.id, g.dealer_rank AS rank, g.total_bonus_point AS total_points, e.gender, r.r_name AS region, e.profile_photo_upload,g.fullname,g.mspin
  FROM mdl_gm_gamification_activity_report g 
  INNER JOIN mdl_ums_employeemaster e ON g.user_id=e.userid 
  INNER JOIN mdl_ums_regions r ON g.region_id=r.id 
  WHERE g.outlet_id='".$urslt->outlet_id."' AND g.dealer_rank!=0 AND g.dealer_rank<=20 ORDER BY g.dealer_rank ASC, g.fullname ASC";
  $dealer_rank_list= $DB->get_records_sql($dd_sql);
  $drank=[];
  foreach($dealer_rank_list as $key => $value){
    if($value->profile_photo_upload){
      $primg=$CFG->wwwroot.'/upload/profile/'.$value->profile_photo_upload;
    }else{
      if($value->gender == 'M'){
        $primg=$CFG->wwwroot.'/images/avatar3.png';
      }else{
        $primg=$CFG->wwwroot.'/images/female-avatar.png';
      }
    }
    $value->userpic=$primg;
    $value->rankimg='https://ilearn.marutisuzuki.com/images/rank/icon3.png';
    $value->region=$value->region==''?'':@$value->region;
    $drank[]=$value;
  }
##End Latest 10 record Dealer Level Rank

  $leaderboardpoint['uTabs']['dealers']            =$drank;
  $leaderboardpoint['uTabs']['regions']            =$rrank;
  $leaderboardpoint['uTabs']['country']            =$crank;
  return $leaderboardpoint;
}
public function myLeaderBoardPoint_updated_returns(){
  return new external_single_structure(
    array(
      'uInfo'=> new external_single_structure(
        array(
          'status'            => new external_value(PARAM_RAW, 'status'),
          'rank_dealer'       => new external_value(PARAM_INT, 'rank_dealer'),
          'dealer_rankimg'    => new external_value(PARAM_RAW, 'dealer_rankimg'),
          'rank_region'       => new external_value(PARAM_INT, 'rank_region'),
          'region_rankimg'    => new external_value(PARAM_RAW, 'region_rankimg'),
          'rank_country'      => new external_value(PARAM_INT, 'rank_country'),
          'country_rankimg'   => new external_value(PARAM_RAW, 'country_rankimg'),
          'total_dailypoint'  => new external_value(PARAM_INT, 'total_dailypoint'),
          'reward_point'      => new external_value(PARAM_INT, 'reward_point'),
          'total_points'      => new external_value(PARAM_TEXT, 'total_points'),
          'fullname'          => new external_value(PARAM_RAW, 'fullname'),
          'userpic'           => new external_value(PARAM_RAW, 'userpic'),
          'mspin'             => new external_value(PARAM_RAW, 'mspin')
        )
      ),
      'uTabs'=> new external_single_structure(
        array(
          'dealers' => new external_multiple_structure(
            new external_single_structure(
              array(
                'fullname'      =>new external_value(PARAM_RAW,'fullname'),
                'mspin'         =>new external_value(PARAM_INT,'mspin'),
                'region'        =>new external_value(PARAM_RAW,'region'),
                'userpic'       =>new external_value(PARAM_RAW,'userpic'),
                'rank'          =>new external_value(PARAM_INT,'rank'),
                'rankimg'       =>new external_value(PARAM_RAW,'rankimg'),
                'total_points'  =>new external_value(PARAM_TEXT,'total_points')
              )
            )
          ),
          'regions' => new external_multiple_structure(
            new external_single_structure(
              array(
                'fullname'      =>new external_value(PARAM_RAW,'fullname'),
                'mspin'         =>new external_value(PARAM_INT,'mspin'),
                'region'        =>new external_value(PARAM_RAW,'region'),
                'userpic'       =>new external_value(PARAM_RAW,'userpic'),
                'rank'          =>new external_value(PARAM_INT,'rank'),
                'rankimg'       =>new external_value(PARAM_RAW,'rankimg'),
                'total_points'  =>new external_value(PARAM_TEXT,'total_points')
              )
            )
          ),
          'country' => new external_multiple_structure(
            new external_single_structure(
              array(
                'fullname'      =>new external_value(PARAM_RAW,'fullname'),
                'mspin'         =>new external_value(PARAM_INT,'mspin'),
                'region'        =>new external_value(PARAM_RAW,'region'),
                'userpic'       =>new external_value(PARAM_RAW,'userpic'),
                'rank'          =>new external_value(PARAM_INT,'rank'),
                'rankimg'       =>new external_value(PARAM_RAW,'rankimg'),
                'total_points'  =>new external_value(PARAM_TEXT,'total_points')
              )
            )
          )
        )
      )
    )
  );
}
###END MY LEADERBOARD - UPDATED

###START MY PROFILE UPLOAD
public function uploadprofilephoto_parameters(){
  return new external_function_parameters(
    array(  
      'file_name' => new external_value(PARAM_RAW, 'file_name',VALUE_DEFAULT,NULL),
      'file_type' => new external_value(PARAM_RAW, 'file_type',VALUE_DEFAULT,NULL),
      'file_blob' => new external_value(PARAM_RAW, 'file_blob',VALUE_DEFAULT,NULL)
    )
  );
}
public function uploadprofilephoto($file_name,$file_type,$file_blob){
  global $DB,$USER,$CFG;
  $photourl='';
  if($file_name!='' and $file_type!='' and $file_blob!=''){
    $fname=$USER->id.'-'.time().'.'.$file_type;
    $exist_file=$DB->get_field('ums_employeemaster','profile_photo_upload',array('userid'=>$USER->id));
    if($exist_file!='' || $exist_file!=null){
      $existfilepath=$CFG->folder.'/upload/profile/'.$exist_file;
      $existthumbnail=$CFG->folder.'/upload/profile/thumbnails/'.$exist_file;
      if(file_exists($existfilepath)){
        unlink($existfilepath);
      }
      if(file_exists($existthumbnail)){
        unlink($existthumbnail);
      }
    }
    $filepath=$CFG->folder.'/upload/profile/'.$fname;
    $thumbnail=$CFG->folder.'/upload/profile/thumbnails/'.$fname;
    $decodedstring=base64_decode(str_replace(' ', '+', trim($file_blob)));
    if(file_put_contents($filepath, $decodedstring)){
      switch ($file_type){
        case 'jpg':
        case 'jpeg':
        case 'png':
        case 'gif':
        $thumb_width=500;
        $thumb_height=500;
        switch($file_type){
          case 'jpg':
          $source = imagecreatefromjpeg($filepath);
          break;
          case 'jpeg':
          $source = imagecreatefromjpeg($filepath);
          break;
          case 'png':
          $source = imagecreatefrompng($filepath);
          break;
          case 'gif':
          $source = imagecreatefromgif($filepath);
          break;
          default:
          $source = imagecreatefromjpeg($filepath);
        }
        list($width,$height) = getimagesize($filepath);
        $thumb_create = imagecreatetruecolor($thumb_width,$thumb_height);
        imagecopyresized($thumb_create,$source,0,0,0,0,$thumb_width,$thumb_height,$width,$height);
        switch($file_type){
          case 'jpg':
          case 'jpeg':
          imagejpeg($thumb_create,$thumbnail,100);
          break;
          case 'png':
          imagepng($thumb_create,$thumbnail,100);
          break;
          case 'gif':
          imagegif($thumb_create,$thumbnail,100);
          break;
          default:
          imagejpeg($thumb_create,$thumbnail,100);
        }
        break;
        default:
        break;
      }
      $DB->execute("UPDATE {ums_employeemaster} SET profile_photo_upload='".$fname."' WHERE userid = '".$USER->id."'");
      $fileurlpath=$CFG->wwwroot.'/upload/profile/'.$fname;
      $result = array('status'=>'success','message'=>'Profile Picture Uploaded Successfully','photourl'=>$fileurlpath);
    }else{
      $result = array('status'=>'failed','message'=>'Upload failed','photourl'=>$photourl);
    }
  }else{
    $result = array('status'=>'failed','message'=>'Parameters missing','photourl'=>$photourl);
  }
  return($result);
}
public function uploadprofilephoto_returns(){
  return new external_single_structure(
    array('status'=> new external_value(PARAM_RAW, 'status'),
      'message'=> new external_value(PARAM_RAW, 'message'),
      'photourl'=> new external_value(PARAM_RAW, 'photo path')
    ));
}
//------------------------------------------------------------------------

  public function uploadprofilephoto_ios_parameters()
  {
    return new external_function_parameters(
      array(  
         
         
            'file_name' => new external_value(PARAM_RAW, 'file_name',VALUE_DEFAULT,NULL),
            'file_type' => new external_value(PARAM_RAW, 'file_type',VALUE_DEFAULT,NULL),
            'file_blob' => new external_value(PARAM_RAW, 'file_blob',VALUE_DEFAULT,NULL)
            
        )
    );
  }
  
  
  public function uploadprofilephoto_ios($file_name,$file_type,$file_blob)
  {
    global $DB,$USER,$CFG;
    $photourl='';
    
    if($file_name!='' and $file_type!='' and $file_blob!='')
    {
      
      $fname=$USER->id.'-'.time().'.'.$file_type;
    
    $exist_file=$DB->get_field('ums_employeemaster','profile_photo_upload',array('userid'=>$USER->id));
    
    if($exist_file!='' || $exist_file!=null)
    {
    $existfilepath=$CFG->folder.'/upload/profile/'.$exist_file;

    $existthumbnail=$CFG->folder.'/upload/profile/thumbnails/'.$exist_file; 
    
    if(file_exists($existfilepath))
    {
      unlink($existfilepath);
      
    }
    if(file_exists($existthumbnail))
    {
      unlink($existthumbnail);
      
    }
    
    }
    
      $filepath=$CFG->folder.'/upload/profile/'.$fname;

      $thumbnail=$CFG->folder.'/upload/profile/thumbnails/'.$fname;
    
    $decodedstring=base64_decode(str_replace(' ', '+', trim($file_blob)));
    
      if(file_put_contents($filepath, $decodedstring))
      {

        switch ($file_type) 
        {
          case 'jpg':
          case 'jpeg':
          case 'png':
          case 'gif':
          case 'heif':
          $thumb_width=500;
          $thumb_height=500;
         
       
       
            switch($file_type)
            {
                case 'jpg':
                    $source = imagecreatefromjpeg($filepath);
                    break;
                case 'jpeg':
                    $source = imagecreatefromjpeg($filepath);
                    break;

                case 'png':
                    $source = imagecreatefrompng($filepath);
                    break;
                case 'gif':
                    $source = imagecreatefromgif($filepath);
                    break;
                case 'heif':
                    $source = imagecreatefromgif($filepath);
                    break;
                default:
                    $source = imagecreatefromjpeg($filepath);
            }

            list($width,$height) = getimagesize($filepath);

            $thumb_create = imagecreatetruecolor($thumb_width,$thumb_height);

            imagecopyresized($thumb_create,$source,0,0,0,0,$thumb_width,$thumb_height,$width,$height);
            switch($file_type)
            {
                case 'jpg':
                case 'jpeg':
                    imagejpeg($thumb_create,$thumbnail,100);
                    break;
                case 'png':
                    imagepng($thumb_create,$thumbnail,100);
                    break;

                case 'gif':
                    imagegif($thumb_create,$thumbnail,100);
                    break;
                case 'heif':
                    imagegif($thumb_create,$thumbnail,100);
                    break;
                default:
                    imagejpeg($thumb_create,$thumbnail,100);
            }
            
            break;
         
          
          default:
            
            break;
        }
    $DB->execute("UPDATE {ums_employeemaster} SET profile_photo_upload='".$fname."' WHERE userid = '".$USER->id."'");
    $fileurlpath=$CFG->wwwroot.'/upload/profile/'.$fname;
    $result = array('status'=>'success','message'=>'Profile Picture Uploaded Successfully','photourl'=>$fileurlpath);

      }
      else
      {
        
         $result = array('status'=>'failed','message'=>'Upload failed','photourl'=>$photourl);

      }
      


    }
    else
    {
      
     
        $result = array('status'=>'failed','message'=>'Parameters missing','photourl'=>$photourl);
      
    }
    return($result);
  }
  
  public function uploadprofilephoto_ios_returns()
  {
    return new external_single_structure(
      array('status'=> new external_value(PARAM_RAW, 'status'),
    'message'=> new external_value(PARAM_RAW, 'message'),
     'photourl'=> new external_value(PARAM_RAW, 'photo path')
       ));
  }


//------------------------------------------------------------------------
###END MY PROFILE UPLOAD


public function deleteprofilephoto_parameters()
  {
    return new external_function_parameters(
      array(  
         
         
            'file_name' => new external_value(PARAM_RAW, 'file_name',VALUE_DEFAULT,NULL),
            'file_type' => new external_value(PARAM_RAW, 'file_type',VALUE_DEFAULT,NULL),
            'file_blob' => new external_value(PARAM_RAW, 'file_blob',VALUE_DEFAULT,NULL)
            
        )
    );
  }
  
  
  public function deleteprofilephoto()
  {
    global $DB,$USER,$CFG;
    $photourl='';
    
    // if($file_name!='' and $file_type!='' and $file_blob!='')
    // {
      
      //$fname=$USER->id.'-'.time().'.'.$file_type;

    $sql = "SELECT gender from mdl_ums_employeemaster where userid='".$USER->id."'";
    $results = $DB->get_record_sql($sql);
    
    $exist_file=$DB->get_field('ums_employeemaster','profile_photo_upload',array('userid'=>$USER->id));
    
    if($exist_file!='' || $exist_file!=null)
    {
        $existfilepath=$CFG->folder.'/upload/profile/'.$exist_file;

        $existthumbnail=$CFG->folder.'/upload/profile/thumbnails/'.$exist_file; 
        
        if(file_exists($existfilepath))
        {
          unlink($existfilepath);
          
        }
        if(file_exists($existthumbnail))
        {
          unlink($existthumbnail);
          
        }

       $DB->execute("UPDATE {ums_employeemaster} SET profile_photo_upload='' WHERE userid = '".$USER->id."'");

       if($results->gender == 'M')
        {
          $photourl='https://ilearn.marutisuzuki.com/images/avatar3.png';
        }else{
          $photourl='https://ilearn.marutisuzuki.com/images/female-avatar.png';
        }

        //$fileurlpath=$CFG->wwwroot.'/upload/profile/'.$fname;
        //$photourl='https://ilearn.marutisuzuki.com/images/avatar3.png';
        $result = array('status'=>'success','message'=>'Profile Picture Removed Successfully','photourl'=>$photourl);
    
    }else{

      if($results->gender == 'M')
        {
          $photourl='https://ilearn.marutisuzuki.com/images/avatar3.png';
        }else{
          $photourl='https://ilearn.marutisuzuki.com/images/female-avatar.png';
        }

       //$fileurlpath=$CFG->wwwroot.'/upload/profile/'.$fname;
       //$photourl='https://ilearnnexa.marutisuzuki.com/images/avatar3.png';
       $result = array('status'=>'success','message'=>'Profile Picture Removed Successfully','photourl'=>$photourl);

    }
    
      
    return($result);
  }
  
  public function deleteprofilephoto_returns()
  {
    return new external_single_structure(
      array('status'=> new external_value(PARAM_RAW, 'status'),
    'message'=> new external_value(PARAM_RAW, 'message'),
     'photourl'=> new external_value(PARAM_RAW, 'photo path')
       ));
  }

###START GAME RULES
public function GameRules_parameters(){
  return new external_function_parameters(
    array()
  );  
}
public function GameRules(){
  global $DB, $CFG, $USER;
  $MyRules=[];
  $QuizTime=date('10:00:00');
  $dayName="monday";
  $dayNum=1;
  //$hours="+30 minute";
  $hours="+10 hours";
  $CurrentMondayDateFixed = date('Y-m-d', strtotime($dayName." 0 week"));
  $NextMondayDate         = date('Y-m-d', strtotime($dayName." 1 week"));
  $sqlF="SELECT * FROM {gm_rules} WHERE status=0";
  $mlist=$DB->get_records_sql($sqlF, array());
  $mlist=json_decode(json_encode($mlist), true);
  $CurrentMondayDate=$CurrentMondayDateFixed;
  $MyRules['CountDown']['active_btn']=false;
  $MyRules['CountDown']['msg']="Game will be active on next ".ucfirst($dayName);
  $MyRules['CountDown']['activation']=$NextMondayDate.' '.$QuizTime;
  $MyRules['CountDown']['valid_date']=date('Y-m-d H:i:s', strtotime($MyRules['CountDown']['activation']. $hours));
  if(date('w')==$dayNum && $CurrentMondayDate==date('Y-m-d')){
    $MyRules['CountDown']['activation']=$CurrentMondayDateFixed.' '.$QuizTime;
    $MyRules['CountDown']['valid_date']=date('Y-m-d H:i:s', strtotime($MyRules['CountDown']['activation']. $hours));
    if(time() >= strtotime($MyRules['CountDown']['activation']) && time() <= strtotime($MyRules['CountDown']['valid_date'])){
      $MyRules['CountDown']['active_btn']=true;
      $NextMondayDate=$CurrentMondayDateFixed;
    }
  }else{
    $CurrentMondayDateFixed = date('Y-m-d');
    $NextMondayDate         = date('Y-m-d', strtotime($dayName." 0 week"));
    $MyRules['CountDown']['activation']=$NextMondayDate.' '.$QuizTime;
    $MyRules['CountDown']['valid_date']=date('Y-m-d H:i:s', strtotime($MyRules['CountDown']['activation']. $hours));
    $CurrentMondayDate=$CurrentMondayDate.' '.date('H:i:s');
    $NextMondayDate=date('Y-m-d '.$QuizTime);
  }

  $date1 = new DateTime($CurrentMondayDate);
  $date2 = $date1->diff(new DateTime($NextMondayDate));
  $MyRules['CountDown']['days']  =$date2->d;
  $MyRules['CountDown']['hour']  =$date2->h;
  $MyRules['CountDown']['minute']=$date2->i;
  $MyRules['CountDown']['second']=$date2->s;

  $MyRules['Rules']=$mlist;

  $MyRules['Selected_weekly_quiz']['id']=0;
  $MyRules['Selected_weekly_quiz']['product_id']=0;
  $MyRules['Selected_weekly_quiz']['title']='';
  $MyRules['Selected_weekly_quiz']['theme_image_landing']='';
  $MyRules['Selected_weekly_quiz']['theme_image_inner_page']='';
  $MyRules['Selected_weekly_quiz']['mark_per_question']='';
  $MyRules['Selected_weekly_quiz']['question_attempt_duration']='';
  $MyRules['Selected_weekly_quiz']['is_negative_marks']='';
  $MyRules['Selected_weekly_quiz']['is_selected']=0;
  $MyRules['Selected_weekly_quiz']['new_status']="new";
  $MyRules['Selected_weekly_quiz']['product_text']="";
  $sqlA="SELECT wq.id, wqa.weekly_quiz_product_type_id AS product_id, wq.title, wqt.theme_image_landing, wqt.theme_image_inner_page, wq.mark_per_question, wq.question_attempt_duration, wq.is_negative_marks, wq.id AS quizid, qpt.cat_name AS product_text, wqa.status AS new_status
  FROM {gm_weekly_quiz_select} wqa 
  INNER JOIN {gm_weekly_quiz} wq ON wqa.weekly_quiz_id=wq.id 
  INNER JOIN {gm_weekly_quiz_theme} wqt ON wqa.weekly_quiz_theme_id=wqt.id
  INNER JOIN {gm_weekly_quiz_product_type} qpt ON qpt.id=wqa.weekly_quiz_product_type_id
  WHERE wqa.user_id='".$USER->id."' AND wq.deleted=0 AND date(wq.date)='".date('Y-m-d')."' ORDER BY wqa.id DESC";
  $olist=$DB->get_record_sql($sqlA, array());
  $olist=json_decode(json_encode($olist), true);
  if($olist['product_id']!=="" && $olist['new_status']=="current"){
    $olist['is_selected']=1;
    $MyRules['Selected_weekly_quiz']=$olist;
  }
  if($olist['product_id']!=="" && $olist['new_status']=="finished"){
    $olist['is_selected']=0;
    $olist['new_status']="new";
    $MyRules['Selected_weekly_quiz']=$olist;
    $MyRules['CountDown']['msg']="Game will be active on next ".ucfirst($dayName);;
    $MyRules['CountDown']['active_btn']=false;
  }
  if($MyRules['CountDown']['active_btn']==false){
    $MyRules['Selected_weekly_quiz']['new_status']="new";
  }
  return $MyRules;
}

public function GameRules_returns(){
  return new external_single_structure(
    array(
      'CountDown'=> new external_single_structure(
        array(
          'days' => new external_value(PARAM_TEXT, 'days'),
          'hour' => new external_value(PARAM_TEXT, 'hour'),
          'minute' => new external_value(PARAM_TEXT, 'minute'),
          'second' => new external_value(PARAM_TEXT, 'second'),
          'active_btn' => new external_value(PARAM_BOOL, 'active_btn'),
          'msg' => new external_value(PARAM_TEXT, 'msg'),
          'activation' => new external_value(PARAM_TEXT, 'activation'),
          'valid_date' => new external_value(PARAM_TEXT, 'valid_date')
        )
      ),
      'Rules'=> new external_multiple_structure(
        new external_single_structure(
        array(
          'description' => new external_value(PARAM_TEXT, 'description'),
          'status'      => new external_value(PARAM_INT, 'status')
        )
      )
     ),
     'Selected_weekly_quiz'=> new external_single_structure(
        array(
          'id' => new external_value(PARAM_INT, 'id'),
          'product_id' => new external_value(PARAM_INT, 'product_id'),
          'title' => new external_value(PARAM_TEXT, 'title'),
          'theme_image_landing' => new external_value(PARAM_TEXT, 'theme_image_landing'),
          'theme_image_inner_page' => new external_value(PARAM_TEXT, 'theme_image_inner_page'),
          'mark_per_question' => new external_value(PARAM_TEXT, 'mark_per_question'),
          'question_attempt_duration' => new external_value(PARAM_TEXT, 'question_attempt_duration'),
          'is_negative_marks' => new external_value(PARAM_TEXT, 'is_negative_marks'),
          'is_selected' => new external_value(PARAM_TEXT, 'is_selected'),
          'product_text' => new external_value(PARAM_TEXT, 'pruduct_text'),
          'new_status' => new external_value(PARAM_TEXT, 'new_status')
        )
      )
    )
  );  
}
###END GAME RULES

###START SPIN WHEEL CATEGORY
public function SpinWheelCategory_parameters(){
  return new external_function_parameters(
    array()
  );  
}

public function SpinWheelCategory(){
  global $DB, $CFG;
  $SpinWheelCategory=[];
  $sqlF="SELECT id,cat_name,color_code,weightage,show_weightage FROM {gm_weekly_quiz_product_type} WHERE deleted=0 ORDER BY weightage ASC";
  $spinlist=$DB->get_records_sql($sqlF, array());
  $spinlist=json_decode(json_encode($spinlist), true);
  $SpinWheelCategory['SpinWheelCategory']=$spinlist;
  return $SpinWheelCategory;
}

public function SpinWheelCategory_returns(){
  return new external_single_structure(
    array(
      'SpinWheelCategory'=> new external_multiple_structure(
        new external_single_structure(
        array(
           'id' => new external_value(PARAM_TEXT, 'id'),
           'cat_name' => new external_value(PARAM_TEXT, 'cat_name'),
           'color_code' => new external_value(PARAM_TEXT, 'color_code'),
           'weightage' => new external_value(PARAM_TEXT, 'weightage'),
           'show_weightage' => new external_value(PARAM_TEXT, 'show_weightage')
        )
      )
     )
    )
  );  
}
###END   SPIN WHEEL CATEGORY

###START GameActivation
public function GameActivation_parameters(){
  return new external_function_parameters(
    array()
  );  
}

public function GameActivation(){
  global $DB, $CFG;
  $GameActivation['GameActivation']['status']=false;
  if(date('w')==1){
  $GameActivation['GameActivation']['status']=true;
  }
  return $GameActivation;
}

public function GameActivation_returns(){
  return new external_single_structure(
    array(
      'GameActivation'=> new external_single_structure(
        array(
           'status' => new external_value(PARAM_BOOL, 'status')
         )
      )
    )
  );  
}
###END GameActivation

###START MixTheme
public function MixTheme_parameters(){
  return new external_function_parameters(
    array()
  );  
}

public function MixTheme(){
  global $DB, $CFG;
  $MixTheme['MixTheme']=[];
  $sqlM="SELECT * FROM {gm_themes} WHERE status=0";
  $mlist=$DB->get_record_sql($sqlM, array());
  $mlist=json_decode(json_encode($mlist), true);
  $MixTheme['MixTheme']=$mlist;
  return $MixTheme;
}

public function MixTheme_returns(){
  return new external_single_structure(
    array(
      'MixTheme'=> new external_multiple_structure(
        new external_single_structure(
        array(
          'name'        => new external_value(PARAM_TEXT, 'name'),
          'description' => new external_value(PARAM_TEXT, 'description'),
          'status'      => new external_value(PARAM_INT, 'status')
        )
      )
     )
    )
  ); 
}
###END MixTheme

###START Display Quiz Time
public function weekly_quiz_display_time_parameters(){
    return new external_function_parameters(
    array()
  );
}
public function weekly_quiz_display_time(){
  global $DB, $CFG, $USER;
  $Quiz_display_time['quiz_display_time']=[];
  $sqlQ="SELECT * FROM {gm_weekly_spin_time}";
  $qlist=$DB->get_record_sql($sqlQ, array());
  $qlist=json_decode(json_encode($qlist), true);
  $Quiz_display_time['quiz_display_time']=$qlist;
  return $Quiz_display_time;
}
public function weekly_quiz_display_time_returns(){
    return new external_single_structure(
    array(
      'quiz_display_time'=> new external_single_structure(
        array(
           'start_time' => new external_value(PARAM_RAW, 'start_time'),
           'end_time' => new external_value(PARAM_RAW, 'end_time')
         )
      )
    )
  );
}
###END  Display Quiz Time

###START WEEKLY PRODUCT TYPE
public function weekly_quiz_product_type_parameters(){
    return new external_function_parameters(
    array()
  );
}
public function weekly_quiz_product_type(){
  global $DB, $CFG, $USER;
  $SpinWheelCategory=[];
  $sqlF="SELECT id,cat_name,color_code,text_color_code,weightage,show_weightage FROM {gm_weekly_quiz_product_type} WHERE deleted=0 ORDER BY weightage ASC";
  $spinlist=$DB->get_records_sql($sqlF, array());
  foreach($spinlist as $key => $spinFirst){
    $sqlQ="SELECT 
    qq.id, qq.id AS weekly_quiz_id, count(qq.id) AS totalquestion
    FROM {gm_weekly_quiz} wq 
    INNER JOIN {gm_weekly_quiz_question} qq ON wq.id=qq.weekly_quiz_id
    WHERE wq.weekly_quiz_product_type_id='".$spinFirst->id."' AND wq.deleted=0 AND date(wq.date)='".date('Y-m-d')."'";
    $qlist=$DB->get_record_sql($sqlQ, array());
    $qlist=json_decode(json_encode($qlist), true);

    $sqlA="SELECT 
    qq.id, qq.id AS weekly_quiz_id, count(qq.id) AS totalquestion, wqa.status
    FROM {gm_weekly_quiz_select} wqa 
    INNER JOIN {gm_weekly_quiz} wq ON wqa.weekly_quiz_id=wq.id 
    INNER JOIN {gm_weekly_quiz_question} qq ON wqa.weekly_quiz_id=qq.weekly_quiz_id
    WHERE wqa.user_id='".$USER->id."'  AND wq.deleted=0 AND date(wq.date)='".date('Y-m-d')."' ORDER BY wqa.id DESC";
    /*AND wqa.weekly_quiz_product_type_id='".$spinFirst->id."'*/
    $olist=$DB->get_record_sql($sqlA, array());
    $olist=json_decode(json_encode($olist), true);
    $spinFirst->is_attempted=false;
    $spinFirst->msg='Question is missing';
    if($qlist['totalquestion'] > 0){
      $spinFirst->is_attempted=true;
      $spinFirst->msg='';
      if(@$olist['status']=="finished"){
        unset($spinFirst->is_attempted);
        $spinFirst->is_attempted=false;
        $spinFirst->msg='Already Attempted';
      }
    }
  }
  $SpinWheelCategory['SpinWheelCategory']=$spinlist;
  return $SpinWheelCategory;
}
public function weekly_quiz_product_type_returns(){
  return new external_single_structure(
    array(
      'SpinWheelCategory'=> new external_multiple_structure(
        new external_single_structure(
        array(
           'id' => new external_value(PARAM_TEXT, 'id'),
           'cat_name' => new external_value(PARAM_TEXT, 'cat_name'),
           'color_code' => new external_value(PARAM_TEXT, 'color_code'),
           'text_color_code' => new external_value(PARAM_TEXT, 'text_color_code'),
           'weightage' => new external_value(PARAM_TEXT, 'weightage'),
           'is_attempted' => new external_value(PARAM_BOOL, 'is_attempted'),
           'msg' => new external_value(PARAM_TEXT, 'msg'),
           'show_weightage' => new external_value(PARAM_TEXT, 'show_weightage'),
        )
      )
     )
    )
  );
}
###END WEEKLY PRODUCT TYPE


###START WEEKLY QUIZ TYPE
public function weekly_quiz_type_parameters(){
    return new external_function_parameters(
    array(
      'product_id' => new external_value(PARAM_INT, 'product_id')
    )
  );
}
public function weekly_quiz_type($product_id){
  global $DB, $CFG, $USER;
  $weekly_quiz_type=[];
  $sqlF="SELECT wq.id, wq.title,wqt.id as theme_id, wqt.theme_name, CONCAT('https://ilearn.marutisuzuki.com', '', wqt.theme_image_landing) AS theme_image_landing ,CONCAT('https://ilearn.marutisuzuki.com', '',wqt.theme_image_inner_page) AS theme_image_inner_page, wq.mark_per_question,wq.question_attempt_duration,wq.is_negative_marks FROM {gm_weekly_quiz} wq INNER JOIN {gm_weekly_quiz_theme} wqt ON wq.weekly_quiz_theme_id=wqt.id WHERE wq.weekly_quiz_product_type_id='".$product_id."' AND wq.deleted=0 AND date(wq.date)='".date('Y-m-d')."'";
  $spinlist=$DB->get_record_sql($sqlF);
  $spinlist->product_id=$product_id;
  $spinlist->title='';
  $sqlI="SELECT * FROM {gm_weekly_quiz_instruction} WHERE weekly_quiz_id='".$spinlist->id."'";
  $instructions=$DB->get_records_sql($sqlI, array());
  $weekly_quiz_type['weekly_quiz_type']=$spinlist;
  $weekly_quiz_type['instructions']=$instructions;
  if(@$spinlist->id==""){
    $weekly_quiz_type['weekly_quiz_type']=[
      'id'=>0,
      'product_id'=>$product_id,
      'title'=>'',
      'theme_name'=>'',
      'theme_image_landing'=>'',
      'theme_image_inner_page'=>'',
      'mark_per_question'=>'',
      'question_attempt_duration'=>0,
      'is_negative_marks'=>0
    ];
    $weekly_quiz_type['instructions']=[];
  }
  return $weekly_quiz_type;
}
public function weekly_quiz_type_returns(){
 return new external_single_structure(
    array(
      'weekly_quiz_type'=> new external_single_structure(
        array(
           'id' => new external_value(PARAM_TEXT, 'id'),
           'product_id' => new external_value(PARAM_INT, 'product_id'),
           'title' => new external_value(PARAM_TEXT, 'title'),
           'theme_name' => new external_value(PARAM_TEXT, 'theme_name'),
           'theme_image_landing' => new external_value(PARAM_TEXT, 'theme_image_landing'),
           'theme_image_inner_page' => new external_value(PARAM_TEXT, 'theme_image_inner_page'),
           'mark_per_question' => new external_value(PARAM_TEXT, 'mark_per_question'),
           'question_attempt_duration' => new external_value(PARAM_TEXT, 'question_attempt_duration'),
           'is_negative_marks' => new external_value(PARAM_BOOL, 'is_negative_marks')
        )
      ),
      'instructions'=> new external_multiple_structure(
        new external_single_structure(
        array(
           'text' => new external_value(PARAM_TEXT, 'text')
        )
      )
     )
    )
  );
}
###END WEEKLY QUIZ TYPE

###START Weekly Quiz
public function weekly_quiz_question_answer_parameters(){
  return new external_function_parameters(
    array(
      'weekly_quiz_id' => new external_value(PARAM_INT,'weekly_quiz_id'),
      'product_id' => new external_value(PARAM_INT,'product_id', VALUE_OPTIONAL)
    )
  );  
}

public function weekly_quiz_question_answer($weekly_quiz_id, $product_id=""){
  global $DB, $CFG, $USER;
  $today  = date('Y-m-d');
  ###App State Information Updates
  $SelectU=[];
  $sqlF="SELECT wq.id, wq.title,wqt.id as theme_id, wqt.theme_image_landing,wqt.theme_image_inner_page,wq.mark_per_question,wq.question_attempt_duration,wq.is_negative_marks,wq.weekly_quiz_product_type_id FROM {gm_weekly_quiz} wq INNER JOIN {gm_weekly_quiz_theme} wqt ON wq.weekly_quiz_theme_id=wqt.id WHERE wq.id='".$weekly_quiz_id."' AND wq.deleted=0 AND date(wq.date)='".date('Y-m-d')."'";
  $spinlist=$DB->get_record_sql($sqlF);
  $sqlSInfo="SELECT id,status FROM {gm_weekly_quiz_select} WHERE user_id='".$USER->id."' AND weekly_quiz_id='".$spinlist->id."' AND weekly_quiz_product_type_id='".$spinlist->weekly_quiz_product_type_id."' AND weekly_quiz_theme_id='".$spinlist->theme_id."'";
  $Sinfor=$DB->get_record_sql($sqlSInfo, array());
  $SelectU['user_id']=$USER->id;
  $SelectU['weekly_quiz_id']=$spinlist->id;
  $SelectU['weekly_quiz_product_type_id']=$spinlist->weekly_quiz_product_type_id;
  $SelectU['weekly_quiz_theme_id']=$spinlist->theme_id;
  $SelectU['created_at']=date('Y-m-d H:i:s');
  $SelectU['status']="current";

  if(@$Sinfor->id && $Sinfor->id!="" && $Sinfor->status!="finished"){
   $SelectU['id']=$Sinfor->id;
   unset($SelectU['created_at']);
   $SelectU['updated_at']=$SelectU['created_at'];
   $DB->update_record('gm_weekly_quiz_select', $SelectU);
  }else{
   $DB->insert_record('gm_weekly_quiz_select', $SelectU);
  }
  ###App State Information Updates

  $attemptQuest=[0];
  $sqlQ="SELECT id, action_type,attempt_limit,weekly_quiz_theme_id FROM {gm_weekly_quiz}  WHERE id='".$weekly_quiz_id."'";
  $FindQ = $DB->get_record_sql($sqlQ);
  $sqlTh="SELECT id, theme_name FROM {gm_weekly_quiz_theme}  WHERE id='".$FindQ->weekly_quiz_theme_id."'";
  $FindTh = $DB->get_record_sql($sqlTh);
  $sqlLast="SELECT id, weekly_quiz_question_id, attempt, is_correct FROM {gm_weekly_quiz_attempt}  WHERE user_id='".$USER->id."' AND weekly_quiz_id='".$weekly_quiz_id."' ORDER BY id DESC";
  $LastAttempt = $DB->get_record_sql($sqlLast);
  if(@$LastAttempt->weekly_quiz_question_id){
    $sqlattempt="SELECT id, weekly_quiz_question_id, attempt, is_correct FROM {gm_weekly_quiz_attempt}  WHERE user_id='".$USER->id."' AND weekly_quiz_id='".$weekly_quiz_id."' AND attempt='".@$LastAttempt->attempt."' ORDER BY id DESC";
    $attempts = $DB->get_records_sql($sqlattempt);
    foreach($attempts as $key => $attempt){
      $attemptQuest[]=$attempt->weekly_quiz_question_id;
    }
  }
  if($FindQ->action_type=="start_again"){
    if(@$LastAttempt==""){
      $attemptQuest=[0];
    }
    if(@$LastAttempt!="" && @$LastAttempt->is_correct==0){
      $attemptQuest=[0];
    }
  }
  $res_Question  = $DB->get_records_sql("SELECT wqq.id,wqq.weekly_quiz_id,wqq.type,wqq.is_answer_draggable,wqq.q_text_image,wqq.q_image,wq.weekly_quiz_theme_id,wqq.weekly_quiz_product_type_id,wq.start_time,wq.end_time,wq.mark_per_question,(wq.question_attempt_duration*1000) AS question_attempt_duration ,wq.is_negative_marks 
    FROM {gm_weekly_quiz_question} wqq 
    INNER JOIN {gm_weekly_quiz} wq ON wqq.weekly_quiz_id=wq.id WHERE wqq.id NOT IN(".implode(', ', $attemptQuest).") AND  wqq.weekly_quiz_id='".@$weekly_quiz_id."' AND wqq.deleted=0 ORDER BY RAND()");
  if($FindQ->action_type=="start_again"){
    if(@$LastAttempt!="" && @$LastAttempt->is_correct==0 && @$LastAttempt->attempt >= $FindQ->attempt_limit){
      $res_Question=[];
    }
  }
  if($FindQ->action_type=="close_quiz"){
    if(@$LastAttempt!="" && @$LastAttempt->is_correct==0){
      $res_Question=[];
    }
  }
    if(!empty($res_Question)){
    foreach($res_Question as $key => $res_Questions){
      $res_Questions->weekly_quiz_product_type_id=@$res_Questions->weekly_quiz_product_type_id!=''?$res_Questions->weekly_quiz_product_type_id:0;
      if($res_Questions->q_image!=""){
        $res_Questions->q_image=$CFG->wwwroot.$res_Questions->q_image;
      }else{
        $res_Questions->q_image="";
      }
      $res_Questions->action_type=$FindQ->action_type;
      $res_Questions->attempt_limit=$FindQ->attempt_limit!=""?$FindQ->attempt_limit:"";
      $res_Questions->theme_name=$FindTh->theme_name;

      $findsql ="SELECT qq.id, q.id AS weekly_quiz_id, count(qq.id) AS totalquestion FROM {gm_weekly_quiz} q INNER JOIN {gm_weekly_quiz_question} qq ON q.id=qq.weekly_quiz_id WHERE q.id='".$res_Questions->weekly_quiz_id."' AND qq.deleted=0 ";
      $findReslt=$DB->get_record_sql($findsql, array());
      
      $attemptsql="SELECT count(id) AS totalattemptquestion FROM {gm_weekly_quiz_attempt} WHERE user_id='".$USER->id."' AND weekly_quiz_id='".$findReslt->weekly_quiz_id."' AND attempt='".@$LastAttempt->attempt."'";
      $attemptResult=$DB->get_record_sql($attemptsql, array());
      $attemptResult->totalattemptquestion=$attemptResult->totalattemptquestion+1;
      if($FindQ->action_type=="start_again"){
        if(@$LastAttempt!="" && @$LastAttempt->is_correct==0){
          $attemptResult->totalattemptquestion=1;
        }
      }

      $res_Questions->totalRemaining=$attemptResult->totalattemptquestion.'/'.$findReslt->totalquestion;
      $options=[];
      $res_options = $DB->get_records_sql("SELECT * 
        FROM {gm_weekly_quiz_answer} WHERE weekly_quiz_question_id='".$res_Questions->id."'");
      foreach($res_options as $key => $res_option){
        $options[]=$res_option;
      }
      $res_Questions->options=$options;
      $res_Questions->option_count=@sizeof($res_options);
    }
  }
  return $res_Question;
}

public function weekly_quiz_question_answer_returns(){
  return new external_multiple_structure(
   new external_single_structure(
    array(
      'id' =>new external_value(PARAM_INT,'id'),
      'totalRemaining' =>new external_value(PARAM_TEXT,'totalRemaining'),
      'weekly_quiz_theme_id' =>new external_value(PARAM_INT,'weekly_quiz_theme_id'),
      'weekly_quiz_product_type_id' =>new external_value(PARAM_INT,'weekly_quiz_product_type_id'),
      'weekly_quiz_id' =>new external_value(PARAM_INT,'weekly_quiz_id'),
      'start_time' =>new external_value(PARAM_TEXT,'start_time'),
      'end_time' =>new external_value(PARAM_TEXT,'end_time'),
      'mark_per_question' =>new external_value(PARAM_INT,'mark_per_question'),
      'question_attempt_duration' =>new external_value(PARAM_INT,'question_attempt_duration'),
      'is_negative_marks' =>new external_value(PARAM_INT,'is_negative_marks'),
      'is_answer_draggable' =>new external_value(PARAM_INT,'is_answer_draggable'),
      'type' =>new external_value(PARAM_RAW,'type'),
      'q_text_image' =>new external_value(PARAM_TEXT,'q_text_image'),
      'q_image' =>new external_value(PARAM_RAW,'q_image'),
      'action_type' =>new external_value(PARAM_TEXT,'action_type'),
      'attempt_limit' =>new external_value(PARAM_TEXT,'attempt_limit'),
      'theme_name' =>new external_value(PARAM_TEXT,'theme_name'),
      'option_count' =>new external_value(PARAM_INT,'option_count'),
      'options' => new external_multiple_structure(
        new external_single_structure(
          array(
            'id' =>new external_value(PARAM_INT,'id'),
            'weekly_quiz_question_id' =>new external_value(PARAM_INT,'weekly_quiz_question_id'),
            'q_text_image' =>new external_value(PARAM_RAW,'q_text_image'),
            'is_correct' =>new external_value(PARAM_INT,'is_correct'),
            'dragg_position' =>new external_value(PARAM_TEXT,'dragg_position')
          ))
      ))
  )
 );
}
###END Weekly Quiz

###START Weekly WQuizSaveAnswer
public function weekly_quiz_submit_answer_parameters(){
  return new external_function_parameters(
    array(
      'weekly_quiz_id' => new external_value(PARAM_INT,'weekly_quiz_id'),
      'weekly_quiz_theme_id' => new external_value(PARAM_INT,'weekly_quiz_theme_id'),
      'weekly_quiz_product_type_id' => new external_value(PARAM_INT,'weekly_quiz_product_type_id'),
      'question_id' => new external_value(PARAM_INT,'question_id'),
      'answer_id' => new external_value(PARAM_INT,'answer_id')
    )
  );  
}
public function weekly_quiz_submit_answer($weekly_quiz_id,$weekly_quiz_theme_id,$weekly_quiz_product_type_id,$question_id,$answer_id){
  global $DB, $CFG, $USER;
  $attemptnum=1;
  $firstA=$insertA=[];
  $firstA['status'] = false;
  $firstA['msg']    = "";
  $firstA['weekly_quiz_id']=0;

  $sqlquiz="SELECT id,action_type,attempt_limit FROM mdl_gm_weekly_quiz WHERE id='".$weekly_quiz_id."'";
  $findquiz=$DB->get_record_sql($sqlquiz,array());
  
  $sqluser="SELECT userid, outlet_id, city_id, state_id, region_id, designation_id, sub_designation_id 
  FROM {ums_employeemaster} WHERE userid=$USER->id";
  $userDetails=$DB->get_record_sql($sqluser, array());

  $sqlanswer="SELECT a.is_correct FROM mdl_gm_weekly_quiz_answer a 
  INNER JOIN mdl_gm_weekly_quiz_question q ON a.weekly_quiz_question_id=q.id  
  WHERE a.id='".$answer_id."' AND q.id='".$question_id."'";
  $findanswer=$DB->get_record_sql($sqlanswer,array());

  $sqlAttempt="SELECT id, attempt, is_correct, weekly_quiz_question_id FROM mdl_gm_weekly_quiz_attempt
  WHERE user_id='".$USER->id."' AND weekly_quiz_id='".$weekly_quiz_id."' ORDER BY id DESC";
  $FindLastAttempt=$DB->get_record_sql($sqlAttempt,array());
  
  if($findquiz->action_type!="start_again"){
    if(@$FindLastAttempt!="" && $FindLastAttempt->weekly_quiz_question_id==$question_id){
     $firstA['msg']  = "Already attempt";
     $firstA['action_type']   = "no_action";
     $firstA['is_correct']    = $FindLastAttempt->is_correct;
     return $firstA;
   }
 }
 if($findquiz->action_type=="close_quiz"){
  if($FindLastAttempt!="" && $FindLastAttempt->is_correct==0){
    $firstA['status'] = true;
    $firstA['msg']  = "Close the window";
    $firstA['action_type']   = "close_quiz";
    $firstA['is_correct']    =  0;  
  }
}
if($findquiz->action_type=="start_again"){
 if(@$FindLastAttempt!="" && $FindLastAttempt->is_correct==0){
  $attemptnum=$attemptnum+$FindLastAttempt->attempt;
  $firstA['action_type']   = "start_again";
  $firstA['is_correct']    = 0;
}
 if(@$FindLastAttempt!="" && $FindLastAttempt->is_correct==1){
  $attemptnum=$FindLastAttempt->attempt;
  $firstA['action_type']   = "no_action";
  $firstA['is_correct']    = 1;
}
if(@$FindLastAttempt!="" && $FindLastAttempt->is_correct==0){
  if($FindLastAttempt->attempt >= $findquiz->attempt_limit){
   $firstA['status'] = false;
   $firstA['msg']  = "Attempt limit reached";
   $firstA['action_type']   = "finished";
   $firstA['is_correct']    = 0;
   return $firstA;
 }
}
if(@$FindLastAttempt!="" && $FindLastAttempt->is_correct==1){
  if($FindLastAttempt->attempt > $findquiz->attempt_limit){
   $firstA['status'] = false;
   $firstA['msg']  = "Attempt limit reached";
   $firstA['action_type']   = "finished";
   $firstA['is_correct']    = 0;
   return $firstA;
 }
}
}

###Started inserted Fn
$insertA['created_at']=date('Y-m-d H:i:s');
$insertA['weekly_quiz_product_type_id'] =$weekly_quiz_product_type_id;
$insertA['weekly_quiz_theme_id']        =$weekly_quiz_theme_id;
$insertA['outlet_id']                   =@$userDetails->outlet_id;
$insertA['attempt']                     =@$attemptnum;
$insertA['city_id']                     =@$userDetails->city_id;
$insertA['state_id']                    =@$userDetails->state_id;
$insertA['region_id']                   =@$userDetails->region_id;
$insertA['designation_id']              =@$userDetails->designation_id;
$insertA['sub_designation_id']          =@$userDetails->sub_designation_id;
$insertA['weekly_quiz_id']              =$weekly_quiz_id;
$insertA['weekly_quiz_question_id']     =$question_id;
$insertA['weekly_quiz_answer_id']       =$question_id;
$insertA['user_id']                     =$USER->id;
$insertA['is_correct']                  =0;
if(@$findanswer->is_correct==1){
$insertA['is_correct']                  =$findanswer->is_correct;
}
$insertA['mark']=0;
if($insertA['is_correct']==1 && $findanswer->mark_per_question!=""){
  $insertA['mark']=$findanswer->mark_per_question;
}
if($DB->insert_record('gm_weekly_quiz_attempt', $insertA)){
  $firstA['status'] = true;
  $firstA['msg']  = "successfully inserted";
  $firstA['action_type']   ="no_action";
  $firstA['is_correct']    = $insertA['is_correct'];
}
$sqlAttempt="SELECT id, attempt, is_correct FROM mdl_gm_weekly_quiz_attempt
WHERE user_id='".$USER->id."' AND weekly_quiz_id='".$weekly_quiz_id."' ORDER BY id DESC";
$FindLastAttempt=$DB->get_record_sql($sqlAttempt,array());
 if($findquiz->action_type=="close_quiz"){
  if($FindLastAttempt->is_correct==0){
    $firstA['status'] = true;
    $firstA['msg']  = "Close the window";
    $firstA['action_type']   = "close_quiz";
    $firstA['is_correct']    =  0;  
  }
}
if($findquiz->action_type=="start_again"){
  if(@$FindLastAttempt!="" && $FindLastAttempt->is_correct==0){
    $attemptnum=$attemptnum+$FindLastAttempt->attempt;
    $firstA['action_type']   = "start_again";
    $firstA['is_correct']    = 0;
  }
  if(@$FindLastAttempt!="" && $FindLastAttempt->is_correct==0){
    if($FindLastAttempt->attempt >= $findquiz->attempt_limit){
     $firstA['status'] = false;
     $firstA['msg']  = "Attempt limit reached";
     $firstA['action_type']   = "finished";
     $firstA['is_correct']    = 0;
     return $firstA;
   }
 }
 if(@$FindLastAttempt!="" && $FindLastAttempt->is_correct==1){
  if($FindLastAttempt->attempt > $findquiz->attempt_limit){
   $firstA['status'] = false;
   $firstA['msg']  = "Attempt limit reached";
   $firstA['action_type']   = "finished";
   $firstA['is_correct']    = 0;
   return $firstA;
 }
}
}
###End inserted Fn

$findsql ="SELECT qq.id, q.id AS weekly_quiz_id, count(qq.id) AS totalquestion FROM {gm_weekly_quiz} q INNER JOIN {gm_weekly_quiz_question} qq ON q.id=qq.weekly_quiz_id WHERE q.id='".$weekly_quiz_id."' AND qq.deleted=0";
$findReslt=$DB->get_record_sql($findsql, array());
$attemptsql="SELECT count(id) AS totalattemptquestion FROM {gm_weekly_quiz_attempt} WHERE user_id='".$USER->id."' AND weekly_quiz_id='".$findReslt->weekly_quiz_id."' AND attempt='".$attemptnum."'";
$attemptResult=$DB->get_record_sql($attemptsql, array());
if($findReslt->totalquestion==$attemptResult->totalattemptquestion){ 
##Final Result
  $InstList=[];
  $sqlquest = "SELECT count(id) AS totalalloted FROM mdl_gm_weekly_quiz_question WHERE weekly_quiz_id='".$weekly_quiz_id."' AND deleted=0";
  $totalquestion=$DB->get_record_sql($sqlquest);
  $sql = "SELECT wqa.id, wqa.attempt, wq.is_negative_marks,wq.mark_per_question FROM mdl_gm_weekly_quiz_attempt AS wqa INNER JOIN mdl_gm_weekly_quiz AS wq ON wqa.weekly_quiz_id=wq.id WHERE wqa.user_id='".$USER->id."' AND wqa.weekly_quiz_id='".$weekly_quiz_id."' ORDER BY wqa.id DESC";
  $first=$DB->get_record_sql($sql);
  $marks_obtained=$total_question=$correct_answer=$wrong_answer=0;
  if($first->attempt){
    $sqlcrt = "SELECT count(id) AS totalcorrect FROM mdl_gm_weekly_quiz_attempt WHERE user_id='".$USER->id."' AND weekly_quiz_id='".$weekly_quiz_id."' AND attempt='".$first->attempt."' AND is_correct=1";
    $attemptcorrect=$DB->get_record_sql($sqlcrt);
    $attemptcorrect->totalcorrect=$attemptcorrect->totalcorrect*$first->mark_per_question;

    $sqlinc = "SELECT count(id) AS totalincorrect FROM mdl_gm_weekly_quiz_attempt WHERE user_id='".$USER->id."' AND weekly_quiz_id='".$weekly_quiz_id."' AND attempt='".$first->attempt."' AND is_correct=0";
    $attemptincorrect=$DB->get_record_sql($sqlinc);
    $attemptincorrect->totalincorrect=$attemptincorrect->totalincorrect*$first->mark_per_question;
    $marks_obtained=$marks_obtained+$attemptcorrect->totalcorrect;
    if($first->is_negative_marks==1){
      $marks_obtained=$marks_obtained-$attemptincorrect->totalincorrect;
      $marks_obtained=$marks_obtained>0?$marks_obtained:'0';
    }
    $total_question = $total_question + $totalquestion->totalalloted;
    $correct_answer = $correct_answer + $attemptcorrect->totalcorrect;
    $wrong_answer   = $wrong_answer   + $attemptincorrect->totalincorrect;
    $InstList['weekly_quiz_id']    =$weekly_quiz_id;
    $InstList['user_id']           =$userDetails->userid;
    $InstList['total_question']    =$total_question;
    $InstList['correct_answer']    =$correct_answer;
    $InstList['wrong_answer']      =$wrong_answer;
    $InstList['marks_obtained']    =$marks_obtained;
    $InstList['outlet_id']         =$userDetails->outlet_id;
    $InstList['state_id']          =$userDetails->state_id;
    $InstList['city_id']           =$userDetails->city_id;
    $InstList['region_id']         =$userDetails->region_id;
    $InstList['designation_id']    =$userDetails->designation_id;
    $InstList['sub_designation_id']=$userDetails->sub_designation_id;
    $InstList['created_at']=date('Y-m-d h:i:s');
    $sqlfind="SELECT id FROM {gm_weekly_quiz_attempt_report} WHERE user_id='".$InstList['user_id']."' AND weekly_quiz_id='".$InstList['weekly_quiz_id']."'";
    $findResult=$DB->get_record_sql($sqlfind, array());
    if(@$findResult==""){
      $DB->insert_record('gm_weekly_quiz_attempt_report', $InstList);
    }
  }
##Final Result
  $firstA['action_type']   = "finished";
  $firstA['weekly_quiz_id']=$weekly_quiz_id;
}
return $firstA;
}
public function weekly_quiz_submit_answer_returns(){
  return new external_single_structure(
    array(
      'status'        => new external_value(PARAM_BOOL, 'status'),
      'msg'           => new external_value(PARAM_TEXT, 'msg'),
      'action_type'   => new external_value(PARAM_TEXT, 'action_type'),
      'is_correct'    => new external_value(PARAM_TEXT, 'is_correct'),
      'weekly_quiz_id'=> new external_value(PARAM_INT, 'weekly_quiz_id')
    )
  );
}
###END Weekly WQuizSaveAnswer

###START Weekly WQuizSaveAnswer All
public function weekly_quiz_submit_answer_all_parameters(){
  return new external_function_parameters(
    array(
      'received_question_answer' =>new external_multiple_structure(
        new external_single_structure(
          array(
            'answer_id'     => new external_value(PARAM_RAW, 'answer_id'),
            'question_id'       => new external_value(PARAM_INT, 'question_id'),
            'weekly_quiz_id'         => new external_value(PARAM_RAW, 'weekly_quiz_id'),
            'weekly_quiz_product_type_id'         => new external_value(PARAM_RAW, 'weekly_quiz_product_type_id'),
            'weekly_quiz_theme_id'         => new external_value(PARAM_RAW, 'weekly_quiz_theme_id')
          )
        )
      )
    )
  );  
}

public function weekly_quiz_submit_answer_all($received_question_answer){
  global $DB, $CFG, $USER;
  $ReportList=$firstA=[];
  $firstA['status'] = false;
  $firstA['msg']    = "";
  $firstA['action_type'] = "";
  $firstA['weekly_quiz_id']=""; 
  $dateFor=date('Y-m-d H:i:s');
  $rulesInfo=self::GameRules();
  if($rulesInfo['CountDown']['active_btn']==false){
    $firstA['msg']    = "You can't submit the result due to the elapse of time now";
    return $firstA;
  }
  $sqluser="SELECT userid, outlet_id, city_id, state_id, region_id, designation_id, sub_designation_id 
  FROM {ums_employeemaster} WHERE userid=$USER->id";
  $userDetails=$DB->get_record_sql($sqluser, array());
  $sql    = "SELECT id, is_negative_marks, mark_per_question FROM mdl_gm_weekly_quiz WHERE id='".$received_question_answer[0]['weekly_quiz_id']."'";
  $WquizInfo=$DB->get_record_sql($sql);
  $marks_obtained=$total_question=$correct_answer=$wrong_answer=0;
  if($received_question_answer!="" && sizeof($received_question_answer)>0){
foreach($received_question_answer as $key => $response){
    $sqlcrt = "SELECT is_correct FROM mdl_gm_weekly_quiz_answer WHERE id='".$response['answer_id']."'";
    $Rcrt   = $DB->get_record_sql($sqlcrt);
    $response['attempt']                =1;
    $response['weekly_quiz_answer_id']  =$response['answer_id'];
    $response['weekly_quiz_question_id']=$response['question_id'];
    $response['user_id']                =$USER->id;
    $response['is_correct']             =$Rcrt->is_correct==''?'0':$Rcrt->is_correct;
    $response['mark']                   =$WquizInfo->mark_per_question;
    $response['outlet_id']              =$userDetails->outlet_id;
    $response['city_id']                =$userDetails->city_id;
    $response['state_id']               =$userDetails->state_id;
    $response['region_id']              =$userDetails->region_id;
    $response['designation_id']         =$userDetails->designation_id;
    $response['sub_designation_id']     =$userDetails->sub_designation_id;
    $response['created_at']             =$dateFor;
    unset($response['answer_id'], $response['question_id']);
    $sqlatmpt="SELECT id FROM {gm_weekly_quiz_attempt} WHERE weekly_quiz_id='".$response['weekly_quiz_id']."' AND  weekly_quiz_product_type_id='".$response['weekly_quiz_product_type_id']."' AND weekly_quiz_theme_id='".$response['weekly_quiz_theme_id']."' AND weekly_quiz_question_id='".$response['weekly_quiz_question_id']."' AND weekly_quiz_answer_id='".$response['weekly_quiz_answer_id']."' AND user_id='".$response['user_id']."'";
    $findAtempt=$DB->get_record_sql($sqlatmpt, array());
    if(@$findAtempt->id==""){
      $DB->insert_record('gm_weekly_quiz_attempt', $response);
    }
}

  $sqlTquestion = "SELECT count(id) AS totalq 
  FROM mdl_gm_weekly_quiz_question 
  WHERE weekly_quiz_id='".@$WquizInfo->id."' AND deleted=0";
  $Tqnfo   = $DB->get_record_sql($sqlTquestion);
  $total_question=$total_question+$Tqnfo->totalq;

  $sqlTcquestion= "SELECT count(id) AS totalc 
  FROM mdl_gm_weekly_quiz_attempt 
  WHERE user_id='".$USER->id."' AND weekly_quiz_id='".@$WquizInfo->id."' AND is_correct=1";
  $Tcqnfo  = $DB->get_record_sql($sqlTcquestion);
  $correct_answer=$correct_answer+($Tcqnfo->totalc*$WquizInfo->mark_per_question);

  $sqlTinquestion= "SELECT count(id) AS totalinc 
  FROM mdl_gm_weekly_quiz_attempt 
  WHERE user_id='".$USER->id."' AND weekly_quiz_id='".@$WquizInfo->id."' AND is_correct=0";
  $Tincqnfo= $DB->get_record_sql($sqlTinquestion);
  $wrong_answer =$wrong_answer+$Tincqnfo->totalinc;

  $marks_obtained  =$marks_obtained+$correct_answer;
  if($WquizInfo->is_negative_marks==1){
    $marks_obtained=$correct_answer-($wrong_answer*0.25);
    $marks_obtained=$marks_obtained>0?$marks_obtained:'0';
  }

  $ReportList['weekly_quiz_id']    =$WquizInfo->id;
  $ReportList['user_id']           =$userDetails->userid;
  $ReportList['total_question']    =$total_question;
  $ReportList['correct_answer']    =$correct_answer;
  $ReportList['wrong_answer']      =$wrong_answer;
  $ReportList['marks_obtained']    =$marks_obtained;
  $ReportList['outlet_id']         =$userDetails->outlet_id;
  $ReportList['state_id']          =$userDetails->state_id;
  $ReportList['city_id']           =$userDetails->city_id;
  $ReportList['region_id']         =$userDetails->region_id;
  $ReportList['designation_id']    =$userDetails->designation_id;
  $ReportList['sub_designation_id']=$userDetails->sub_designation_id;
  $ReportList['created_at']=$dateFor;
  $sqlfind="SELECT id FROM {gm_weekly_quiz_attempt_report} WHERE user_id='".$ReportList['user_id']."' AND weekly_quiz_id='".$ReportList['weekly_quiz_id']."'";
  $findResult=$DB->get_record_sql($sqlfind, array());
  if(@$findResult==""){
    $DB->insert_record('gm_weekly_quiz_attempt_report', $ReportList);
    $firstA['status'] = true;
    $firstA['msg']    = "successfully inserted";
    $firstA['action_type'] = "finished";
    $firstA['weekly_quiz_id']=$ReportList['weekly_quiz_id'];

    ###App State Information Updates
    $SelectU=[];
    $sqlF="SELECT wq.id, wq.title,wqt.id as theme_id, wqt.theme_image_landing,wqt.theme_image_inner_page,wq.mark_per_question,wq.question_attempt_duration,wq.is_negative_marks,wq.weekly_quiz_product_type_id FROM {gm_weekly_quiz} wq INNER JOIN {gm_weekly_quiz_theme} wqt ON wq.weekly_quiz_theme_id=wqt.id WHERE wq.id='".$ReportList['weekly_quiz_id']."' AND wq.deleted=0 AND date(wq.date)='".date('Y-m-d')."'";
    $spinlist=$DB->get_record_sql($sqlF);
    $sqlSInfo="SELECT id FROM {gm_weekly_quiz_select} WHERE user_id='".$USER->id."' AND weekly_quiz_id='".$ReportList['weekly_quiz_id']."' AND weekly_quiz_product_type_id='".$spinlist->weekly_quiz_product_type_id."' AND weekly_quiz_theme_id='".$spinlist->theme_id."'";
    $Sinfor=$DB->get_record_sql($sqlSInfo, array());
    $SelectU['user_id']=$USER->id;
    $SelectU['weekly_quiz_id']=$ReportList['weekly_quiz_id'];
    $SelectU['weekly_quiz_product_type_id']=$spinlist->weekly_quiz_product_type_id;
    $SelectU['weekly_quiz_theme_id']=$spinlist->theme_id;
    $SelectU['created_at']=date('Y-m-d H:i:s');
    $SelectU['status']="finished";

    if(@$Sinfor->id && $Sinfor->id!=""){
     $SelectU['id']=$Sinfor->id;
     $SelectU['updated_at']=$SelectU['created_at'];
     unset($SelectU['created_at']);
     $DB->update_record('gm_weekly_quiz_select', $SelectU);
   }else{
     $DB->insert_record('gm_weekly_quiz_select', $SelectU);
   }
   ###App State Information Updates
 }
}
  return $firstA;
}
public function weekly_quiz_submit_answer_all_returns(){
  return new external_single_structure(
    array(
      'status'        => new external_value(PARAM_BOOL, 'status'),
      'msg'           => new external_value(PARAM_TEXT, 'msg'),
      'action_type'   => new external_value(PARAM_TEXT, 'action_type'),
      'weekly_quiz_id'=> new external_value(PARAM_TEXT, 'weekly_quiz_id')
    )
  );
}
###END Weekly WQuizSaveAnswer All

###START Weekly FindAttempt Result
public function weekly_quiz_attempt_result_parameters(){
  return new external_function_parameters(
    array(
      'weekly_quiz_id' => new external_value(PARAM_INT,'weekly_quiz_id')
    )
  );  
}
public function weekly_quiz_attempt_result($weekly_quiz_id){
  global $DB, $USER;
  $Results=[];
  $sqlR="SELECT qar.total_question, qar.correct_answer, qar.wrong_answer, qar.marks_obtained, (qar.total_question*wq.mark_per_question) AS total_marks 
  FROM {gm_weekly_quiz_attempt_report} qar INNER JOIN {gm_weekly_quiz} wq ON qar.weekly_quiz_id=wq.id WHERE qar.user_id='".$USER->id."' AND qar.weekly_quiz_id='".$weekly_quiz_id."'";
  $Results=$DB->get_record_sql($sqlR);
  if($Results==""){
    $Results['total_marks']   =0;
    $Results['total_question']=0;
    $Results['correct_answer']=0;
    $Results['wrong_answer']  =0;
    $Results['marks_obtained']=0;
  }
  return $Results;
}
public function weekly_quiz_attempt_result_returns(){
  return new external_single_structure(
    array(
      'total_question'   => new external_value(PARAM_INT, 'total_question'),
      'total_marks'      => new external_value(PARAM_INT, 'total_marks'),
      'correct_answer'   => new external_value(PARAM_INT, 'correct_answer'),
      'wrong_answer'     => new external_value(PARAM_INT, 'wrong_answer'),
      'marks_obtained'   => new external_value(PARAM_INT, 'marks_obtained')
    )
  );
}
###END Weekly FindAttempt Result

###START Weekly FindAttempt Result - UPDATED
public function weekly_quiz_attempt_result_updated_parameters(){
  return new external_function_parameters(
    array(
      'weekly_quiz_id' => new external_value(PARAM_INT,'weekly_quiz_id')
    )
  );  
}
public function weekly_quiz_attempt_result_updated($weekly_quiz_id){
  global $DB, $USER;
  $Results=[];
  $sqlR="SELECT qar.total_question, qar.correct_answer, qar.wrong_answer, qar.marks_obtained, (qar.total_question*wq.mark_per_question) AS total_marks 
  FROM {gm_weekly_quiz_attempt_report} qar INNER JOIN {gm_weekly_quiz} wq ON qar.weekly_quiz_id=wq.id WHERE qar.user_id='".$USER->id."' AND qar.weekly_quiz_id='".$weekly_quiz_id."'";
  $Results=$DB->get_record_sql($sqlR);
  if($Results==""){
    $Results['total_marks']   =0;
    $Results['total_question']=0;
    $Results['correct_answer']=0;
    $Results['wrong_answer']  =0;
    $Results['marks_obtained']=0;
  }
  return $Results;
}
public function weekly_quiz_attempt_result_updated_returns(){
  return new external_single_structure(
    array(
      'total_question'   => new external_value(PARAM_INT, 'total_question'),
      'total_marks'      => new external_value(PARAM_TEXT, 'total_marks'),
      'correct_answer'   => new external_value(PARAM_INT, 'correct_answer'),
      'wrong_answer'     => new external_value(PARAM_INT, 'wrong_answer'),
      'marks_obtained'   => new external_value(PARAM_TEXT, 'marks_obtained')
    )
  );
}
###END Weekly FindAttempt Result - UPDATED

###START Weekly Quiz
public function WQuiz_parameters(){
  return new external_function_parameters(
    array(
      'quizcat' => new external_value(PARAM_INT,'quizcat')
    )
  );  
}

public function WQuiz($quizcat){
  global $DB, $CFG, $USER;
  $options=[];
  $today  = date('Y-m-d');
  $res_Question = $DB->get_records_sql("SELECT wqq.id,wqq.weekly_quiz_id,wqq.type,wqq.is_answer_draggable,wqq.q_text_image,wq.weekly_quiz_theme_id,wq.weekly_quiz_product_type_id FROM {gm_weekly_quiz_question} wqq LEFT JOIN {gm_weekly_quiz} wq ON wqq.weekly_quiz_id=wq.weekly_quiz_theme_id");
  if(!empty($res_Question)){
    foreach($res_Question as $key => $res_Questions){
      $res_options = $DB->get_records_sql("SELECT * 
        FROM {gm_weekly_quiz_answer} WHERE weekly_quiz_question_id='".$res_Questions->id."'");
      foreach($res_options as $key => $res_option){
        $options[]=$res_option;
      }
      $res_Questions->options=$options;
    }
  }
  return $res_Question;
}

public function WQuiz_returns(){
  return new external_multiple_structure(
   new external_single_structure(
    array(
      'id' =>new external_value(PARAM_INT,'id'),
      'weekly_quiz_theme_id' =>new external_value(PARAM_INT,'weekly_quiz_theme_id'),
      'weekly_quiz_product_type_id' =>new external_value(PARAM_INT,'weekly_quiz_product_type_id'),
      'weekly_quiz_id' =>new external_value(PARAM_INT,'weekly_quiz_id'),
      'is_answer_draggable' =>new external_value(PARAM_INT,'is_answer_draggable'),
      'type' =>new external_value(PARAM_RAW,'type'),
      'q_text_image' =>new external_value(PARAM_RAW,'q_text_image'),
      'options' => new external_multiple_structure(
        new external_single_structure(
          array(
            'id' =>new external_value(PARAM_INT,'id'),
            'weekly_quiz_question_id' =>new external_value(PARAM_INT,'weekly_quiz_question_id'),
            'q_text_image' =>new external_value(PARAM_RAW,'q_text_image'),
            'is_correct' =>new external_value(PARAM_INT,'is_correct')
          ))
      ))
  )
 );
}
###END Weekly Quiz

###GAMIFICATION WEB SERVICE
   public static function get_conference_parameters() {
        return new external_function_parameters(
                array()
        );
    }

    public static function get_conference() {
        global $USER, $DB,$CFG;
        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);
        //$sqlu = 'SELECT u.code,c.latitude,c.longitude FROM {ums_employeemaster} u INNER JOIN {ums_user_cordinate} c ON u.userid=c.userid WHERE u.userid="'.$USER->id.'"';
        $sqlu = 'SELECT code FROM {ums_employeemaster} WHERE userid="'.$USER->id.'"';
        $ufirst = $DB->get_record_sql($sqlu);
        $todaydatetime = date('d-m-Y H:i');
       
        $sql = 'SELECT * FROM {conference} WHERE employee LIKE "%'.$ufirst->code.'%" AND deleted=0';
        //echo $sql;exit;
        $records = $DB->get_records_sql($sql);
        $newdata = array();
        foreach ($records as $key => $val){
          $dates = $val->meeting_end_time;
          if($dates >= $todaydatetime)
          {

            $result = new stdClass();

            $day = date('l',strtotime($val->meeting_start_time));
            $start_time = date('h:i A',strtotime($val->meeting_start_time));
            $end_time = date('h:i A',strtotime($val->meeting_end_time));
            $meeting_time = $day.', '.$start_time.' - '.$end_time;   
            $result->id = $val->id;
            $result->meeting_title = $val->meeting_title;
            $result->meeting_time = $meeting_time;
            $result->meeting_plateform = $val->meeting_plateform;
            $result->meeting_link = $val->meeting_link;
            $result->created_date = $val->created_date;
            $result->video_id = $val->url_type;
            $result->meeting_status = 'Join Now';  
            $result->geofencing_enabled = 'No';
            if($val->geofencing_enabled=="Yes"){
              $result->geofencing_enabled = 'Yes';
            }
            $result->lat = $ufirst->latitude;  
            $result->long = $ufirst->longitude;  
            $result->radius = 50; 
            $result->message = '';  
            $newdata[]=$result;
          }
        }
        return $newdata;
    }

    public static function get_conference_returns() {
      return new external_multiple_structure(
        new external_single_structure(
            array(
             'id' => new external_value(PARAM_RAW, 'Conference id', VALUE_OPTIONAL),
             'meeting_title' => new external_value(PARAM_RAW, 'Conference Title', VALUE_OPTIONAL),
             'meeting_time' => new external_value(PARAM_RAW, 'Conference Start time', VALUE_OPTIONAL),
             'meeting_plateform' => new external_value(PARAM_RAW, 'Conference Plateform'),
             'meeting_link' => new external_value(PARAM_RAW, 'Conference Link'),
             'created_date' => new external_value(PARAM_RAW, 'Conference Link upload date'),
             'video_id' => new external_value(PARAM_INT, 'Conference Link video id'),
             'meeting_status' => new external_value(PARAM_RAW, 'Conference Link Status'),
             'geofencing_enabled' => new external_value(PARAM_RAW, 'Geo Fencing Enabled'),
             'lat' => new external_value(PARAM_RAW, 'Latitude'),
             'long' => new external_value(PARAM_RAW, 'Longitude'),
             'radius' => new external_value(PARAM_RAW, 'Radius'),
             'message' => new external_value(PARAM_RAW, 'Message')
            )
     ));
  }

    //------------------weekly quiz start from here ----------------------

  public static function weekly_quiz_parameters() 
  {
    return new external_function_parameters(
      array()
    );
  }
  
  public static function weekly_quiz()
  {
      global $USER,$DB,$CFG;
      $aa = array();
    $resultarray=array();
    $category = array();
        $dd = $dd1 = $dd2 = $dd3 = $dd4 = $dd5 = $dd6 = array();
        $op1 = $op2 = $op3 = $op4 = $op5 = $op6 = array();
      
        $today  = date('Y-m-d');
        $date = new DateTime();
    $date->modify('next monday');
    $m_date =  $date->format('Y-m-d');
    $m_time =  date('H:i:s'); 

    //echo $m_time;exit;  

        $q_cat = $DB->get_records_sql("SELECT * FROM mdl_gm_quiz_category WHERE deleted ='0'");

        foreach ($q_cat as $key => $value) {
          $cat_result = array('id'   => $value->id,
                  'cat_name'   => $value->cat_name,
                  'color_code'   => $value->color_code,
                );
      $category[]= $cat_result;
        }

      //$res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE deleted ='0' AND qdate = '".$today."'");

      if(($today == $m_date) && ($m_time >= '15:00:00' && $m_time <= '17:00:00'))
    {

      $res_Question = $DB->get_record_sql("SELECT wq.*,wqa.weekly_quiz_question_id,wqa.type,wqa.q_text_image,wqa.is_correct
      FROM maruti_prod.mdl_weekly_quiz wq
      inner join mdl_weekly_quiz_answer wqa on wq.id = wqa.weekly_quiz_question_id where wq.start_date = '".$m_date."'");
      if(!empty($res_Question))
        {
        $questionid       = $res_Question->id;
        $question_type    = $res_Question->type;
        $question       = $res_Question->title;
        // $option_a_type    = $res_Question->option_a_type;
        // $option_a         = $res_Question->option_a;
        // $option_b_type    = $res_Question->option_b_type;
        // $option_b         = $res_Question->option_b;
        // $option_c_type    = $res_Question->option_c_type;
        // $option_c         = $res_Question->option_c;
        // $option_d_type    = $res_Question->option_d_type;
        // $option_d         = $res_Question->option_d;
        //$additional_text  = $res_Question->additional_text;
        if($question_type == 'text')
        {
          $q_type = 'text';
          $question_text  = isset($question) && $question!=''?$question:'--';
          $question_image = "";
        }
        if($question_type == 2)
        {
          $q_type = 'Image';
          $question_text  = "";
          $question_image = $CFG->wwwroot.$question;
        }
        // if($question_type == 3)
        // {
        //  $q_type = 'Both';
        //  $question_text  = $additional_text;
        //  $question_image = $CFG->wwwroot.$question;
        // }
        
        //------------------------------------------------------------//
        // if($option_a_type == 1)
        // {
        //  $option_A_type  = 'Text';
        //  $option_A_text  = isset($option_a) && $option_a!=''?$option_a:'--';
        //  $option_A_image = '-';
        // }
        // if($option_a_type == 2)
        // {
        //  $option_A_type   = 'Image';
        //  $option_A_text   = "";
        //  $option_A_image  = $CFG->wwwroot.$option_a;
          
        // }
        //----------------------------------------------------------------//
        // if($option_b_type == 1)
        // {
        //  $option_B_type  = 'Text';
        //  $option_B_text  = isset($option_b) && $option_b!=''?$option_b:'--';
        //  $option_B_image = '-';
        // }
        // if($option_b_type == 2)
        // {
        //  $option_B_type   = 'Image';
        //  $option_B_text   = "";
        //  $option_B_image  = $CFG->wwwroot.$option_b;
        // }
        
        //-------------------------------------------------------------//
        
        // if($option_c_type == 1)
        // {
        //  $option_C_type  = 'Text';
        //  $option_C_text  = isset($option_c) && $option_c!=''?$option_c:'--';
        //  $option_C_image = '-';
        // }
        // if($option_c_type == 2)
        // {
        //  $option_C_type   = 'Image';
        //  $option_C_text   = "";
        //  $option_C_image  = $CFG->wwwroot.$option_c;
        // }
        
        //-------------------------------------------------------------//
        
        // if($option_d_type == 1)
        // {
        //  $option_D_type   = 'Text';
        //  $option_D_text   = isset($option_d) && $option_d!=''?$option_d:'--';
        //  $option_D_image  = '-';
        //  //$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
          
        // }
        // if($option_d_type == 2)
        // {
        //  $option_D_type   = 'Image';
        //  $option_D_text   = "";
        //  $option_D_image  = $CFG->wwwroot.$option_d;
        // }
        
        // $option_E_type   = 'Text';
        // $option_E_text   = 'All of these';
        // $option_E_image  = '-'; 
        // $option_F_type   = 'Text';
        // $option_F_text   = 'None of these';
        // $option_F_image  = '-'; 
        
        //---------------------------------------------------------------//
        
        $alldd  = array('questionid' => $questionid,
                'questiontype'   => $q_type,
                'question_text'  => $question_text,
                'question_image' => $question_image);
        $aa[]   = $alldd;       
        // $option1 = array('option_type'   => $option_A_type,
        //         'option_text'   => $option_A_text,
        //         'option_image'  => $option_A_image
        //        );
        // $op1[]= $option1;
        
        // $option2 = array('option_type'   => $option_B_type,
        //         'option_text'   => $option_B_text,
        //         'option_image'  => $option_B_image
        //        );
        // $op2[]= $option2;
        
        // $option3 = array('option_type'  => $option_C_type,
        //         'option_text'   => $option_C_text,
        //         'option_image'  => $option_C_image
        //        );
        // $op3[]= $option3;
        
        // $option4 = array('option_type'   => $option_D_type,
        //         'option_text'   => $option_D_text,
        //         'option_image'  => $option_D_image
        //        );
        // $op4[]= $option4;
        
        // $option5 = array('option_type'   => $option_E_type,
        //         'option_text'   => $option_E_text,
        //         'option_image'  => $option_F_image
        //        );
        // $op5[]= $option5;
        
        // $option6 = array('option_type'   => $option_F_type,
        //         'option_text'   => $option_F_text,
        //         'option_image'  => $option_F_image
        //        );
        // $op6[]= $option6;
        //$op = array_merge($op1,$op2,$op3,$op4);
        $dd['Question'] = $aa;
        //$dd['Options']  = $op;
        $dd['category']  = $category;
        return($dd);
      }
      else
      {
        // $resultarray = array(
        //            'status'  => 1,
        //            'message' => 'Question Missing'
        //      );
        $alldd  = array('questionid' => 0,
                'questiontype'   => '',
                'question_text'  => '',
                'question_image' => '');
        $aa[]   = $alldd; 
        $dd['Question'] = $aa;
        $dd['category']  = $category;
        return($dd);
      }
      //echo "IN";
    }else{

      $alldd  = array('questionid' => 0,
                'questiontype'   => '',
                'question_text'  => '',
                'question_image' => '');
        $aa[]   = $alldd; 
        $dd['Question'] = $aa;
        $dd['category']  = $category;
        return($dd);
      //echo "out";
    }
        
  }
  
  public static function weekly_quiz_returns()
  {
    return new external_single_structure(
            array(
                    
       'Question' => new external_multiple_structure(
          new external_single_structure(
          array(
            'questionid'      => new external_value(PARAM_INT,'questionid'),
            'questiontype'    => new external_value(PARAM_TEXT,'questiontype'),
            'question_text'   => new external_value(PARAM_TEXT,'question_text'),
            'question_image'  => new external_value(PARAM_TEXT,'question_image'),
           
          ))),
      // 'Options' => new external_multiple_structure(
      //      new external_single_structure(
      //    array(
      //        'option_type'   => new external_value(PARAM_TEXT,'option_type'),
      //        'option_text'   => new external_value(PARAM_TEXT,'option_text'),
      //        'option_image'  => new external_value(PARAM_TEXT,'option_image')
      //      ))
      //    ),
      'category' => new external_multiple_structure(
            new external_single_structure(
          array(
              'id'   => new external_value(PARAM_RAW,'cat id'),
              'cat_name'   => new external_value(PARAM_TEXT,'cat name'),
              'color_code'   => new external_value(PARAM_TEXT,'cat color code')
              
            ))
          )
                )
        );
  }
  //----------weekly quiz_end_here---------------------




// code for gramx

  //--------start emoji master--------------------------------

  public function get_emojimaster_parameters()
  {
    return new external_function_parameters(
      array( )
    );
  }
    
  public function get_emojimaster()
  {
    global $DB,$USER,$CFG;
    $emlists = $DB->get_records_sql("SELECT * FROM {ums_emoji_master} WHERE is_inactive=0 ORDER BY id ASC");
    
    $mainfolder = array();
    foreach ($emlists as $key => $em) 
    { 
      $alldd['EmojiList'][] = array('emojiid'=>$em->id,'emojiname'=>$em->name,'emojipath'=>$CFG->wwwroot.$em->filepath);
    }
    $aa = $alldd;
    return($aa);
  }
    
  public function get_emojimaster_returns()
  {
    return new external_single_structure(
      array(
        
         'EmojiList' => new external_multiple_structure(
              new external_single_structure(
                      array(
            'emojiid'=>new external_value(PARAM_INT,'Emoji ID'),
            'emojiname'=>new external_value(PARAM_RAW,'Emoji Name'),
            'emojipath'=>new external_value(PARAM_RAW,'Emoji Path'),

             
        ))),
          

      )
    );
  }

//--------end emoji master----------------------------------

//--------get emoji response--------------------------------

  public function put_emoji_response_parameters()
  {
    return new external_function_parameters(
      array( 'elementid'=>new external_value(PARAM_INT, 'Unique ID of activity performed'),
           'menutype'=>new external_value(PARAM_RAW, 'Activity which triggers emoji event'),
           'comment'=>new external_value(PARAM_RAW, 'Feedback for activity',VALUE_OPTIONAL),
           'emojiid'=>new external_value(PARAM_RAW, 'Emoji ID',VALUE_OPTIONAL),
           'module_id'=>new external_value(PARAM_INT, 'Sub Folder ID',VALUE_OPTIONAL)
      )
    );
  }
  
  public function put_emoji_response($elementid,$menutype,$comment,$emojiid,$module_id)
  {
    global $DB,$USER,$CFG;
    $status=false;
    $message="";
    $is_commented=false;
    //print_r($_REQUEST);exit;
    //exit
    
    if($emojiid == 11)
    {
      if(!$DB->record_exists('ums_emoji_responses_comments',array('userid'=>$USER->id,'menutype'=>$menutype,'element_id'=>$elementid,'module_id'=>$module_id)))
      {
        
        if($comment!='')
        {
          if(!preg_match('/^[a-zA-Z0-9.?,% ]+$/', $comment))
          {
            $is_commented=false;
            $message="special characters not allowed !!";
          }else{
            $record=new StdClass();
            $record->userid=$USER->id;
            $record->comment=$comment;
            $record->menutype=$menutype;
            $record->element_id=$elementid;
                $record->module_id=$module_id;
            $record->created=time();
            $DB->insert_record('ums_emoji_responses_comments',$record);
            $is_commented=true;
          }
          
        }
      }
      else
      {
        $is_commented=false;
        $message="Already Commented!";
      }
    }

    switch($menutype)
    {
      case 'course':
      // case 'assessment':
      // case 'survey':
      if(!$DB->record_exists('course', array('id'=>$elementid)))
      {
        $status=false;
      }
      else
      {
        $status=true;
      }
      
      break;
      case 'avhub':
      if(!$DB->record_exists('ums_av_files', array('av_folder_id'=>$elementid)))
      {
        $status=false;
      }
      else
      {
        $status=true;
      }
      break;
      
      default:
      $status=false;
      $message="Activity does not exist";
      
    }
    //check whether user have liked or disliked this activity earlier
    $dislike_visible=true;
    $like_visible=true;
    $checklikeunlike=$DB->get_record_sql("SELECT ues.id,ues.emoji_id,uem.name FROM {ums_emoji_responses} ues LEFT JOIN {ums_emoji_master} uem ON uem.id=ues.emoji_id WHERE ues.emoji_id in (1,2) AND ues.element_id='".$elementid."' AND ues.module_id='".$module_id."' AND ues.userid='".$USER->id."' AND ues.menutype='".$menutype."'");
    $like_selected=false;
    $dislike_selected=false;
    if(!empty($checklikeunlike))
    {
      if($emojiid==1 || $emojiid==2)
      {
      $DB->execute("UPDATE {ums_emoji_responses} SET emoji_id='".$emojiid."',updated='".time()."',status=1 WHERE id='".$checklikeunlike->id."'");

      $checklikeunlike=$DB->get_record_sql("SELECT ues.id,ues.emoji_id,uem.name FROM {ums_emoji_responses} ues LEFT JOIN {ums_emoji_master} uem ON uem.id=ues.emoji_id WHERE ues.emoji_id in (1,2) AND ues.element_id='".$elementid."' AND ues.module_id='".$module_id."' AND ues.userid='".$USER->id."' AND ues.menutype='".$menutype."'");
      }
      switch($checklikeunlike->name)
      {
        case 'like':
        $dislike_visible=true;
        $like_visible=false;
        $like_selected=true;
        break;
        case 'dislike':
        $dislike_visible=false;
        $like_visible=true;
        $dislike_selected=true;
        break;
      }
    }
    else
    {
      if($emojiid==1 || $emojiid==2)
      {
      $record=new StdClass();
      $record->userid=$USER->id;
      $record->emoji_id=$emojiid;
      $record->menutype=$menutype;
      $record->element_id=$elementid;
        $record->module_id=$module_id;
      $record->status=1;
      $record->created=time();
      $DB->insert_record('ums_emoji_responses',$record);
      }

      $checklikeunlike=$DB->get_record_sql("SELECT ues.id,ues.emoji_id,uem.name FROM {ums_emoji_responses} ues LEFT JOIN {ums_emoji_master} uem ON uem.id=ues.emoji_id WHERE ues.emoji_id in (1,2) AND ues.element_id='".$elementid."' AND ues.module_id='".$module_id."' AND ues.userid='".$USER->id."' AND ues.menutype='".$menutype."'");
      switch($checklikeunlike->name)
      {
        case 'like':
        $dislike_visible=true;
        $like_visible=false;
        $like_selected=true;
        break;
        case 'dislike':
        $dislike_visible=false;
        $like_visible=true;
        $dislike_selected=true;
        break;
      }
    }
            
    $emojilist=array();
    if($status)
    {
      $get_all_emoji_records=$DB->get_records_sql("SELECT * FROM {ums_emoji_master} where is_inactive=0");
      if(!empty($get_all_emoji_records))
      {
        foreach($get_all_emoji_records as $emoji_record)
        {
          $is_emoji_visible=true;
          $is_emoji_selected=false;
          if($emoji_record->name=='like')
          {
            $is_emoji_visible=$like_visible;
            $is_emoji_selected=$like_selected;
            
          }
          if($emoji_record->name=='dislike')
          {
            $is_emoji_visible=$dislike_visible;
            $is_emoji_selected=$dislike_selected;
          }
          $filter=" AND status=1 ";
          if($emoji_record->id>2 && $emojiid==$emoji_record->id)
          {
            
            
            // $checkstatus=$DB->get_record_sql("SELECT ues.id,ues.status,uem.name FROM {ums_emoji_responses} ues LEFT JOIN {ums_emoji_master} uem ON uem.id=ues.emoji_id WHERE ues.emoji_id='".$emoji_record->id."' AND ues.element_id='".$elementid."' AND ues.module_id='".$module_id."' AND ues.userid='".$USER->id."' AND ues.menutype='".$menutype."'");
            $checkstatus_view=$DB->get_record_sql("SELECT ues.id,ues.status,uem.name FROM {ums_emoji_responses} ues LEFT JOIN {ums_emoji_master} uem ON uem.id=ues.emoji_id WHERE ues.emoji_id in (10,11) AND ues.element_id='".$elementid."' AND ues.module_id='".$module_id."' AND ues.userid='".$USER->id."' AND ues.menutype='".$menutype."'");

            if(!empty($checkstatus_view))
            {
              $record=new StdClass();
              $record->id=$checkstatus_view->id;
              $record->status=$s;
              $record->updated=time();
              $DB->update_record('ums_emoji_responses',$record);
            }else{
              $record=new StdClass();
              $record->userid=$USER->id;
              $record->emoji_id=$emoji_record->id;
              $record->status=1;
              $record->menutype=$menutype;
              $record->element_id=$elementid;
              $record->module_id=$module_id;
              $record->created=time();
              $DB->insert_record('ums_emoji_responses',$record);
            }

            $checkstatus=$DB->get_record_sql("SELECT ues.id,ues.status,uem.name FROM {ums_emoji_responses} ues LEFT JOIN {ums_emoji_master} uem ON uem.id=ues.emoji_id WHERE ues.emoji_id in (6,7,8,9,12) AND ues.element_id='".$elementid."' AND ues.module_id='".$module_id."' AND ues.userid='".$USER->id."' AND ues.menutype='".$menutype."'");
            
            if(!empty($checkstatus))
            {
              $ch="if";
              if($checkstatus->status==1)
              {
                $s=0;
              }
              else
              {
                $s=1;
              }
              if($emojiid == 6 || $emojiid == 7 || $emojiid == 8 || $emojiid == 9 || $emojiid == 12)
              {
              $record=new StdClass();
              $record->id=$checkstatus->id;
              $record->status=$s;
              $record->emoji_id=$emoji_record->id;
              $record->updated=time();
              $DB->update_record('ums_emoji_responses',$record);
              }
            }
            else
            {
              $ch="else";
              
              if($emojiid == 6 || $emojiid == 7 || $emojiid == 8 || $emojiid == 9 || $emojiid == 12)
              {
              $record=new StdClass();
              $record->userid=$USER->id;
              $record->emoji_id=$emoji_record->id;
              $record->status=1;
              $record->menutype=$menutype;
              $record->element_id=$elementid;
                      $record->module_id=$module_id;
              $record->created=time();
              $DB->insert_record('ums_emoji_responses',$record);
              
              }
            }
            
          }
          $checks=$DB->get_record_sql("SELECT ues.id,ues.status,uem.name FROM {ums_emoji_responses} ues LEFT JOIN {ums_emoji_master} uem ON uem.id=ues.emoji_id WHERE ues.emoji_id='".$emoji_record->id."' AND ues.element_id='".$elementid."' AND ues.module_id='".$module_id."' AND ues.userid='".$USER->id."' AND ues.menutype='".$menutype."'");
            
            if(!empty($checks))
            {
              if($checkstatus->status==1)
              {
                $is_emoji_selected=true;
              }
              else
              {
                $is_emoji_selected=false;
              }
            }
          $count=0;
          
          $c=$DB->get_record_sql("SELECT count(id) as c FROM {ums_emoji_responses} WHERE element_id='".$elementid."' AND module_id='".$module_id."' and menutype='".$menutype."' and emoji_id='".$emoji_record->id."' $filter");
          if(!empty($c))
          {
            $count=$c->c;
          }
          $emojilist[]=array('emoji_id'=>$emoji_record->id,
          'emoji_name'=>$emoji_record->name,
          'emoji_filepath'=>$CFG->wwwroot.$emoji_record->filepath,
          'is_emoji_visible'=>$is_emoji_visible,
          'is_emoji_selected'=>$is_emoji_selected,
          'count'=>$count
          );
          
        }
      }
    }
    else
    {
    $message="Activity does not exist"; 
    }
    
    $result=array(
    'status'=>$status,
    'message'=>$message,
    'is_commented'=>$is_commented,
    'emojilist'=>$emojilist
    );

    if($menutype == 'course')
    {
       course_like_comment_point_update($USER->id,$elementid);
       //echo "byy";exit;
    }else{
       video_like_comment_point_update($USER->id,$elementid);
    }

    // exit;
    //print_r($result);
    //exit;
    return($result);
  }
  
  public function put_emoji_response_returns()
  {
    return new external_single_structure(
      array(
        'status'=>new external_value(PARAM_RAW,'Status'),
        'message'=>new external_value(PARAM_RAW,'Message'),
        'is_commented'=>new external_value(PARAM_RAW,'If activity feedback is given'),
        'emojilist'=>new external_multiple_structure(
              new external_single_structure(
          array(
          'emoji_id'=>new external_value(PARAM_INT,'Emoji ID',VALUE_OPTIONAL),
          'emoji_name'=>new external_value(PARAM_RAW,'Emoji Name',VALUE_OPTIONAL),
          'emoji_filepath'=>new external_value(PARAM_RAW,'Emoji File Path',VALUE_OPTIONAL),
          'is_emoji_visible'=>new external_value(PARAM_RAW,'Emoji Visible',VALUE_OPTIONAL),
          'is_emoji_selected'=>new external_value(PARAM_RAW,'Emoji Selected',VALUE_OPTIONAL),
          'count'=>new external_value(PARAM_RAW,'Emoji Count',VALUE_OPTIONAL)
          )
          )
        )
             
        )
    );
  }

//--------end emoji response--------------------------------

//--------top 10 like course and video---------------------------

  public static function top10_courses_videos_parameters(){
        return new external_function_parameters(
            array()
        );

    }

    public static function top10_courses_videos(){
      global $DB,$USER;
      $topten=$courselist=$avhublist=[];

      $course_lcount = $DB->get_records_sql("SELECT element_id,module_id, COUNT(emoji_id) as total_like
            FROM mdl_ums_emoji_responses where emoji_id=1 and menutype = 'course'
            Group By element_id
            Order By COUNT(emoji_id) DESC
            LIMIT 10");
      //print_r($course_lcount);die;

      $i = 1;
      foreach($course_lcount as $key => $data){ 

        // if($i%2 == 0)
        // {
        //   $img_url='https://demolms.gols.in/images/course1.jpg';
        // }else{
        //   $img_url='https://demolms.gols.in/images/course2.jpg';
        // }

        $img_url='https://ilearn.marutisuzuki.com/images/course1.jpg';

        $checkenrollmentmethods = $DB->get_record_sql("SELECT id FROM mdl_enrol WHERE courseid = '".$data->element_id."' and enrol='manual'");

        $enrollmentdate = $DB->get_record_sql("SELECT timeend FROM mdl_user_enrolments WHERE enrolid = '".$checkenrollmentmethods->id."' AND userid = '".$USER->id."'");
        //print_r($enrollmentdate);exit;

        $vcourse = $DB->get_record_sql("SELECT id,visible FROM mdl_course WHERE id = '".$data->element_id."'");
        //print_r($vcourse->visible);
        $progress = null;
        if($vcourse->visible == 1)
        {
            if(!empty($enrollmentdate))
            {
              $enrolenddate = $enrollmentdate->timeend;

              if($enrolenddate == 0)
              {
                $progress = "CourseActive";
              }else{
                if($enrolenddate > time())
                {
                     $progress = "CourseActive";
                }else{
                     $progress = "CourseExpired";
                }
              }
            }else{
                 $progress = "NotEnrolled";
            }
        }else{
            $progress = "CourseHidden";
        }

        // if(!empty($enrollmentdate))
        //   {
        //     $enrolenddate = $enrollmentdate->timeend;
        //     $progress = null;

        //     if($enrolenddate == 0)
        //     {
        //      $progress = "CourseActive";
        //     }else{
        //      if($enrolenddate > time())
         //      {
         //           $progress = "CourseActive";
         //      }else{
         //           $progress = "CourseExpired";
         //      }
        //     }
        //   }else{
        //        $progress = "NotEnrolled";
        //   }
        

         $url = 'https://ilearn.marutisuzuki.com/mod/scorm/view.php?id='.$data->module_id.'&act='.$progress;

         $course = $DB->get_records_sql("SELECT c.id, c.shortname, c.fullname, c.idnumber, c.visible,c.summary, c.summaryformat, c.format, c.showgrades, c.lang, c.enablecompletion, c.category, c.startdate, c.enddate,cm.id as module_id,s.name as video_name from mdl_course c
          left join mdl_course_modules cm on c.id = cm.course
          left join mdl_scorm s on cm.instance = s.id
          where c.visible=1 and cm.course='".$data->element_id."' and cm.id='".$data->module_id."'");

         //print_r($course);


        foreach($course as $key => $courses){
          $courselist[] = array(
           'id' => $courses->id,
           'shortname' => $courses->shortname,
           'fullname' => $courses->fullname,
           'idnumber' => $courses->idnumber,
           'visible' => $courses->visible,
           'summary' => $courses->summary,
           'summaryformat' => $courses->summaryformat,
           'format' => $courses->format,
           'showgrades' => $courses->showgrades,
           'lang' => clean_param($courses->lang, PARAM_LANG),
           'enablecompletion' => $courses->enablecompletion,
           'category' => $courses->category,
           'startdate' => date('Y-m-d', $courses->startdate),
           'enddate' => date('Y-m-d', $courses->enddate),
           'url' => $url,
           'image_url' => $img_url,
           'process' => $progress,
           'enrollend_date'=>date('Y-m-d',$enrolenddate),
           'total_like'=>$data->total_like
         );
        }
        $i++;
      }

      //print_r($courselist);die;
      

//==========================avhub=========================
      
       $avhub = $DB->get_records_sql("SELECT id,element_id,module_id, COUNT(emoji_id) as total_like
            FROM mdl_ums_emoji_responses where emoji_id=1 and menutype = 'avhub'
            Group By module_id
            Order By COUNT(emoji_id) DESC
            LIMIT 10");
      // print_r($avhub);
      foreach($avhub as $key => $data1){

        $hub = $DB->get_records_sql("SELECT * from mdl_ums_av_files where id='".$data1->module_id."' and av_folder_id='".$data1->element_id."' and deleted=0");
        foreach($hub as $key => $value) {

          // for video link and thumb
            if(!empty($value->external_url))
            {
              $video_file_name = $value->external_url;
              parse_str( parse_url( $value->external_url, PHP_URL_QUERY ), $my_array_of_vars );
              $thumb="https://img.youtube.com/vi/".$my_array_of_vars['v']."/hqdefault.jpg";    
            }
            else
            {
              $new =$value->local_file_path;        
              //$video_file_name = $CFG->wwwroot.$new;
              $video_file_name = 'https://ilearn.marutisuzuki.com'.$new;
              $thumb = basename($CFG->folder.$new,".mp4");  
              $filepath=$CFG->folder.$new;
             // $thumbnail=$CFG->folder.'/upload/audio_video/thumbnails/'.$value->id.'.jpg';
              $thumbnail='https://ilearn.marutisuzuki.com/upload/audio_video/thumbnails/'.$value->id.'.jpg';
              if(!file_exists($thumbnail))
              {
                $second = 0;  
                $ffmpeg = "/usr/bin/ffmpeg"; 
                $cmd = $ffmpeg." -i \"".$filepath."\" -s 250x250 -an -ss ".$second.".001 -y -f mjpeg \"".$thumbnail."\" 2>&1";
                $output = shell_exec($cmd);           
              }    
             }
            $thumb = 'https://ilearn.marutisuzuki.com/upload/audio_video/thumbnails/'.$value->id.'.jpg';

          // end here



          $avhublist[] = array(
           'id' => $value->id,
           'folder' => $value->filename,
           'created' => $value->created!=""?$value->created:"",
           'updated' => $value->updated!=""?$value->updated:"",
           'image_url' => $thumb,
           'video_file_name' => $video_file_name,
           'total_like'=>$data1->total_like
         );
        }
      }
// ------for most view-----------------------------------------------
      $courselist_view=$avhublist_view=[];

      $course_lcountv = $DB->get_records_sql("SELECT element_id,module_id, COUNT(emoji_id) as total_view
            FROM mdl_ums_emoji_responses where emoji_id=10 and menutype = 'course'
            Group By module_id
            Order By COUNT(emoji_id) DESC
            LIMIT 10");

      $j = 1;
      foreach($course_lcountv as $keys => $datas){ 

        // if($j%2 == 0)
        // {
        //   $img_urlv='https://demolms.gols.in/images/course1.jpg';
        // }else{
        //   $img_urlv='https://demolms.gols.in/images/course2.jpg';
        // }

        $img_urlv='https://ilearn.marutisuzuki.com/images/course1.jpg';

        $checkenrollmentmethods_v = $DB->get_record_sql("SELECT id FROM mdl_enrol WHERE courseid = '".$datas->element_id."' and enrol='manual'");

        $enrollmentdatev = $DB->get_record_sql("SELECT timeend FROM mdl_user_enrolments WHERE enrolid = '".$checkenrollmentmethods_v->id."' AND userid = '".$USER->id."'");

        $vcourses = $DB->get_record_sql("SELECT id,visible FROM mdl_course WHERE id = '".$datas->element_id."'");
        $progressv = null;
        if($vcourses->visible == 1)
        {
            if(!empty($enrollmentdatev))
            {
              $enrolenddatev = $enrollmentdatev->timeend;

              if($enrolenddatev == 0)
              {
                $progressv = "CourseActive";
              }else{
                if($enrolenddatev > time())
                {
                     $progressv = "CourseActive";
                }else{
                     $progressv = "CourseExpired";
                }
              }
            }else{
                 $progressv = "NotEnrolled";
            }
        }else{
            $progressv = "CourseHidden";
        }

         $urlv = 'https://ilearn.marutisuzuki.com/mod/scorm/view.php?id='.$datas->module_id.'&act='.$progressv;

         $course_v = $DB->get_records_sql("SELECT c.id, c.shortname, c.fullname, c.idnumber, c.visible,c.summary, c.summaryformat, c.format, c.showgrades, c.lang, c.enablecompletion, c.category, c.startdate, c.enddate,cm.id as module_id,s.name as video_name from mdl_course c
          left join mdl_course_modules cm on c.id = cm.course
          left join mdl_scorm s on cm.instance = s.id
          where c.visible=1 and cm.course='".$datas->element_id."' and cm.id='".$datas->module_id."'");


        foreach($course_v as $keyes => $courses_v){
          $courselist_view[] = array(
           'id' => $courses_v->id,
           'shortname' => $courses_v->shortname,
           'fullname' => $courses_v->fullname,
           'idnumber' => $courses_v->idnumber,
           'visible' => $courses_v->visible,
           'summary' => $courses_v->summary,
           'summaryformat' => $courses_v->summaryformat,
           'format' => $courses_v->format,
           'showgrades' => $courses_v->showgrades,
           'lang' => clean_param($courses_v->lang, PARAM_LANG),
           'enablecompletion' => $courses_v->enablecompletion,
           'category' => $courses_v->category,
           'startdate' => date('Y-m-d', $courses_v->startdate),
           'enddate' => date('Y-m-d', $courses_v->enddate),
           'url' => $urlv,
           'image_url' => $img_urlv,
           'process' => $progressv,
           'enrollend_date'=>date('Y-m-d',$enrolenddatev),
           'total_view'=>$datas->total_view
         );
        }
        $j++;
      }
      

//==========================avhub=========================
      
       $avhub_v = $DB->get_records_sql("SELECT id,element_id,module_id, COUNT(emoji_id) as total_view
            FROM mdl_ums_emoji_responses where emoji_id=10 and menutype = 'avhub'
            Group By module_id
            Order By COUNT(emoji_id) DESC
            LIMIT 10");
      
      foreach($avhub_v as $key_v => $data1_v){

        $hub_v = $DB->get_records_sql("SELECT * from mdl_ums_av_files where id='".$data1_v->module_id."' and av_folder_id='".$data1_v->element_id."' and deleted=0");
        foreach($hub_v as $keyy => $values) {

            if(!empty($values->external_url))
            {
              $video_file_names = $values->external_url;
              parse_str( parse_url( $values->external_url, PHP_URL_QUERY ), $my_array_of_vars );
              $thumbs="https://img.youtube.com/vi/".$my_array_of_vars['v']."/hqdefault.jpg";    
            }
            else
            {
              $news =$values->local_file_path;        
              $video_file_names = 'https://ilearn.marutisuzuki.com'.$news;
              $thumbs = basename($CFG->folder.$news,".mp4");  
              $filepaths=$CFG->folder.$news;
              $thumbnails='https://ilearn.marutisuzuki.com/upload/audio_video/thumbnails/'.$values->id.'.jpg';
              if(!file_exists($thumbnails))
              {
                $second = 0;  
                $ffmpeg = "/usr/bin/ffmpeg"; 
                $cmd = $ffmpeg." -i \"".$filepaths."\" -s 250x250 -an -ss ".$second.".001 -y -f mjpeg \"".$thumbnails."\" 2>&1";
                $output = shell_exec($cmd);           
              }    
             }
            $thumbs = 'https://ilearn.marutisuzuki.com/upload/audio_video/thumbnails/'.$values->id.'.jpg';

          $avhublist_view[] = array(
           'id' => $values->id,
           'folder' => $values->filename,
           'created' => $values->created!=""?$values->created:"",
           'updated' => $values->updated!=""?$values->updated:"",
           'image_url' => $thumbs,
           'video_file_name' => $video_file_names,
           'total_view'=>$data1_v->total_view
         );
        }
      }

//-------end here----------------------------------------------------

      $topten['courses']= $courselist;
      $topten['videos'] = $avhublist;
      $topten['courses_view']= $courselist_view;
      $topten['videos_view'] = $avhublist_view;

      if(empty($courselist))
      {
        $topten['courses'] = array();
      }

      if(empty($avhublist))
      {
        $topten['videos'] = array();
      }
      if(empty($courselist_view))
      {
        $topten['courses_view'] = array();
      }
      if(empty($avhublist_view))
      {
        $topten['videos_view'] = array();
      }
      return($topten);
    }


    public static function top10_courses_videos_returns(){
     return new external_single_structure(
      array(
       'courses' => new external_multiple_structure(
        new external_single_structure(
          array(
            'id' => new external_value(PARAM_INT, 'id of course', VALUE_OPTIONAL),
            'shortname' => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
            'fullname'  => new external_value(PARAM_RAW, 'long name of course', VALUE_OPTIONAL),
            'idnumber'  => new external_value(PARAM_RAW, 'id number of course', VALUE_OPTIONAL),
            'visible'   => new external_value(PARAM_INT, '1 means visible, 0 means hidden course', VALUE_OPTIONAL),
            'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
            'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
            'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
            'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
            'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
            'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',VALUE_OPTIONAL),
            'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
            'startdate' => new external_value(PARAM_RAW, 'Timestamp when the course start', VALUE_OPTIONAL),
            'enddate' => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
            'url' => new external_value(PARAM_RAW,'course url', VALUE_OPTIONAL),
            'process' => new external_value(PARAM_RAW,'process', VALUE_OPTIONAL),
            'enrollend_date' => new external_value(PARAM_RAW, 'Timestamp when the enroll end', VALUE_OPTIONAL),
            'image_url' => new external_value(PARAM_RAW,'img url', VALUE_OPTIONAL),
            'total_like' => new external_value(PARAM_INT, 'total like course', VALUE_OPTIONAL), 
          ))),
       'videos' => new external_multiple_structure(
        new external_single_structure(
          array(
           'id'=>new external_value(PARAM_INT,'id',VALUE_OPTIONAL),
           'folder'=>new external_value(PARAM_TEXT,'folder name',VALUE_OPTIONAL),
           'created'=>new external_value(PARAM_RAW,'upload date',VALUE_OPTIONAL),
           'updated'=>new external_value(PARAM_RAW,'upload date',VALUE_OPTIONAL),
           'image_url' => new external_value(PARAM_RAW,'img url', VALUE_OPTIONAL),
           'video_file_name' => new external_value(PARAM_RAW,'video link', VALUE_OPTIONAL),
           'total_like'=>new external_value(PARAM_INT,'count number of files to view',VALUE_OPTIONAL)
         ))),
       'courses_view' => new external_multiple_structure(
        new external_single_structure(
          array(
            'id' => new external_value(PARAM_INT, 'id of course', VALUE_OPTIONAL),
            'shortname' => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
            'fullname'  => new external_value(PARAM_RAW, 'long name of course', VALUE_OPTIONAL),
            'idnumber'  => new external_value(PARAM_RAW, 'id number of course', VALUE_OPTIONAL),
            'visible'   => new external_value(PARAM_INT, '1 means visible, 0 means hidden course', VALUE_OPTIONAL),
            'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
            'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
            'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
            'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
            'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
            'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',VALUE_OPTIONAL),
            'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
            'startdate' => new external_value(PARAM_RAW, 'Timestamp when the course start', VALUE_OPTIONAL),
            'enddate' => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
            'url' => new external_value(PARAM_RAW,'course url', VALUE_OPTIONAL),
            'process' => new external_value(PARAM_RAW,'process', VALUE_OPTIONAL),
            'enrollend_date' => new external_value(PARAM_RAW, 'Timestamp when the enroll end', VALUE_OPTIONAL),
            'image_url' => new external_value(PARAM_RAW,'img url', VALUE_OPTIONAL),
            'total_view' => new external_value(PARAM_INT, 'total view course', VALUE_OPTIONAL), 
          ))),
       'videos_view' => new external_multiple_structure(
        new external_single_structure(
          array(
           'id'=>new external_value(PARAM_INT,'id',VALUE_OPTIONAL),
           'folder'=>new external_value(PARAM_TEXT,'folder name',VALUE_OPTIONAL),
           'created'=>new external_value(PARAM_RAW,'upload date',VALUE_OPTIONAL),
           'updated'=>new external_value(PARAM_RAW,'upload date',VALUE_OPTIONAL),
           'image_url' => new external_value(PARAM_RAW,'img url', VALUE_OPTIONAL),
           'video_file_name' => new external_value(PARAM_RAW,'video link', VALUE_OPTIONAL),
           'total_view'=>new external_value(PARAM_INT,'count number of files to view',VALUE_OPTIONAL)
         )))
       )
    );
   }

//--------end top 10 like and view course and video-----------------------

//-------top 10 youtube video---------------------------------------------

  public static function get_youtube_video_parameters(){
    return new external_function_parameters(
        array()
    );
  }
  public static function get_youtube_video(){
    global $USER, $DB ,$CFG;
    //------------------------------------------------------------------------------------------------//
    $sql = "SELECT * from mdl_ums_youtube_videos where deleted = 0 order by id desc";
    $sqldata = $DB->get_records_sql($sql);
    $dd = array();
    foreach ($sqldata as $key => $data) {
  
       // parse_str( parse_url( $data->youtube_url, PHP_URL_QUERY ), $my_array_of_vars );
        $video_id = explode("?v=", $data->youtube_url);
        $video_id = $video_id[1];
        $thumb="https://img.youtube.com/vi/".$video_id."/hqdefault.jpg";
        
        $result = new stdClass();
        $result->id = $data->id;
        $result->name= $data->name;
        $result->desc = $data->description==''?'':$data->description;
        $result->url = $data->youtube_url==''?'':$data->youtube_url;
        $result->thumbnail = $thumb;
        $result->created = $data->created==''?'':$data->created;
        $dd[] = $result;
    }
    return $dd;
    
  } 

  public static function get_youtube_video_returns() {
      return new external_multiple_structure(
        new external_single_structure(
            array(
             'id' => new external_value(PARAM_INT, 'id', VALUE_OPTIONAL),
             'name' => new external_value(PARAM_RAW, 'name',VALUE_OPTIONAL),
             'desc' => new external_value(PARAM_RAW, 'desc', VALUE_OPTIONAL),
             'url' => new external_value(PARAM_RAW, 'url', VALUE_OPTIONAL),
             'thumbnail' => new external_value(PARAM_RAW, 'thumbnail', VALUE_OPTIONAL),
             'created' => new external_value(PARAM_RAW,'posted date',  VALUE_OPTIONAL)
            )
     ));
  }


//-------end top 10 youtube video-----------------------------------------
// end here gramx

//==========code for course status===========================

   public static function get_praarambh_course_status_by_mspin_old_parameters() {

        return new external_function_parameters(
                array(
                    'mspin' => new external_value(PARAM_RAW,'mspin')
                  )
        );
    }

    public static function get_praarambh_course_status_by_mspin_old($mspin){
    global $USER, $DB ,$CFG;
    $user_type_data = $DB->get_record_sql("SELECT userid,user_type_id FROM mdl_ums_employeemaster WHERE 
    code = '".$mspin."'");
    $cid=763;
    $user_type_id  = $user_type_data->user_type_id;
    $user_id       = $user_type_data->userid;
    $onlinecourses = $DB->get_records_sql("select
        c.id as courseid,
        c.fullname as coursename,
        c.summary as summary,
        c.shortname as shortname,
        c.idnumber as idnumber,
        c.visible as visible,
        c.summaryformat as summaryformat,
        c.format,
        c.showgrades,
        c.lang,
        c.enablecompletion,
        c.category,
        b.path,
        c.geofencing_enabled,
        c.startdate,
        c.enddate,
        (
          select count(sa.id) as totalscorms
            from mdl_scorm_scoes as sa
            inner join mdl_scorm as sb ON(sb.id=sa.scorm)
            where sb.course=c.id and sa.scormtype='sco'
        ) as totalscorms,
        (
          select count(sa.id) as totaltracked
            FROM mdl_scorm_scoes_track as sa
            INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
            INNER JOIN mdl_course as sc on (sc.id=sb.course)
            WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='completed' || value='passed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
        ) as totalcompleted,
        (
          select count(sa.id) as totaltracked
            FROM mdl_scorm_scoes_track as sa
            INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
            INNER JOIN mdl_course as sc on (sc.id=sb.course)
            WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='incomplete' || value='failed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
        ) as totalincomplete,
        'duedate',
        (SELECT timestart FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol  where courseid=c.id and enrol='manual') AND userid=a.userid) as courseenrollmentdate,
        (SELECT timecreated FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol  where courseid=c.id and enrol='manual') AND userid=a.userid) as created_date,
        (SELECT timeend FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol where courseid=c.id and enrol='manual') AND userid=a.userid) as enrolenddate

        FROM mdl_role_assignments  as a
        INNER JOIN mdl_context     as b on(b.id=a.contextid)
        INNER JOIN mdl_course      as c on(c.id=b.instanceid)
        left outer join mdl_user   as d on(d.id=a.userid)
        INNER JOIN mdl_course_categories as e on(e.id=c.category)
        where b.contextlevel = 50 and userid = '".$user_id."' and c.id='".$cid."' and c.visible=1 and c.category=3 and d.deleted=0 group by c.id ORDER BY c.id DESC");

      foreach($onlinecourses as $onlinecourse){
          $id        = $onlinecourse->courseid;
          $shortname = $onlinecourse->shortname;
          $fullname  = $onlinecourse->coursename;
          $idnumber  = $onlinecourse->idnumber;
          $visible   = $onlinecourse->visible;
          $summary   = $onlinecourse->summary;
          $summaryformat = $onlinecourse->summaryformat;
          $format     = $onlinecourse->format;
          $showgrades = $onlinecourse->showgrades;
          $lang       = $onlinecourse->lang;
          $enablecompletion = $onlinecourse->enablecompletion;
          $category  = $onlinecourse->category;
          
          $startdate = $onlinecourse->startdate;
          $enddate   = $onlinecourse->enddate;
          $enroldate = $onlinecourse->courseenrollmentdate;
          $enrolenddate = $onlinecourse->enrolenddate;
          $created_date = $onlinecourse->created_date;
          $progress = '';
          $incomplete = 0;
          $complete = 0;

          // $sqlst = "SELECT sst.* from mdl_scorm_scoes_track sst
          //           inner join mdl_scorm s on s.id = sst.scormid
          //           where sst.userid=236294 and s.course=763 and (sst.element='cmi.core.lesson_status') and sst.attempt=1
          //           ";
          // $resultst = $DB->get_records_sql($sqlst);

          // foreach ($resultst as $keyst => $valst) {
          //   if(($valst->element=='cmi.core.lesson_status' && $valst->value='passed') || ( $valst->element=='cmi.core.lesson_status' && $valst->value='completed'))
          //   {
          //       $complete = $complete + 1;
          //   }else{
          //       $incomplete = $incomplete + 1;
          //   }
          // }

         // echo $complete.'/'.$incomplete;


           $allModules = $DB->get_records_sql('SELECT * FROM {course_modules} where course = ? AND visible = ?', array($cid, 1));
            $finalArray = [];
            $getSequence = $DB->get_records_sql('SELECT sequence FROM mdl_course_sections where course =? AND sequence !="" ORDER BY section', array($cid, ''));
            foreach ($getSequence as $key => $getSequence) {
                $sequenceArray = explode(',', $getSequence->sequence);
                foreach ($sequenceArray as $key => $index) {
                    array_push($finalArray, $allModules[$index]);
                }
            }

          //  print_r($finalArray);

          foreach($finalArray as $keyss => $module)
          {
            $moduleId = $module->instance;
            $module   = $module->module;
            $userId   = $user_id;
            // $details = $classObj->getActivityInfo($module->instance,$module->module,$userId);


            $status = '';
            $score = '';
            //Quiz
            $returnArray = [];
            if ($module == 17) {
                $moduleInfo = $DB->get_record_sql('SELECT name,gi.grademax, gi.gradepass, gg.rawgrade from {quiz} q JOIN {grade_items} gi ON q.id = gi.iteminstance LEFT JOIN {grade_grades} gg ON gi.id = gg.itemid  WHERE q.id = ? AND gi.itemmodule =? AND gg.userid =?', array($moduleId, 'quiz', $userId));
                $allAttempts = $DB->get_records_sql('SELECT qa.attempt,qa.sumgrades,qa.state FROM {quiz_attempts} qa WHERE qa.quiz= ? AND qa.userId = ? ORDER BY qa.id', array($moduleId, $userId));
                print_r($allAttempts); die;
                if (!empty($allAttempts)) {
                    foreach ($allAttempts as $key => $value) {
                        if ($value->sumgrades >= $moduleInfo->gradepass) {
                            $status = 'Passed';
                            $score = round($value->sumgrades);
                        } else if ($value->sumgrades == '') {
                            $status = 'Inprogress';
                            $score = '';
                        } else {
                            $status = 'Failed';
                            //$score = '-';
                            $score = round($value->sumgrades);
                        }

                        $returnObj = new stdClass();
                        $returnObj->name = $moduleInfo->name;
                        $returnObj->grademax = round($moduleInfo->grademax);
                        $returnObj->gradepass = $moduleInfo->gradepass;
                        $returnObj->status = $status;
                        $returnObj->aType = 'Assessment';
                        $returnObj->attempt = $value->attempt;
                        $returnObj->rawgrade = $score;
                        array_push($returnArray, $returnObj);
                    }
                } else {
                    $returnObj = new stdClass();
                    $returnObj->name = $moduleInfo->name;
                    $returnObj->grademax = round($moduleInfo->grademax);
                    $returnObj->gradepass = $moduleInfo->gradepass;
                    $returnObj->status = 'Not Started';
                    $returnObj->aType = 'Assessment';
                    $returnObj->attempt = '-';
                    $returnObj->rawgrade = '-';
                    array_push($returnArray, $returnObj);
                }
                return $returnArray;
            } elseif ($module == 18) {

                $moduleInfo = $DB->get_record_sql('SELECT name,maxgrade FROM {scorm} WHERE id =?', array($moduleId));
                //print_r($moduleInfo);
                $attemptDetails = $DB->get_records_sql('SELECT * FROM {scorm_scoes_track} WHERE userid=? AND scormid = ?', array($userId, $moduleId));
               // print_r($attemptDetails);

                $status = '';
                $score = '';

                if (!empty($attemptDetails)) {
                    foreach ($attemptDetails as $key => $attempt) {

                        if ($attempt->element == 'cmi.core.lesson_status' || $attempt->element == 'cmi.completion_status') {
                            //$status = $attempt->value == 'passed' ? 'completed' : $attempt->value ;
                            if ($attempt->value == 'passed' || $attempt->value == 'completed') {
                                $status = 'Completed';

                                break;
                            } else {
                                $status = $attempt->value;
                            }
                        } else {
                            $status = 'Incomplete';
                        }
                    }

                    $attempt = 1;
                }
                if ($status == 'Completed') {
                    //$score = $this->getMaxScore($userId, $moduleId);
                    $result = $DB->get_record_sql("SELECT sb.value as maxscore FROM {scorm_scoes_track} as sb WHERE sb.userid= '" . $userId . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.score.raw' || sb.element = 'cmi.score.raw') order by sb.attempt desc limit 1");
                    $score =  $result->maxscore;
                }
                $returnObjScorm = new stdClass();
                $returnObjScorm->name = $moduleInfo->name;
                $returnObjScorm->grademax = $moduleInfo->maxgrade;
                $returnObjScorm->gradepass = 0;
                $returnObjScorm->status = ucfirst($status == '' ? 'Not Started' : $status);
                $returnObjScorm->aType = 'Scorm';
                $returnObjScorm->attempt = $status == '' ? '-' : '1';
                $returnObjScorm->rawgrade = $score != '' ? round($score) : '-';
                $returnScorm = [];
                array_push($returnScorm, $returnObjScorm);
                //return $returnScorm;
            }
            //print_r($returnScorm);
            foreach($returnScorm as $key => $details){
             // print_r($details);

              if($details->status == 'Completed')
              {
                 $complete = $complete + 1;
              }else{
                 $incomplete = $incomplete + 1;
              }

            }

          $ccpsql = $DB->get_record_sql("SELECT * FROM mdl_scorm WHERE course = '".$cid."'");

          $cctsql = $DB->get_record_sql("SELECT * FROM mdl_scorm_scoes_track WHERE scormid = '".$moduleId."' and userid='".$user_id."' and element='cmi.core.lesson_status'");
          $ccpdate = $cctsql->timemodified;


          }

          if($incomplete > 0)
          {
            $progress = 'Incomplete';
            $completiondate = '-';
          }
          else{
            $progress = 'Completed';
            $completiondate  = gmdate("d/m/Y", $ccpdate + ((3500) * 5.5));
          	$completiondate = $completiondate == 0 ? '-' : $completiondate;
          }

          //echo $complete.'/to/'.$incomplete.'/st/'.$progress;

          //for last access course

          $sql = "SELECT * FROM mdl_user_lastaccess where userid=$user_id and courseid=$cid";
          $result = $DB->get_records_sql($sql, array());
          $lastaccess = "0";
          foreach ($result as $rows) {
              if (isset($rows->timeaccess)) {

                  $lastaccess = $rows->timeaccess;
              }
          }

          $lastaccess  = date('d/m/Y', $lastaccess);
          $lastaccess = $lastaccess == 0 ? '-' : $lastaccess;

          // course completion date

          //$completiondate  = date('d/m/Y', $ccpdate);
          // $completiondate  = gmdate("d/m/Y", $ccpdate + ((3500) * 5.5));
          // $completiondate = $completiondate == 0 ? '-' : $completiondate;
         // echo $completiondate;

           $geofencing_enabled = $onlinecourse->geofencing_enabled;
           $sqlgetpoints = $DB->get_record_sql("SELECT * FROM mdl_ums_user_cordinate WHERE userid = '".$USER->id."'");
           $latitude   = "";
           $longitude  = "";
          if($user_type_id == 1){
            $geofencing_enabled = 'No';
          }else{
            if($geofencing_enabled=="Yes"){
              $latitude   = $sqlgetpoints->latitude;
              $longitude  = $sqlgetpoints->longitude;
            }
          }          
          $get_time = @$DB->get_field('ums_course_duartion','duration', array('course_id' => $id));
          if(!empty($get_time))
          {
            $course_duration = $get_time;
          }
          else
          {
            $course_duration = "";
          }

          if($enrolenddate == 0)
          {
             $final_end_date = "0";
             
          }else{
              $final_end_date = date('Y-m-d', $enrolenddate);
          }

          $modulecount=0;
          $list = get_array_of_activities($id);
          if(!empty($list))
          {
            foreach($list as $l)
            {
              if($l->mod=='scorm' && $l->deletioninprogress!=1)
              {
                $modulecount++;
              }           
            }
          }

          $dates =  date('Y-m-d');
          //echo $id.'--'.$shortname.'--'.$progress.'<br>';

            $result = array(
            'id' => $id,
            'coursename' => $shortname,
            'fullname'  => $fullname,
            'idnumber'  => $idnumber,
            'visible'   => $visible,
            'summary'   => $summary,
            'summaryformat' => $summaryformat,
            'format' => $format,
            'showgrades' => $showgrades,
            'lang' => $lang,
            'enablecompletion' => $enablecompletion,
            'category' => $category,
            'status' => $progress,
            'lastaccess'=>$lastaccess,
            'completiondate'=>$completiondate,
            'startdate' => date('Y-m-d',$startdatedate),
            'enddate' => date('Y-m-d',$enddate),
            'enroldate' => date('Y-m-d',$enroldate),
            'enrolenddate' => date('Y-m-d',$enrolenddate),
            'created_date' => date('d-m-Y H:i:s',$created_date),
            'created' => date('d-m-Y H:i:s',$created_date),
            'url' => $url,
            'totalsubcourses'=>$modulecount,
            'course_duration' => $course_duration,
            'latitude'  => $latitude,
            'longitude' => $longitude,
            'radius' => 100,
            'geofencing_enabled' => $geofencing_enabled
          );
  
        }
        if(empty($result)){
          $result[] = array();
        }
        return $result;
  }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_praarambh_course_status_by_mspin_old_returns() {
        //return new external_multiple_structure(
              return  new external_single_structure(
                array(
  
      'id'        => new external_value(PARAM_INT, 'id of course', VALUE_OPTIONAL),
      'coursename' => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
      // 'fullname'  => new external_value(PARAM_RAW, 'long name of course', VALUE_OPTIONAL),
      // 'idnumber'  => new external_value(PARAM_RAW, 'id number of course', VALUE_OPTIONAL),
      // 'visible'   => new external_value(PARAM_INT, '1 means visible, 0 means hidden course', VALUE_OPTIONAL),
      // 'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
      // 'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
      // 'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
      // 'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
      // 'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
      // 'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
      //                       VALUE_OPTIONAL),
      // 'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
      'status' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
      'completiondate' => new external_value(PARAM_RAW, 'Timestamp when the course completion date', VALUE_OPTIONAL),
      'lastaccess' => new external_value(PARAM_RAW, 'Timestamp when the course last access', VALUE_OPTIONAL),
      // 'startdate' => new external_value(PARAM_RAW, 'Timestamp when the course start', VALUE_OPTIONAL),
      // 'enddate' => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
      // 'enroldate' => new external_value(PARAM_RAW, 'Timestamp when the course end', VALUE_OPTIONAL),
      // 'enrolenddate' => new external_value(PARAM_RAW, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
      // 'created_date' => new external_value(PARAM_RAW, 'Timestamp when the enrolment date', VALUE_OPTIONAL),
      // 'created' => new external_value(PARAM_RAW, 'Timestamp when the enrolment date', VALUE_OPTIONAL),
      'totalsubcourses' => new external_value(PARAM_INT,'count of modules', VALUE_OPTIONAL),
      // 'url' => new external_value(PARAM_RAW,'course url', VALUE_OPTIONAL),
      // 'course_duration' => new external_value(PARAM_RAW, 'course duration',VALUE_OPTIONAL),
      // 'latitude' => new external_value(PARAM_RAW, 'latitude point of user location',VALUE_OPTIONAL),
      // 'longitude' => new external_value(PARAM_RAW, 'longitude point of user location',VALUE_OPTIONAL),
      // 'radius' => new external_value(PARAM_INT, 'radius point of user location',VALUE_OPTIONAL),
      //'geofencing_enabled' => new external_value(PARAM_RAW, 'geofencing_enabled',VALUE_OPTIONAL),
                )
                );
       // );
    }


  //----------------- code by yogita created date - 09-05-2020---//
  
  public static function get_brand_parameters() 
  {
    return new external_function_parameters(
      array()
    );
  }
  
  public static function get_brand()
  {
    global $DB,$USER;
    $resultarray = array();

    $sql = "SELECT * FROM mdl_car_brand WHERE is_delete = '0' AND is_active = '1'";
    $res = $DB->get_records_sql($sql);

    print_r($res); die;
    
    $resultarray  = array('questioncount' => $thismonth_total_question,
                'answercount'   => $thismonth_correct_ans,
                'current_month_question_answer_status' => $thismonth_correct_ans."/".$thismonth_total_question
              );
           
  
    return $resultarray;
  }
  
  
  public static function get_brand_returns()
  {
    return new external_single_structure(
            array(
        'questioncount' => new external_value(PARAM_INT,'questioncount'),
        'answercount'   => new external_value(PARAM_INT,'answercount'),
        'current_month_question_answer_status' => new external_value(PARAM_TEXT,'current_month_question_answer_status'),
      )
        );
  }
  
    
  //-------------------------------------------------------------------------------//

  public static function get_praarambh_course_status_parameters() 
  {
    return new external_function_parameters(
      array()
    );
  }
  
  public static function get_praarambh_course_status()
  {
    global $DB,$USER;
    // $mspins = '';
    $courseid = 763;
    $resultall = array();

    $sqlcrs = "SELECT ue.*,u.username,e.courseid,c.fullname from mdl_user_enrolments ue
                inner join mdl_enrol e on ue.enrolid = e.id
                inner join mdl_user u on ue.userid= u.id
                inner join mdl_course c on e.courseid = c.id
                INNER JOIN mdl_ums_employeemaster emp ON emp.userid = u.id
                where e.courseid='".$courseid."' and e.enrol='manual' and u.deleted=0 and emp.designation_id IN(2,3,4,5,6,7,8,9,10,11,23,30,32,33,40,43,44,45,52,54,57,61,63,74,80,90,106,120,128,131,143,153,157,159,166,218,221,222,223,225,226,228,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,259,260,261,262,265,266,295,300,289,198,310) AND u.id NOT IN(2,4) AND u.username NOT IN('admin','guest','administrator')  ";
    $crsdata = $DB->get_records_sql($sqlcrs);
    //print_r($crsdata);exit;

    foreach ($crsdata as $key => $value)
    {
          $cid    = $value->courseid;
          $userid = $value->userid;
          $coursename = $value->fullname;
          $mspin = $value->username;
          $progress = '';
          $incomplete = 0;
          $complete = 0;
          $notstarted = 0;
          $farray=[];


          $allModules = $DB->get_records_sql('SELECT * FROM {course_modules} where course = ? AND visible = ?', array($cid, 1));
            $finalArray = [];
            $getSequence = $DB->get_records_sql('SELECT sequence FROM mdl_course_sections where course =? AND sequence !="" ORDER BY section', array($cid, ''));
            foreach ($getSequence as $key => $getSequence) {
                $sequenceArray = explode(',', $getSequence->sequence);
                foreach ($sequenceArray as $key => $index) {
                    array_push($finalArray, $allModules[$index]);
                }
               // array_push($finalArray, $allModules[$index]);
            }
         array_push($farray, reset($finalArray));
         array_push($farray, end($finalArray));
        // print_r($farray);
        // print_r($finalArray);

        foreach($farray as $keyss => $module)
        {
            $moduleId = $module->instance;
            $module   = $module->module;
            $userId   = $userid;
            // $details = $classObj->getActivityInfo($module->instance,$module->module,$userId);


            $status = '';
            $score = '';
            //Quiz
            $returnArray = [];
            if ($module == 17)
            {
                $moduleInfo = $DB->get_record_sql('SELECT name,gi.grademax, gi.gradepass, gg.rawgrade from {quiz} q JOIN {grade_items} gi ON q.id = gi.iteminstance LEFT JOIN {grade_grades} gg ON gi.id = gg.itemid  WHERE q.id = ? AND gi.itemmodule =? AND gg.userid =?', array($moduleId, 'quiz', $userId));
                $allAttempts = $DB->get_records_sql('SELECT qa.attempt,qa.sumgrades,qa.state FROM {quiz_attempts} qa WHERE qa.quiz= ? AND qa.userId = ? ORDER BY qa.id', array($moduleId, $userId));
                print_r($allAttempts); die;
                if (!empty($allAttempts)) {
                    foreach ($allAttempts as $key => $value) {
                        if ($value->sumgrades >= $moduleInfo->gradepass) {
                            $status = 'Passed';
                            $score = round($value->sumgrades);
                        } else if ($value->sumgrades == '') {
                            $status = 'Inprogress';
                            $score = '';
                        } else {
                            $status = 'Failed';
                            //$score = '-';
                            $score = round($value->sumgrades);
                        }

                        $returnObj = new stdClass();
                        $returnObj->name = $moduleInfo->name;
                        $returnObj->grademax = round($moduleInfo->grademax);
                        $returnObj->gradepass = $moduleInfo->gradepass;
                        $returnObj->status = $status;
                        $returnObj->aType = 'Assessment';
                        $returnObj->attempt = $value->attempt;
                        $returnObj->rawgrade = $score;
                        array_push($returnArray, $returnObj);
                    }
                } else {
                    $returnObj = new stdClass();
                    $returnObj->name = $moduleInfo->name;
                    $returnObj->grademax = round($moduleInfo->grademax);
                    $returnObj->gradepass = $moduleInfo->gradepass;
                    $returnObj->status = 'Not Started';
                    $returnObj->aType = 'Assessment';
                    $returnObj->attempt = '-';
                    $returnObj->rawgrade = '-';
                    array_push($returnArray, $returnObj);
                }
                return $returnArray;
            } elseif ($module == 18)
            {

                $moduleInfo = $DB->get_record_sql('SELECT name,maxgrade FROM {scorm} WHERE id =?', array($moduleId));
                //print_r($moduleInfo);
                $attemptDetails = $DB->get_records_sql('SELECT * FROM {scorm_scoes_track} WHERE userid=? AND scormid = ?', array($userId, $moduleId));
               // print_r($attemptDetails);

                $status = '';
                $score = '';

                if (!empty($attemptDetails)) {
                    foreach ($attemptDetails as $key => $attempt) {

                        if ($attempt->element == 'cmi.core.lesson_status' || $attempt->element == 'cmi.completion_status') {
                            //$status = $attempt->value == 'passed' ? 'completed' : $attempt->value ;
                            if ($attempt->value == 'passed' || $attempt->value == 'completed') {
                                $status = 'Completed';

                                break;
                            } else {
                                $status = $attempt->value;
                            }
                        } else {
                            $status = 'Incomplete';
                        }
                    }

                    $attempt = 1;
                }

               // echo $mspin.'-'.$userid.'-'.$status.'/';
                // if ($status == 'Completed')
                // {
                //     $result = $DB->get_record_sql("SELECT sb.value as maxscore FROM {scorm_scoes_track} as sb WHERE sb.userid= '" . $userId . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.score.raw' || sb.element = 'cmi.score.raw') order by sb.attempt desc limit 1");
                //     $score =  $result->maxscore;
                // }
                $returnObjScorm = new stdClass();
                $returnObjScorm->name = $moduleInfo->name;
                $returnObjScorm->grademax = $moduleInfo->maxgrade;
                $returnObjScorm->gradepass = 0;
                $returnObjScorm->status = ucfirst($status == '' ? 'Not Started' : $status);
                $returnObjScorm->aType = 'Scorm';
                $returnObjScorm->attempt = $status == '' ? '-' : '1';
               // $returnObjScorm->rawgrade = $score != '' ? round($score) : '-';
                $returnScorm = [];
                array_push($returnScorm, $returnObjScorm);
                //return $returnScorm;
            }
            //print_r($returnScorm);
            foreach($returnScorm as $key => $details)
            {
             // print_r($details);

              if($details->status == 'Completed')
              {
                 $complete = $complete + 1;
              }else if($details->status == 'Incomplete'){
                 $incomplete = $incomplete + 1;
              }else{
              	$notstarted = $notstarted + 1;
              }

            }

            //$ccpsql = $DB->get_record_sql("SELECT * FROM mdl_scorm WHERE course = '".$cid."'");
            $cctsql = $DB->get_record_sql("SELECT * FROM mdl_scorm_scoes_track WHERE scormid = '".$moduleId."' and userid='".$userid."' and element='cmi.core.lesson_status'");
            $ccpdate = $cctsql->timemodified;
            
        }

        // echo $mspin.'-'.$notstarted.'-'.$incomplete.'-'.$complete.'/';

          if($notstarted > 0 && $incomplete == 0 && $complete == 0)
          {
          	$progress = 'Not Started';
            $completiondate = '-';
          }
          elseif($incomplete > 0 && $complete == 0 && $notstarted > 0)
          {
            $progress = 'Incomplete';
            $completiondate = '-';
          }
          elseif($notstarted > 0 && $complete > 0)
          {
            $progress = 'Incomplete';
            $completiondate = '-';
          }
          elseif($incomplete > 0 && $complete > 0)
          {
            $progress = 'Incomplete';
            $completiondate = '-';
          }
          // elseif($incomplete > 0 )
          // {
          //   $progress = 'Incomplete';
          //   $completiondate = '-';
          // }
          else{
            $progress = 'Completed';
            $completiondate  = gmdate("d/m/Y", $ccpdate + ((3500) * 5.5));
            $completiondate = $completiondate == 0 ? '-' : $completiondate;
          }

          //echo $complete.'/to/'.$incomplete.'/st/'.$progress;

          //for last access course

          $sql = "SELECT * FROM mdl_user_lastaccess where userid=$userid and courseid=$cid";
          $result = $DB->get_records_sql($sql, array());
          $lastaccess = 0;
          foreach ($result as $rows) {
              if (isset($rows->timeaccess)) {

                  $lastaccess = $rows->timeaccess;
              }
          }

          if(empty($lastaccess) || $lastaccess == '' || $lastaccess == null)
          {
          	$lastaccess = 0;
          }else{
          	$lastaccess  = date('d/m/Y', $lastaccess);
          }
          $lastaccess = $lastaccess == 0 ? '-' : $lastaccess;

          //echo $mspin.'/'.$coursename.'/'.$progress.'-';

          $resultall[] = array(
            'mspin' => $mspin,
            'userid' => $userid,
            'coursename' => $coursename,
            'status' => $progress,
            'lastaccess'=>$lastaccess,
            'completiondate'=>$completiondate
          );

          //print_r($resultall);

    }
    //print_r($resultall);
    if(empty($resultall)){
          $result[] = array();
    }
   
    return $resultall;
  }
  
  
   public static function get_praarambh_course_status_returns() {
        return new external_multiple_structure(
             new external_single_structure(
                array(
  
      'mspin' => new external_value(PARAM_RAW, 'id of course', VALUE_OPTIONAL),
      'coursename' => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
      'status' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
      'completiondate' => new external_value(PARAM_RAW, 'Timestamp when the course completion date', VALUE_OPTIONAL),
      'lastaccess' => new external_value(PARAM_RAW, 'Timestamp when the course last access', VALUE_OPTIONAL),
          )
                )
        );
    }


//=========End Here

//=========new code for praarambh course status by mspin==============



  public static function get_praarambh_course_status_by_mspin_parameters() {

        return new external_function_parameters(
                array(
                    'mspin' => new external_value(PARAM_RAW,'mspin')
                  )
        );
    }
  
  public static function get_praarambh_course_status_by_mspin($mspin)
  {
    global $DB,$USER;
    // $mspins = '';
    $courseid = 763;
    $resultall = array();

    $sqlcrs = "SELECT ue.*,u.username,e.courseid,c.fullname from mdl_user_enrolments ue
                inner join mdl_enrol e on ue.enrolid = e.id
                inner join mdl_user u on ue.userid= u.id
                inner join mdl_course c on e.courseid = c.id
                INNER JOIN mdl_ums_employeemaster emp ON emp.userid = u.id
                where e.courseid='".$courseid."' and e.enrol='manual' and u.deleted=0 and u.username='".$mspin."'  ";
    $crsdata = $DB->get_records_sql($sqlcrs);
    //print_r($crsdata);exit;

    foreach ($crsdata as $key => $value)
    {
          $cid    = $value->courseid;
          $userid = $value->userid;
          $coursename = $value->fullname;
          $mspin = $value->username;
          $progress = '';
          $incomplete = 0;
          $complete = 0;
          $notstarted = 0;
          $farray=[];


          $allModules = $DB->get_records_sql('SELECT * FROM {course_modules} where course = ? AND visible = ?', array($cid, 1));
            $finalArray = [];
            $getSequence = $DB->get_records_sql('SELECT sequence FROM mdl_course_sections where course =? AND sequence !="" ORDER BY section', array($cid, ''));
            foreach ($getSequence as $key => $getSequence) {
                $sequenceArray = explode(',', $getSequence->sequence);
                foreach ($sequenceArray as $key => $index) {
                    array_push($finalArray, $allModules[$index]);
                }
               // array_push($finalArray, $allModules[$index]);
            }
         array_push($farray, reset($finalArray));
         array_push($farray, end($finalArray));
        // print_r($farray);
        // print_r($finalArray);

        foreach($farray as $keyss => $module)
        {
            $moduleId = $module->instance;
            $module   = $module->module;
            $userId   = $userid;
            // $details = $classObj->getActivityInfo($module->instance,$module->module,$userId);


            $status = '';
            $score = '';
            //Quiz
            $returnArray = [];
            if ($module == 17)
            {
                $moduleInfo = $DB->get_record_sql('SELECT name,gi.grademax, gi.gradepass, gg.rawgrade from {quiz} q JOIN {grade_items} gi ON q.id = gi.iteminstance LEFT JOIN {grade_grades} gg ON gi.id = gg.itemid  WHERE q.id = ? AND gi.itemmodule =? AND gg.userid =?', array($moduleId, 'quiz', $userId));
                $allAttempts = $DB->get_records_sql('SELECT qa.attempt,qa.sumgrades,qa.state FROM {quiz_attempts} qa WHERE qa.quiz= ? AND qa.userId = ? ORDER BY qa.id', array($moduleId, $userId));
                print_r($allAttempts); die;
                if (!empty($allAttempts)) {
                    foreach ($allAttempts as $key => $value) {
                        if ($value->sumgrades >= $moduleInfo->gradepass) {
                            $status = 'Passed';
                            $score = round($value->sumgrades);
                        } else if ($value->sumgrades == '') {
                            $status = 'Inprogress';
                            $score = '';
                        } else {
                            $status = 'Failed';
                            //$score = '-';
                            $score = round($value->sumgrades);
                        }

                        $returnObj = new stdClass();
                        $returnObj->name = $moduleInfo->name;
                        $returnObj->grademax = round($moduleInfo->grademax);
                        $returnObj->gradepass = $moduleInfo->gradepass;
                        $returnObj->status = $status;
                        $returnObj->aType = 'Assessment';
                        $returnObj->attempt = $value->attempt;
                        $returnObj->rawgrade = $score;
                        array_push($returnArray, $returnObj);
                    }
                } else {
                    $returnObj = new stdClass();
                    $returnObj->name = $moduleInfo->name;
                    $returnObj->grademax = round($moduleInfo->grademax);
                    $returnObj->gradepass = $moduleInfo->gradepass;
                    $returnObj->status = 'Not Started';
                    $returnObj->aType = 'Assessment';
                    $returnObj->attempt = '-';
                    $returnObj->rawgrade = '-';
                    array_push($returnArray, $returnObj);
                }
                return $returnArray;
            } elseif ($module == 18)
            {

                $moduleInfo = $DB->get_record_sql('SELECT name,maxgrade FROM {scorm} WHERE id =?', array($moduleId));
                //print_r($moduleInfo);
                $attemptDetails = $DB->get_records_sql('SELECT * FROM {scorm_scoes_track} WHERE userid=? AND scormid = ?', array($userId, $moduleId));
               // print_r($attemptDetails);

                $status = '';
                $score = '';

                if (!empty($attemptDetails)) {
                    foreach ($attemptDetails as $key => $attempt) {

                        if ($attempt->element == 'cmi.core.lesson_status' || $attempt->element == 'cmi.completion_status') {
                            //$status = $attempt->value == 'passed' ? 'completed' : $attempt->value ;
                            if ($attempt->value == 'passed' || $attempt->value == 'completed') {
                                $status = 'Completed';

                                break;
                            } else {
                                $status = $attempt->value;
                            }
                        } else {
                            $status = 'Incomplete';
                        }
                    }

                    $attempt = 1;
                }

               // echo $mspin.'-'.$userid.'-'.$status.'/';
                // if ($status == 'Completed')
                // {
                //     $result = $DB->get_record_sql("SELECT sb.value as maxscore FROM {scorm_scoes_track} as sb WHERE sb.userid= '" . $userId . "' AND sb.scormid = '" . $scormid . "' AND (sb.element = 'cmi.core.score.raw' || sb.element = 'cmi.score.raw') order by sb.attempt desc limit 1");
                //     $score =  $result->maxscore;
                // }
                $returnObjScorm = new stdClass();
                $returnObjScorm->name = $moduleInfo->name;
                $returnObjScorm->grademax = $moduleInfo->maxgrade;
                $returnObjScorm->gradepass = 0;
                $returnObjScorm->status = ucfirst($status == '' ? 'Not Started' : $status);
                $returnObjScorm->aType = 'Scorm';
                $returnObjScorm->attempt = $status == '' ? '-' : '1';
               // $returnObjScorm->rawgrade = $score != '' ? round($score) : '-';
                $returnScorm = [];
                array_push($returnScorm, $returnObjScorm);
                //return $returnScorm;
            }
            //print_r($returnScorm);
            foreach($returnScorm as $key => $details)
            {
             // print_r($details);

              if($details->status == 'Completed')
              {
                 $complete = $complete + 1;
              }else if($details->status == 'Incomplete'){
                 $incomplete = $incomplete + 1;
              }else{
                $notstarted = $notstarted + 1;
              }

            }

            //$ccpsql = $DB->get_record_sql("SELECT * FROM mdl_scorm WHERE course = '".$cid."'");
            $cctsql = $DB->get_record_sql("SELECT * FROM mdl_scorm_scoes_track WHERE scormid = '".$moduleId."' and userid='".$userid."' and element='cmi.core.lesson_status'");
            $ccpdate = $cctsql->timemodified;
            
        }

        // echo $mspin.'-'.$notstarted.'-'.$incomplete.'-'.$complete.'/';

          if($notstarted > 0 && $incomplete == 0 && $complete == 0)
          {
            $progress = 'Not Started';
            $completiondate = '-';
          }
          elseif($incomplete > 0 && $complete == 0 && $notstarted > 0)
          {
            $progress = 'Incomplete';
            $completiondate = '-';
          }
          elseif($notstarted > 0 && $complete > 0)
          {
            $progress = 'Incomplete';
            $completiondate = '-';
          }
          elseif($incomplete > 0 && $complete > 0)
          {
            $progress = 'Incomplete';
            $completiondate = '-';
          }
          // elseif($incomplete > 0 )
          // {
          //   $progress = 'Incomplete';
          //   $completiondate = '-';
          // }
          else{
            $progress = 'Completed';
            $completiondate  = gmdate("d/m/Y", $ccpdate + ((3500) * 5.5));
            $completiondate = $completiondate == 0 ? '-' : $completiondate;
          }

          //echo $complete.'/to/'.$incomplete.'/st/'.$progress;

          //for last access course

          $sql = "SELECT * FROM mdl_user_lastaccess where userid=$userid and courseid=$cid";
          $result = $DB->get_records_sql($sql, array());
          $lastaccess = 0;
          foreach ($result as $rows) {
              if (isset($rows->timeaccess)) {

                  $lastaccess = $rows->timeaccess;
              }
          }

          if(empty($lastaccess) || $lastaccess == '' || $lastaccess == null)
          {
            $lastaccess = 0;
          }else{
            $lastaccess  = date('d/m/Y', $lastaccess);
          }
          $lastaccess = $lastaccess == 0 ? '-' : $lastaccess;

          //echo $mspin.'/'.$coursename.'/'.$progress.'-';

          $resultall = array(
            'mspin' => $mspin,
            'userid' => $userid,
            'coursename' => $coursename,
            'status' => $progress,
            'lastaccess'=>$lastaccess,
            'completiondate'=>$completiondate
          );

          //print_r($resultall);

    }
    //print_r($resultall);
    if(empty($resultall)){
          $result[] = array();
    }
   
    return $resultall;
  }
  
  
   public static function get_praarambh_course_status_by_mspin_returns() {
        // return new external_multiple_structure(
            return new external_single_structure(
                array(
  
      //'mspin' => new external_value(PARAM_RAW, 'id of course', VALUE_OPTIONAL),
      'coursename' => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
      'status' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
      'completiondate' => new external_value(PARAM_RAW, 'Timestamp when the course completion date', VALUE_OPTIONAL),
      'lastaccess' => new external_value(PARAM_RAW, 'Timestamp when the course last access', VALUE_OPTIONAL),
          )
                );
       // );
    }

//=======end here=====================================================

}