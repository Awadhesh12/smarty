<?php
require_once('../../../config.php');
require_login();
require_once('sat_report_assessment_class.php'); 
$systemcontext = context_system::instance();
$url = new moodle_url('/local/pagecontainer/ums/assessment_individual_report.php');
$PAGE->set_context($systemcontext);
$PAGE->set_title('SAT Assessment Individual Report');
$PAGE->set_pagelayout('report');
$PAGE->set_heading('SAT Assessment Individual Report');
echo $OUTPUT->header();
$id   = $USER->id;
$user = $USER->username;
$obj  = new assessment();
$regionlist      = $obj->regionlist();
$chaneellist     = $obj->chaneellist();
$outletgrouplist = $obj->outletgrouplist();
$assessmentList  = $obj->assessmentList();
$topicList       = $obj->topiclist();
?>
<div class="row">
	<form name="form1" id="form1" method="post">
		<div class="col-md-12">
			<div class="panel-body">
			    <div class="row">
					<div class="col-sm-6">
							<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Status</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select name="quiz_status" id="quiz_status" class="form-control">
										<option value="0">All</option>
										<option value="notstarted" <?php echo $select=$hmi_status=='notstarted'?'selected':''?>>Not Started</option>
										<option value="finished" <?php echo $select=$hmi_status=='finished'?'selected':''?>>Finished </option>
										<option value="inprogress" <?php echo $select=$hmi_status=='inprogress'?'selected':''?>>Inprogress</option>
									</select>
								</div>
							</div>
					</div>
					<div class="col-sm-6">
							<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Assessment</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select name="quiz_id" id="quiz_id"  class="form-control" 
									onchange="getTopic();">
										<option value="0">Select Assessment</option>
										<?php echo $assessmentList;?>
									</select>
								</div>
							</div>
					</div>
				</div>
			    <div class="row">
					
					<div class="col-sm-6">
							<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Employee MSPIN</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<input class="form-control" type="text" name="empcode" id="empcode" placeholder="Employee MSPIN" />
								</div>
							</div>
					</div>
					<div class="col-sm-6">
							<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Employee Name</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<input class="form-control" type="text" name="empname" id="empname" placeholder="Employee Name" />
								</div>
							</div>
					</div>
				</div>

				<div class="row">
				    <div class="col-sm-6">
							<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Question Type</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select name="topic" id="topic"  class="form-control" 
									onchange="getCategory();">
										<option value="0">Select Question Type</option>
										<?php echo $topicList;?>
									</select>
								</div>
							</div>
					</div>
					
					<div class="col-sm-6">
						<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Topic</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select class="form-control" name="category" id="category" 
									onchange="getSubCategory();">
										<option value="0">Select Topic</option>

									</select>
								</div>
							</div>
					</div>
				</div>
				
				<div class="row">
				    <div class="col-sm-6">
							<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Category</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select name="subcategory" id="subcategory"  class="form-control" onchange="getSubSubCategory();">
										<option value="0">Select Category</option>
										<?php //echo $assessmentList;?>
									</select>
								</div>
							</div>
					</div>

					<div class="col-sm-6">
							<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Sub-Category</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select name="subsubcategory" id="subsubcategory"  class="form-control">
										<option value="0">Select Sub-Category</option>
										<?php //echo $assessmentList;?>
									</select>
								</div>
							</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6">
						<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">State</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select class="form-control" name="state" id="state">
										<option value="0">Select State</option>
									
									</select>
								</div>
							</div>
					</div>
					
					<div class="col-sm-6">
						<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Region</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select class="form-control" name="region" id="region" onchange="getSTFromRegion();">
										<option value="0">Select Region</option>
										<?php  echo $regionlist;?>
									</select>
								</div>
							</div>
					</div>
				</div>
			    <div class="row">
					<div class="col-sm-6">
						<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Dealer Name</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select class="form-control" name="outlet" id="outlet" >
										<option value="0">Select Dealer Name</option>
									</select>
								</div>
							</div>
					</div>
					
					<div class="col-sm-6">
						<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Dealer Group</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select class="form-control" name="outletgr" id="outletgr" onchange="getOutFromOG();" >
										<option value="0">Select Dealer Group</option>
										<?php echo $outletgrouplist; ?>
									</select>
								</div>
							</div>
					</div>					
				</div>
				<div class="row">					
					<div class="col-sm-6">
							<div class="col-sm-5">
								<div class="form-group no-margin-hr">
									<label class="control-label">Employee Designation</label>
								</div>
							</div>

							<div class="col-sm-7">
								<div class="form-group no-margin-hr">
									<select class="form-control" name="designation[]" id="designation" multiple>
										<option value="0">Select Employee Designation</option>
										<?php echo $obj->designationlist();?>
									</select>
								</div>
							</div>
					</div>
				</div>
				
					
			</div>
			<div class="panel-footer text-center" style="text-align: center;">
				<input type="button" name="searchbtn" id="searchbtn" value="Search" onclick = "populate()" class="btn btn-primary">
				<input type="reset" name="reset" id="reset" value="Reset" class="btn btn-primary" >
			</div>
		</div>
	</form>
	<div>&nbsp;</div>
	<div class="clear" style="clear:both;"></div>
	<div class="col-md-12">
		<div class="table-primary">
			<table class="table table-striped table-bordered" id="datatableid" cellspacing="0" width="100%" style = "display:none;">
				<thead>
					<tr>
							<th>Sr.No</th>
							<th>Assessment Name</th>
							<th>Employee Name</th>
							<th>Employee MSPIN</th>
							<?php
								if (!$obj->isDealerLogin()) { ?>
							
								<th>Employee Phone</th>

								<?php }
							?>
							<th>Designation</th>
							<th>Region</th>
							<th>State</th>
							<th>Dealer Group</th>
							<th>Dealer Name</th>
							<th>Dealer Code</th>
							<th>Status</th>
							<th>Total Marks</th>
							<th>Total Marks Scored</th>
							<th>Percentage Scored</th>
							<th>Pass/Fail</th>

							<th>Question Type</th>
							<th>Topic</th>
							<th>Category</th>
							<th>Proficiency Level</th>

							<th>Date of Completion</th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
	<div class="col-md-1"></div>
</div>
<link rel="stylesheet" type="text/css" href="../css/jquery.dataTables.min.css">
<link rel="stylesheet" href="../css/font-awesome.min.css">
<link rel="stylesheet" href="../css/jquery.timepicker.min.css">
<link rel="stylesheet" href="../css/jquery-ui.css">
<script type="text/javascript" language="javascript" src="../js/jquery-1.12.4.js"></script>
<script type="text/javascript" language="javascript" src="../js/jquery.dataTables.min.js"></script>	
<script src="../js/jquery-ui.js"></script>
<script src="../js/jquery.timepicker.min.js"></script>
<script src="../js/jquery-ui-timepicker-addon-i18n.min.js"></script>
<script type="text/javascript" src="../js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="../js/buttons.flash.min.js"></script>
<script type="text/javascript" src="../js/jszip.min.js"></script>
<script type="text/javascript" src="../js/pdfmake.min.js"></script>
<script type="text/javascript" src="../js/vfs_fonts.js"></script>
<script type="text/javascript" src="../js/buttons.html5.min.js"></script>
<script type="text/javascript" src="../js/buttons.print.min.js"></script>
<script type="text/javascript">
		function populate()
		{
			var quiz_id = $('#quiz_id').val();
			if(quiz_id != 0){
				
			$('#datatableid').show();
			$('#datatableid').dataTable().fnDestroy();
			$(document).ready(function()
			{
				var frmval = $('#form1').serialize();
				$('#datatableid').DataTable({
					"ajax": {
						"url": "sat_report_assessment_class.php?__g__=data1&__u__=<?php echo $USER->id;?>&"+frmval,
						"dataSrc": ""
					},
					"language": {
						"search": "Search",
						"searchPlaceholder":"Type here to search"
					},
					dom: 'Bfrtip',
					buttons: [
					{
					   extend: 'excel',
					   text: 'Export to Excel',
					   className: 'buttons-excel',
					   title: '',
					   filename: 'SAT Assessment Individual Report'
					
					}	
					],		
					"columns": [ 
						{ "data": "Sr"},
						{ "data": "AssessmentName" },
						{ "data": "EmpName" },
						{ "data": "Empcode"},
						<?php
								if (!$obj->isDealerLogin()) { ?>
							
								{ "data": "EmpPhone"},

								<?php }
							?>
						{ "data": "Designation"},
						{ "data": "Region"},
						{ "data": "State"},
						{ "data": "OutletGroup"},
						{ "data": "OutletName"},
						{ "data": "Outlet"},
						{ "data": "Status" },
						{ "data": "TotalMarks" },
						{ "data": "TotalMarksScored" },
						{ "data": "PercentageScored" },
						{ "data": "PassFail" },	

						{ "data": "Topic" },
						{ "data": "Category" },
						{ "data": "SubCategory" },
						{ "data": "ProficiencyLevel" },

						{ "data": "DateOfCompletion" }
					]
					});
				});
			}else{
				alert("Please select an Assessment");
			}
		
		}
		$(document).ready(function(){
			//populate();
		});
		
		function getEmpCodeTxt(val)
		{
			$('#empusernamehidden').val(val);
		}
		
		function getSTFromRegion() 
		{
			$.ajax({
				type: "post",
				url: "../ajax/displaystatefromregion.php",
				data: {
					"regionid": $("#region").val(),
				},
				success: function (response) {
					$('#state').find('option:gt(0)').remove();
					$("#state").append(response);

				}
			});
		}
		
		function getOutFromOG() 
		{
			$.ajax({
				type: "post",
				url: "../ajax/displayOutletfromOutletGroup.php",
				data: {
					"outletgr": $("#outletgr").val(),
				},
				success: function (response) {
					$('#outlet').find('option:gt(0)').remove();
					$("#outlet").append(response);

				}
			});
		}

		
</script>
<script type="text/javascript">
	function getTopic(){
		$.ajax({
				type: "post",
				url: "../ajax/displayTopicFromAssessment.php",
				data: {
					"quizid": $("#quiz_id").val(),
				},
				success: function (response) {
					// alert(response); return;
					$('#topic').find('option:gt(0)').remove();
					$('#category').find('option:gt(0)').remove();					
					$('#subcategory').find('option:gt(0)').remove();
					$("#topic").append(response);

				}
			});
	}

	function getCategory(){
		$.ajax({
				type: "post",
				url: "../ajax/displayCategoryFromTopic.php",
				data: {
					"topicid": $("#topic").val(),
				},
				success: function (response) {
					// alert(response); return;
					$('#category').find('option:gt(0)').remove();
					$("#category").append(response);

				}
			});
	}

	function getSubCategory(){
		$.ajax({
				type: "post",
				url: "../ajax/displaySubCategoryFromCategory.php",
				data: {
					"categoryid": $("#category").val(),
				},
				success: function (response) {
					$('#subcategory').find('option:gt(0)').remove();
					$("#subcategory").append(response);

				}
			});
	}

	function getSubSubCategory(){
		$.ajax({
				type: "post",
				url: "../ajax/displaySubSubCategoryFromSubCategory.php",
				data: {
					"subcategoryid": $("#subcategory").val(),
				},
				success: function (response) {
					$('#subsubcategory').find('option:gt(0)').remove();
					$("#subsubcategory").append(response);

				}
			});
	}

</script>
<?php
echo $OUTPUT->footer ();
