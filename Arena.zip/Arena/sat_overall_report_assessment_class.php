<?php
ini_set('max_execution_time', 300);
require_once('../../../config.php');
// include('../class/datatable.php');
include('../class/datatable-large.php');
require_once('../custom_methods.php'); 

require_once('../ums/dealer/DealerTrait.php'); 

class Assessment extends DataTable
{
	use DealerTrait;

		var $userid ;
		function __construct($userid) 
		{
			parent::__construct($userid);
			$this->userid   = $userid;
		}

		function getTableData1()
		{
			$data['table'] = array( 
									"Sr. No."=>'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Assessment Name"=>'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Employee Name"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Employee MSPIN"=>'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Employee Phone"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Designation"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Region"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"State"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Dealer Group"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Dealer Name"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Dealer Code"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Status"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Assessment Score"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Question Type"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Question Type Score"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Topic"=>'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Topic Score"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
								    "Category"=>'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Category Score"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Sub Category"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Sub Category Score"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Percentage Scored"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Pass/Fail"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Proficiency Level"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},',
									"Date Of Completion"=>	'{"bVisible": true,"bSearchable": true,"bSortable": true},'

							);

			

						
			return $data;
			
		}
		
		function getIndividualAssessmentJsonData()
		{
			global $DB;

			$status = (isset($_REQUEST['quiz_status']) && !empty($_REQUEST['quiz_status'])) ? $_REQUEST['quiz_status']: '';

			$quiz_id = (isset($_REQUEST['quiz_id']) && !empty($_REQUEST['quiz_id'])) ? $_REQUEST['quiz_id'] : '';
			$empcode = (isset($_REQUEST['empcode']) && !empty($_REQUEST['empcode'])) ? $_REQUEST['empcode'] : '';
			$empname = (isset($_REQUEST['empname']) && !empty($_REQUEST['empname'])) ? $_REQUEST['empname'] : '';
			$topic_id = (isset($_REQUEST['topic']) && !empty($_REQUEST['topic'])) ? $_REQUEST['topic'] : '';
			$category_id = (isset($_REQUEST['category']) && !empty($_REQUEST['category'])) ? $_REQUEST['category'] : '';
			$subcategory_id = (isset($_REQUEST['subcategory']) && !empty($_REQUEST['subcategory'])) ? $_REQUEST['subcategory'] : '';
			$subsubcategory_id = (isset($_REQUEST['subsubcategory']) && !empty($_REQUEST['subsubcategory'])) ? $_REQUEST['subsubcategory'] : '';
			$region_id = (isset($_REQUEST['region']) && !empty($_REQUEST['region'])) ? $_REQUEST['region'] : '';
			$state_id = (isset($_REQUEST['state']) && !empty($_REQUEST['state'])) ? $_REQUEST['state'] : '';
			$outletgr_id = (isset($_REQUEST['outletgr']) && !empty($_REQUEST['outletgr'])) ? $_REQUEST['outletgr'] : '';
			$outlet_id = (isset($_REQUEST['outlet']) && !empty($_REQUEST['outlet'])) ? $_REQUEST['outlet'] : '';
			$designation_id = (isset($_REQUEST['designation']) && !empty($_REQUEST['designation'])) ? $_REQUEST['designation'] : '';
			$designation_id = implode(',',$designation_id);

			// echo $designation_id; die;

			if($status =='notstarted'){
				$filter = " AND ass_status = 'Not Started'";
			}
			if($status == 'finished'){
				$filter = " AND ass_status = 'Completed'";
			}
			if($status == 'inprogress'){
				$filter = " AND ass_status = 'Incomplete'";
			}

			if($quiz_id != ''){
				$filter	.= " AND quiz_id = ".$quiz_id."";
			}
			if($empcode != ''){
				$filter	.= " AND mspin = ".$empcode."";
			}
			if ($empname != '') {
				$filter .= " AND emp_name LIKE '%" . trim($empname) . "%'";
			}
			if($topic_id != ''){
				$filter	.= " AND topic_id = ".$topic_id."";
			}
			if($category_id != ''){
				$filter	.= " AND cat_id = ".$category_id."";
			}
			if($subcategory_id != ''){
				$filter	.= " AND sub_cat_id = ".$subcategory_id."";
			}
			if($subsubcategory_id != ''){
				$filter	.= " AND sub_sub_cat_id = ".$subsubcategory_id."";
			}
			if($region_id != ''){
				$filter	.= " AND region_id = ".$region_id."";
			}
			if($state_id != ''){
				$filter	.= " AND state_id = ".$state_id."";
			}
			if($outletgr_id != ''){
				$filter	.= " AND dealer_group_id = ".$outletgr_id."";
			}
			if($outlet_id != ''){
				$filter	.= " AND dealer_id = ".$outlet_id."";
			}
			if($designation_id != ''){
				$filter	.= " AND designation_id IN (".$designation_id.")";
			}


			############# FILTER CODE END ####################
			
			$aColumns = array('id','quiz_name','emp_name','mspin','topic_name','cat_name','sub_cat_name','sub_sub_cat_name','ass_score','cat_score','sub_cat_score','sub_sub_cat_score','doj','designation_name','region_name','city_name','state_name','phone','dealer_name','dealer_code','dealer_group_name','ass_status','ass_result','ass_score','percentage','proficiency','date_of_completion');	
			
			$sql = "SELECT
					id, quiz_id, quiz_name, topic_id, topic_name, question_type_score, cat_name, sub_cat_name, sub_sub_cat_name, mspin, emp_name, doj, designation_name, region_id, region_name, city_name, state_name, phone, dealer_name, dealer_code, dealer_group_id, dealer_group_name, ass_status, ass_result, percentage, ass_score, topic_score, topic_score_summery, cat_score, cat_score_summery, sub_cat_score, sub_cat_score_summery, sub_sub_cat_score,sub_sub_cat_score_summery, proficiency,date_of_completion 
					FROM mdl_sat_ass_score_report_new1 where 1 $filter";//exclude MSIL employees in list
			// echo $sql;exit;
			
			$result = $this->exQuery($sql,$aColumns);
			//print_r($result);exit;
			//echo '<pre>';print_r($result);exit;
			//sEcho: 2, iTotalRecords: 23, iTotalDisplayRecords: 23
			//sEcho: 3, iTotalRecords: 23, iTotalDisplayRecords: 2
			if($result['iTotal']=='')
			{
				$output = array(
			"sEcho" =>0,
			"iTotalRecords" =>0,
			"iTotalDisplayRecords" => 0,
			"aaData" => array()
			);
			}
			else{
			$output = array(
			"sEcho" => intval($_GET['sEcho']),
			"iTotalRecords" => $result['iTotal'],
			"iTotalDisplayRecords" => $result['iTotalDisplayRecords'],
			"aaData" => array()
			);
			}
			
			$i = 1;
			foreach ( $result['rResult'] as $key=>$value )
			{
			    //print_r($result);die;
				$row = array(); 
				
				$row[] = $i++;
				$row[] = $value['quiz_name']!=''?$value['quiz_name']:'--';
				$row[] = $value['emp_name']!=''?$value['emp_name']:'--';
				$row[] = $value['mspin']!=''?$value['mspin']:'--';
				$row[] = $value['phone']!=''?$value['phone']:'--';
				$row[] = $value['designation_name']!=''?$value['designation_name']:'--';
				$row[] = $value['region_name']!=''?$value['region_name']:'--';
				$row[] = $value['state_name']!=''?$value['state_name']:'--';
				$row[] = $value['dealer_group_name']!=''?$value['dealer_group_name']:'--';
				$row[] = $value['dealer_name']!=''?$value['dealer_name']:'--';
				$row[] = $value['dealer_code']!=''?$value['dealer_code']:'--';
				$row[] = $value['ass_status']!=''?$value['ass_status']:'--';
				$row[] = $value['ass_score']!=''?$value['ass_score']:'--';
				//$row[] = $value['topic_score']!=''?$value['topic_score']:'--';
				$row[] = trim($value['topic_name'],'.');
				$row[] = $value['question_type_score']!=''?$value['question_type_score']:'--'; 
				$row[] = $value['cat_name']!=''?$value['cat_name']:'--';
				$row[] = $value['cat_score']!=''?$value['cat_score']:'--';				
				$row[] = $value['sub_cat_name']!=''?$value['sub_cat_name']:'--';
				$row[] = $value['sub_cat_score']!=''?$value['sub_cat_score']:'--';				
				$row[] = $value['sub_sub_cat_name'];
				$row[] = $value['sub_sub_cat_score']!=''?$value['sub_sub_cat_score']:'--';
				$row[] = $value['percentage']!=''?$value['percentage']:'--';
				$row[] = $value['ass_result'];
				$row[] = $value['proficiency']!=''?$value['proficiency']:'--';
				$row[] = $value['date_of_completion']!=''?$value['date_of_completion']:'--';
				//$row[] = $value['ass_result']!=''?$value['ass_result']:'--';
				// $row[] = date('d/m/Y', strtotime($value['doj']));
				// $row[] = ($value['dol']!='' && $value['dol']!='0000-00-00')?date('d/m/Y', strtotime($value['dol'])):'--';
				
				
				$output['aaData'][] = $row;
			}

			//print_r($output['aaData']);exit;
		
			echo json_encode( $output );
		}
	   
	    
		
		function assessmentList($selected='')
		{
			global $DB;
			
			$mysql = "select
				a.id as id,
				a.fullname as coursename,
				q.name as quizname,
				q.id as quizid
				from {course} as a
				inner join {course_categories} as b on(b.id=a.category)
				inner join {quiz} as q on(q.course=a.id)
				where b.id IN (2) AND a.is_set = 1 ORDER BY a.fullname";// old where b.id IN (2,3) bcoz cat=2 is for assessment and 3=course in mdl_course_categories tbl.
			$result=$DB->get_records_sql($mysql, array());
			$list     = '';
			$selected = '';
			foreach($result as $rows)
			{
				$id 	= $rows->quizid;
				$quizname = $rows->quizname;	
				if($rows->id==$selected) $val='selected';									
				$list .= "<option value=".$id.">".ucwords($quizname)."</option>";
			}
			return $list;
		}
		
				
		function regionlist($selected="")
		{
			global $DB;

			$filter = "";
			if ($this->isDealerLogin()) {
				
				$regionId = $this->getRegionId();
				$filter = " AND id IN ($regionId)";
			}

			$result = $DB->get_records_sql("SELECT * FROM {ums_regions} WHERE deleted = 0 $filter order by r_name ASC", array());
			$list="";
			$selected="";
			foreach($result as $rows)
			{
				$rid = $rows->id;
				$rname  = $rows->r_name;	
				if($rows->id==$selected) $val='selected';	
				$list .= "<option value=".$rid.">".ucwords($rname)."</option>";
			}
			return $list;
		}
		
		function chaneellist($selected="")
		{
			global $DB;
			$result = $DB->get_records_sql('SELECT * FROM {ums_channels} WHERE deleted = 0 order by c_abbr_name ASC', array());
			$list="";
			$selected="";
			foreach($result as $rows)
			{
				$chid         = $rows->id;
				$c_abbr_name  = $rows->c_abbr_name;	
				if($rows->id==$selected) $val='selected';	
				$list .= "<option value=".$chid.">".ucwords($c_abbr_name)."</option>";
			}
			return $list;
		}
		
		function topiclist($selected="")
		{
			global $DB;
			$result = $DB->get_records_sql('SELECT id, name FROM {question_categories} WHERE parent = 0 order by name ASC', array());
			$list="";
			$selected="";
			foreach($result as $rows)
			{
				$resultchk = $DB->get_records_sql('SELECT id FROM {question_categories} WHERE parent = "'.$rows->id.'"');
				if(count($resultchk)>0){
					$chid  = $rows->id;
					$name  = $rows->name;	
					if($rows->id==$selected) $val='selected';	
					$list .= "<option value=".$chid.">".ucwords($name)."</option>";
				}
				
			}
			return $list;
		}

		function outletgrouplist($selected="")
		{
			global $DB;

			$filter = "";
			if ($this->isDealerLogin()) {
				
				$outletGroupId = $this->getOutletGroupId();
				$filter .= " AND id IN ($outletGroupId)";
			}

			$result = $DB->get_records_sql("SELECT id,og_name,og_code,deleted FROM {ums_outlet_group} where deleted =0 $filter ORDER BY og_name ASC", array());
			$list="";
			$selected="";
			foreach($result as $rows)
			{
				$chid         = $rows->id;
				$og_name  = $rows->og_name;	
				if($rows->id==$selected) $val='selected';	
				$list .= "<option value=".$chid.">".ucwords($og_name)."</option>";
			}
			return $list;
		}

		function designationlist()
		{
		    global $DB;
			
			/* $result = $DB->get_records_sql("SELECT id, d_name FROM mdl_ums_designations where deleted = 0 AND id NOT IN(1,11,202,203) ORDER BY d_name"); *///hide Admin, FSDM, CBH, RM designations
			
			$result = $DB->get_records_sql("SELECT id, d_name FROM mdl_ums_designations where deleted = 0 AND id!=1 AND d_name IN('NCM' , 'NQM' , 'NRM' , 'NSC' , 'NSM' , 'NSR' , 'NTD','RRM','NMF','NAM','NFM','NAC') ORDER BY d_name", array());
			
			$list="";
			foreach($result as $row)
			{
				$did1 	= $row->id;
				$dname1 = $row->d_name;
				$list .= "<option value=".$did1.">".ucwords($dname1)."</option>";
			}
			
			$list .= "<option value='159' style='font-weight:bold;'><strong>AM</strong></option>";
			$list .= "<option value='202' style='font-weight:bold;'><strong>CBH</strong></option>";
			$list .= "<option value='11' style='font-weight:bold;'><strong>FSDM</strong></option>";
			$list .= "<option value='10' style='font-weight:bold;'><strong>HO</strong></option>";
			$list .= "<option value='209' style='font-weight:bold;'><strong>MSIL-DMS</strong></option>";
			$list .= "<option value='203' style='font-weight:bold;'><strong>RM</strong></option>";
			$list .= "<option value='204' style='font-weight:bold;'><strong>TSM</strong></option>";
			$list .= "<option value='205' style='font-weight:bold;'><strong>Divisional Head</strong></option>";
			$list .= "<option value='206' style='font-weight:bold;'><strong>Department Head</strong></option>";
			$list .= "<option value='208' 
			style='font-weight:bold;'><strong>Field Team</strong></option>";
			return $list;
		}
		
		function getDesignation($currUID){
			global $DB;
			$cnd = '';$this->response = array();
			if($currUID!='' && $currUID > 0){
				$sqlData = $DB->get_record_sql("SELECT designation_id FROM mdl_ums_employeemaster WHERE userid = '".$currUID."'");
				
				if(count($sqlData) > 0){
					$desigID = $sqlData->designation_id;
					if($desigID == 79){//NTD - outlet(dealer)
						$getData = $DB->get_record_sql("SELECT outlet_id FROM mdl_ums_employeemaster WHERE userid = '".$currUID."'");
						if(count($getData) > 0){
							$this->response['filterby'] = "outlet";
							$this->response['filterid'] = $getData->outlet_id;
						}	
					}
					else if($desigID == 11 || $desigID == 159 || $desigID == 202 || $desigID == 203 || $desigID == 204 || $desigID == 205 || $desigID == 206){//FSDM,CBH,RM, TSM, DVM, DPM - region
						$getData = $DB->get_record_sql("SELECT region_id FROM mdl_ums_employeemaster WHERE userid = '".$currUID."'");
							$this->response['filterby'] = "region";
							$this->response['filterid'] = $getData->region_id!=''?$getData->region_id:0;
					}
				}
			}
			return $this->response;
		}
		
		
		
}


if(isset($_GET['__u__']) && !empty($_GET['__u__']))
{
	$userid = $_GET['__u__'];
}
else
{
	$userid = $USER->id;
}
$obj = new Assessment($USER->id);
$table = $obj->getTableData1();
if(isset($_GET['__g__']) && $_GET['__g__'] == 'data1')
{
	$obj->getIndividualAssessmentJsonData();
}
?>