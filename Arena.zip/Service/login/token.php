<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Return token
 * @package    moodlecore
 * @copyright  2011 Dongsheng Cai <dongsheng@moodle.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('AJAX_SCRIPT', true);
define('REQUIRE_CORRECT_ACCESS', true);
define('NO_MOODLE_COOKIES', true);

require_once(__DIR__ . '/../config.php');
require_once($CFG->libdir . '/externallib.php');

// Allow CORS requests.
header('Access-Control-Allow-Origin: *');

$username = required_param('username', PARAM_USERNAME);
$otp = required_param('otp', PARAM_RAW);
$serviceshortname  = required_param('service',  PARAM_ALPHANUMEXT);
$devicetoken = required_param('devicetoken', PARAM_RAW);
$ostype  = required_param('ostype',  PARAM_RAW);

echo $OUTPUT->header();

global $DB,$CFG;

if (!$CFG->enablewebservices) {
    throw new moodle_exception('enablewsdescription', 'webservice');
}
$username = trim(core_text::strtolower($username));
if (is_restored_user($username)) {
    throw new moodle_exception('restoredaccountresetpassword', 'webservice');
}

$systemcontext = context_system::instance();

$user = $DB->get_record_sql('SELECT * FROM {user} where username = "'.$username.'" ');

// print_r($user);

$currenttime = time();

$otpdetails = $DB->get_record_sql('SELECT * FROM {otp} WHERE userid =? AND otp = ?',array($user->id,$otp));

if(!empty($otpdetails)){

    //OLD -$optexpirytime = $otpdetails->timesent + (3*180);
	$optexpirytime = $otpdetails->timesent + (60*3);//3minutes
    if($currenttime > $optexpirytime  ){
        $error = new stdClass;
        $error->error = 'OTP Expired';
        echo json_encode($error);
        die;
    }
}else{
     $error = new stdClass;
    $error->error = 'Invalid OTP';
    echo json_encode($error);
    die;
}

// $confirmotp = $DB->get_record_sql('SELECT * FROM {otp} WHERE userid =? AND otp =? AND timesent <= ?',array($user->id,$otp,$optexpirytime));
// print_r($confirmotp);

// die;
// if(empty($confirmotp)){
//     $error = new stdClass;
//     $error->error = 'Invalid OTP Or Might be Expired';
//     echo json_encode($error);
//     die;
// }


// $user = authenticate_user_login($username, $password);
if (!empty($user)) {

    // Cannot authenticate unless maintenance access is granted.
    $hasmaintenanceaccess = has_capability('moodle/site:maintenanceaccess', $systemcontext, $user);
    if (!empty($CFG->maintenance_enabled) and !$hasmaintenanceaccess) {
        throw new moodle_exception('sitemaintenance', 'admin');
    }

    if (isguestuser($user)) {
        throw new moodle_exception('noguest');
    }
    if (empty($user->confirmed)) {
        throw new moodle_exception('usernotconfirmed', 'moodle', '', $user->username);
    }
    // check credential expiry
    $userauth = get_auth_plugin($user->auth);
    if (!empty($userauth->config->expiration) and $userauth->config->expiration == 1) {
        $days2expire = $userauth->password_expire($user->username);
        if (intval($days2expire) < 0 ) {
            throw new moodle_exception('passwordisexpired', 'webservice');
        }
    }

    // let enrol plugins deal with new enrolments if necessary
    enrol_check_plugins($user);

    // setup user session to check capability
    \core\session\manager::set_user($user);

    //check if the service exists and is enabled
    $service = $DB->get_record('external_services', array('shortname' => $serviceshortname, 'enabled' => 1));
    if (empty($service)) {
        // will throw exception if no token found
        throw new moodle_exception('servicenotavailable', 'webservice');
    }

    // Get an existing token or create a new one.
    $token = external_generate_token_for_current_user($service);
    $privatetoken = $token->privatetoken;
    external_log_token_request($token);

    $siteadmin = has_capability('moodle/site:config', $systemcontext, $USER->id);

    $usertoken = new stdClass;
    $usertoken->token = $token->token;

    /*
	COMMENTED ON 6th August, 2019
    $update = $DB->execute("UPDATE {user} set devicetoken = '".$devicetoken."',ostype= '".$ostype."' WHERE id = ".$user->id."");
	*/
	
	/*  Requirement on : 15July2019 Hence below changes
		Entry is inserted to mdl_user_lastaccess wen user access Course,Assessment from web.
		But to chk wic users have logged into App we explicitly insert entry to this tbl with courseid=1
	*/
	$sqluser = $DB->get_record_sql("SELECT * FROM mdl_user_lastaccess WHERE userid = '".$user->id."' ORDER BY id DESC LIMIT 1"); //latest time is fetched. whether login via web or app
	if($sqluser->userid!=''){//update in mdl_user_lastaccess
		if($sqluser->courseid == 1){ //courseid 1 is for site access wic is never used anywer
			$updatelaccess = "UPDATE mdl_user_lastaccess SET timeaccess = '".time()."' WHERE id = ".$sqluser->id." AND userid = '".$user->id."' AND courseid = 1 ";
			$DB->execute($updatelaccess);
		}else{
			$checkuser = $DB->get_record_sql("SELECT * FROM mdl_user_lastaccess WHERE courseid = 1 AND userid = '".$user->id."' ");
			if(!empty($checkuser)){ //
				$updatelaccess = "UPDATE mdl_user_lastaccess SET timeaccess = '".time()."' WHERE id = ".$checkuser->id." AND userid = '".$user->id."' AND courseid = 1 ";
				$DB->execute($updatelaccess);
			}else{ //
				$insertlaccess = "INSERT INTO mdl_user_lastaccess(userid, courseid, timeaccess) VALUES('".$user->id."','1', '".time()."' )";//courseid is given static
				$DB->execute($insertlaccess);
			}
		}
	}else{//insert
		$insertlaccess = "INSERT INTO mdl_user_lastaccess(userid, courseid, timeaccess) VALUES('".$user->id."','1', '".time()."' )";//courseid is given static
		$DB->execute($insertlaccess);
	}
	
    // echo "UPDATE {user} set devicetoken = '".$devicetoken."', ostype= '".$ostype."' WHERE id = ".$user->id."";
    // print_r($record);
    // Private token, only transmitted to https sites and non-admin users.
    $fus=$DB->get_record_sql("SELECT face_id_user, is_reverified, is_monthly_reverified,registration_skip,verification_skip, region_id FROM mdl_ums_employeemaster WHERE code='".$username."'");

    if (is_https() and !$siteadmin) {
        $usertoken->privatetoken = $privatetoken;
    } else {
        $usertoken->privatetoken = null;
    }
    $usertoken->userid = $user->id;
    $usertoken->is_registered =@$fus->face_id_user==1?true:false;
    $usertoken->is_reverified =@$fus->is_monthly_reverified==1?true:false;
    $usertoken->registration_skip =@$fus->registration_skip;
    $usertoken->verification_skip =@$fus->verification_skip;
    $server1=[1,2,6,19];
    $server2=[4,16,5];
    $server3=[7,3,8,11];
    $server4=[13,17,12];
    $server5=[18,14,10,15,9];

    $serverip="http://20.207.201.226";
    $serverip1="http://20.207.201.226";
    $serverip2="http://20.204.42.30";
    $serverip3="http://20.204.112.1";
    $serverip4="http://20.204.113.239";
    $serverip5="http://20.204.114.133";

    if(@in_array($fus->region_id, $server1)){
        $usertoken->face_base_url = $serverip1;
        $usertoken->face_base_add_url = $serverip1."/add_face";
        $usertoken->face_base_verify_url = $serverip1."/verify";
        $usertoken->face_quiz_verify_url = $serverip1;
        $usertoken->face_quiz_verify_ios_url = $serverip1."/quiz_course_face_verify";
    }elseif(@in_array($fus->region_id, $server2)){         
        $usertoken->face_base_url = $serverip2;
        $usertoken->face_base_add_url = $serverip2."/add_face";
        $usertoken->face_base_verify_url = $serverip2."/verify";
        $usertoken->face_quiz_verify_url = $serverip2;
        $usertoken->face_quiz_verify_ios_url = $serverip2."/quiz_course_face_verify";
    }elseif(@in_array($fus->region_id, $server3)){         
        $usertoken->face_base_url = $serverip3;
        $usertoken->face_base_add_url = $serverip3."/add_face";
        $usertoken->face_base_verify_url = $serverip3."/verify";
        $usertoken->face_quiz_verify_url = $serverip3;
        $usertoken->face_quiz_verify_ios_url = $serverip3."/quiz_course_face_verify";
    }elseif(@in_array($fus->region_id, $server4)){
        $usertoken->face_base_url = $serverip4;
        $usertoken->face_base_add_url = $serverip4."/add_face";
        $usertoken->face_base_verify_url = $serverip4."/verify";
        $usertoken->face_quiz_verify_url = $serverip4;
        $usertoken->face_quiz_verify_ios_url = $serverip4."/quiz_course_face_verify";
    }elseif(@in_array($fus->region_id, $server5)){
        $usertoken->face_base_url = $serverip5;
        $usertoken->face_base_add_url = $serverip5."/add_face";
        $usertoken->face_base_verify_url = $serverip5."/verify";
        $usertoken->face_quiz_verify_url = $serverip5;
        $usertoken->face_quiz_verify_ios_url = $serverip5."/quiz_course_face_verify";
    }else{         
        $usertoken->face_base_url = $serverip5;
        $usertoken->face_base_add_url = $serverip5."/add_face";
        $usertoken->face_base_verify_url = $serverip5."/verify";
        $usertoken->face_quiz_verify_url = $serverip5;
        $usertoken->face_quiz_verify_ios_url = $serverip5."/quiz_course_face_verify";
    }
    $usersList=["88888888", "888886", "262626", "90825", "72765", "208309", "452639", "404040", "202702", "685637", "863755", "5464"];
    if(in_array($username, $usersList)){
        $serverlessip="https://msil-faceapp.azurewebsites.net";
        $usertoken->face_base_url = $serverlessip;
        $usertoken->face_base_add_url = $serverlessip."/add_face";
        $usertoken->face_base_verify_url = $serverlessip."/verify";
        $usertoken->face_quiz_verify_url = $serverlessip;
        $usertoken->face_quiz_verify_ios_url = $serverlessip."/quiz_course_face_verify";
    }
    echo json_encode($usertoken);
} else {
    throw new moodle_exception('invalidlogin');
}
