<?php





// Moodle is free software: you can redistribute it and/or modify


// it under the terms of the GNU General Public License as published by


// the Free Software Foundation, either version 3 of the License, or


// (at your option) any later version.


//


// Moodle is distributed in the hope that it will be useful,


// but WITHOUT ANY WARRANTY; without even the implied warranty of


// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the


// GNU General Public License for more details.


//


// You should have received a copy of the GNU General Public License


// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**


 * Web service local plugin template external functions and service definitions.


 *


 * @package    localwstemplate


 * @copyright  2011 Jerome Mouneyrac


 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later


 */


// We defined the web service functions to install.




$functions = array(





        'mobile_webservices_hello_world' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'hello_world',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return enrolled courses for logged in user',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),
        'mobile_webservices_get_myprofile' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_myprofile',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return user profile detailes',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),
        'mobile_webservices_get_myassessments' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_myassessments',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return user active assessments',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),
		'mobile_webservices_get_assessments' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_assessments',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return user active assessments',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),
        'mobile_webservices_get_mycourses' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_mycourses',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return user active courses',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),
          'mobile_webservices_get_mynotifications' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_mynotifications',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return notification',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),
           'mobile_webservices_get_myperf_assessments' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_myperf_assessments',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return performance in assessments',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),

            'mobile_webservices_get_myperf_courses' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_myperf_courses',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return performance in assessments',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),

             'mobile_webservices_get_videos' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_videos',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return performance in assessments',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),


              'mobile_webservices_get_audios' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_audios',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return performance in assessments',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),

               'mobile_webservices_get_knowledge' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_knowledge',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return performance in assessments',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),

               'mobile_webservices_get_knowledgetabs' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_knowledgetabs',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return performance in assessments',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),


               'mobile_webservices_get_tabs' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_tabs',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Return performance in assessments',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),

                'mobile_webservices_knowledgecenter_folders' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'knowledgecenter_folders',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Returns folders in knowledgecenter database activity',

                'type'        => 'read',

                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)

        ),


                'mobile_webservices_get_mycertifications' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'get_mycertifications',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'Returns certifcate of user',

                'type'        => 'Read',

                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ),

                 'mobile_webservices_logout' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'logout',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'logout user',

                'type'        => 'Read',

                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ),

                 'mobile_webservices_knowledgecenter_parentfolders' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'knowledgecenter_parentfolders',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'knowledgecenter Parent folders',

                'type'        => 'Read',

                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ),


                 'mobile_webservices_knowledgecenter_subfolders' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'knowledgecenter_subfolders',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'knowledgecenter subfolders folders',

                'type'        => 'Read',

                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ),


                 'mobile_webservices_knowledgecenter_file' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'knowledgecenter_file',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'knowledgecenter files',

                'type'        => 'Read',

                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ),


                 'mobile_webservices_audio_video_parentfolders' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'audio_video_parentfolders',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'audio_video Parent folders',

                'type'        => 'Read',

                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ),


                 'mobile_webservices_audio_video_subfolders' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'audio_video_subfolders',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'audio_video subfolders folders',

                'type'        => 'Read',

                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ),


                 'mobile_webservices_audio_video_file' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'audio_video_file',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'audio_video files',

                'type'        => 'Read',

                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ),

                   'mobile_webservices_audio_video_folders' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'audio_video_folders',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'audio_video folders',

                'type'        => 'Read',

                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ),
                'mobile_webservices_verify_version' => array(

                'classname'   => 'mobile_webservices',

                'methodname'  => 'verify_version',

                'classpath'   => 'local/mobile_webservices/externallib.php',

                'description' => 'verify version',

                'type'        => 'Read',

                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ),
        'mobile_webservices_get_myquestion' => array(

                'classname'   => 'mobile_webservices',
                'methodname'  => 'get_myquestion',
                'classpath'   => 'local/mobile_webservices/externallib.php',
                'description' => 'question of day',
                'type'        => 'Read',
                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ), 
		'mobile_webservices_get_myquestionanwser' => array(

                'classname'   => 'mobile_webservices',
                'methodname'  => 'get_myquestionanwser',
                'classpath'   => 'local/mobile_webservices/externallib.php',
                'description' => 'question of day',
                'type'        => 'Read',
                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ), 
		'mobile_webservices_get_mytodayquestionstatus' => array(

                'classname'   => 'mobile_webservices',
                'methodname'  => 'get_mytodayquestionstatus',
                'classpath'   => 'local/mobile_webservices/externallib.php',
                'description' => 'todays question of day status',
                'type'        => 'Read',
                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ), 
		'mobile_webservices_get_previousdayQuestion' => array(

                'classname'   => 'mobile_webservices',
                'methodname'  => 'get_previousdayQuestion',
                'classpath'   => 'local/mobile_webservices/externallib.php',
                'description' => 'previous day question',
                'type'        => 'Read',
                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ), 
		'mobile_webservices_get_attemptedQuestionAnswerStatus' => array(

                'classname'   => 'mobile_webservices',
                'methodname'  => 'get_attemptedQuestionAnswerStatus',
                'classpath'   => 'local/mobile_webservices/externallib.php',
                'description' => 'question answer rank',
                'type'        => 'Read',
                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ), 
		
		'mobile_webservices_get_QODRanKStatus' => array(

                'classname'   => 'mobile_webservices',
                'methodname'  => 'get_QODRanKStatus',
                'classpath'   => 'local/mobile_webservices/externallib.php',
                'description' => 'get rank',
                'type'        => 'Read',
                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ), 
		'mobile_webservices_get_mylistcourses' => array(

                'classname'   => 'mobile_webservices',
                'methodname'  => 'get_mylistcourses',
                'classpath'   => 'local/mobile_webservices/externallib.php',
                'description' => 'get mylistcourses',
                'type'        => 'Read',
                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ), 
		'mobile_webservices_get_final_assessments' => array(

                'classname'   => 'mobile_webservices',
                'methodname'  => 'get_final_assessments',
                'classpath'   => 'local/mobile_webservices/externallib.php',
                'description' => 'get myfinalassessment',
                'type'        => 'Read',
                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ), 
		'mobile_webservices_get_userlmsperformance' => array(

                'classname'   => 'mobile_webservices',
                'methodname'  => 'get_userlmsperformance',
                'classpath'   => 'local/mobile_webservices/externallib.php',
                'description' => 'get userlmsperformance',
                'type'        => 'Read',
                'services'    => array(MOODLE_OFFICIAL_MOBILE_SERVICE) 
        ),

);


// We define the services to install as pre-build services. A pre-build service is not editable by administrator..s.


$services = array(

        'mobile_services' => array(

                'functions' => array ('mobile_webservices_hello_world','mobile_webservices_get_myprofile','mobile_webservices_get_myassessments','mobile_webservices_get_mycourses','mobile_webservices_get_mynotifications','mobile_webservices_get_myperf_assessments','mobile_webservices_get_myperf_courses','mobile_webservices_get_videos','mobile_webservices_get_audios','mobile_webservices_get_knowledge','mobile_webservices_get_knowledgetabs','mobile_webservices_get_tabs','mobile_webservices_knowledgecenter_folders','mobile_webservices_get_mycertifications','mobile_webservices_logout','mobile_webservices_knowledgecenter_parentfolders','mobile_webservices_knowledgecenter_subfolders','mobile_webservices_knowledgecenter_file','mobile_webservices_audio_video_parentfolders','mobile_webservices_audio_video_subfolders','mobile_webservices_audio_video_file','mobile_webservices_audio_video_folders','mobile_webservices_verify_version',
				'mobile_webservices_get_myquestion',
				'mobile_webservices_get_myquestionanwser',
				'mobile_webservices_get_mylistcourses',
				'mobile_webservices_get_final_assessments',
				'mobile_webservices_get_mytodayquestionstatus',
				'mobile_webservices_get_previousdayQuestion',
				'mobile_webservices_get_attemptedQuestionAnswerStatus',
				'mobile_webservices_get_QODRanKStatus',
				'mobile_webservices_get_userlmsperformance'),
                'restrictedusers' => 0,
                'enabled'=>1,
        )


);