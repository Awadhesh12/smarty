<?php

// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External Web Service Template
 *
 * @package    localwstemplate
 * @copyright  2011 Moodle Pty Ltd (http://moodle.com)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once("$CFG->libdir/externallib.php");

//echo '../pagecontainer/custom_methods.php';
//require_once('../pagecontainer/custom_methods.php');

class mobile_webservices extends external_api {


public static function verify_version_parameters() {
        return new external_function_parameters(
                array('version' => new external_value(PARAM_RAW, 'version'),
                      'platform' => new external_value(PARAM_TEXT, 'platform')
                    )
        );
    }
  
   public static function verify_version($version,$platform) {
        global $DB,$USER;
        $sql = 'SELECT * FROM {app_version_check} where type = "'.$platform.'" And version = "'.$version.'"';
        $version = array();
        // echo $sql;echo $platform;
		
        $records = $DB->get_record_sql($sql);

        if(!empty($records)){
			if($platform=='ios'){
				$version['status'] = 'Verified';//commented to crash webservice for android only(ask later to App developer to enable or not)
			}
        }else{
			if($platform=='ios'){
				$version['status'] = 'Not Verified';//commented to crash webservice for android only
			}
        }
        return $version;
    }
  
  public static function verify_version_returns() {
       return  new external_single_structure(
       array('status'=> new external_value(PARAM_RAW, 'mobile app version')
       ));
    }



 public static function hello_world_parameters()
     {

        return new external_function_parameters(

                array('userid' => new external_value(PARAM_INT, 'Retrieve information based on userid ', VALUE_DEFAULT, 2))
                );

    }

    /**

     * Returns welcome message

     * @return string welcome message

     */

    public static function hello_world() {

        global $USER;
        //Parameter validation

        // $result = new stdClass();

         $subresult = new stdClass();
       $subresult->status = 'true';
      
       return $subresult;

    }

      

      public static function hello_world_returns()
     {

     return new external_single_structure(
                array(
            'status' => new external_value(PARAM_TEXT, 'Name of the cert'),
          )
        );
      }



  public static function get_myupcomingcert_parameters() {

      return new external_function_parameters(
              array()
      );
  }


   public static function get_myupcomingcert() 
   {
	     // function for upcoming
         global $USER, $DB, $CFG;
        
        $params = self::validate_parameters(self::get_myprofile_parameters(), array('welcomemessage' => $welcomemessage));

        
        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);
		
		$result = new stdClass();
        $result->name = 'HStep2 Chassis';
        $result->startdate = '28/11/2017';
        return $result;
		
  }

  public static function get_myupcomingcert_returns() {
    return new external_single_structure(
            array(
        'name' => new external_value(PARAM_TEXT, 'Name of the cert'),
        'startdate' => new external_value(PARAM_TEXT, 'Date')
            )
    );
  }





 public static function get_mycertifications_parameters() {

      return new external_function_parameters(
              array()
      );
  }



    public static function get_mycertifications(){
    global $USER, $DB, $CFG;
        

        // print_r($USER);
        $params = self::validate_parameters(self::get_myprofile_parameters(), array('welcomemessage' => $welcomemessage));

        $userid= $USER->id;
        
        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);

        $allcertificates = $DB->get_records_sql('SELECT * FROM {certificate}');

        // print_r($allcertificates);
        $newresult = array();
        foreach ($allcertificates as $key => $allcertificate) {

              $completedcount = 0;
              $totalcount = 0;
              $coursecompletedcount = 0;
              $totalcoursecount = 0;

          if(!empty($allcertificate->assessment_id) && !empty($allcertificate->course_id)){

            $coursecontext = context_course::instance($allcertificate->course_id);
            $getquizcourseid = $DB->get_record('quiz',array('id'=>$allcertificate->assessment_id));
            $quizcoursecontext = context_course::instance($getquizcourseid->course);
            // $quizcoursecontext = $quizcoursecontext->id;

            $isenrolledin_course = is_enrolled($coursecontext, $userid);

            $isenrolledinassessment_course = is_enrolled($quizcoursecontext, $userid);

            if(!empty($isenrolledin_course) && !empty($isenrolledinassessment_course)){

            $assessment_courseid = $allcertificate->assessment_id;        
            // $quizs = $DB->get_records_sql("SELECT * FROM {quiz} WHERE course =?",array($assessment_courseid));
            // print_r($quizs);
  
              $checkquiz  = $DB->get_records_sql('SELECT * from {quiz_attempts} WHERE  quiz =? AND userid =? AND state = ?',array($allcertificate->assessment_id,$userid,'finished'));
              if(!empty($checkquiz)){
                  $completedcount++;
                $is_assessmentcoursecompleted = "Yes";
              }else{
                  $is_assessmentcoursecompleted = "No";
              }

            $courseid = $allcertificate->course_id;     
            // echo $courseid; 
            $scorms = $DB->get_records('scorm',array('course'=>$courseid));
            // print_r($scorms);
            foreach ($scorms as $key => $scorm) {
              $checkscorm  = $DB->get_record_sql('SELECT * from {scorm_scoes_track} WHERE  scormid =? AND userid =? AND element = ? OR element',array($scorm->id,$userid,'cmi.core.lesson_status','cmi.completion_status'));
              // print_r($checkscorm);
              if($checkscorm->value =="completed" OR $checkscorm->value =="passed"){
                $coursecompletedcount++;
              }
                $totalcoursecount++;
            }
              if($totalcoursecount == $coursecompletedcount){
                  $iscoursecompleted = "Yes";
              }else{
                  $iscoursecompleted = "No";
              }

              if($is_assessmentcoursecompleted == "Yes" && $iscoursecompleted == "Yes"){
                 $coursedetails = $DB->get_record('course',array('id'=>$allcertificate->course_id));

                  $result = new stdClass();
                  $result->courseid = $courseid;
                  $result->coursename = $coursedetails->fullname;
                  $result->assessmentid = $allcertificate->assessment_id;
                  $result->assessmentname =  $getquizcourseid->name;
                  $result->certifacte_name = $allcertificate->certificate_name;
                  $result->startdate = $allcertificate->created;
                  $newresult[] = $result;

              }
              // echo $iscoursecompleted;


            }
           
          }elseif(!empty($allcertificate->assessment_id)){
    

            $getquizcourseid = $DB->get_record('quiz',array('id'=>$allcertificate->assessment_id));

            $quizcoursecontext = context_course::instance($getquizcourseid->course);
            // $coursedetails = $DB->get_record('course',array('id'=>$allcertificate->assessment_id));
            $isenrolledinassessment_course = is_enrolled($quizcoursecontext, $userid);
            if(!empty($isenrolledinassessment_course)){

              $assessment_courseid = $allcertificate->assessment_id;        
                $checkquiz  = $DB->get_record_sql('SELECT * from {quiz_attempts} WHERE  quiz =? AND userid =? AND state = ?',array($allcertificate->assessment_id,$userid,'finished'));
                if(!empty($checkquiz)){
                  $completedcount++;
                
                  $result = new stdClass();
                  $result->assessmentid = $allcertificate->assessment_id;
                  $result->assessmentname =  $getquizcourseid->name;
                  $result->certifacte_name = $allcertificate->certificate_name;
                  $result->startdate = $allcertificate->created;
                  $newresult[] = $result;

              }

            }


          }elseif(!empty($allcertificate->course_id)){



            $coursedetails = $DB->get_record('course',array('id'=>$allcertificate->course_id));

             $coursecontext = context_course::instance($allcertificate->course_id);
             $isenrolledin_course = is_enrolled($coursecontext, $userid);
             if(!empty($isenrolledin_course)){

            $courseid = $allcertificate->course_id;     
            // echo $courseid; 
            $scorms = $DB->get_records('scorm',array('course'=>$courseid));
            // print_r($scorms);
            foreach ($scorms as $key => $scorm) {
              $checkscorm  = $DB->get_record_sql('SELECT * from {scorm_scoes_track} WHERE  scormid =? AND userid =? AND element = ? OR element',array($scorm->id,$userid,'cmi.core.lesson_status','cmi.completion_status'));
              // print_r($checkscorm);
              if($checkscorm->value =="completed" OR $checkscorm->value =="passed"){
                $coursecompletedcount++;
                }
                  $totalcoursecount++;
              }
              if($totalcoursecount == $coursecompletedcount){

                  $result = new stdClass();
                  $result->courseid = $courseid;
                  $result->coursename = $coursedetails->fullname;
                  $result->certifacte_name = $allcertificate->certificate_name;
                  $result->startdate = $allcertificate->created;
                  $newresult[] = $result;

              }

             }

          }
 // die;
        }

        return $newresult;
    
      
  }



      public static function get_mycertifications_returns() {
      return new external_multiple_structure(
        new external_single_structure(
            array(
             'courseid' => new external_value(PARAM_RAW, 'Course id', VALUE_OPTIONAL),
             'coursename' => new external_value(PARAM_RAW, 'Name of the Course', VALUE_OPTIONAL),
             'assessmentid' => new external_value(PARAM_RAW, 'assessment id', VALUE_OPTIONAL),
             'assessmentname' => new external_value(PARAM_RAW, 'Name of the category', VALUE_OPTIONAL),
             'certifacte_name' => new external_value(PARAM_RAW, 'Name of the cert'),
             'startdate' => new external_value(PARAM_RAW, 'Date')
            )
     ));
  }






    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_myprofile_parameters() {

        return new external_function_parameters(
                array('welcomemessage' => new external_value(PARAM_TEXT, 'The welcome message. By default it is "Hello world,"', VALUE_DEFAULT, 'Hello world, '))
        );
    }

        /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function get_myprofile($welcomemessage = 'Hello world') {
        global $USER, $DB;
        //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::get_myprofile_parameters(), array('welcomemessage' => $welcomemessage));

        //Context validation
        //OPTIONAL but in most web service it should present
        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);
      
        $employee = $DB->get_record_sql("SELECT ue.*,ud.d_name as designation,usd.sd_name as subdesignation,uch.c_abbr_name as channel,uut.ut_name as usertype ,uo.o_name as outlet,uo.o_code_latest as outletcode,us.s_name as state,uc.c_name as city,ue.tl_mspin_no as tl_mspin,uog.og_name as outletgroupname FROM {user} u LEFT JOIN {ums_employeemaster} ue on u.id = ue.userid LEFT JOIN {ums_designations} ud on ue.designation_id = ud.id LEFT JOIN {ums_sub_designations} usd ON ue.sub_designation_id = usd.id LEFT JOIN {ums_channels} uch ON ue.channels_id = uch.id LEFT JOIN {ums_user_type} uut ON ue.user_type_id = uut.id LEFT JOIN {ums_outlet} uo ON ue.outlet_id = uo.id LEFT JOIN {ums_outlet_group} uog ON uog.id = uo.outlet_group_id LEFT JOIN {ums_state} us ON ue.state_id = us.id LEFT JOIN {ums_city} uc ON ue.city_id = uc.id WHERE u.id = $USER->id");

        $tlname = $DB->get_record('user',array('username'=>$employee->tl_mspin));
     
        $teamlead = $tlname->firstname.' '.$tlname->lastname;
		
		$regionstr = "";
		if($employee->region_id!=''){
			$regionidtemp = explode(",",$employee->region_id);
			foreach($regionidtemp as $rid){
				$regionname	=	$DB->get_field("ums_regions","r_name",array("id"=>$rid));
				$regionstr .= $regionname.", ";
			}
		}
		
		//----------------------------------------------------------//
		if($employee->expression_user ==1)
		{
			$expression = 'Yes';
		}
        else
		{
			$expression = 'No';
		}
		//---------------------------------------------------------//
		if($employee->bestpractice_user ==1)
		{
			$bestpractice = 'Yes';
		}
        else
		{
			$bestpractice = 'No';
		}

    /* Modified Date : 14 May 2020
    Added code for Monthly count

    */
    $today  = date("Y-m-d"); // todays date
    $thismonthstart = date('Y-m-01'); // start date of current month
    $thismonth_sql = "SELECT count(*) as total_question FROM mdl_question_of_day WHERE qdate >= '".$thismonthstart."' AND qdate <= '".$today."'"; 
    $sqlData       = $DB->get_record_sql($thismonth_sql);
    $thismonth_total_question = $sqlData->total_question;
      
    $month = date("Y-m");// here we get current month
    $thismonth_sql_ans = "SELECT answer FROM mdl_question_of_day_correct_answer WHERE mspin = '".$USER->username."' AND month = '".$month."'"; 
    $sqlData_1m = $DB->get_record_sql($thismonth_sql_ans);
	//$outletname!=''?$outletname:'-'
    $thismonth_correct_ans = $sqlData_1m->answer!=''?$sqlData_1m->answer:'0';
    $score_this_month = $thismonth_total_question."-".$thismonth_correct_ans;
    // total question and total question answer given
    $rank_this_month  = number_format((($thismonth_correct_ans/$thismonth_total_question)*100),2);
    /* Monthly Count Code End */

        $profile = array(
            'id' => $USER->id,
            'empcode' => $USER->username,
            'name' => $USER->firstname.' '.$USER->lastname,
            'contactno' => $USER->phone1,
            'password' => $employee->password,
            // 'empdob' => $empdob,
            'email' => $USER->email,
            'designation' => $employee->designation,
            'subdesignation' => $employee->subdesignation,
            'TL'=>$teamlead,
            'channel' => $employee->channel,
            'usertype' => $employee->usertype,
            'outletid'=>$employee->outletcode,
            'outlet' => $employee->outlet,
            'outletgroupname'=>$employee->outletgroupname,
            'region' => $regionstr!=''?rtrim($regionstr,", "):'--',
            'state' => $employee->state,
            'city' => $employee->city,
			'is_Expression' => $expression,
			'is_Bestpractice' => $bestpractice,
            // 'mspin' => $employee->mspin
      /* 14 May 2020 */
            'questioncount' => $thismonth_total_question,
      'answercount'   => $thismonth_correct_ans,
      'current_month_question_answer_status' => $thismonth_correct_ans."/".$thismonth_total_question
        );

        return $profile;
        // return $params['welcomemessage'] . $USER->firstname .$coursename;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_myprofile_returns() {
        // return new external_value(PARAM_TEXT, 'The welcome message + user first name');
        return new external_single_structure(
                array(
            'id' => new external_value(PARAM_INT, 'id of user'),
            'empcode' => new external_value(PARAM_TEXT, 'Emp Code/GDMS Code'),
            'name' => new external_value(PARAM_TEXT, 'Name'),
            'contactno' => new external_value(PARAM_TEXT, 'Phone number'),
            'password' => new external_value(PARAM_TEXT, 'Password'),
            'email' => new external_value(PARAM_TEXT, 'Email id'),
            'designation' => new external_value(PARAM_TEXT, 'Designation'),
            'subdesignation' => new external_value(PARAM_TEXT, 'Sub Designation'),
            'TL' =>new external_value(PARAM_RAW,'tl_mspin'),
            'channel' => new external_value(PARAM_TEXT, 'Chanel'),
            'usertype' => new external_value(PARAM_TEXT, 'User Type'),
            'outletid' => new external_value(PARAM_RAW,'outletid'),
            'outlet' => new external_value(PARAM_TEXT, 'Outlet'),
            'outletgroupname' => new external_value(PARAM_TEXT,'outletgroupname'),
            'region' => new external_value(PARAM_TEXT, 'Region'),
            'state' => new external_value(PARAM_TEXT,'State'),
            'city' => new external_value(PARAM_TEXT,'City'),
			'is_Expression' => new external_value(PARAM_TEXT,'Expression'),
			'is_Bestpractice' => new external_value(PARAM_TEXT,'Best Practice'),
      'questioncount' => new external_value(PARAM_INT,'questioncount'),
      'answercount'   => new external_value(PARAM_INT,'answercount'),
      'current_month_question_answer_status' => new external_value(PARAM_TEXT,'current_month_question_answer_status'),
            // 'mspin' => new external_value(PARAM_TEXT,'MSPIN')
                )
        );
    }


    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_myassessments_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    
    public static function get_myassessments($welcomemessage = 'Hello world, ')
	{
		
		global $USER, $DB, $CFG;

        $courses = enrol_get_users_courses($USER->id, false, 'id, shortname, fullname, idnumber, visible,
                   summary, summaryformat, format, showgrades, lang, enablecompletion, category, startdate, enddate');
        foreach ($courses as $key => $course)
		{
            if($course->category == 2)
			{
				if($course->visible == 1)
				{
					$checkenrollmentmethods = $DB->get_records_sql('SELECT * FROM {enrol} WHERE courseid = ?',array($course->id));
                    foreach ($checkenrollmentmethods as $key => $checkenrollmentmethod)
					{
						$enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($checkenrollmentmethod->id,$USER->id));
						if(!empty($enrollmentdate))
						{
							$courseenrollmentdate = $enrollmentdate->timecreated;
							$enrolenddate = $enrollmentdate->timeend;
						}                                
					}
					$progress = null;
           			$pro = null;
					if ($course->enablecompletion) 
					{
						/* $pro = \core_completion\progress::get_course_progress_percentage($course);
						if($pro == 100)
						{
						  $progress = "Completed";
						}
						else
						{ */
							$pro = \core_completion\progress::get_course_progress_percentage($course);
							if($pro == 100)
							{
							  $progress = "Completed";
							}
							else if(!$DB->record_exists('quiz', array('course' => $course->id)))
							{
								$sql_scorm = $DB->get_records_sql("SELECT * FROM {scorm} s JOIN {scorm_scoes_track} sst ON sst.scormid = s.id WHERE s.course = ? AND sst.userid = ?",array($course->id,$USER->id));
								if(empty($sql_scorm))
								{
									$progress = "Not Started";
								}
								else
								{
									$progress = "Incomplete";
								}
							} 
							else
							{
								$quizrecord  = $DB->get_record('quiz', array('course' => $course->id));
								$quizattempt = $DB->get_field('quiz', 'attempts', array('course' => $course->id));
								$modid = $DB->get_field('modules', 'id', array('name' => 'quiz'));
								$cmid  = $DB->get_field('course_modules', 'id', array('course' => $course->id, 'module' => $modid,'instance' => $quizrecord->id));	
								
								// Here we are checking user latest attempt //
								$user_attempts = $DB->get_record_sql('SELECT MAX(attempt) as user_max_attempt FROM {quiz_attempts} WHERE quiz = '.$quizrecord->id.' AND userid= '.$USER->id.'');
								$latestattempt = $user_attempts->user_max_attempt;
								
								// if the date passed 								
								$attempstatus = $DB->get_field('quiz_attempts','state',array('quiz' =>$quizrecord->id, 'userid' => $USER->id,'attempt' => 1));
								if (empty($attempstatus)) 
								{
									if ($quizrecord->timeclose > time()) 
									{
										$progress = "Expired";
									}
									else
									{
										$progress = "Not Started";
									}
								}
								else
								{
									/// here we are checking user grade of latest attempt ///
									$sumgrade = $DB->get_field('quiz_attempts', 'sumgrades', array('quiz' => $quizrecord->id, 'userid' => $USER->id,'attempt' => $latestattempt));
									
									// here we are checking the user //
									$passgrade = $DB->get_field('grade_items', 'gradepass', array('courseid' => $course->id, 'iteminstance' => $quizrecord->id, 'itemmodule' => 'quiz'));
									
									if($sumgrade >= $passgrade)
									{
										$progress = "Completed";
									}
									else
									{
										$progress = "Incomplete";
									}		
								}	
							}		
						//}//
               		}
					$url = $CFG->wwwroot.'/course/view.php?id='.$course->id;
					$result[] = array(
						'id' => $course->id,
						'shortname' => $course->shortname,
						'fullname' => $course->fullname,
						'idnumber' => $course->idnumber,
						'visible' => $course->visible,
						'summary' => $course->summary,
						'summaryformat' => $course->summaryformat,
						'format' => $course->format,
						'showgrades' => $course->showgrades,
						'lang' => clean_param($course->lang, PARAM_LANG),
						'enablecompletion' => $course->enablecompletion,
						'category' => $course->category,
						'progress' => $progress,
						'startdate' => $course->startdate,
						'enddate' => $course->enddate,
						'enroldate' => $courseenrollmentdate,
						'enrolenddate' => $enrolenddate,
						'url' => $url,
					);
				}
			}
        }
        if(empty($result))
		{
            $result[] = array();
        }
        return $result;
       /* global $USER, $DB, $CFG;

        $courses = enrol_get_users_courses($USER->id, false, 'id, shortname, fullname, idnumber, visible,
                   summary, summaryformat, format, showgrades, lang, enablecompletion, category, startdate, enddate');
       
        foreach ($courses as $key => $course)
		{
         
          if($course->category == 2){
			if($course->visible == 1){

             $checkenrollmentmethods = $DB->get_records_sql('SELECT * FROM {enrol} WHERE courseid = ?',array($course->id));
            foreach ($checkenrollmentmethods as $key => $checkenrollmentmethod) {
            $enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($checkenrollmentmethod->id,$USER->id));
           
                if(!empty($enrollmentdate)){
                    $courseenrollmentdate = $enrollmentdate->timecreated;
                    $enrolenddate = $enrollmentdate->timeend;
                }                                
            }
            $progress = null;
        
              $pro = null;
            if ($course->enablecompletion) {
                $pro = \core_completion\progress::get_course_progress_percentage($course);
                if($pro == 100){
                  $progress = "Completed";
                }else{
					
					
				  $sql_scorm = $DB->get_records_sql("SELECT * FROM {scorm} s JOIN {scorm_scoes_track} sst ON sst.scormid = s.id WHERE s.course = ? AND sst.userid = ?",array($course->id,$USER->id));
                  if(empty($sql_scorm)){
                    $progress = "Not Started";
                  }else{
                    $progress = "Incomplete";
                  }


				  
                }
              
            }
            $url = $CFG->wwwroot.'/course/view.php?id='.$course->id;
         
            $result[] = array(
                'id' => $course->id,
                'shortname' => $course->shortname,
                'fullname' => $course->fullname,
                'idnumber' => $course->idnumber,
                'visible' => $course->visible,
                'summary' => $course->summary,
                'summaryformat' => $course->summaryformat,
                'format' => $course->format,
                'showgrades' => $course->showgrades,
                'lang' => clean_param($course->lang, PARAM_LANG),
                'enablecompletion' => $course->enablecompletion,
                'category' => $course->category,
                'progress' => $progress,
                'startdate' => $course->startdate,
                'enddate' => $course->enddate,
                'enroldate' => $courseenrollmentdate,
                'enrolenddate' => $enrolenddate,
                'url' => $url,
            );
		    }
           }
          }
          if(empty($result)){
            $result[] = array();
          }
          return $result;*/
		  
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    // public static function get_myassessments_returns() {
    //     return new external_multiple_structure(
    //             new external_single_structure(
    //             array(
    //         'courseid' => new external_value(PARAM_INT, 'id of course'),
    //         'name' => new external_value(PARAM_TEXT, 'name of quiz'),
    //         'starttime' => new external_value(PARAM_RAW, 'Start time of quiz'),
    //         'endtime' => new external_value(PARAM_RAW, 'End Quiz time'),
    //         'status' => new external_value(PARAM_TEXT, 'Status'),
    //         'testlink' => new external_value(PARAM_TEXT, 'Test Link'),
    //             )
    //             )
    //     );
    // }

    public static function get_myassessments_returns() {
       return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id'        => new external_value(PARAM_RAW, 'id of course',VALUE_OPTIONAL),
                    'shortname' => new external_value(PARAM_RAW, 'short name of course',VALUE_OPTIONAL),
                    'fullname'  => new external_value(PARAM_RAW, 'long name of course',VALUE_OPTIONAL),
                    'idnumber'  => new external_value(PARAM_RAW, 'id number of course',VALUE_OPTIONAL),
                    'visible'   => new external_value(PARAM_RAW, '1 means visible, 0 means hidden course',VALUE_OPTIONAL),
                    'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
                                                                VALUE_OPTIONAL),
                    'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate' => new external_value(PARAM_INT, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_INT, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'url' => new external_value(PARAM_RAW,'assessment url', VALUE_OPTIONAL),
                )
            )
        );
    }

	/***************************************************************************************/
	// Code Developed By - Yogita Ghegadmal
	// Date - 31 oct 2019
	// this is also for testing purpose
	public static function get_assessments_parameters() {

        return new external_function_parameters(array());
    }
	
	public static function get_assessments()
	{
		global $USER, $DB, $CFG;

        $courses = enrol_get_users_courses($USER->id, false, 'id, shortname, fullname, idnumber, visible,
                   summary, summaryformat, format, showgrades, lang, enablecompletion, category, startdate, enddate');
        foreach ($courses as $key => $course)
		{
         
            if($course->category == 2)
			{
				if($course->visible == 1)
				{
					$checkenrollmentmethods = $DB->get_records_sql('SELECT * FROM {enrol} WHERE courseid = ?',array($course->id));
                    foreach ($checkenrollmentmethods as $key => $checkenrollmentmethod)
					{
						$enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($checkenrollmentmethod->id,$USER->id));
						if(!empty($enrollmentdate))
						{
							$courseenrollmentdate = $enrollmentdate->timecreated;
							$enrolenddate = $enrollmentdate->timeend;
						}                                
					}
					$progress = null;
           			$pro = null;
					if ($course->enablecompletion) 
					{
						/* $pro = \core_completion\progress::get_course_progress_percentage($course);
						if($pro == 100)
						{
						  $progress = "Completed";
						}
						else
						{ */
							$pro = \core_completion\progress::get_course_progress_percentage($course);
							if($pro == 100)
							{
							  $progress = "Completed";
							}
							else if(!$DB->record_exists('quiz', array('course' => $course->id)))
							{
								$sql_scorm = $DB->get_records_sql("SELECT * FROM {scorm} s JOIN {scorm_scoes_track} sst ON sst.scormid = s.id WHERE s.course = ? AND sst.userid = ?",array($course->id,$USER->id));
								if(empty($sql_scorm))
								{
									$progress = "Not Started";
								}
								else
								{
									$progress = "Incomplete";
								}
							}
							else
							{
								$quizrecord  = $DB->get_record('quiz', array('course' => $course->id));
								$quizattempt = $DB->get_field('quiz', 'attempts', array('course' => $course->id));
								$modid = $DB->get_field('modules', 'id', array('name' => 'quiz'));
								$cmid  = $DB->get_field('course_modules', 'id', array('course' => $course->id, 'module' => $modid,'instance' => $quizrecord->id));	
								
								// Here we are checking user latest attempt //
								$user_attempts = $DB->get_record_sql('SELECT MAX(attempt) as user_max_attempt FROM {quiz_attempts} WHERE quiz = '.$quizrecord->id.' AND userid= '.$USER->id.'');
								$latestattempt = $user_attempts->user_max_attempt;
								
								// if the date passed 								
								$attempstatus = $DB->get_field('quiz_attempts','state',array('quiz' =>$quizrecord->id, 'userid' => $USER->id,'attempt' => 1));
								if (empty($attempstatus)) 
								{
									if ($quizrecord->timeclose > time()) 
									{
										$progress = "Expired";
									}
									else
									{
										$progress = "Not Started";
									}
								}
								else
								{
									/// here we are checking user grade of latest attempt ///
									$sumgrade = $DB->get_field('quiz_attempts', 'sumgrades', array('quiz' => $quizrecord->id, 'userid' => $USER->id,'attempt' => $latestattempt));
									
									// here we are checking the user //
									$passgrade = $DB->get_field('grade_items', 'gradepass', array('courseid' => $course->id, 'iteminstance' => $quizrecord->id, 'itemmodule' => 'quiz'));
									
									if($sumgrade >= $passgrade)
									{
										$progress = "Completed";
									}
									else
									{
										$progress = "Incomplete";
									}		
								}	
							}		
						//}//
               		}
					$url = $CFG->wwwroot.'/course/view.php?id='.$course->id;
					$result[] = array(
						'id' => $course->id,
						'shortname' => $course->shortname,
						'fullname' => $course->fullname,
						'idnumber' => $course->idnumber,
						'visible' => $course->visible,
						'summary' => $course->summary,
						'summaryformat' => $course->summaryformat,
						'format' => $course->format,
						'showgrades' => $course->showgrades,
						'lang' => clean_param($course->lang, PARAM_LANG),
						'enablecompletion' => $course->enablecompletion,
						'category' => $course->category,
						'progress' => $progress,
						'startdate' => $course->startdate,
						'enddate' => $course->enddate,
						'enroldate' => $courseenrollmentdate,
						'enrolenddate' => $enrolenddate,
						'url' => $url,
					);
				}
			}
        }
        if(empty($result))
		{
            $result[] = array();
        }
        return $result;
    }
	
	public static function get_assessments_returns() 
	{
		return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id'        => new external_value(PARAM_RAW, 'id of course',VALUE_OPTIONAL),
                    'shortname' => new external_value(PARAM_RAW, 'short name of course',VALUE_OPTIONAL),
                    'fullname'  => new external_value(PARAM_RAW, 'long name of course',VALUE_OPTIONAL),
                    'idnumber'  => new external_value(PARAM_RAW, 'id number of course',VALUE_OPTIONAL),
                    'visible'   => new external_value(PARAM_RAW, '1 means visible, 0 means hidden course',VALUE_OPTIONAL),
                    'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
                                                                VALUE_OPTIONAL),
                    'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate' => new external_value(PARAM_INT, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_INT, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'url' => new external_value(PARAM_RAW,'assessment url', VALUE_OPTIONAL),
                )
            )
        );
	}
	/***************************************************************************************/
	
	/*********************** Assessment Final 20/02/2020 **************************************/
	// this is for testing purpose
	public static function get_final_assessments_parameters() {

        return new external_function_parameters(array());
    }
	
	public static function get_final_assessments()
	{
		global $USER, $DB, $CFG;
		$sqlAssessment = $DB->get_records_sql('select 
		c.id as courseid,
		c.fullname as coursename,
		c.summary as summary,
		c.shortname as shortname,
		c.idnumber as idnumber,
		c.visible as visible,
		c.summaryformat as summaryformat,
		c.format,
		c.showgrades,
		c.lang,
		c.enablecompletion,
		c.category,
		c.startdate,
		c.enddate,
		a.timemodified as enrolldate 
		FROM {role_assignments} AS a
		INNER JOIN {context} AS b on(b.id = a.contextid)
		INNER JOIN {course} AS c on(c.id = b.instanceid) WHERE a.userid= ?
		AND c.category = 2 AND c.visible = 1
		ORDER BY c.id DESC', array($USER->id));
		foreach($sqlAssessment as $assessment)
		{
			$id       	   = $assessment->courseid;
			$shortname 	   = $assessment->shortname;
			$fullname  	   = $assessment->coursename;
			$idnumber  	   = $assessment->idnumber;
			$visible   	   = $assessment->visible;
			$summary   	   = $assessment->summary;
			$summaryformat = $assessment->summaryformat;
			$format        = $assessment->format;
			$showgrades    = $assessment->showgrades;
			$lang          = $assessment->lang;
			$enablecompletion = $assessment->enablecompletion;
			$category  = $assessment->category;
			$startdate = $assessment->startdate;
			$enddate   = $assessment->enddate;
			$url       = $CFG->wwwroot.'/course/view.php?id='.$id;	
			
			$checkenrollmentmethods = $DB->get_records_sql('SELECT * FROM {enrol} WHERE courseid = ?',array($id));
			foreach ($checkenrollmentmethods as $key => $checkenrollmentmethod)
			{
				$enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($checkenrollmentmethod->id,$USER->id));
				if(!empty($enrollmentdate))
				{
					$courseenrollmentdate = $enrollmentdate->timecreated;
					$enrolenddate = $enrollmentdate->timeend;
				}                                
			}
			// here we are checking assessment within course only
			if(!$DB->record_exists('quiz', array('course' => $id)))
			{
				$sql_scorm = $DB->get_records_sql("SELECT * FROM {scorm} s JOIN {scorm_scoes_track} sst ON sst.scormid = s.id WHERE s.course = ? AND sst.userid = ?",array($id,$USER->id));
				if(empty($sql_scorm))
				{
					$progress = "Not Started";
				}
				else
				{
					$progress = "Incomplete";
				}
			}
			else
			{
				$quizrecord  = $DB->get_record('quiz', array('course' => $id));
				$quizattempt = $DB->get_field('quiz', 'attempts', array('course' => $id));
				$modid = $DB->get_field('modules', 'id', array('name' => 'quiz'));
				$cmid  = $DB->get_field('course_modules', 'id', array('course' => $id, 'module' => $modid,'instance' => $quizrecord->id));	
				// Here we are checking user latest attempt //
				$user_attempts = $DB->get_record_sql('SELECT MAX(attempt) as user_max_attempt FROM {quiz_attempts} WHERE quiz = '.$quizrecord->id.' AND userid= '.$USER->id.'');
				$latestattempt = $user_attempts->user_max_attempt;
				// if the date passed 								
				$attempstatus = $DB->get_field('quiz_attempts','state',array('quiz' =>$quizrecord->id, 'userid' => $USER->id,'attempt' => $latestattempt));
				if(empty($attempstatus)) 
				{
					if($enrolenddate > time()) 
					{
						$progress = "Expired";
					}
					else
					{
						$progress = "Not Started";
					}
				}
				else
				{
					/// here we are checking user grade of latest attempt ///
					$sumgrade = $DB->get_field('quiz_attempts', 'sumgrades', array('quiz' => $quizrecord->id, 'userid' => $USER->id,'attempt' => $latestattempt));
					//here we are checking the user //
					$passgrade = $DB->get_field('grade_items', 'gradepass', array('courseid' => $id,'iteminstance' => $quizrecord->id, 'itemmodule' => 'quiz'));
					
					if($sumgrade >= $passgrade)
					{
						$progress = "Completed";
					}
					else
					{
						$progress = "Incomplete";
					}	
				}
			}		
			$result[] = array(
				'id' => $id,
				'shortname' => $shortname,
				'fullname'  => $fullname,
				'idnumber'  => $idnumber,
				'visible'   => $visible,
				'summary'   => $summary,
				'summaryformat' => $summaryformat,
				'format' => $format,
				'showgrades' => $showgrades,
				'lang' => $lang,
				'enablecompletion' => $enablecompletion,
				'category' => $category,
				'progress' => $progress,
				'startdate' => $startdate,
				'enddate' => $enddate,
				'enroldate' => $courseenrollmentdate,
				'enrolenddate' => $enrolenddate,
				'url' => $url
			);
		}
		
		if(empty($result))
		{
			$result[] = array();
		}
		return $result;
    }
	
	public static function get_final_assessments_returns() 
	{
		return new external_multiple_structure(
            new external_single_structure(
                array(
                    'id'        => new external_value(PARAM_RAW, 'id of course',VALUE_OPTIONAL),
                    'shortname' => new external_value(PARAM_RAW, 'short name of course',VALUE_OPTIONAL),
                    'fullname'  => new external_value(PARAM_RAW, 'long name of course',VALUE_OPTIONAL),
                    'idnumber'  => new external_value(PARAM_RAW, 'id number of course',VALUE_OPTIONAL),
                    'visible'   => new external_value(PARAM_RAW, '1 means visible, 0 means hidden course',VALUE_OPTIONAL),
                    'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
                                                                VALUE_OPTIONAL),
                    'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate' => new external_value(PARAM_INT, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_INT, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'url' => new external_value(PARAM_RAW,'assessment url', VALUE_OPTIONAL),
                )
            )
        );
	}
	
	/***************************************************************************************/
	
	
    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_mytrainings_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function get_mytrainings($welcomemessage = 'Hello world, ') {
        global $USER, $DB, $CFG;
        //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::get_myprofile_parameters(), array('welcomemessage' => $welcomemessage));

        //Context validation
        //OPTIONAL but in most web service it should present
        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);
        /*
          //Capability checking
          //OPTIONAL but in most web service it should present
          if (!has_capability('moodle/user:viewdetails', $context)) {
          throw new moodle_exception('cannotviewprofile');
          } */
      /*  $trainings = $DB->get_records_sql("
            SELECT b.trgtitle, c.trgtype, DATE_FORMAT(a.trgfromdt,'%D %b %y')as startdate,DATE_FORMAT(a.trgfromdt,'%h:%i %p') as starttime, DATE_FORMAT(a.trgtodt,'%D %b %y')as enddate,DATE_FORMAT(a.trgtodt,'%h:%i %p')as endtime, f.trgdate, d.preasmtscore, d.postasmtscore, d.trgfbkscore
            FROM hmiltp_tms_trainingdetail a
            inner join hmiltp_tms_trainingmaster b
            on b.trgid=a.trgid
            inner join hmiltp_tms_trgtypemaster c
            on c.trgtypecode=a.trgtypecode
            left join hmiltp_tms_trgenrollments d
            on d.trgscheduleid=a.trgscheduleid
            left join hmiltp_user e
            on d.empcode=e.username and e.username=d.empcode
            left join hmiltp_tms_trgattendance f
            on  f.trgscheduleid=a.trgscheduleid and e.username=f.empcode
            where e.id=?
            AND d.status = 2
            order by a.trgfromdt desc limit 5;", array($USER->id));
        //die(print_object($trainings));
        $result = array();
        foreach ($trainings as $training) {*/
            $subresult = new stdClass();
            $subresult->name = 'HStep1 Chassis';
            $subresult->type = 'Certification';
            $subresult->startdate = '28/07/2018';
            $subresult->enddate = '31/07/2018';
            $subresult->starttime = '8:00 AM';
            $subresult->endtime = '9:00 PM';
            $subresult->status = 'Scheduled';
            $subresult->presentdate = "N/A";
            $subresult->score = "N/A";
            $subresult->feedback = "N/A";

            //		die(print_object($subresult));
            $result[] = $subresult;
            $subresult = new stdClass();
            $subresult->name = 'HStep2 Chassis';
            $subresult->type = 'Certification';
            $subresult->startdate = '28/11/2017';
            $subresult->enddate = '31/08/2018';
            $subresult->starttime = '8:00 AM';
            $subresult->endtime = '9:00 PM';
            $subresult->status = 'Present';
            $subresult->presentdate = "N/A";
            $subresult->score = "20";
            $subresult->feedback = "Pass";
            //		die(print_object($subresult));
            $result[] = $subresult;

        /*}*/
        //die(print_object($result));
        //echo $query;
        return $result;
        // return $params['welcomemessage'] . $USER->firstname .$coursename;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_mytrainings_returns() {
        return new external_multiple_structure(
                new external_single_structure(
                array(
            'name' => new external_value(PARAM_TEXT, 'name of training'),
            'type' => new external_value(PARAM_TEXT, 'Type of training'),
            'startdate' => new external_value(PARAM_TEXT, 'Start date of the training'),
            'enddate' => new external_value(PARAM_TEXT, 'End date of the training'),
            'starttime' => new external_value(PARAM_TEXT, 'Start time of the training'),
            'endtime' => new external_value(PARAM_TEXT, 'End time of the training'),
            'status' => new external_value(PARAM_TEXT, 'Status'),
            'presentdate' => new external_value(PARAM_TEXT, 'Employee Present for training'),
            'score' => new external_value(PARAM_TEXT, 'score'),
            'feedback' => new external_value(PARAM_TEXT, 'Feedback'),
                )
                )
        );
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_mycourses_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function get_mycourses($welcomemessage = 'Hello world, ')
	{
		/*global $USER, $DB ,$CFG;
        $courses = enrol_get_users_courses($USER->id, false, 'id, shortname, fullname, idnumber, visible,
                   summary, summaryformat, format, showgrades, lang, enablecompletion, category, startdate, enddate');
       
        foreach ($courses as $key => $course) {
        
          if($course->category == 3){
			if($course->visible == 1){
					 $checkenrollmentmethods = $DB->get_records_sql('SELECT * FROM {enrol} WHERE courseid = ?',array($course->id));
				
					foreach ($checkenrollmentmethods as $key => $checkenrollmentmethod) {
					$enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($checkenrollmentmethod->id,$USER->id));
					
						if(!empty($enrollmentdate)){
							$courseenrollmentdate = $enrollmentdate->timecreated;
							$enrolenddate = $enrollmentdate->timeend;
						}                                
					}
					$progress = null;
				  
				
					$pro = null;
					if ($course->enablecompletion)
					{
						$pro = \core_completion\progress::get_course_progress_percentage($course);
						if($pro == 100)
						{
							$progress = "Completed";
						}
						else
						{
							$sql_scorm = $DB->get_records_sql("SELECT * FROM {scorm} s JOIN {scorm_scoes_track} sst ON sst.scormid = s.id WHERE s.course = ? AND sst.userid = ?",array($course->id,$USER->id));
							if(empty($sql_scorm))
							{
								$progress = "Not Started";
							}
							else
							{
								$progress = "Incomplete";
							}
						}
					}
					$url = $CFG->wwwroot.'/course/view.php?id='.$course->id;
					$result[] = array(
						'id' => $course->id,
						'shortname' => $course->shortname,
						'fullname' => $course->fullname,
						'idnumber' => $course->idnumber,
						'visible' => $course->visible,
						'summary' => $course->summary,
						'summaryformat' => $course->summaryformat,
						'format' => $course->format,
						'showgrades' => $course->showgrades,
						'lang' => clean_param($course->lang, PARAM_LANG),
						'enablecompletion' => $course->enablecompletion,
						'category' => $course->category,
						'progress' => $progress,
						'startdate' => $course->startdate,
						'enddate' => $course->enddate,
						'enroldate' => $courseenrollmentdate,
						'enrolenddate' => $enrolenddate,
						'url' => $url,
					);
			}
           }
          }
           if(empty($result)){
            $result[] = array();
          }
          return $result;*/
		global $USER, $DB ,$CFG;
		$onlinecourses = $DB->get_records_sql("select
				c.id as courseid,
				c.fullname as coursename,
				c.summary as summary,
				c.shortname as shortname,
				c.idnumber as idnumber,
				c.visible as visible,
				c.summaryformat as summaryformat,
				c.format,
				c.showgrades,
				c.lang,
				c.enablecompletion,
				c.category,
				b.path,
				c.startdate,
				c.enddate,
				(
				  select count(sa.id) as totalscorms
						from mdl_scorm_scoes as sa
						inner join mdl_scorm as sb ON(sb.id=sa.scorm)
						where sb.course=c.id and sa.scormtype='sco'
				) as totalscorms,
				(
				  select count(sa.id) as totaltracked
						FROM mdl_scorm_scoes_track as sa
						INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
						INNER JOIN mdl_course as sc on (sc.id=sb.course)
						WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='completed' || value='passed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
				) as totalcompleted,
				(
				  select count(sa.id) as totaltracked
						FROM mdl_scorm_scoes_track as sa
						INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
						INNER JOIN mdl_course as sc on (sc.id=sb.course)
						WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='incomplete' || value='failed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
				) as totalincomplete,
			  'duedate',
			  (SELECT timestart FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol  where courseid=c.id and enrol='manual') AND userid=a.userid) as courseenrollmentdate,
			  (SELECT timeend FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol where courseid=c.id and enrol='manual') AND userid=a.userid) as enrolenddate

			  FROM mdl_role_assignments  as a
			  INNER JOIN mdl_context     as b on(b.id=a.contextid)
			  INNER JOIN mdl_course      as c on(c.id=b.instanceid)
			  left outer join mdl_user   as d on(d.id=a.userid)
			  INNER JOIN mdl_course_categories as e on(e.id=c.category)
			  where b.contextlevel = 50 and userid = '".$USER->id."' and c.visible=1 and c.category>0 and e.name<>'assessment container' group by c.id ORDER BY c.id DESC");
			foreach ($onlinecourses as $onlinecourse) 
		    {
				    $id        = $onlinecourse->courseid;
				    $shortname = $onlinecourse->shortname;
					$fullname  = $onlinecourse->coursename;
					$idnumber  = $onlinecourse->idnumber;
					$visible   = $onlinecourse->visible;
					$summary   = $onlinecourse->summary;
					$summaryformat = $onlinecourse->summaryformat;
					$format     = $onlinecourse->format;
					$showgrades = $onlinecourse->showgrades;
					$lang       = $onlinecourse->lang;
					$enablecompletion = $onlinecourse->enablecompletion;
					$category  = $onlinecourse->category;
					
					$startdate = $onlinecourse->startdate;
					$enddate   = $onlinecourse->enddate;
					$enroldate = $onlinecourse->courseenrollmentdate;
					$enrolenddate = $onlinecourse->enrolenddate;
					//$url       = $CFG->wwwroot.'/course/view.php?id='.$id;
					$progress = '';
					if($id == 12)
					{	
						$sqlass = $DB->get_record_sql("SELECT quiz.id as quizid,
						quiz.course,
						grade_items.id,
						grade_items.grademax,
						grade_items.grademin,
						grade_items.gradepass,
						grade_items.itemmodule
						FROM mdl_quiz AS quiz 
						INNER JOIN mdl_grade_items AS grade_items 
						ON grade_items.iteminstance = quiz.id
						WHERE quiz.course= '12' AND 
						quiz.id = '24' AND 
						grade_items.itemmodule = 'quiz'");
						$quizid     = $sqlass->quizid;
						$grademax   = $sqlass->grademax;
						$grademin   = $sqlass->grademin;
						$gradepass  = $sqlass->gradepass;
						
						$highestattempt = $DB->get_record_sql("SELECT max(attempt) as hattempt FROM mdl_quiz_attempts WHERE quiz = '".$quizid."' AND userid = '".$USER->id."'");
						$attempt = $highestattempt->hattempt;
						if(!empty($attempt))
						{	
							$sqlGrade = $DB->get_record_sql("SELECT sumgrades,timefinish FROM mdl_quiz_attempts WHERE quiz = '".$quizid."' AND userid = '".$USER->id."' AND state = 'finished' AND attempt = '".$attempt."'");
							$resGrade  = $sqlGrade->sumgrades;
							if($resGrade >= $gradepass)
							{
								$state1 = 'pass';
							}	
							else
							{
								$state1 = 'fail';
							}
							if($state1 == 'pass')
							{
								$progress = 'Completed';
								$url       = $CFG->wwwroot.'/course/courseview.php?id='.$id;
								
							}		
							if($state1 == 'fail') 
							{
								$progress = 'Incomplete';
								$url       = $CFG->wwwroot.'/course/view.php?id='.$id;
						
							}
						}
						else
						{
							$sql="SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = '10' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') ";
							$attemptdetails = $DB->get_record_sql($sql);
							if(empty($attemptdetails->value) || $attemptdetails->value == "")
							{
								$progress = 'Not Started';
								$url      = $CFG->wwwroot.'/course/view.php?id='.$id;
							}
							else
							{
								$progress = 'Incomplete';
								$url       = $CFG->wwwroot.'/course/view.php?id='.$id;
						
							}
						}	
					}
					else
					{
						$sqlScormid = $DB->get_record_sql("SELECT * FROM mdl_scorm WHERE course = '".$id."'");
						$courseContext = context_course::instance($id);
						$checkTag = $DB->get_record_sql('select t.id from {tag} t JOIN {tag_instance} ti ON t.id = ti.tagid WHERE ti.itemtype = ? AND ti.contextid = ? AND t.name =?',array('course',$courseContext->id,'learning_path' ));

						$scormid = $sqlScormid->id;
						$isLearningPathCourse = false;
						if(!empty($checkTag)){
							$module = $DB->get_record_sql('SELECT instance as id FROM {course_modules} where course = ? order by  id desc',array($id));
							$scormid = $module->id;
							$isLearningPathCourse = true;
						}
						
						
						$sqlScormTrack = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = ".$scormid." AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') order by sb.attempt DESC LIMIT 1";
						$resultScormTrack = $DB->get_record_sql($sqlScormTrack);
						if(empty($resultScormTrack->value) || $resultScormTrack->value == "")
						{
							$progress = "Not Started";
							if($isLearningPathCourse){
									$sql="SELECT * FROM mdl_user_lastaccess where userid=".$USER->id." and courseid=".$id."";
									$cStatus = $DB->get_record_sql($sql);
									if(!empty($cStatus)){
										$progress = 'Incomplete';
									}
							}
							
							$url       = $CFG->wwwroot.'/course/view.php?id='.$id;
						}
						else
						{
							// todays changes by yogita - 07-03-2020
							//--------------------------------------------------//
							//NEED TO RESTRUCTURE WEBSERVICE 
							$total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '".$USER->id."' AND sb.scormid = '".$scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status')");
							$i = 1;
							foreach($total_attempt as $val)
							{
								if($val->value == 'completed' || $val->value == 'passed')
								{
									$progress = "Completed";
									$url      = $CFG->wwwroot.'/course/courseview.php?id='.$id;
									break;
								}
								else
								{
									$progress = "Incomplete";
									$url      = $CFG->wwwroot.'/course/view.php?id='.$id;
								}
								if($val->attempt >=3)
								{
									$progress = "Completed";
									$url = $CFG->wwwroot.'/course/courseview.php?id='.$id;
								}
								$i++;
							}
							/* $attempt = $total_attempt->attempt;
							//---------------------------------------------------//
							$status =  $resultScormTrack->value;
							if($status == 'completed' || $status == 'passed')
							{
								$progress = "Completed";
								$url      = $CFG->wwwroot.'/course/courseview.php?id='.$id;
							}
                            if($status == 'incomplete' || $status == 'failed')
							{
								$progress = "Incomplete";
								$url      = $CFG->wwwroot.'/course/view.php?id='.$id;
							}
							//-----------------------------------------//
							if($attempt >=3)
							{
								$progress = "Completed";
								$url = $CFG->wwwroot.'/course/courseview.php?id='.$id;
							} */
							//----------------------------------------//	
						}
					}	
					
					
					$result[] = array(
						'id' => $id,
						'shortname' => $shortname,
						'fullname'  => $fullname,
						'idnumber'  => $idnumber,
						'visible'   => $visible,
						'summary'   => $summary,
						'summaryformat' => $summaryformat,
						'format' => $format,
						'showgrades' => $showgrades,
						'lang' => $lang,
						'enablecompletion' => $enablecompletion,
						'category' => $category,
						'progress' => $progress,
						'startdate' => $startdate,
						'enddate' => $enddate,
						'enroldate' => $enroldate,
						'enrolenddate' => $enrolenddate,
						'url' => $url
					);
				   
		    }
			if(empty($result))
			{
				$result[] = array();
			}
			return $result;	 
	}

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_mycourses_returns() {
        return new external_multiple_structure(
                new external_single_structure(
                array(
          
                  'id'        => new external_value(PARAM_INT, 'id of course', VALUE_OPTIONAL),
                    'shortname' => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
                    'fullname'  => new external_value(PARAM_RAW, 'long name of course', VALUE_OPTIONAL),
                    'idnumber'  => new external_value(PARAM_RAW, 'id number of course', VALUE_OPTIONAL),
                    'visible'   => new external_value(PARAM_INT, '1 means visible, 0 means hidden course', VALUE_OPTIONAL),
                    'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',
                                                                VALUE_OPTIONAL),
                    'category' => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress' => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate' => new external_value(PARAM_INT, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate' => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_INT, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'url' => new external_value(PARAM_RAW,'course url', VALUE_OPTIONAL),
                )
                )
        );
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_mynotifications_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function get_mynotifications($welcomemessage = 'Hello world, ') {
        global $USER, $DB, $CFG;
		$userid = $USER->id; $emp_mspin = $USER->username;
		$newresult = array();
		//OLD 
		//$notifations = $DB->get_records_sql("SELECT * FROM {ums_notifications} WHERE deleted = 0 ORDER BY id desc");
		
		/* VALID changed on 23Sept2019 */
		$notifations = $DB->get_records_sql("SELECT n.* FROM mdl_ums_notifications as n LEFT JOIN mdl_ums_user_notification as un ON n.id = un.notificationid WHERE n.deleted = 0 AND un.deleted = 0 AND un.mspin = '".$emp_mspin."' AND un.userid = '".$userid."' AND un.is_processed = 2 GROUP BY un.notificationid ORDER BY n.updated_date DESC");
		
		foreach ($notifations as $key => $notifation) {
		 
			$result = new stdClass();
			$result->notifid = $notifation->id;
			$result->name = $notifation->n_title;
			$result->description =  $notifation->n_description; 
			$result->date =  $notifation->updated_date; //$notifation->inserted_date; 
			$result->urlname =  $notifation->n_url;
			$result->urltype =  $notifation->n_url_type;
			$newresult[]=$result;

		}
		return $newresult;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_mynotifications_returns() {
        return new external_multiple_structure(
                new external_single_structure(
                array(
			'notifid' => new external_value(PARAM_INT, 'id of Notification'),
            'name' => new external_value(PARAM_TEXT, 'name of Notification'),
            'description' => new external_value(PARAM_RAW, 'Description of notification'),
            'date' => new external_value(PARAM_TEXT, 'Date of notification'),
            'urlname' => new external_value(PARAM_RAW, 'URL of notification'),
            'urltype' => new external_value(PARAM_RAW, 'URLType of notification'),
                )
                )
        );
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */

    public static function get_hello_world_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    public static function get_hello_world() {
        global $USER, $DB;
        $params = self::validate_parameters(self::get_myprofile_parameters(), array('welcomemessage' => $welcomemessage));

        $context = get_context_instance(CONTEXT_USER, $USER->id);
        self::validate_context($context);

        $profile = array('first' => "Firstapp");
        return $profile;
    }

    public static function get_hello_world_returns() {
        return new external_single_structure(
                array(
            'first' => new external_value(PARAM_TEXT, 'Our First App')
                )
        );
    }

   
     public static function get_myperf_assessments_parameters() {

           return new external_function_parameters(
                   array()
           );
       }


         /**
        * Returns welcome message
        * @return string welcome message
        */
       public static function get_myperf_assessments($welcomemessage = 'Hello world, ') {
           global $USER,$DB,$CFG;
           //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
           //Parameter validation
           //REQUIRED
           $params = self::validate_parameters(self::get_myprofile_parameters(),
                   array('welcomemessage' => $welcomemessage));

           //Context validation
           //OPTIONAL but in most web service it should present
           $context = get_context_instance(CONTEXT_USER, $USER->id);
           self::validate_context($context);
           /*
           //Capability checking
           //OPTIONAL but in most web service it should present
           if (!has_capability('moodle/user:viewdetails', $context)) {
               throw new moodle_exception('cannotviewprofile');
           }*/
       $result = array();
          $userid = $USER->id;
           $assessmentslm = $DB->get_records_sql('select c.id from {role_assignments} as a
          Inner join {context} as b on(b.id = a.contextid)
          Inner join {course} as c on(c.id = b.instanceid) where a.userid= ?
            AND c.category = ?
          AND a.timemodified <= ? AND a.timemodified >= ?',array($userid,2,time(),time() - (30 * 24 * 60 * 60)));

           // print_r($assessmentslm);
           

      $assessmentcountlm = 0;
      $assessmentlmpass  = 0;
      $assessmentlmappeared = 0;
      foreach($assessmentslm as $assessment) {
        $assessmentcountlm++;
        $quizrecord = $DB->get_record('quiz',array('course'=>$assessment->id));
        //echo "Quiz id is ".$quizrecord->id;
        $attemptstatus = $DB->get_field('quiz_attempts','state',array('quiz'=>$quizrecord->id,'userid'=>$userid,'attempt'=>1));
         if(empty($attemptstatus)) {

            }
            else {
              $sumgrade = $DB->get_field('quiz_attempts','sumgrades',array('quiz'=>$quizrecord->id,'userid'=>$userid,'attempt'=>1));
              $passgrade = $DB->get_field('grade_items','gradepass',array('courseid'=>$assessment->id,'iteminstance'=>$quizrecord->id,'itemmodule'=>'quiz'));
              if($sumgrade >= $passgrade){
                $assessmentlmpass++;
                $assessmentlmappeared++;
              }
              else {
                $assessmentlmappeared++;
              }
            }
      }


      $assessments3lm = $DB->get_records_sql('select c.id from {role_assignments} as a
              Inner join {context} as b on(b.id = a.contextid)
              Inner join {course} as c on(c.id = b.instanceid) where a.userid= ?
              AND c.category = ?
              AND a.timemodified <= ? AND a.timemodified >= ?',array($userid,31,time(),time() - (3 * 30 * 24 * 60 * 60)));
      $assessmentcount3lm = 0;
      $assessment3lmpass  = 0;
      $assessment3lmappeared = 0;
      foreach($assessments3lm as $assessment) {
        $assessmentcount3lm++;
        $quizrecord = $DB->get_record('quiz',array('course'=>$assessment->id));
        $attemptstatus = $DB->get_field('quiz_attempts','state',array('quiz'=>$quizrecord->id,'userid'=>$userid,'attempt'=>1));
         if(empty($attemptstatus)) {

            }
            else {
              $sumgrade = $DB->get_field('quiz_attempts','sumgrades',array('quiz'=>$quizrecord->id,'userid'=>$userid,'attempt'=>1));
              $passgrade = $DB->get_field('grade_items','gradepass',array('courseid'=>$assessment->id,'iteminstance'=>$quizrecord->id,'itemmodule'=>'quiz'));
              if($sumgrade >= $passgrade){
                $assessment3lmpass++;
                $assessment3lmappeared++;
              }
              else {
                $assessment3lmappeared++;
              }
            }
      }




      $assessments6lm = $DB->get_records_sql('select c.id from {role_assignments} as a
              Inner join {context} as b on(b.id = a.contextid)
              Inner join {course} as c on(c.id = b.instanceid) where a.userid= ?
              AND c.category = ?
              AND a.timemodified <= ? AND a.timemodified >= ?',array($userid,31,time(),time() - (6 * 30 * 24 * 60 * 60)));
      $assessmentcount6lm = 0;
      $assessment6lmpass  = 0;
      $assessment6lmappeared = 0;
      foreach($assessments6lm as $assessment) {
        $assessmentcount6lm++;
        $quizrecord = $DB->get_record('quiz',array('course'=>$assessment->id));
        $attemptstatus = $DB->get_field('quiz_attempts','state',array('quiz'=>$quizrecord->id,'userid'=>$userid,'attempt'=>1));
         if(empty($attemptstatus)) {

            }
            else {
              $sumgrade = $DB->get_field('quiz_attempts','sumgrades',array('quiz'=>$quizrecord->id,'userid'=>$userid,'attempt'=>1));
              $passgrade = $DB->get_field('grade_items','gradepass',array('courseid'=>$assessment->id,'iteminstance'=>$quizrecord->id,'itemmodule'=>'quiz'));
              if($sumgrade >= $passgrade){
                $assessment6lmpass++;
                $assessment6lmappeared++;
              }
              else {
                $assessment6lmappeared++;
              }
            }
      }

        $subresult = new stdClass();
        $subresult->time = 'Last Month';
        $subresult->numassessments = $assessmentcountlm;
        $subresult->appeared = $assessmentlmappeared;
              $subresult->passed = $assessmentlmpass;
              $result[] = $subresult;
        $subresult = new stdClass();
        $subresult->time = 'Last 3 Months';
        $subresult->numassessments = $assessmentcount3lm;
        $subresult->appeared = $assessment3lmappeared;
              $subresult->passed = $assessment3lmpass;
              $result[] = $subresult;
              $subresult = new stdClass();
        $subresult->time = 'Last 6 Months';
        $subresult->numassessments = $assessmentcount6lm;
        $subresult->appeared = $assessment6lmappeared;
              $subresult->passed = $assessment6lmpass;
        $result[] = $subresult;
              $subresult = new stdClass();
        $subresult->time = 'Calendar Year';
        $subresult->numassessments = $assessmentcount6lm;
        $subresult->appeared = $assessment6lmappeared;
              $subresult->passed = $assessment6lmpass;
              $result[] = $subresult;
         return $result;


       }
       /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_myperf_assessments_returns() {
       return new external_multiple_structure(
            new external_single_structure(
                 array(
                    'time' => new external_value(PARAM_TEXT, 'time duration'),
          'numassessments' => new external_value(PARAM_TEXT, 'Total number of assessments assigned'),
          'appeared' => new external_value(PARAM_TEXT, 'Number of assessments appeared'),
          'passed' => new external_value(PARAM_TEXT, 'Number of assessments passed'),
                )
            )
        );

    }

      /**
        * Returns description of method parameters
        * @return external_function_parameters
        */
       public static function get_myperf_courses_parameters() {

           return new external_function_parameters(
                   array()
           );
       }


         /**
        * Returns welcome message
        * @return string welcome message
        */
       public static function get_myperf_courses($welcomemessage = 'Hello world, ') {
           global $USER,$DB,$CFG;
           //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
           //Parameter validation
           //REQUIRED
           $params = self::validate_parameters(self::get_myprofile_parameters(),
                   array('welcomemessage' => $welcomemessage));

           //Context validation
           //OPTIONAL but in most web service it should present
           $context = get_context_instance(CONTEXT_USER, $USER->id);
           self::validate_context($context);
           /*
           //Capability checking
           //OPTIONAL but in most web service it should present
           if (!has_capability('moodle/user:viewdetails', $context)) {
               throw new moodle_exception('cannotviewprofile');
           }*/


           $onlinecourses=$DB->get_records_sql("select
      c.id as courseid,
      c.fullname as coursename,
      c.summary as summary,
      b.path,
      a.timemodified as enrolldate,
      (
        select count(sa.id) as totalscorms
          from {scorm_scoes} as sa
          inner join {scorm} as sb ON(sb.id=sa.scorm)
          where sb.course=c.id and sa.scormtype='sco'
      ) as totalscorms,
      (
        select count(sa.id) as totaltracked
          FROM {scorm_scoes_track} as sa
          INNER JOIN {scorm} as sb on (sb.id=sa.scormid)
          INNER JOIN {course} as sc on (sc.id=sb.course)
          where sa.element='cmi.core.lesson_status' and (value='completed' OR value='passed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
      ) as totalcompleted,
      (
        select count(sa.id) as totaltracked
          FROM {scorm_scoes_track} as sa
          INNER JOIN {scorm} as sb on (sb.id=sa.scormid)
          INNER JOIN {course} as sc on (sc.id=sb.course)
          where sa.element='cmi.core.lesson_status' and value='incomplete' AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
      ) as totalincomplete,
      'duedate',
      (SELECT timestart FROM {user_enrolments} where enrolid=(select id from {enrol}  where courseid=c.id and enrol='manual') AND userid=a.userid) as timestart,
      (SELECT timeend FROM {user_enrolments} where enrolid=(select id from {enrol}  where courseid=c.id and enrol='manual') AND userid=a.userid) as timeend

    from {role_assignments}  as a
    inner join {context}     as b on(b.id=a.contextid)
    inner join {course}      as c on(c.id=b.instanceid)
    left outer join {user}   as d on(d.id=a.userid)
    inner join {course_categories} as e on(e.id=c.category)
    where b.contextlevel = 50 and userid=?  and c.visible=1 and (category<>0 and e.name<>'assessment container' and e.name<>'polls') order by a.timemodified desc",array($USER->id));

            $result = array();
            $countcourses = 0;
            $countcompleted = 0;
            // print_r($onlinecourses);
            // die;
            foreach($onlinecourses as $onlinecourse) {
        $countcourses++;
        $subresult = new stdClass();
        $subresult->courseid = $onlinecourse->courseid;
        $subresult->name = $onlinecourse->coursename;
        $status = "";
        $totalscorms    = $onlinecourse->totalscorms;
        $totalcompleted   = $onlinecourse->totalcompleted;
        $totalincomplete  = $onlinecourse->totalincomplete;

        $totalcompleted = $totalcompleted>$totalscorms ? $totalscorms : $totalcompleted;

        $per=0;
        if($totalscorms!=0)
        {
          $per = round(($totalcompleted*100)/$totalscorms, 2);

        }


        if($per==100)
        {
          $subresult->status='Completed';
                    $countcompleted++;
        }else if($totalcompleted==0 && $totalincomplete==0){
          $subresult->status='Not Started';
        }else{
          $subresult->status='Incomplete';
        }
        $subresult->courselink = $CFG->wwwroot."/course/view.php?id=".$onlinecourse->courseid;
        $enrolldate = isset($onlinecourse->enrolldate)?$onlinecourse->enrolldate:'0';
            $subresult->startdate = $enrolldate=='enrolldate'?'0':$enrolldate;

        $enrollenddate = $onlinecourse->timeend;
            $subresult->activetill = $enrollenddate==0 ? '-': ($enrollenddate);

      }
           $subresult = new stdClass();
           $subresult->time = 'Last Month';
           $subresult->numcourses = $countcourses;
           $subresult->completed = $countcompleted;
         $result[] = $subresult;
                      $subresult = new stdClass();
           $subresult->time = 'Last 3 Months';
           $subresult->numcourses = $countcourses;
           $subresult->completed = $countcompleted;
         $result[] = $subresult;
                      $subresult = new stdClass();
           $subresult->time = 'Last 6 Months';
           $subresult->numcourses = $countcourses;
           $subresult->completed = $countcompleted;
         $result[] = $subresult;
                      $subresult = new stdClass();
           $subresult->time = 'Calendar Year';
           $subresult->numcourses = $countcourses;
           $subresult->completed = $countcompleted;
         $result[] = $subresult;

           return $result;


       }
       /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_myperf_courses_returns() {
       return new external_multiple_structure(
            new external_single_structure(
                 array(
                    'time' => new external_value(PARAM_TEXT, 'time duration'),
                    'numcourses' => new external_value(PARAM_INT,'number of courses assigned'),
                    'completed' => new external_value(PARAM_INT,'number of completed courses')

                )
            )
        );

    }


   /**
        * Returns description of method parameters
        * @return external_function_parameters
        */
       public static function get_videos_parameters() {

           return new external_function_parameters(
                    array('foldername' => new external_value(PARAM_RAW,'folder name'))
           );
       }


       /**
        * Returns welcome message
        * @return string welcome message
        */
public static function get_videos($foldername) {


global $USER,$DB,$CFG;

$audio_video_hub_id_sql = $DB->get_record_sql('SELECT id FROM  {data} WHERE name = "Audio Video Hub" ');
$audio_video_hub_id = $audio_video_hub_id_sql->id;
// echo $audio_video_hub_id;

$allrecords  =  $DB->get_records_sql('SELECT * FROM {data_content} WHERE content = "Video" ');
// $allrecords  =  $DB->get_records_sql('SELECT * FROM {data_content} WHERE content = "Video" ');

$filefieldid = $DB->get_record_sql('SELECT * FROM {data_fields} WHERE dataid = ? AND type = ?',array($audio_video_hub_id,'file'));
$filenamesql = $DB->get_record_sql('SELECT * FROM {data_fields} WHERE dataid = ? AND type = ?',array($audio_video_hub_id,'text'));
$dd = array();
if(!empty($allrecords)){

    foreach ($allrecords as $key => $allrecord) {

        $getcontents =  $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$allrecord->recordid.' AND content = "'.$foldername.'" ');
            // print_r($getcontents);
        if(!empty($getcontents)){

            $getfilename =  $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$allrecord->recordid.' AND fieldid = '.$filefieldid->id.' ');
            $getfiletitle = $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$allrecord->recordid.' AND fieldid = '.$filenamesql->id.' ');
            $itemid  =$getfilename->id;
            $filename = $getfilename->content;
            $result = new stdClass();
            $result->name = $getfiletitle->content ;
            $filedetails =  $DB->get_record_sql('SELECT * FROM {files} WHERE itemid = '.$itemid.' AND filename = "'.$filename.'" ');
            $fileurl = $CFG->wwwroot.'/pluginfile.php/'.$filedetails->contextid.'/mod_data/content/'.$itemid.'/'.$filename.'';
            $result->filename = $filename;
            $result->mediaurl = $fileurl;
            $newresult[]=$result;

        }else{
             $result = new stdClass();
            $result->name = "";
            $result->filename = "";
            $result->mediaurl = "";
            $dd[]=$result;
        }
      
    }
}else{
            $result = new stdClass();
            $result->name = "No data found";
            $result->filename = "";
            $result->mediaurl = "";
            $newresult[]=$result;


}
        
        if(!empty($dd)){
            $newresult[]=$result;
        }
        return $newresult;


}
       /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_videos_returns() {
       return new external_multiple_structure(
            new external_single_structure(
                array(
                    'name' => new external_value(PARAM_TEXT, 'title of the video'),
					'filename' => new external_value(PARAM_TEXT, 'Filename'),
                    'mediaurl' => new external_value(PARAM_TEXT, 'URL of the video'),
                    // 'thumbnail' => new external_value(PARAM_TEXT, 'Thumbnail'),
                    // 'duration' => new external_value(PARAM_TEXT, 'Duration'),
                )
            )
        );

    }


   /**
        * Returns description of method parameters
        * @return external_function_parameters
        */
       public static function get_audios_parameters() {

           return new external_function_parameters(
            array('foldername' => new external_value(PARAM_RAW,'folder name'))
           );
       }


       /**
        * Returns welcome message
        * @return string welcome message
        */
       public static function get_audios($foldername) {
           global $USER,$DB,$CFG;
           //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
           //Parameter validation
           //REQUIRED

$audio_video_hub_id_sql = $DB->get_record_sql('SELECT id FROM  {data} WHERE name = "Audio Video Hub" ');
$audio_video_hub_id = $audio_video_hub_id_sql->id;
// echo $audio_video_hub_id;

$allrecords  =  $DB->get_records_sql('SELECT * FROM {data_content} WHERE content = "audio" ');
$filefieldid = $DB->get_record_sql('SELECT * FROM {data_fields} WHERE dataid = ? AND type = ?',array($audio_video_hub_id,'file'));
$filenamesql = $DB->get_record_sql('SELECT * FROM {data_fields} WHERE dataid = ? AND type = ?',array($audio_video_hub_id,'text'));
$dd = array();
if(!empty($allrecords)){

    foreach ($allrecords as $key => $allrecord) {

        $getcontents =  $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$allrecord->recordid.' AND content = "'.$foldername.'" ');
            // print_r($getcontents);
        if(!empty($getcontents)){

            $getfilename =  $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$allrecord->recordid.' AND fieldid = '.$filefieldid->id.' ');
            $getfiletitle = $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$allrecord->recordid.' AND fieldid = '.$filenamesql->id.' ');
            $itemid  =$getfilename->id;
            $filename = $getfilename->content;
            $result = new stdClass();
            $result->name = $getfiletitle->content ;
            $filedetails =  $DB->get_record_sql('SELECT * FROM {files} WHERE itemid = '.$itemid.' AND filename = "'.$filename.'" ');
            $fileurl = $CFG->wwwroot.'/pluginfile.php/'.$filedetails->contextid.'/mod_data/content/'.$itemid.'/'.$filename.'';
            $result->filename = $filename;
            $result->mediaurl = $fileurl;
             $newresult[]=$result;
           


        }else{
             $result = new stdClass();
            $result->name = "";
            $result->filename = "";
            $result->mediaurl = "";
             $dd[]=$result;
        }
      
    }
}else{
            $result = new stdClass();
            $result->name = "";
            $result->filename = "";
            $result->mediaurl = "";
             $newresult[]=$result;

}
       if(!empty($dd)){
            $newresult[]=$result;
        }

        return $newresult;
   }
       /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_audios_returns() {
       return new external_multiple_structure(
            new external_single_structure(
                array(
                    'name' => new external_value(PARAM_TEXT, 'title of the video'),
                    'mediaurl' => new external_value(PARAM_TEXT, 'URL of the video'),
					// 'duration' => new external_value(PARAM_TEXT, 'Duration'),
					'filename' => new external_value(PARAM_TEXT, 'Filename')
                )
            )
        );

    }


   /**
        * Returns description of method parameters
        * @return external_function_parameters
        */
       public static function get_knowledge_parameters() {

           return new external_function_parameters(
                   array()
           );
       }


       /**
        * Returns welcome message
        * @return string welcome message
        */
       public static function get_knowledge() {
           global $USER,$DB,$CFG;
           //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
           //Parameter validation
           //REQUIRED
             global $DB;
       // $data = array();

       $records = $DB->get_records_sql("SELECT dr.id as recordid FROM {data} d JOIN {data_records} dr ON dr.dataid = d.id WHERE d.name = 'Knowledge Centre'");
       if(!empty($records)){
           // print_r($records);
           foreach ($records as $key => $record) {
               $fields = $DB->get_records_sql("SELECT df.name,df.id  FROM {data_content} dc LEFT JOIN {data_fields} df ON dc.fieldid = df.id WHERE dc.recordid = ? ",array($record->recordid));
               // print_r($fields);
               $data =array();
               foreach ($fields as $key => $field) {
                  $content = $DB->get_record_sql("SELECT content FROM {data_content} WHERE fieldid = ? AND recordid = ? ",array($field->id,$record->recordid));

                  $data[] = array($field->name => $content->content);
               }
               $getfilename12 =  $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$record->recordid.' AND fieldid = 5 ');

                    $getfilename =  $DB->get_record_sql('SELECT * FROM {data_content} WHERE recordid = '.$record->recordid.' AND fieldid = 4 ');
                    // echo $getfilename->id;
                    $itemid  =$getfilename->id;
                    $filename = $getfilename->content;
                    $filedetails =  $DB->get_record_sql('SELECT * FROM {files} WHERE itemid = '.$itemid.' AND filename = "'.$filename.'" ');
                    // echo $filename; 

                    $fileurl = $CFG->wwwroot.'/pluginfile.php/'.$filedetails->contextid.'/mod_data/content/'.$itemid.'/'.$filename.'';
                    // print_r($fileurl);
                    // die;
                    $data['url']=$fileurl; 
               $newdata[] = $data;
               // $newdata = array("data"=>$data);
               // print_r($newdata);
                  // print_r($data);

           }
       }else{
           $newdata =  array('No Data Found');

       }
     
       print_r(json_encode($newdata));
       die;

       }
       /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_knowledge_returns() {
       return new external_multiple_structure(
            new external_multiple_structure(
            new external_single_structure(
                array(
                    'name' => new external_value(PARAM_TEXT, 'Name of the file'),
                    'folder' => new external_value(PARAM_TEXT, 'Name of the folder of the file'),
                    'url' => new external_value(PARAM_TEXT, 'URL of the resource')
                )
             )
            )
        );
    }


    /**
        * Returns description of method parameters
        * @return external_function_parameters
        */
       public static function get_knowledgetabs_parameters() {

           return new external_function_parameters(
                   array('tab' => new external_value(PARAM_TEXT, 'name of the tab'))
           );
       }


       /**
        * Returns welcome message
        * @return string welcome message
        */
       public static function get_knowledgetabs($tab) {
           global $USER,$DB,$CFG;
           //$coursename = $DB->get_field('course','fullname',array('id'=>$USER->id));
           //Parameter validation
           //REQUIRED
           $params = self::validate_parameters(self::get_knowledgetabs_parameters(),
                   array('tab' => $tab));

           //Context validation
           //OPTIONAL but in most web service it should present
           $context = get_context_instance(CONTEXT_USER, $USER->id);
           self::validate_context($context);
           /*
           //Capability checking
           //OPTIONAL but in most web service it should present
           if (!has_capability('moodle/user:viewdetails', $context)) {
               throw new moodle_exception('cannotviewprofile');
           }*/


$filter = " WHERE  b.intro like '%".$tab."%' AND a.module=(SELECT id FROM {modules} where name='resource') and a.visible=1 AND c.contextlevel = 70
  AND d.component='mod_resource' and length(d.filename)>1 AND (SUBSTRING(d.filename,-3,3) not in ('mp4','mp3','flv','f4v'))
 order by d.sortorder desc ";

$resultarray = array();
$sql = "SELECT
  a.id as id,
  b.name as name,
  b.intro as intro,
  d.filename as filename,
  a.course as courseid,
  SUBSTRING_INDEX(d.filename,'.',-1)  as format,
  DATE_FORMAT(from_unixtime(a.added), '%d-%m-%Y %H:%i:%s') as addeddate,
  c.id as contextid,
  d.sortorder as sortorder,
  d.filepath as filepath

  FROM {course_modules} as a
  INNER JOIN {resource} as b ON (a.instance=b.id)
  INNER JOIN {context}  as c ON (c.instanceid=a.id)
  INNER JOIN {files}    as d ON (d.contextid=c.id) ".$filter ;

//echo $sql;

$index = 0;

$result=$DB->get_recordset_sql($sql, array());
//$result=$DB->get_records_sql($sql, array());
$mediaurl='';
$public = '';
$private = '';


$folders = array();
$folder='';
foreach($result as $rows)
{
	$folders[trim($rows->name)][] = array("filename"=>$rows->filename,
										  "id"=>$rows->id,
										  "courseid"=>$rows->courseid,
										  "format"=>$rows->format,
										  "addeddate"=>$rows->addeddate,
										  "contextid"=>$rows->contextid,
										  "sortorder"=>$rows->sortorder,
										  "filepath"=>$rows->filepath
										  );
}

foreach($folders as $key=>$value){
				$index =1;
				$content='';
				$folder = $key;
		     //  echo "<h1>".$folder."</h1>";
				$subresultarray = array();
				foreach($value as $rows){
                    $fileobj = new stdClass();
					$img_src = $CFG->wwwroot.'/mc_icons/format1/'.$rows['format'].'.png';
					$mediaurl = $CFG->wwwroot.'/mod/resource/view.php?id='.$rows['id'];
					$filename = strip_tags(explode(".",$rows['filename']));
                    $mediaurl = $CFG->wwwroot.'/webservice/pluginfile.php/'.$rows['contextid'].'/mod_resource/content/'.$rows['sortorder'].'/'.rawurlencode($rows['filename']).'?token='.$_REQUEST['wstoken'];
                   // echo $rows['filename']." - ". $mediaurl."<br/>";
                    $fileobj->name = strip_tags($rows['filename']);
                    $fileobj->folder = strip_tags($key);
                    $fileobj->url = $mediaurl;
					$subresultarray[]= $fileobj;
				}
     $resultarray[$key] = $subresultarray;

}
           //die(print_object(json_encode($resultarray)));
           return $resultarray;


       }
       /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_knowledgetabs_returns() {
       return new external_multiple_structure(
            new external_multiple_structure(
            new external_single_structure(
                array(
                    'name' => new external_value(PARAM_TEXT, 'Name of the file'),
                    'folder' => new external_value(PARAM_TEXT, 'Name of the folder of the file'),
                    'url' => new external_value(PARAM_TEXT, 'URL of the resource')
                )
             )
            )
        );
    }


   /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_tabs_parameters() {

        return new external_function_parameters(
                array()
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function get_tabs() {
        global $USER,$DB;

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::get_tabs_parameters(),
                array());



        $filter = " WHERE  a.module=(SELECT id FROM {modules} where name='resource') and a.visible=1 AND c.contextlevel = 70
  AND d.component='mod_resource' and length(d.filename)>1 AND (SUBSTRING(d.filename,-3,3) not in ('mp4','mp3','flv','f4v'))
  and b.intro  in ('Facility','Awards','Body n Paint','Initial Quality Service (IQS)','Periodic Maintenance Schedule(PMS)') order by d.sortorder desc ";

$resultarray = array();
$sql = "SELECT
  DISTINCT b.intro as intro


  FROM {course_modules} as a
  INNER JOIN {resource} as b ON (a.instance=b.id)
  INNER JOIN {context}  as c ON (c.instanceid=a.id)
  INNER JOIN {files}    as d ON (d.contextid=c.id) ".$filter;

        $results = $DB->get_records_sql($sql);
        foreach($results as $record)
        {
            $subresult = new stdClass();
            $subresult->name = strip_tags($record->intro);
            $resultarray[] = $subresult;
        }
        return $resultarray;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function get_tabs_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
                    'name' => new external_value(PARAM_TEXT, 'Name of the tabs')
                )
             )
        );
    }

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function update_password_parameters() {

        return new external_function_parameters(
                array('password' => new external_value(PARAM_TEXT, 'New password to be updated'))
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function update_password($password) {
        global $USER,$DB;

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::update_password_parameters(),
                array('password' => $password));


       // die('Farhan');
        $id = $USER->id;
        $DB->execute("UPDATE {ums_employeemaster} SET password = '".$password."' WHERE userid = ".$id);
		$hashedpassword = hash_internal_user_password($password);
		//if($moodleregid){
			$DB->set_field('user','password', $hashedpassword, array('id'=>$id));

		//}
		$rtn = array();
		$rtn['status'] = 'TRUE';
        return $rtn;
    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function update_password_returns() {
         return new external_single_structure (
                   array (
                       'status'=>new external_value(PARAM_TEXT, 'true or false')

                   )
                );
    }

 public static function knowledgecenter_parentfolders_parameters(){
        return new external_function_parameters(
            array()
        );

    }

    public static function knowledgecenter_parentfolders(){
        global $DB;
      
         $folders = $DB->get_records_sql('SELECT * FROM {ums_knc_folder} WHERE parent_id = 0 ORDER BY folder ASC');
         $mainfolder = array();
          foreach ($folders as $key => $folder) { 
            $alldd['folders'][] = array('folderid'=>$folder->id,'foldername'=>$folder->folder);
           }
            $aa=$alldd;
 
  
           
            return($aa);
    }


     public static function knowledgecenter_parentfolders_returns(){
         return new external_single_structure(
                array(
                    
                     'folders' => new external_multiple_structure(
                                new external_single_structure(
                                              array(
                            'folderid'=>new external_value(PARAM_INT,'folderid'),

                            'foldername'=>new external_value(PARAM_RAW,'foldername'),

                           
                    ))),
                      

                )
            );

        

     }

     public static function knowledgecenter_subfolders_parameters(){
        return new external_function_parameters(
            array(
              'id' => new external_value(PARAM_INT,'folderid')
            )

        );

    }

    public static function knowledgecenter_subfolders($id){
        global $DB;
       
         #$folders = $DB->get_records('ums_knc_folder',array('parent_id'=>$id));
         $folders = $DB->get_records_sql('SELECT * FROM {ums_knc_folder} WHERE parent_id = '.$id.' ORDER BY folder ASC');
         $mainfolder = array();
         if(!empty($folders)){
          foreach ($folders as $key => $folder) { 
            $alldd['subfolders'][] = array('folderid'=>$folder->id,'foldername'=>$folder->folder);
           }
         }else{
             $alldd['subfolders'][] = array('folderid'=>null,'foldername'=>null);
         }
            $aa=$alldd;
            // print_r($aa);
 
  
           
            return($aa);
    }


     public static function knowledgecenter_subfolders_returns(){
         return new external_single_structure(
                array(
                    
                     'subfolders' => new external_multiple_structure(
                                new external_single_structure(
                                              array(
                            'folderid'=>new external_value(PARAM_INT,'folderid'),

                            'foldername'=>new external_value(PARAM_RAW,'foldername'),

                           
                    ))),
                      

                )
            );

        

     }


        public static function knowledgecenter_folders_parameters(){
        return new external_function_parameters(
            array()
        );

    }

    public static function knowledgecenter_folders(){
        global $DB;

         $aa = array();
         $dd = array();
          $kk = array();
          $ss = array();
         
          $folders = $DB->get_records_sql('SELECT * FROM {ums_knc_folder} WHERE parent_id = 0 ORDER BY folder ASC');
         $mainfolder = array();
          foreach ($folders as $key => $folder) { 
            // $alldd['folderid'] = $folder->id;
            $alldd['id'] =$folder->id;
            $alldd['foldername'] =$folder->folder;
            // $alldd['folder'][] = $users; 
            // $sub_folder = array();
              // $alldd['subfolders'] = $kk;
              $aa[]=$alldd;
              // print_r($aa);
          }
            #$subfolders = $DB->get_records_sql('SELECT * FROM {ums_knc_folder} WHERE parent_id != ?',array(0));
            $subfolders = $DB->get_records_sql('SELECT * FROM {ums_knc_folder} WHERE parent_id != 0 ORDER BY folder ASC');
            foreach ($subfolders as $key => $subfolder) {
                 $bb['subfoldername']= $subfolder->folder;

              $subfolder = array('id'=>$subfolder->id,'folder_id'=>$subfolder->parent_id,'subfoldername'=>$subfolder->folder);
              $kk[]= $subfolder;
                 
              // print_r($kk);
            }
            
            $dd['folders']=$aa;
            $dd['subfolders']=$kk;
            // print_r($dd);            


           
            return($dd);
           
            // return($result);
    }


     public static function knowledgecenter_folders_returns(){
           return new external_single_structure(
                array(
                    
                     'folders' => new external_multiple_structure(
                                new external_single_structure(
                                              array(
                            'id' => new external_value(PARAM_INT,'folderid'),
                            'foldername'=>new external_value(PARAM_RAW,'foldername'),
                           
                    ))),
                    'subfolders' => new external_multiple_structure(
                                  new external_single_structure(
                                              array(
                            'id'=>new external_value(PARAM_INT,'subfolderid'),
                            'folder_id'=>new external_value(PARAM_INT,'parentfolderid'),
                            'subfoldername'=>new external_value(PARAM_RAW,'subfoldername'),
                           
                        )))
                      

                )
            

        );

     }


      public static function knowledgecenter_file_parameters(){
        return new external_function_parameters(
            array(
              'id' => new external_value(PARAM_INT,'id'),
            )

        );

    }

    public static function knowledgecenter_file($id)
	{
       global $DB,$CFG;
       $final =array();
        
         $files = $DB->get_records_sql('SELECT * FROM {ums_knc_files} WHERE knc_folder_id = '.$id.' ORDER BY filename ASC');
         
		 $aa= array();
         $dd = array();
         if(!empty($files)){
        
            foreach ($files as $key => $file) 
			{
				if($file->filetypes == 1) { $type = 'url'; }
				if($file->filetypes == 2) { $type = 'pdf'; }
                $aa['id'] = $file->id;
                $aa['filename'] = $file->filename;
                $aa['is_downloadable'] = $file->is_downloadable;
                $aa['type'] = $type;
				if($file->filetypes == 1) 
				{
					$aa['url'] = $file->local_file_path;
				}
				if($file->filetypes == 2) 
				{
					$aa['url'] = $CFG->wwwroot.$file->local_file_path;		
				}
                $aa['createddate'] = $file->created;
                $dd[]= $aa;
            }
         }
         
          $final['files'] = $dd;
      
            return($final);

            /*
            NEW CODE WITH EXCLUSIVE ACCESS
            global $DB,$CFG,$USER;
       $final =array();
       $aa= array();
      $dd = array();
          $folderrecord =  $DB->get_record_sql('SELECT * FROM {ums_knc_folder} WHERE id = ? ',array($id));
  if($folderrecord->exclusive==0)
  {
         $files = $DB->get_records_sql('SELECT * FROM {ums_knc_files} WHERE knc_folder_id = '.$id.' ORDER BY filename ASC');
   }
   else
   {
    $allowed_files=Array();
  $sqlData = $DB->get_record_sql("SELECT designation_id FROM mdl_ums_employeemaster WHERE userid = '".$USER->id."'");
    
    $desigID=$sqlData->designation_id;
  
  $allowed_files_data= $DB->get_records_sql("SELECT DISTINCT file_id FROM mdl_ums_knc_excl_permissions WHERE desg_id = ".$desigID." AND status=1");
  foreach ($allowed_files_data as $key => $value) {
    array_push($allowed_files, $value->file_id);
      }

  if(!empty($allowed_files_data))
  {
    $s="SELECT * FROM mdl_ums_knc_files WHERE id in (".implode(',',$allowed_files).")";
    
  $files =  $DB->get_records_sql($s);
  
  }

   }      
     
         if(!empty($files)){
        
            foreach ($files as $key => $file) 
      {
        if($file->filetypes == 1) { $type = 'url'; }
        if($file->filetypes == 2) { $type = 'pdf'; }
                $aa['id'] = $file->id;
                $aa['filename'] = $file->filename;
                $aa['is_downloadable'] = $file->is_downloadable;
                $aa['type'] = $type;
        if($file->filetypes == 1) 
        {
          $aa['url'] = $file->local_file_path;
        }
        if($file->filetypes == 2) 
        {
          $aa['url'] = $CFG->wwwroot.$file->local_file_path;    
        }
                $aa['createddate'] = $file->created;
                $dd[]= $aa;
            }
         }
         
          $final['files'] = $dd;
      
            return($final);
            */
    }


     public static function knowledgecenter_file_returns(){
        return  new external_single_structure(
          array(
            'files' =>  new external_multiple_structure(
                          new external_single_structure(
                            array(
                            'id'=> new external_value(PARAM_INT,'id'),
                             'filename' => new external_value(PARAM_TEXT,'filename'),
                             'is_downloadable' => new external_value(PARAM_TEXT,'is_downloadable'),
							 'type' => new external_value(PARAM_TEXT,'type'),
                             'url'=>new external_value(PARAM_RAW,'url'),
                             'createddate'=>new external_value(PARAM_RAW,'date'),
                            )
                          )
                        ),
              )
        );

     }



     //function to get audio video folders

    
      public static function audio_video_folders_parameters(){
        return new external_function_parameters(
            array()
        );

    }

    public static function audio_video_folders(){
        global $DB;

         $aa = array();
         $dd = array();
          $kk = array();
          $ss = array();
         #$folders = $DB->get_records('ums_av_folder',array('parent_id'=>0));
          $folders = $DB->get_records_sql('SELECT * FROM {ums_av_folder} WHERE parent_id = 0 ORDER BY folder ASC');
         // print_r($folders);
         $mainfolder = array();
          foreach ($folders as $key => $folder) { 
            // $alldd['folderid'] = $folder->id;
            $alldd['id'] =$folder->id;
            $alldd['foldername'] =$folder->folder;
            // $alldd['folder'][] = $users; 
            // $sub_folder = array();
              // $alldd['subfolders'] = $kk;
              $aa[]=$alldd;
              // print_r($aa);
          }
            #$subfolders = $DB->get_records_sql('SELECT * FROM {ums_av_folder} WHERE parent_id != ?',array(0));
            $subfolders = $DB->get_records_sql('SELECT * FROM {ums_av_folder} WHERE parent_id != 0 ORDER BY folder ASC');
            foreach ($subfolders as $key => $subfolder) {
                 $bb['subfoldername']= $subfolder->folder;

              $subfolder = array('id'=>$subfolder->id,'folder_id'=>$subfolder->parent_id,'subfoldername'=>$subfolder->folder);
              $kk[]= $subfolder;
                 
              // print_r($kk);
            }
            
            $dd['folders']=$aa;
            $dd['subfolders']=$kk;
            // print_r($dd);            


           
            return($dd);
    }


     public static function audio_video_folders_returns(){
         return new external_single_structure(
                array(
                    
                     'folders' => new external_multiple_structure(
                                new external_single_structure(
                                              array(
                            'id' => new external_value(PARAM_INT,'folderid'),
                            'foldername'=>new external_value(PARAM_RAW,'foldername'),
                           
                    ))),
                    'subfolders' => new external_multiple_structure(
                                  new external_single_structure(
                                              array(
                            'id'=>new external_value(PARAM_INT,'subfolderid'),
                            'folder_id'=>new external_value(PARAM_INT,'parentfolderid'),
                            'subfoldername'=>new external_value(PARAM_RAW,'subfoldername'),
                           
                        )))
                      

                )
            

        );

     }


    

      public static function audio_video_parentfolders_parameters(){
        return new external_function_parameters(
            array()
        );

    }

    public static function audio_video_parentfolders(){
        global $DB;
       
         $folders = $DB->get_records('ums_av_folder',array('parent_id'=>0));
         $folders = $DB->get_records_sql('SELECT * FROM {ums_av_folder} WHERE parent_id = 0 ORDER BY folder ASC');
         $mainfolder = array();
          foreach ($folders as $key => $folder) { 
            $alldd['folders'][] = array('folderid'=>$folder->id,'foldername'=>$folder->folder);
           }
            $aa=$alldd;
 
  
           
            return($aa);
    }


     public static function audio_video_parentfolders_returns(){
         return new external_single_structure(
                array(
                    
                     'folders' => new external_multiple_structure(
                                new external_single_structure(
                                              array(
                            'folderid'=>new external_value(PARAM_INT,'folderid'),

                            'foldername'=>new external_value(PARAM_RAW,'foldername'),

                           
                    ))),
                      

                )
            );

        

     }

     public static function audio_video_subfolders_parameters(){
        return new external_function_parameters(
            array(
              'id' => new external_value(PARAM_INT,'folderid')
            )

        );
    }

    public static function audio_video_subfolders($id){
        global $DB;
       
         #$folders = $DB->get_records('ums_av_folder',array('parent_id'=>$id));
         $folders =$DB->get_records_sql('SELECT * FROM {ums_av_folder} WHERE parent_id = '.$id.' ORDER BY folder ASC');
         $mainfolder = array();
         if(!empty($folders)){
          foreach ($folders as $key => $folder) { 
            $alldd['subfolders'][] = array('folderid'=>$folder->id,'foldername'=>$folder->folder);
           }
         }else{
             $alldd['subfolders'][] = array('folderid'=>null,'foldername'=>null);
         }
            $aa=$alldd;
            // print_r($aa);
 
  
           
            return($aa);
    }


     public static function audio_video_subfolders_returns(){
         return new external_single_structure(
                array(
                    
                     'subfolders' => new external_multiple_structure(
                                new external_single_structure(
                                              array(
                            'folderid'=>new external_value(PARAM_INT,'folderid'),

                            'foldername'=>new external_value(PARAM_RAW,'foldername'),

                           
                    ))),
                      

                )
            );

        

     }

     public static function audio_video_file_parameters(){
        return new external_function_parameters(
            array(
              'id' => new external_value(PARAM_INT,'id'),
            )

        );

    }

    public static function audio_video_file($id){
        global $DB,$CFG;
        $final =array();
         #$files = $DB->get_records('ums_av_files',array('av_folder_id'=>$id,'deleted'=>0));
         $files = $DB->get_records_sql('SELECT * FROM {ums_av_files} WHERE av_folder_id = '.$id.' AND deleted = 0 ORDER BY filename ASC');
		$aa= array();
        $dd = array();
         if(!empty($files)){
            foreach ($files as $key => $file) {

                $aa['id'] = $file->id;
                $aa['videoname'] = $file->filename;
                $aa['is_downloadable'] = $file->is_downloadable;
                if(!empty($file->external_url)){
                  $aa['video_file_name'] = $file->external_url;
                }else{
                  $new = str_replace(' ', '%20', $file->local_file_path);
                  $aa['video_file_name'] = $CFG->wwwroot.$new;
                }
                $aa['createddate'] = $file->created;

                $dd[]= $aa;
             
            }
         }
         
          $final['Video'] = $dd;
   
		return($final);
    }


     public static function audio_video_file_returns(){
      return new external_single_structure(
          array(
            'Video'=>    new external_multiple_structure(
                          new external_single_structure(
                            array(
                                 'id' => new external_value(PARAM_INT,'fileid'),
                                 'videoname' => new external_value(PARAM_TEXT,'filename'),
                                 'is_downloadable' => new external_value(PARAM_TEXT,'is_downloadable'),
                                 'video_file_name'=>new external_value(PARAM_RAW,'url'),
                                 'createddate'=>new external_value(PARAM_RAW,'date'),
                                
                                )
                      

                          )

                      ),
            )
          );
        

     }

       //function to logout

      public static function logout_parameters(){
        return new external_function_parameters(
            array(            
            )
        );

    }

    public static function logout(){
        global $DB,$USER;
		
		/* OLD 11Oct, 2019
		$updatenewtbl = $DB->execute("UPDATE {ums_device_information} SET devicetoken = NULL, ostype= NULL, fcmid=NULL, mobilemodelname=NULL, mobileosname=NULL, currentappversion=NULL, macid=NULL, extraparam1=NULL, extraparam2=NULL, updated = '".date("Y-m-d H:i:s")."' WHERE userid = ".$USER->id."");
		
        $update = $DB->execute("UPDATE {user} set devicetoken = NULL, ostype= NULL, fcmid=NULL, mobilemodelname=NULL, mobileosname=NULL, currentappversion=NULL, macid=NULL, extraparam1=NULL, extraparam2=NULL WHERE id = ".$USER->id.""); */
		
		//Changed on 11Oct,2019
		$update = $DB->execute("UPDATE {ums_device_information} SET logout_date = '".date("Y-m-d H:i:s")."', is_logout = '1' WHERE userid = ".$USER->id."");
        if($update){
          $result = array('status'=>'success');
        }else{
          $result = array('status'=>'failed');
        }
        
        
           
            return($result);
    }


    public static function logout_returns(){
       return new external_single_structure(
                array(
                      'status'=>new external_value(PARAM_RAW,'status'),

                )
            );

    }
	
	// webservice created date - 23/01/2020 
	public static function get_myquestion_parameters() 
	{
		return new external_function_parameters(
			array()
		);
	}
	
	public static function get_myquestion()
	{
	    global $USER,$DB,$CFG;
	    $aa = array();
		$resultarray=array();
        $dd = $dd1 = $dd2 = $dd3 = $dd4 = $dd5 = $dd6 = array();
        $op1 = $op2 = $op3 = $op4 = $op5 = $op6 = array();
			
        $today  = date('Y-m-d');
	    $res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE deleted ='0' AND qdate = '".$today."'");
		if(!empty($res_Question))
	    {
			$questionid       = $res_Question->id;
			$question_type    = $res_Question->questiontype;
			$question  		  = $res_Question->question;
			$option_a_type    = $res_Question->option_a_type;
			$option_a         = $res_Question->option_a;
			$option_b_type    = $res_Question->option_b_type;
			$option_b         = $res_Question->option_b;
			$option_c_type    = $res_Question->option_c_type;
			$option_c         = $res_Question->option_c;
			$option_d_type    = $res_Question->option_d_type;
			$option_d         = $res_Question->option_d;
			$additional_text  = $res_Question->additional_text;
			if($question_type == 1)
			{
				$q_type = 'Text';
				$question_text  = isset($question) && $question!=''?$question:'--';
				$question_image = "";
			}
			if($question_type == 2)
			{
				$q_type = 'Image';
				$question_text  = "";
				$question_image = $CFG->wwwroot.$question;
			}
			if($question_type == 3)
			{
				$q_type = 'Both';
				$question_text  = $additional_text;
				$question_image = $CFG->wwwroot.$question;
			}
			
			//------------------------------------------------------------//
			if($option_a_type == 1)
			{
				$option_A_type  = 'Text';
				$option_A_text  = isset($option_a) && $option_a!=''?$option_a:'--';
				$option_A_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			}
			if($option_a_type == 2)
			{
				$option_A_type   = 'Image';
				$option_A_text   = "";
				$option_A_image  = $CFG->wwwroot.$option_a;
				
			}
			//----------------------------------------------------------------//
			if($option_b_type == 1)
			{
				$option_B_type  = 'Text';
				$option_B_text  = isset($option_b) && $option_b!=''?$option_b:'--';
				$option_B_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			}
			if($option_b_type == 2)
			{
				$option_B_type   = 'Image';
				$option_B_text   = "";
				$option_B_image  = $CFG->wwwroot.$option_b;
			}
			
			//-------------------------------------------------------------//
			
			if($option_c_type == 1)
			{
				$option_C_type  = 'Text';
				$option_C_text  = isset($option_c) && $option_c!=''?$option_c:'--';
				$option_C_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			}
			if($option_c_type == 2)
			{
				$option_C_type   = 'Image';
				$option_C_text   = "";
				$option_C_image  = $CFG->wwwroot.$option_c;
			}
			
			//-------------------------------------------------------------//
			
			if($option_d_type == 1)
			{
				$option_D_type   = 'Text';
				$option_D_text   = isset($option_d) && $option_d!=''?$option_d:'--';
				$option_D_image  = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				
			}
			if($option_d_type == 2)
			{
				$option_D_type   = 'Image';
				$option_D_text   = "";
				$option_D_image  = $CFG->wwwroot.$option_d;
			}
			
			$option_E_type   = 'Text';
			$option_E_text   = 'All of these';
			$option_E_image  = '-'; //$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				
			$option_F_type   = 'Text';
			$option_F_text   = 'None of these';
			$option_F_image  = '-'; //$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			
			//---------------------------------------------------------------//
			
			$alldd  = array('questionid' => $questionid,
							'questiontype'   => $q_type,
							'question_text'  => $question_text,
							'question_image' => $question_image);
			$aa[]   = $alldd;				
			$option1 = array('option_type'   => $option_A_type,
							 'option_text'   => $option_A_text,
							 'option_image'  => $option_A_image
							);
			$op1[]= $option1;
			
			$option2 = array('option_type'   => $option_B_type,
							 'option_text'   => $option_B_text,
							 'option_image'  => $option_B_image
							);
			$op2[]= $option2;
			
			$option3 = array('option_type'  => $option_C_type,
							 'option_text'   => $option_C_text,
							 'option_image'  => $option_C_image
							);
			$op3[]= $option3;
			
			$option4 = array('option_type'   => $option_D_type,
							 'option_text'   => $option_D_text,
							 'option_image'  => $option_D_image
							);
			$op4[]= $option4;
			
			$option5 = array('option_type'   => $option_E_type,
							 'option_text'   => $option_E_text,
							 'option_image'  => $option_F_image
							);
			$op5[]= $option5;
			
			$option6 = array('option_type'   => $option_F_type,
							 'option_text'   => $option_F_text,
							 'option_image'  => $option_F_image
							);
			$op6[]= $option6;
			$op = array_merge($op1,$op2,$op3,$op4);
			$dd['Question'] = $aa;
			$dd['Options']  = $op;
			return($dd);
		}
		else
		{
			$resultarray = array(
									'status'  => 1,
									'message' => 'Question Missing'
						);	
		}
			
	}
	
	public static function get_myquestion_returns()
	{
		return new external_single_structure(
            array(
                    
			 'Question' => new external_multiple_structure(
					new external_single_structure(
					array(
						'questionid'      => new external_value(PARAM_INT,'questionid'),
						'questiontype'    => new external_value(PARAM_TEXT,'questiontype'),
						'question_text'   => new external_value(PARAM_TEXT,'question_text'),
						'question_image'  => new external_value(PARAM_TEXT,'question_image'),
				   
					))),
			'Options' => new external_multiple_structure(
				    new external_single_structure(
					array(
							'option_type'   => new external_value(PARAM_TEXT,'option_type'),
							'option_text'   => new external_value(PARAM_TEXT,'option_text'),
							'option_image'  => new external_value(PARAM_TEXT,'option_image')
						))
					)
                )
        );
	}
	
	public static function get_myquestionanwser_parameters() 
	{
		return new external_function_parameters(
            array(
               'questionid' => new external_value(PARAM_INT,'questionid'),
			   'answerid' => new external_value(PARAM_RAW,'answerid'),
            )
        );
	}
	
	public static function get_myquestionanwser($questionid,$answerid)
	{
	    global $USER,$DB,$CFG;
		$today       = date('Y-m-d H:i:s');
		$resultarray = array();
		$aa = array();
		$dd = $dd1 = $dd2 = $dd3 = $dd4 = $dd5 = $dd6 = array();
        $op1 = $op2 = $op3 = $op4 = $op5 = $op6 = array();
		$sqlResponce = $DB->get_record_sql("SELECT * FROM mdl_question_user_answer WHERE questionid = '".$questionid."' AND userid = '".$USER->id."'");
		if(empty($sqlResponce))
		{
			$sqlQuestion = "SELECT * FROM mdl_question_of_day WHERE id = '".$questionid."'";
			$resQuestion = $DB->get_record_sql($sqlQuestion);
			$qviewdate   = $resQuestion->qdate;
			$correctanswer    = explode(",",$resQuestion->correctanswer);
			$givenanswerarray=array();
			if (strpos($answerid,',') == true) 
			{
				$givenanswerarray = explode(",",$answerid);
				$givenanswerarray=array_filter($givenanswerarray);
			}
			else
			{
				array_push($givenanswerarray, $answerid);
			}
			$noncommon=array_diff($correctanswer,$givenanswerarray);
			if(count($noncommon)==0 && count($givenanswerarray)==count($correctanswer)) 
			{
				
				$is_correct = 1;
			    $insertCorrectResponce = "INSERT mdl_question_user_answer SET 
								questionid = '".$questionid."',
								answerid = '".$answerid."',
								userid = '".$USER->id."',
								mspin = '".$USER->username."',
								attempt_status = 1,
								is_correct = '".$is_correct."',
								qviewdate  = '".$qviewdate."',
								answer_posted_date = '".date("Y-m-d H:i:s")."'";
				if($DB->execute($insertCorrectResponce))
				{	
					$updateUserStatus = "UPDATE mdl_ums_employeemaster SET 	attempted_todays_question_view = 0,
					attempted_todays_question_view_date = '".date('Y-m-d')."' 
					WHERE userid = '".$USER->id."'";
					$DB->execute($updateUserStatus);
					// this is for month wise report for perticular employee
					$month  = date("Y-m");
					$sqlData = $DB->get_record_sql("SELECT id,answer FROM mdl_question_of_day_correct_answer WHERE mspin = '".$USER->username."' AND month = '".$month."'");
					
					if(isset($sqlData->answer) && !empty($sqlData->answer))
					{		
							$answer = $sqlData->answer + 1;
							$record = new stdClass();
							$record->id 	    	= $sqlData->id;
							$record->answer 	    = $answer;
							$record->updated 	    = date("Y-m-d H:i:s");
							$lastinsertid           = $DB->update_record('question_of_day_correct_answer',$record);
					}
					else
					{
						
							$record = new stdClass();
							$record->month 			= $month;
							$record->mspin 	  		= $USER->username;
							$record->answer 	    = 1;
							$record->created 	    = date("Y-m-d H:i:s");
							$lastinsertid           = $DB->insert_record('question_of_day_correct_answer',$record);
					}
					//------ once answer submit need to show previous day question--//
					$currentDatecurrentDate = date('Y-m-d');
				
					$res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE qdate = '".$currentDatecurrentDate."'");
					
					if(!empty($res_Question))
	    {
			$questionid       = $res_Question->id;
			$question_type    = $res_Question->questiontype;
			$question  		  = strip_tags($res_Question->question);
			$option_a_type    = $res_Question->option_a_type;
			$option_a         = $res_Question->option_a;
			$option_b_type    = $res_Question->option_b_type;
			$option_b         = $res_Question->option_b;
			$option_c_type    = $res_Question->option_c_type;
			$option_c         = $res_Question->option_c;
			$option_d_type    = $res_Question->option_d_type;
			$option_d         = $res_Question->option_d;
			$additional_text  = $res_Question->additional_text;
			$qdate            = date("d-m-Y",strtotime($res_Question->qdate));
			$correctanswerOp  = $res_Question->correctanswer;
			$c_p = explode(',',$correctanswerOp);
			if($question_type == 1)
			{
				$q_type = 'Text';
				$question_text  = isset($question) && $question!=''?$question:'--';
				$question_image = '';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			}
			if($question_type == 2)
			{
				$q_type = 'Image';
				$question_text  = '';
				$question_image = $CFG->wwwroot.$question;
			}
			if($question_type == 3)
			{
				$q_type = 'Both';
				$question_text  = $additional_text;
				$question_image = $CFG->wwwroot.$question;
			}
			
			//------------------------------------------------------------//
			if($option_a_type == 1)
			{
				$option_A_type  = 'Text';
				$option_A_text  = isset($option_a) && $option_a!=''?$option_a:'--';
				$option_A_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_a_type == 2)
			{
				$option_A_type   = 'Image';
				$option_A_text   = '';
				$option_A_image  = $CFG->wwwroot.$option_a;
				$is_right_answer = '';
				
			}
			//----------------------------------------------------------------//
			if($option_b_type == 1)
			{
				$option_B_type  = 'Text';
				$option_B_text  = isset($option_b) && $option_b!=''?$option_b:'--';
				$option_B_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_b_type == 2)
			{
				$option_B_type   = 'Image';
				$option_B_text   = '';
				$option_B_image  = $CFG->wwwroot.$option_b;
				$is_right_answer = '';
			}
			
			//-------------------------------------------------------------//
			
			if($option_c_type == 1)
			{
				$option_C_type  = 'Text';
				$option_C_text  = isset($option_c) && $option_c!=''?$option_c:'--';
				$option_C_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_c_type == 2)
			{
				$option_C_type   = 'Image';
				$option_C_text   = '';
				$option_C_image  = $CFG->wwwroot.$option_c;
				$is_right_answer = '';
			}
			
			//-------------------------------------------------------------//
			
			if($option_d_type == 1)
			{
				$option_D_type   = 'Text';
				$option_D_text   = isset($option_d) && $option_d!=''?$option_d:'--';
				$option_D_image  = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
				
			}
			if($option_d_type == 2)
			{
				$option_D_type   = 'Image';
				$option_D_text   = '';
				$option_D_image  = $CFG->wwwroot.$option_d;
				$is_right_answer = '';
			}
			
			$option_E_type   = 'Text';
			$option_E_text   = 'All of these';
			$option_E_image  = '-'; 
			$is_right_answer = '';
			//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				
			$option_F_type   = 'Text';
			$option_F_text   = 'None of these';
			$option_F_image  = '-'; 
			$is_right_answer = '';
			//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			
			//---------------------------------------------------------------//
			
			$alldd  = array('questionid' => $questionid,
							'questiontype'   => $q_type,
							'question_text'  => $question_text,
							'question_image' => $question_image,
							'questiondate'   => $qdate);
			$aa[]   = $alldd;	
			$is_right_answer=(in_array("A", $c_p)?'Yes':'No');			
			$option1 = array('option_type'   => $option_A_type,
							 'option_text'   => $option_A_text,
							 'option_image'  => $option_A_image,
							 'is_right_anwser' => $is_right_answer 
							);
			$op1[]= $option1;
			$is_right_answer=(in_array("B", $c_p)?'Yes':'No');
			$option2 = array('option_type'   => $option_B_type,
							 'option_text'   => $option_B_text,
							 'option_image'  => $option_B_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op2[]= $option2;
			$is_right_answer=(in_array("C", $c_p)?'Yes':'No');
			$option3 = array('option_type'  => $option_C_type,
							 'option_text'   => $option_C_text,
							 'option_image'  => $option_C_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op3[]= $option3;
			$is_right_answer=(in_array("D", $c_p)?'Yes':'No');
			$option4 = array('option_type'   => $option_D_type,
							 'option_text'   => $option_D_text,
							 'option_image'  => $option_D_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op4[]= $option4;
			$is_right_answer=(in_array("E", $c_p)?'Yes':'No');
			$option5 = array('option_type'   => $option_E_type,
							 'option_text'   => $option_E_text,
							 'option_image'  => $option_F_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op5[]= $option5;
			$is_right_answer=(in_array("F", $c_p)?'Yes':'No');
			$option6 = array('option_type'   => $option_F_type,
							 'option_text'   => $option_F_text,
							 'option_image'  => $option_F_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op6[]= $option6;
			$op = array_merge($op1,$op2,$op3,$op4);
			$dd['Question'] = $aa;
			$dd['Options']  = $op;
			return($dd);
		}
					//--------------- end of question answer status -----//
				} 
			} 
			else
			{
				$is_correct = 0;
			    $insertWorngResponce = "INSERT mdl_question_user_answer SET 
								questionid = '".$questionid."',
								answerid = '".$answerid."',
								userid = '".$USER->id."',
								mspin = '".$USER->username."',
								attempt_status = 1,
								is_correct = '".$is_correct."',
								qviewdate  = '".$qviewdate."',
								answer_posted_date = '".date("Y-m-d H:i:s")."'";
								
				if($DB->execute($insertWorngResponce))
				{ 
					$updateUserStatus = "UPDATE mdl_ums_employeemaster 
					SET attempted_todays_question_view = 0,				attempted_todays_question_view_date = '".date('Y-m-d')."'					
					WHERE userid = '".$USER->id."'";
					$DB->execute($updateUserStatus);
					
				}
				//-------------------------------------------------------//
				$currentDatecurrentDate = date('Y-m-d');
				$res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE qdate = '".$currentDatecurrentDate."'");
				if(!empty($res_Question))
				{
					$questionid       = $res_Question->id;
					$question_type    = $res_Question->questiontype;
					$question  		  = strip_tags($res_Question->question);
					$option_a_type    = $res_Question->option_a_type;
					$option_a         = $res_Question->option_a;
					$option_b_type    = $res_Question->option_b_type;
					$option_b         = $res_Question->option_b;
					$option_c_type    = $res_Question->option_c_type;
					$option_c         = $res_Question->option_c;
					$option_d_type    = $res_Question->option_d_type;
					$option_d         = $res_Question->option_d;
					$additional_text  = $res_Question->additional_text;
					$qdate            = date("d-m-Y",strtotime($res_Question->qdate)); 
					$correctanswerOp  = $res_Question->correctanswer;
					$c_p = explode(',',$correctanswerOp);
					if($question_type == 1)
					{
						$q_type = 'Text';
						$question_text  = isset($question) && $question!=''?$question:'--';
						$question_image = '';
					}
					if($question_type == 2)
					{
						$q_type = 'Image';
						$question_text  = '';
						$question_image = $CFG->wwwroot.$question;
					}
					if($question_type == 3)
					{
						$q_type = 'Both';
						$question_text  = $additional_text;
						$question_image = $CFG->wwwroot.$question;
					}
					
					//--------------------------------------------------//
					if($option_a_type == 1)
					{
						$option_A_type  = 'Text';
						$option_A_text  = isset($option_a) && $option_a!=''?$option_a:'--';
						$option_A_image = '-';
						$is_right_answer = '';
					}
					if($option_a_type == 2)
					{
						$option_A_type   = 'Image';
						$option_A_text   = '';
						$option_A_image  = $CFG->wwwroot.$option_a;
						$is_right_answer = '';
						
					}
					//------------------------------------------------------//
					if($option_b_type == 1)
					{
						$option_B_type  = 'Text';
						$option_B_text  = isset($option_b) && $option_b!=''?$option_b:'--';
						$option_B_image = '-';
						$is_right_answer = '';
					}
					if($option_b_type == 2)
					{
						$option_B_type   = 'Image';
						$option_B_text   = '';
						$option_B_image  = $CFG->wwwroot.$option_b;
						$is_right_answer = '';
					}
					
					//--------------------------------------------------//
			
					if($option_c_type == 1)
					{
						$option_C_type  = 'Text';
						$option_C_text  = isset($option_c) && $option_c!=''?$option_c:'--';
						$option_C_image = '-';
						$is_right_answer = '';
					}
					if($option_c_type == 2)
					{
						$option_C_type   = 'Image';
						$option_C_text   = '';
						$option_C_image  = $CFG->wwwroot.$option_c;
						$is_right_answer = '';
					}
			
					//-------------------------------------------------------//
			
					if($option_d_type == 1)
					{
						$option_D_type   = 'Text';
						$option_D_text   = isset($option_d) && $option_d!=''?$option_d:'--';
						$option_D_image  = '-';
						$is_right_answer = '';
						
					}
					if($option_d_type == 2)
					{
						$option_D_type   = 'Image';
						$option_D_text   = '';
						$option_D_image  = $CFG->wwwroot.$option_d;
						$is_right_answer = '';
					}
			
					$option_E_type   = 'Text';
					$option_E_text   = 'All of these';
					$option_E_image  = '-'; 
					$is_right_answer = '';
					//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
						
					$option_F_type   = 'Text';
					$option_F_text   = 'None of these';
					$option_F_image  = '-'; 
					$is_right_answer = '';
			
			
					//-----------------------------------------------------//
			
					$alldd  = array('questionid' => $questionid,
									'questiontype'   => $q_type,
									'question_text'  => $question_text,
									'question_image' => $question_image,
									'questiondate'   => $qdate);
					$aa[]   = $alldd;	
					$is_right_answer=(in_array("A", $c_p)?'Yes':'No');			
					$option1 = array('option_type'   => $option_A_type,
									 'option_text'   => $option_A_text,
									 'option_image'  => $option_A_image,
									 'is_right_anwser' => $is_right_answer 
									);
					$op1[]= $option1;
					$is_right_answer=(in_array("B", $c_p)?'Yes':'No');
					$option2 = array('option_type'   => $option_B_type,
									 'option_text'   => $option_B_text,
									 'option_image'  => $option_B_image,
									 'is_right_anwser' => $is_right_answer
									);
					$op2[]= $option2;
					$is_right_answer=(in_array("C", $c_p)?'Yes':'No');
					$option3 = array('option_type'  => $option_C_type,
									 'option_text'   => $option_C_text,
									 'option_image'  => $option_C_image,
									 'is_right_anwser' => $is_right_answer
									);
					$op3[]= $option3;
					$is_right_answer=(in_array("D", $c_p)?'Yes':'No');
					$option4 = array('option_type'   => $option_D_type,
									 'option_text'   => $option_D_text,
									 'option_image'  => $option_D_image,
									 'is_right_anwser' => $is_right_answer
									);
					$op4[]= $option4;
					$is_right_answer=(in_array("E", $c_p)?'Yes':'No');
					$option5 = array('option_type'   => $option_E_type,
									 'option_text'   => $option_E_text,
									 'option_image'  => $option_F_image,
									 'is_right_anwser' => $is_right_answer
									);
					$op5[]= $option5;
					$is_right_answer=(in_array("F", $c_p)?'Yes':'No');
					$option6 = array('option_type'   => $option_F_type,
									 'option_text'   => $option_F_text,
									 'option_image'  => $option_F_image,
									 'is_right_anwser' => $is_right_answer
									);
					$op6[]= $option6;
					$op = array_merge($op1,$op2,$op3,$op4);
					$dd['Question'] = $aa;
					$dd['Options']  = $op;
					return($dd);
				}
				//--------------------------------------------------------//
			}
					
		}	
		else
		{
			$resultarray = array(
									'status'  => 2,
									'message' => 'Already Attemped'
								);
		}	
		
	}
	
	public static function get_myquestionanwser_returns()
	{
		return new external_single_structure(
            array(
                    
			 'Question' => new external_multiple_structure(
					new external_single_structure(
					array(
						'questionid'      => new external_value(PARAM_INT,'questionid'),
						'questiontype'    => new external_value(PARAM_TEXT,'questiontype'),
						'question_text'   => new external_value(PARAM_TEXT,'question_text'),
						'question_image'  => new external_value(PARAM_TEXT,'question_image'),
						'questiondate'    => new external_value(PARAM_RAW,'questiondate'),
				   
					))),
			'Options' => new external_multiple_structure(
				    new external_single_structure(
					array(
							'option_type'   => new external_value(PARAM_TEXT,'option_type'),
							'option_text'   => new external_value(PARAM_TEXT,'option_text'),
							'option_image'  => new external_value(PARAM_TEXT,'option_image'),
							'is_right_anwser' => new external_value(PARAM_TEXT,'is_right_anwser')
						))
					)
                )
        );
	}
	
	// this function for user todays question stataus whether attmpted or not 
	public static function get_mytodayquestionstatus_parameters() 
	{
		return new external_function_parameters(
            array(
             	'MSPIN' => new external_value(PARAM_RAW,'MSPIN'),
            )
        );
	}
	
	public static function get_mytodayquestionstatus($MSPIN)
	{
	    global $USER,$DB;
		$resultarray = array();
		$todaydate   = date('Y-m-d');
		$token = $_REQUEST['wstoken'];
		if(!empty($token))
		{	
			if($MSPIN == $USER->username)
			{	
				$sqlResponce = $DB->get_record_sql("SELECT * FROM mdl_question_user_answer 
				WHERE mspin = '".$MSPIN."' AND qviewdate = '".$todaydate."'");
				if(!empty($sqlResponce))
				{
					// change request - 0
					$resultarray = array(
											'status'  => 1,
											'message' => 'Question Attemped'
										);
				}	
				else
				{
					// now change to 0
					$resultarray = array(
											'status'  => 0,
											'message' => 'Question Not Attemped'
										);
				}
			}
			else
			{
				$resultarray = array(
										'status'  => 1,
										'message' => 'Question Not Attemped'
										);
			}
		}
        else
		{
			$resultarray = array(
										'status'  => 2,
										'message' => 'Question Not Attemped'
										);
		}		
		return $resultarray; 
	}
	
	public static function get_mytodayquestionstatus_returns()
	{
		return new external_single_structure(
            array(
				'status' => new external_value(PARAM_INT,'status'),
				'message' => new external_value(PARAM_RAW,'message'),
			)
        );
	}
	
	//----------------------------- 08-05-2020-----------------------------------//
	// Code by Yogita P. Ghegadmal
	
	public static function get_previousdayQuestion_parameters() 
	{
		return new external_function_parameters(
			array()
		);
	}
	
	public static function get_previousdayQuestion()
	{
		global $USER,$DB,$CFG;
	    $aa = array();
		$resultarray=array();
        $dd = $dd1 = $dd2 = $dd3 = $dd4 = $dd5 = $dd6 = array();
        $op1 = $op2 = $op3 = $op4 = $op5 = $op6 = array();
			
        $currentDatecurrentDate = date('Y-m-d');
        $dt1 = strtotime($currentDatecurrentDate);
        $dt2 = date("l", $dt1);
        $dt3 = strtolower($dt2);
		if($dt3 == "monday") // if monday come then show question of sat
		{
			$res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE qdate >= CURDATE() - INTERVAL 2 DAY AND qdate < CURDATE()");
		}
		else
		{
			$res_Question = $DB->get_record_sql("SELECT * FROM mdl_question_of_day WHERE qdate >= CURDATE() - INTERVAL 1 DAY AND qdate < CURDATE()");
		}
		if(!empty($res_Question))
	    {
			$questionid       = $res_Question->id;
			$question_type    = $res_Question->questiontype;
			$question  		  = strip_tags($res_Question->question);
			$option_a_type    = $res_Question->option_a_type;
			$option_a         = $res_Question->option_a;
			$option_b_type    = $res_Question->option_b_type;
			$option_b         = $res_Question->option_b;
			$option_c_type    = $res_Question->option_c_type;
			$option_c         = $res_Question->option_c;
			$option_d_type    = $res_Question->option_d_type;
			$option_d         = $res_Question->option_d;
			$additional_text  = $res_Question->additional_text;
			$qdate            = date("d-m-Y",strtotime($res_Question->qdate));  //$res_Question->qdate; 
			$correctanswerOp  = $res_Question->correctanswer;
			$c_p = explode(',',$correctanswerOp);
			if($question_type == 1)
			{
				$q_type = 'Text';
				$question_text  = isset($question) && $question!=''?$question:'--';
				$question_image = '';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			}
			if($question_type == 2)
			{
				$q_type = 'Image';
				$question_text  = '';
				$question_image = $CFG->wwwroot.$question;
			}
			if($question_type == 3)
			{
				$q_type = 'Both';
				$question_text  = $additional_text;
				$question_image = $CFG->wwwroot.$question;
			}
			
			//------------------------------------------------------------//
			if($option_a_type == 1)
			{
				$option_A_type  = 'Text';
				$option_A_text  = isset($option_a) && $option_a!=''?$option_a:'--';
				$option_A_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_a_type == 2)
			{
				$option_A_type   = 'Image';
				$option_A_text   = '';
				$option_A_image  = $CFG->wwwroot.$option_a;
				$is_right_answer = '';
				
			}
			//----------------------------------------------------------------//
			if($option_b_type == 1)
			{
				$option_B_type  = 'Text';
				$option_B_text  = isset($option_b) && $option_b!=''?$option_b:'--';
				$option_B_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_b_type == 2)
			{
				$option_B_type   = 'Image';
				$option_B_text   = '';
				$option_B_image  = $CFG->wwwroot.$option_b;
				$is_right_answer = '';
			}
			
			//-------------------------------------------------------------//
			
			if($option_c_type == 1)
			{
				$option_C_type  = 'Text';
				$option_C_text  = isset($option_c) && $option_c!=''?$option_c:'--';
				$option_C_image = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
			}
			if($option_c_type == 2)
			{
				$option_C_type   = 'Image';
				$option_C_text   = '';
				$option_C_image  = $CFG->wwwroot.$option_c;
				$is_right_answer = '';
			}
			
			//-------------------------------------------------------------//
			
			if($option_d_type == 1)
			{
				$option_D_type   = 'Text';
				$option_D_text   = isset($option_d) && $option_d!=''?$option_d:'--';
				$option_D_image  = '-';//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				$is_right_answer = '';
				
			}
			if($option_d_type == 2)
			{
				$option_D_type   = 'Image';
				$option_D_text   = '';
				$option_D_image  = $CFG->wwwroot.$option_d;
				$is_right_answer = '';
			}
			
			$option_E_type   = 'Text';
			$option_E_text   = 'All of these';
			$option_E_image  = '-'; 
			$is_right_answer = '';
			//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
				
			$option_F_type   = 'Text';
			$option_F_text   = 'None of these';
			$option_F_image  = '-'; 
			$is_right_answer = '';
			//$CFG->wwwroot.'/upload/QuestionOfDay/no_record_found.gif';
			
			//---------------------------------------------------------------//
			
			$alldd  = array('questionid' => $questionid,
							'questiontype'   => $q_type,
							'question_text'  => $question_text,
							'question_image' => $question_image,
							'questiondate'   => $qdate);
			$aa[]   = $alldd;	
      $is_right_answer=(in_array("A", $c_p)?'Yes':'No');			
			$option1 = array('option_type'   => $option_A_type,
							 'option_text'   => $option_A_text,
							 'option_image'  => $option_A_image,
							 'is_right_anwser' => $is_right_answer 
							);
			$op1[]= $option1;
			$is_right_answer=(in_array("B", $c_p)?'Yes':'No');
			$option2 = array('option_type'   => $option_B_type,
							 'option_text'   => $option_B_text,
							 'option_image'  => $option_B_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op2[]= $option2;
			$is_right_answer=(in_array("C", $c_p)?'Yes':'No');
			$option3 = array('option_type'  => $option_C_type,
							 'option_text'   => $option_C_text,
							 'option_image'  => $option_C_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op3[]= $option3;
			$is_right_answer=(in_array("D", $c_p)?'Yes':'No');
			$option4 = array('option_type'   => $option_D_type,
							 'option_text'   => $option_D_text,
							 'option_image'  => $option_D_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op4[]= $option4;
			$is_right_answer=(in_array("E", $c_p)?'Yes':'No');
			$option5 = array('option_type'   => $option_E_type,
							 'option_text'   => $option_E_text,
							 'option_image'  => $option_F_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op5[]= $option5;
			$is_right_answer=(in_array("F", $c_p)?'Yes':'No');
			$option6 = array('option_type'   => $option_F_type,
							 'option_text'   => $option_F_text,
							 'option_image'  => $option_F_image,
							 'is_right_anwser' => $is_right_answer
							);
			$op6[]= $option6;
			$op = array_merge($op1,$op2,$op3,$op4);
			$dd['Question'] = $aa;
			$dd['Options']  = $op;
			return($dd);
		}
		else
		{
			$resultarray = array(
									'status'  => 1,
									'message' => 'Question Missing'
						);	
		}
	}
	
	public static function get_previousdayQuestion_returns()
	{
		return new external_single_structure(
            array(
                    
			 'Question' => new external_multiple_structure(
					new external_single_structure(
					array(
						'questionid'      => new external_value(PARAM_INT,'questionid'),
						'questiontype'    => new external_value(PARAM_TEXT,'questiontype'),
						'question_text'   => new external_value(PARAM_TEXT,'question_text'),
						'question_image'  => new external_value(PARAM_TEXT,'question_image'),
						'questiondate'    => new external_value(PARAM_RAW,'questiondate'),
				   
					))),
			'Options' => new external_multiple_structure(
				    new external_single_structure(
					array(
							'option_type'   => new external_value(PARAM_TEXT,'option_type'),
							'option_text'   => new external_value(PARAM_TEXT,'option_text'),
							'option_image'  => new external_value(PARAM_TEXT,'option_image'),
							'is_right_anwser' => new external_value(PARAM_TEXT,'is_right_anwser')
						))
					)
                )
        );
	}
	
	
	//----------------- code by yogita created date - 09-05-2020---//
	
	public static function get_attemptedQuestionAnswerStatus_parameters() 
	{
		return new external_function_parameters(
			array()
		);
	}
	
	public static function get_attemptedQuestionAnswerStatus()
	{
		global $DB,$USER;
		$resultarray = array();
		$today  = date("Y-m-d"); // todays date
		$thismonthstart = date('Y-m-01'); // start date of current month
		$thismonth_sql = "SELECT count(*) as total_question FROM mdl_question_of_day WHERE qdate >= '".$thismonthstart."' AND qdate <= '".$today."'"; 
		$sqlData       = $DB->get_record_sql($thismonth_sql);
		$thismonth_total_question = $sqlData->total_question;
			
		$month = date("Y-m");// here we get current month
		$thismonth_sql_ans = "SELECT answer FROM mdl_question_of_day_correct_answer WHERE mspin = '".$USER->username."' AND month = '".$month."'"; 
		$sqlData_1m = $DB->get_record_sql($thismonth_sql_ans);
		$thismonth_correct_ans = $sqlData_1m->answer;
		$score_this_month = $thismonth_total_question."-".$thismonth_correct_ans;
		// total question and total question answer given
		$rank_this_month  = number_format((($thismonth_correct_ans/$thismonth_total_question)*100),2);
		if(count($thismonth_total_question) > 0)
		{		
			$resultarray  = array('questioncount' => $thismonth_total_question,
								  'answercount'   => $thismonth_correct_ans,
								  'current_month_question_answer_status' => $thismonth_correct_ans."/".$thismonth_total_question
								);
		}						
	
		return $resultarray;
	}
	
	
	public static function get_attemptedQuestionAnswerStatus_returns()
	{
		return new external_single_structure(
            array(
				'questioncount' => new external_value(PARAM_INT,'questioncount'),
				'answercount'   => new external_value(PARAM_INT,'answercount'),
				'current_month_question_answer_status' => new external_value(PARAM_TEXT,'current_month_question_answer_status'),
			)
        );
	}
	
		
	//-------------------------------------------------------------------------------//
	
	public static function get_QODRanKStatus_parameters() 
	{
		return new external_function_parameters(
			array()
		);
	}
	
	public static function get_QODRanKStatus()
	{
	    global $USER,$DB,$CFG;
		$dd = $resultarray = $current = $last3 = $last6 = $last12 = $overall = array();
		$res_QuestionAnswer = $DB->get_record_sql("SELECT * FROM mdl_question_of_day_rank_report WHERE mspin = '".$USER->username."'");
		if(!empty($res_QuestionAnswer))
	    {	
		
			$id   			  = $res_QuestionAnswer->id;
			$score_this_month = $res_QuestionAnswer->score_this_month;
			$score_3_month    = $res_QuestionAnswer->score_3_month;
			$score_6_month    = $res_QuestionAnswer->score_6_month;
			$score_1_year     = $res_QuestionAnswer->score_1_year;
			$score_overall    = $res_QuestionAnswer->score_overall;
			
        	$alldd   = array('published_quiz'   => $score_this_month,
							 'attempted'  		=> $score_3_month,
							 'my_score'         => $score_6_month,
							 'quiz_rank'        => $score_1_year
							 );
			$current[]   = $alldd;
			
			$option1 = array('published_quiz'   => $score_this_month,
							 'attempted'  		=> $score_3_month,
							 'my_score'         => $score_6_month,
							 'quiz_rank'        => $score_1_year
							);
			$last3[]= $option1;
			
			$option2 = array('published_quiz'   => $score_this_month,
							 'attempted'  		=> $score_3_month,
							 'my_score'         => $score_6_month,
							 'quiz_rank'        => $score_1_year
							);
			$last6[]= $option2;
			
			$option3 = array('published_quiz'   => $score_this_month,
							 'attempted'  		=> $score_3_month,
							 'my_score'         => $score_6_month,
							 'quiz_rank'        => $score_1_year
							);
			$last12[]= $option3;
			
			$option4 = array('published_quiz'   => $score_this_month,
							 'attempted'  		=> $score_3_month,
							 'my_score'         => $score_6_month,
							 'quiz_rank'        => $score_1_year
							);
			$overall[]= $option4;
		
			$dd['Current_Month_Status'] = $current;
			$dd['Last_3_Month_Status']  = $last3;
			$dd['Last_6_Month_Status']  = $last6;
			$dd['Last_12_Month_Status'] = $last12;
			$dd['Overall_Month_Status'] = $overall;
			return($dd);
		}
		else
		{
			$resultarray = array('status'  => 0,'message' => 'You have not attempted questions till now.');	
			return($resultarray);
		}
			
	}
	
	
	public static function get_QODRanKStatus_returns()
	{
		return new external_single_structure
		(
            array(
                    
					 'Current_Month_Status' => new external_multiple_structure(
							new external_single_structure(
							array(
								'published_quiz'   => new external_value(PARAM_TEXT,'published_quiz'),
								'attempted'        => new external_value(PARAM_TEXT,'attempted'),
								'my_score'         => new external_value(PARAM_TEXT,'my_score'),
								'quiz_rank'        => new external_value(PARAM_TEXT,'quiz_rank'),
						   
							))),
					'Last_3_Month_Status' => new external_multiple_structure(
							new external_single_structure(
							array(
								'published_quiz'   => new external_value(PARAM_TEXT,'published_quiz'),
								'attempted'        => new external_value(PARAM_TEXT,'attempted'),
								'my_score'         => new external_value(PARAM_TEXT,'my_score'),
								'quiz_rank'        => new external_value(PARAM_TEXT,'quiz_rank'),
								))),
					'Last_6_Month_Status' => new external_multiple_structure(
							new external_single_structure(
							array(
								'published_quiz'   => new external_value(PARAM_TEXT,'published_quiz'),
								'attempted'        => new external_value(PARAM_TEXT,'attempted'),
								'my_score'         => new external_value(PARAM_TEXT,'my_score'),
								'quiz_rank'        => new external_value(PARAM_TEXT,'quiz_rank'),
								))),	
					'Last_12_Month_Status' => new external_multiple_structure(
							new external_single_structure(
							array(
								'published_quiz'   => new external_value(PARAM_TEXT,'published_quiz'),
								'attempted'        => new external_value(PARAM_TEXT,'attempted'),
								'my_score'         => new external_value(PARAM_TEXT,'my_score'),
								'quiz_rank'        => new external_value(PARAM_TEXT,'quiz_rank'),
								))),	
					'Overall_Month_Status' => new external_multiple_structure(
							new external_single_structure(
							array(
								'published_quiz'   => new external_value(PARAM_TEXT,'published_quiz'),
								'attempted'        => new external_value(PARAM_TEXT,'attempted'),
								'my_score'         => new external_value(PARAM_TEXT,'my_score'),
								'quiz_rank'        => new external_value(PARAM_TEXT,'quiz_rank'),
								)))		
				)
        );
	}
	//-------------------------------------------------------------------------//
	
	
	//------------------------------ New webservice ----------------------------//
	
	public static function get_mylistcourses_parameters()
	{
		return new external_function_parameters(
                array()
        );
    }
	
	public static function get_mylistcourses() 
	{
		global $USER, $DB ,$CFG;
		$onlinecourses = $DB->get_records_sql("select
				c.id as courseid,
				c.fullname as coursename,
				c.summary as summary,
				c.shortname as shortname,
				c.idnumber as idnumber,
				c.visible as visible,
				c.summaryformat as summaryformat,
				c.format,
				c.showgrades,
				c.lang,
				c.enablecompletion,
				c.category,
				b.path,
				c.startdate,
				c.enddate,
				(
				  select count(sa.id) as totalscorms
						from mdl_scorm_scoes as sa
						inner join mdl_scorm as sb ON(sb.id=sa.scorm)
						where sb.course=c.id and sa.scormtype='sco'
				) as totalscorms,
				(
				  select count(sa.id) as totaltracked
						FROM mdl_scorm_scoes_track as sa
						INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
						INNER JOIN mdl_course as sc on (sc.id=sb.course)
						WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='completed' || value='passed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
				) as totalcompleted,
				(
				  select count(sa.id) as totaltracked
						FROM mdl_scorm_scoes_track as sa
						INNER JOIN mdl_scorm as sb on (sb.id=sa.scormid)
						INNER JOIN mdl_course as sc on (sc.id=sb.course)
						WHERE (sa.element = 'cmi.core.lesson_status' || sa.element = 'cmi.completion_status') and (value='incomplete' || value='failed') AND sa.userid=a.userid AND sc.id=c.id  AND sc.category!=0
				) as totalincomplete,
			  'duedate',
			  (SELECT timestart FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol  where courseid=c.id and enrol='manual') AND userid=a.userid) as courseenrollmentdate,
			  (SELECT timeend FROM mdl_user_enrolments where enrolid=(select id from mdl_enrol where courseid=c.id and enrol='manual') AND userid=a.userid) as enrolenddate

			  FROM mdl_role_assignments  as a
			  INNER JOIN mdl_context     as b on(b.id=a.contextid)
			  INNER JOIN mdl_course      as c on(c.id=b.instanceid)
			  left outer join mdl_user   as d on(d.id=a.userid)
			  INNER JOIN mdl_course_categories as e on(e.id=c.category)
			  where b.contextlevel = 50 and userid = '".$USER->id."' and c.visible=1 and c.category>0 and e.name<>'assessment container' group by c.id ORDER BY c.id DESC");
			foreach ($onlinecourses as $onlinecourse) 
		    {
				    $id        = $onlinecourse->courseid;
				    $shortname = $onlinecourse->shortname;
					$fullname  = $onlinecourse->coursename;
					$idnumber  = $onlinecourse->idnumber;
					$visible   = $onlinecourse->visible;
					$summary   = $onlinecourse->summary;
					$summaryformat = $onlinecourse->summaryformat;
					$format     = $onlinecourse->format;
					$showgrades = $onlinecourse->showgrades;
					$lang       = $onlinecourse->lang;
					$enablecompletion = $onlinecourse->enablecompletion;
					$category  = $onlinecourse->category;
					
					$startdate = $onlinecourse->startdate;
					$enddate   = $onlinecourse->enddate;
					$enroldate = $onlinecourse->courseenrollmentdate;
					$enrolenddate = $onlinecourse->enrolenddate;
					$url       = $CFG->wwwroot.'/course/view.php?id='.$id;
					$progress = '';
					if($id == 12)
					{	
						$sqlass = $DB->get_record_sql("SELECT quiz.id as quizid,
						quiz.course,
						grade_items.id,
						grade_items.grademax,
						grade_items.grademin,
						grade_items.gradepass,
						grade_items.itemmodule
						FROM mdl_quiz AS quiz 
						INNER JOIN mdl_grade_items AS grade_items 
						ON grade_items.iteminstance = quiz.id
						WHERE quiz.course= '12' AND 
						quiz.id = '24' AND 
						grade_items.itemmodule = 'quiz'");
						$quizid     = $sqlass->quizid;
						$grademax   = $sqlass->grademax;
						$grademin   = $sqlass->grademin;
						$gradepass  = $sqlass->gradepass;
						
						$highestattempt = $DB->get_record_sql("SELECT max(attempt) as hattempt FROM mdl_quiz_attempts WHERE quiz = '".$quizid."' AND userid = '".$USER->id."'");
						$attempt = $highestattempt->hattempt;
						if(!empty($attempt))
						{	
							$sqlGrade = $DB->get_record_sql("SELECT sumgrades,timefinish FROM mdl_quiz_attempts WHERE quiz = '".$quizid."' AND userid = '".$USER->id."' AND state = 'finished' AND attempt = '".$attempt."'");
							$resGrade  = $sqlGrade->sumgrades;
							if($resGrade >= $gradepass)
							{
								$state1 = 'pass';
							}	
							else
							{
								$state1 = 'fail';
							}
							if($state1 == 'pass')
							{
								$progress = 'Completed';
								
							}		
							if($state1 == 'fail') 
							{
								$progress = 'Incomplete';
						
							}
						}
						else
						{
							$sql="SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = '10' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') ";
							$attemptdetails = $DB->get_record_sql($sql);
							if(empty($attemptdetails->value) || $attemptdetails->value == "")
							{
								$progress = 'Not Started';
								
							}
							else
							{
								$progress = 'Incomplete';
						
							}
						}	
					}
					else
					{
						$sqlScormid = $DB->get_record_sql("SELECT * FROM mdl_scorm WHERE course = '".$id."'");
						$scormid = $sqlScormid->id;
						$sqlScormTrack = "SELECT sb.value FROM {scorm_scoes_track} as sb WHERE sb.userid= ".$USER->id." AND sb.scormid = ".$scormid." AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') ";
						$resultScormTrack = $DB->get_record_sql($sqlScormTrack);
						if(empty($resultScormTrack->value) || $resultScormTrack->value == "")
						{
							$progress = "Not Started";
						}
						else
						{
							$status =  $resultScormTrack->value;
							if($status == 'completed' || $status == 'passed')
							{
								$progress = "Completed";
							}
                            if($status == 'incomplete' || $status == 'failed')
							{
								$progress = "Incomplete";
							}		
						}
					}	
					
					
					$result[] = array(
						'id' => $id,
						'shortname' => $shortname,
						'fullname'  => $fullname,
						'idnumber'  => $idnumber,
						'visible'   => $visible,
						'summary'   => $summary,
						'summaryformat' => $summaryformat,
						'format' => $format,
						'showgrades' => $showgrades,
						'lang' => $lang,
						'enablecompletion' => $enablecompletion,
						'category' => $category,
						'progress' => $progress,
						'startdate' => $startdate,
						'enddate' => $enddate,
						'enroldate' => $enroldate,
						'enrolenddate' => $enrolenddate,
						'url' => $url
					);
				   
		    }
			if(empty($result))
			{
				$result[] = array();
			}
			return $result;	
			  
	}

    public static function get_mylistcourses_returns() {
        return new external_multiple_structure(
            new external_single_structure(
                array(
          
					'id'   => new external_value(PARAM_INT, 'id of course', VALUE_OPTIONAL),
                    'shortname' => new external_value(PARAM_RAW, 'short name of course', VALUE_OPTIONAL),
                    'fullname'  => new external_value(PARAM_RAW, 'long name of course', VALUE_OPTIONAL),
                    'idnumber'  => new external_value(PARAM_RAW, 'id number of course', VALUE_OPTIONAL),
                    'visible'   => new external_value(PARAM_INT, '1 means visible, 0 means hidden course', VALUE_OPTIONAL),
                    'summary'   => new external_value(PARAM_RAW, 'summary', VALUE_OPTIONAL),
                    'summaryformat' => new external_format_value('summary', VALUE_OPTIONAL),
                    'format'    => new external_value(PARAM_PLUGIN, 'course format: weeks, topics, social, site', VALUE_OPTIONAL),
                    'showgrades' => new external_value(PARAM_BOOL, 'true if grades are shown, otherwise false', VALUE_OPTIONAL),
                    'lang'      => new external_value(PARAM_LANG, 'forced course language', VALUE_OPTIONAL),
                    'enablecompletion' => new external_value(PARAM_BOOL, 'true if completion is enabled, otherwise false',VALUE_OPTIONAL),
                    'category'     => new external_value(PARAM_INT, 'course category id', VALUE_OPTIONAL),
                    'progress'     => new external_value(PARAM_RAW, 'Progress percentage', VALUE_OPTIONAL),
                    'startdate'    => new external_value(PARAM_INT, 'Timestamp when the course start', VALUE_OPTIONAL),
                    'enddate'      => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enroldate'    => new external_value(PARAM_INT, 'Timestamp when the course end', VALUE_OPTIONAL),
                    'enrolenddate' => new external_value(PARAM_INT, 'Timestamp when the enrolment end', VALUE_OPTIONAL),
                    'url' => new external_value(PARAM_RAW,'course url', VALUE_OPTIONAL),
                )
            )
        );
    }
    	
	
	//------------------------------------------------------------------------------------------------------------//
	
	// code added by yogit on date - 17 oct 2020
	
	public static function get_userlmsperformance_parameters()
	{
		return new external_function_parameters(
				array()
		);
	}
	
	public static function get_userlmsperformance()
	{
		
		global $USER, $DB ,$CFG;
		//------------------------------------------------------------------------------------------------//
		$totalassignedcourse = "select count(a.id) as totalenroled 
						FROM mdl_role_assignments as a
						INNER JOIN mdl_user as u on(a.userid=u.id )
						INNER JOIN mdl_ums_employeemaster as emp on(u.id=emp.userid )
						INNER JOIN mdl_context e ON e.id = a.contextid
						INNER JOIN mdl_course as d on (d.id=e.instanceid)
						WHERE u.deleted=0 AND u.id = '".$USER->id."' AND d.category = 3 AND e.contextlevel=50 AND  d.visible = 1 ";
		$enrolledcourse = $DB->get_records_sql($totalassignedcourse);
		$allotedcourse = key($enrolledcourse);
		if($allotedcourse > 0)
		{
			$sqlStatus = "SELECT
				concat(a.id,'-',u.id) as tempid,
				d.id,
				d.fullname,
				d.startdate,
				emp.userid as empuid,
				emp.region_id,
				emp.dol,
							
			(SELECT 
					sb.value AS lession_status
				FROM
					mdl_scorm AS sa
						INNER JOIN
					mdl_scorm_scoes_track AS sb ON (sa.id = sb.scormid)
				WHERE
					sb.element = 'cmi.core.lesson_status'
						AND sb.attempt = 1
						AND (sb.value = 'completed'
						OR sb.value = 'passed'
						OR sb.value = 'failed'
						OR sb.value = 'incomplete')
						AND sb.userid = u.id
						AND sa.course = d.id ORDER BY sb.id desc limit 1
			) AS lession_status,
			(SELECT 
					sb.value AS completion_status
				FROM 
					mdl_scorm AS sa
						INNER JOIN
					mdl_scorm_scoes_track AS sb ON (sa.id = sb.scormid)
				WHERE
					sb.element = 'cmi.completion_status'
						AND sb.attempt = 1
						AND (sb.value = 'completed'
						OR sb.value = 'passed'
						OR sb.value = 'failed'
						OR sb.value = 'incomplete')
						AND sb.userid = u.id
						AND sa.course = d.id ORDER BY sb.id desc limit 1
			) AS completion_status
			
			FROM mdl_role_assignments as a
			LEFT JOIN mdl_user as u on(a.userid=u.id)
			INNER JOIN mdl_ums_employeemaster as emp on(u.id=emp.userid )
			INNER JOIN mdl_context as e on (e.id = a.contextid and e.contextlevel=50)
			INNER JOIN mdl_course as d on (d.id=e.instanceid) WHERE u.id = '".$USER->id."' AND d.category = 3 AND d.visible = 1";
			$courseRes = $DB->get_records_sql($sqlStatus, array());	
			$completed = 0;
			$incompleted = 0;
			$notstarted = 0;
			if(isset($courseRes) && !empty($courseRes))
			{
				foreach ($courseRes as $res)
				{	
					if(isset($res->lession_status) && !empty($res->lession_status))
					{
						$status =  $res->lession_status;
					}
					else if(isset($res->completion_status) && !empty($res->completion_status))
					{
						$status =  $res->completion_status;
					}
					else
					{
						$status = "Not Started";	
					}
					############ get Status ################
					if($status=='completed' || $status=='passed' )
					{
						$completed = $completed + 1;
					}
					else if($status=='incomplete' || $status == 'failed')
					{
						$incompleted = $incompleted + 1;
					}
					else
					{
						$notstarted = $notstarted + 1;
					} 
				}
			}
			$total_enrolled_course     = $allotedcourse;
			$incompleted_course_count  = $incompleted;
			$completed_course_count    = $completed;
			$not_started_course_count  = $notstarted;	
		}
		else
		{
			$total_enrolled_course     = 0;
			$incompleted_course_count  = 0;
			$completed_course_count    = 0;
			$not_started_course_count  = 0;
		}
		/*----------------------------------------------------------------------------------------------------*/
		
		$totalassignedassess = "select count(a.id) as totalenroled 
						FROM mdl_role_assignments as a
						INNER JOIN mdl_user as u on(a.userid=u.id )
						INNER JOIN mdl_ums_employeemaster as emp on(u.id=emp.userid )
						INNER JOIN mdl_context e ON e.id = a.contextid
						INNER JOIN mdl_course as d on (d.id=e.instanceid)
						WHERE u.deleted=0 AND u.id = '".$USER->id."' AND d.category = 2 AND e.contextlevel=50 AND d.visible = 1 ";
		$enrolledassessment = $DB->get_records_sql($totalassignedassess);
		$allotedassessement = key($enrolledassessment);
		if($allotedassessement > 0)
		{
			$assesments = $DB->get_records_sql("SELECT * FROM mdl_course WHERE category = 2 AND visible = 1");
			foreach($assesments as $assesment) 
			{
				$quizid   = $DB->get_field('quiz','id', array('course' => $assesment->id));
				$quizname = $DB->get_field('quiz','name', array('course' => $assesment->id));
				$sql = "SELECT a.id,
						a.state as state,
						a.sumgrades as score,
						g.grademax,
						g.grademin,
						g.iteminstance,
						g.itemmodule
						FROM mdl_quiz_attempts AS a
						INNER JOIN mdl_user AS b ON(a.userid=b.id)
						INNER JOIN mdl_role_assignments as ra ON ra.userid=b.id
                        INNER JOIN mdl_context e ON e.id = ra.contextid
						INNER JOIN mdl_ums_employeemaster emp ON emp.userid = b.id
						INNER JOIN mdl_grade_items AS g ON g.iteminstance = '".$quizid."'
						AND g.itemmodule='quiz' WHERE a.quiz='".$quizid."' AND a.attempt=(SELECT MAX(attempt) FROM mdl_quiz_attempts WHERE b.deleted =0 AND quiz = '".$quizid."' AND 
						e.instanceid='".$assesment->id."' AND userid = '".$USER->id."')" ;
				
				$quizattempts = $DB->get_records_sql($sql, array());
				$completed = 0;
				$not_started = 0;
				$incomplete = 0;
				foreach($quizattempts as $attempt)
				{
					
					if($attempt->state == 'finished')
					{
						$completed++;
					}
					else
					{
						$incomplete++;
					}
				}
			}	
			$not_started = $allotedassessement - ($completed + $incomplete);
			$total_enrolled_assessment     = $allotedassessement;
			$completed_assessment_count    = $completed;
			$incompleted_assessment_count  = $incomplete;
			$not_started_assessment_count  = $not_started ;
		}
		else
		{
			$total_enrolled_assessment     = 0;
			$completed_assessment_count    = 0;
			$incompleted_assessment_count  = 0;
			$not_started_assessment_count  = 0;
			
		}	
		/*-------------------------------------------------------------------------------------------------*/
		
		$result = array(
						'total_enrolled_course'        => $total_enrolled_course,
						'completed_course_count'       => $completed_course_count,
						'incompleted_course_count'     => $incompleted_course_count,
						'not_started_course_count'     => $not_started_course_count,
						'total_enrolled_assessment'    => $total_enrolled_assessment,
						'completed_assessment_count'   => $completed_assessment_count,
						'incompleted_assessment_count' => $incompleted_assessment_count,
						'not_started_assessment_count' => $not_started_assessment_count
					);
	   	return $result;		
	}	
	
	public static function get_userlmsperformance_returns()
	{
		return new external_single_structure(
		array(
  			'total_enrolled_course'  => new external_value(PARAM_RAW, 'Total Enrolled Course Count ', VALUE_OPTIONAL),
			'completed_course_count' => new external_value(PARAM_RAW, 'Total Completed Course Count', VALUE_OPTIONAL),
			'incompleted_course_count'=> new external_value(PARAM_RAW, 'Total Incompleted Course Count', VALUE_OPTIONAL),
			'not_started_course_count' => new external_value(PARAM_RAW, 'Total Not Started Course Count', VALUE_OPTIONAL),
			'total_enrolled_assessment'=> new external_value(PARAM_RAW, 'Total Enrolled Assessment Count ', VALUE_OPTIONAL),
			'completed_assessment_count' => new external_value(PARAM_RAW, 'Total Completed Assessment Count', VALUE_OPTIONAL),
			'incompleted_assessment_count'=> new external_value(PARAM_RAW, 'Total Incompleted Assessment Count', VALUE_OPTIONAL),
			'not_started_assessment_count'=> new external_value(PARAM_RAW, 'Total Not Started Assessment Count', VALUE_OPTIONAL),
			)
        );
	}	

}
