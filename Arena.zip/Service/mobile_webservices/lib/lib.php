<?php
error_reporting(E_ALL);
require_once('../../../config.php');
/**
Developer Name: Vinod Gadade
This File contains generic function which can be used in overall lms
Before changing any function check reference of this file
*/

class helperFuctions {
	
	/**
	This function returns the status of scorm limited to 3 attempts only
	*/
	function getScormStatus($userid,$scormid) {
		
		global $DB;
		
		$total_attempt = $DB->get_records_sql("SELECT * FROM mdl_scorm_scoes_track as sb WHERE sb.userid = '".$userid."' AND sb.scormid = '".$scormid."' AND (sb.element = 'cmi.core.lesson_status' OR sb.element = 'cmi.completion_status') AND sb.attempt <= 3");
		$courseStatus = '';
		$i = 1;
		if(!empty($total_attempt)){
			foreach($total_attempt as $val)
				{
					if($val->value == 'completed' || $val->value == 'passed')
					{
						$courseStatus = "Completed";
						break;
					}
					else
					{
						$courseStatus = "Incomplete";
					}
					if($i >=3){
						$courseStatus = "Completed";
					}
					$i++;
				}
		}else{
			$courseStatus = 'Not Started';
		}
		return $courseStatus;
	}
	
	function enrolledCourses ($username) {
		global $DB,$CFG;
		$userDetail = $DB->get_record_sql('SELECT id FROM {user} WHERE username = ?',array($username));
		$userid = $userDetail->id;
		$courses = enrol_get_users_courses($userid, false, 'id, shortname, fullname, idnumber, visible,summary, summaryformat, format, showgrades, lang, enablecompletion, category, startdate, enddate');
       
        foreach ($courses as $key => $course) { 
          if($course->category == 3){
			if($course->visible == 1){
				$checkenrollmentmethods = $DB->get_records_sql('SELECT * FROM {enrol} WHERE courseid = ?',array($course->id));
		
				foreach ($checkenrollmentmethods as $key => $checkenrollmentmethod) {
				$enrollmentdate = $DB->get_record_sql('SELECT * FROM {user_enrolments} WHERE enrolid = ? AND userid = ?',array($checkenrollmentmethod->id,$userid));
					if(!empty($enrollmentdate)){
						$courseenrollmentdate = $enrollmentdate->timecreated;
						$enrolenddate = $enrollmentdate->timeend;
					}                                
				}
			
				$url = $CFG->wwwroot.'/course/view.php?id='.$course->id;
				//@yogita for prarambh please add your code. or we can discuss the approach. 
				if($course->id == 12){
					$progress = 'Yogita add Your Code';
				}else{
					$scorms = $DB->get_records_sql("SELECT id FROM {scorm} WHERE course = ? ORDER BY id ASC",array($course->id));
					$progress = '';
					foreach($scorms as $key => $scorm){
						$progress = $this->getScormStatus($userid,$scorm->id);
					}
				}
				$result[] = array(
					'id' => $course->id,
					'shortname' => $course->shortname,
					'fullname' => $course->fullname,
					'idnumber' => $course->idnumber,
					'visible' => $course->visible,
					'summary' => $course->summary,
					'summaryformat' => $course->summaryformat,
					'format' => $course->format,
					'showgrades' => $course->showgrades,
					'lang' => clean_param($course->lang, PARAM_LANG),
					'enablecompletion' => $course->enablecompletion,
					'category' => $course->category,
					'progress' => $progress,
					'startdate' => $course->startdate,
					'enddate' => $course->enddate,
					'enroldate' => $courseenrollmentdate,
					'enrolenddate' => $enrolenddate,
					'url' => $url,
				);
			}
          }
        }
		if(empty($result)){
			$result[] = array();
		}
        return $result;
	}
}

$classObject = new helperFuctions();
$username = $_GET['username'] ? $_GET['username'] : 'admin';

$mycourses = $classObject->enrolledCourses($username);
echo json_encode($mycourses);
?>