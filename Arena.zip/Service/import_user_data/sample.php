<?php
$allinput = json_decode(file_get_contents('php://input'), true);
if(@filter_var($allinput['mspin'], FILTER_VALIDATE_INT) && $allinput['image']){
	define('AJAX_SCRIPT', true);
	define('REQUIRE_CORRECT_ACCESS', true);
	define('NO_MOODLE_COOKIES', true);
	require_once('../config.php');
	global $DB;
	$msg->msg='can not be empty mspin, image';
	$msg = new stdClass;
	$msg->status=false;
	 if($_SERVER['REQUEST_METHOD']=='POST'){
		##Start for image upload only
	 	/*$curl = curl_init();
	 	curl_setopt_array($curl, array(
	 		CURLOPT_URL => "http://20.204.83.30/verify",
	 		CURLOPT_RETURNTRANSFER => true,
	 		CURLOPT_ENCODING => "",
	 		CURLOPT_MAXREDIRS => 10,
	 		CURLOPT_TIMEOUT => 0,
	 		CURLOPT_FOLLOWLOCATION => true,
	 		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	 		CURLOPT_CUSTOMREQUEST => "POST",
	 		CURLOPT_POSTFIELDS => $postData,
	 	));
	 	$response = curl_exec($curl);
	 	curl_close($curl);
	 	$output = @json_decode($response, true);*/
	 	if(@$output['verified']==true){
	 		$is_verified='1';
	 	}else{
	 		$is_verified='0';
	 	}
	 	$qin="INSERT INTO face_register_img (mspin, img) VALUES ('".$allinput['mspin']."', '".$allinput['image']."')";
	 	$DB->execute($qin);
	 }
}
?>