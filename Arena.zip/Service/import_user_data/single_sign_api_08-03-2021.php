<?php
//here need to check timezone//
define('AJAX_SCRIPT', true);
define('REQUIRE_CORRECT_ACCESS', true);
define('NO_MOODLE_COOKIES', true);
date_default_timezone_set("UTC");
require_once('../config.php');
$mspin = required_param('MSPIN', PARAM_RAW);
$macid = required_param('MACID', PARAM_RAW);
if(!$DB->record_exists('ums_employeemaster',array('code'=>$mspin,'deleted' => 0))) 
{
		$errorobject = new stdClass;
        $errorobject->exception = 'moodle_exception';
        $errorobject->errorcode = 902;
        $errorobject->error = 'MSPIN not found';
		echo json_encode($errorobject);
		die();
}
else
{		

		if ($macid == '' || empty($macid)) {

			$rtn = array();
			$rtn['status'] = 'FALSE';
			$rtn['ErrorCode'] = 1;
			$rtn['ErrorMessage'] = 'Invalid MacID';
			echo json_encode($rtn);
		
		} else {

			/*$verifyUserMacID = $DB->get_record_sql('SELECT username, macid FROM mdl_user WHERE macid = "'.$macid.'" AND deleted = 0');

			if ($verifyUserMacID->macid && $verifyUserMacID->username == $mspin) {*/

				$chkloginalready = $DB->get_record_sql('SELECT * FROM mdl_user WHERE username = "'.$mspin.'" AND deleted = 0');
				if($chkloginalready->macid == '' || $chkloginalready->macid == $macid)
				{	

					$verifyUserMacID = $DB->get_record_sql('SELECT username, macid FROM mdl_user WHERE macid = "'.$macid.'" AND deleted = 0');

					if (!empty($verifyUserMacID->macid) && $verifyUserMacID->username != $mspin) {

						$rtn = array();
						$rtn['status'] = 'FALSE';
						$rtn['ErrorCode'] = 1;
						$rtn['ErrorMessage'] = 'Device not authorized for your login id';
						echo json_encode($rtn);
						exit;
					}

					$sql = 'UPDATE {user} SET macid = "'.$macid.'" WHERE username = "'.$username.'"';
					$DB->execute($sql);	
					
					$updatetbl = 'UPDATE {ums_device_information} SET macid = "'.$macid.'" WHERE  mspin = "'.$username.'"';
					$DB->execute($updatetbl);
					
					$phone = $DB->get_field_sql('SELECT phone1 FROM {user} where username = "'.$mspin.'" AND deleted = 0');
					$userid = $DB->get_field('user','id',array('username'=>$mspin));
					$channels_id = $DB->get_field('ums_employeemaster','channels_id',array('code'=>$mspin));
					$i = 0; //counter
					$pin = ""; //our default pin is blank.
					while($i < 4)
					{
						$pin .= mt_rand(1, 9);
						$i++;
					}
					$record = new stdClass();
					$record->userid = $userid;
					$record->otp = $pin;
					$record->timesent = time();
					$record->phone = $phone;
					$insert_record = $DB->insert_record('otp',$record);
					if($insert_record)
					{
						$message = 'Your%20One%20Time%20Password%20is%20'.$pin;
						$to = '91'.trim($phone);
						$url = 'https://sms4.tatacommunications.com:3821/sendsms?username=m_msil_lapp&password=w8P3CxnF&from=MSILOT&to='.$to.'&text='.$message;
						$ch = curl_init();
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch,CURLOPT_URL, $url);
						$result = curl_exec($ch);
						curl_close($ch);
						$rtn = array();
						$rtn['status'] = 'TRUE';
						$rtn['userid'] = $userid;
						$rtn['pin'] = $pin;
						$rtn['phone'] = $phone;
						$rtn['channels_id'] = $channels_id;
						$rtn['ErrorCode'] = 0;
						$rtn['ErrorMessage'] = 'An otp sent on your registered mobile number';
						echo json_encode($rtn);
					}	
				}
			    else
				{
					$chkloginalready = $DB->get_record_sql('SELECT * FROM mdl_user WHERE username = "'.$mspin.'" AND deleted = 0');
					if($chkloginalready->macid != $macid)
					{
						$rtn = array();
						$rtn['status'] = 'FALSE';
						$rtn['ErrorCode'] = 1;
						$rtn['ErrorMessage'] = 'Device not authorized for your login ID';
						echo json_encode($rtn);
					}
				}

			/*} else {
			
				$rtn = array();
				$rtn['status'] = 'FALSE';
				$rtn['ErrorCode'] = 1;
				$rtn['ErrorMessage'] = 'Device not authorized for your login ID';
				echo json_encode($rtn);				

			}	*/	

		

		}

			
		
}	
?>		