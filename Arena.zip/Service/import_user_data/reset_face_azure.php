 <?php
 require_once('../config.php');
 /* NOTE : Ref. taken from api.php */
 global $DB;
 $mspin = required_param('mspin',  PARAM_RAW);
 $source = required_param('source', PARAM_TEXT);
 if(@$mspin!=""){
 	$qurl = 'SELECT code,region_id FROM {ums_employeemaster} WHERE code="'.$mspin.'"';
 	$fetchq=$DB->get_record_sql($qurl);
    if(@$fetchq->code==""){
    	echo "Mspin not valid";
    	die();
    }
	$url="20.207.201.226:8080/delete_record?mspin=".$mspin."&source=".$source;
 	?>
 	<script>
 	window.open("<?php echo $url?>", '_blank');
 	</script>
 	<?php
 }else{
 	echo "Please enter mspin";
 }
 ?>