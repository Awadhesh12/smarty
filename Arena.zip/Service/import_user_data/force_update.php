 <?php
 define('AJAX_SCRIPT', true);
 define('REQUIRE_CORRECT_ACCESS', true);
 define('NO_MOODLE_COOKIES', true);
 require_once('../config.php');

 /* NOTE : Ref. taken from api.php */

 global $DB;

 $platform = required_param('platform', PARAM_RAW);
 $version = required_param('version', PARAM_RAW);
 $mspin=optional_param('mspin',null,PARAM_RAW);

 $v = array();
 $sql = 'SELECT * FROM {app_version_check} where type = "'.$platform.'"';	   
 $record = $DB->get_record_sql($sql);
 if($mspin!=""){
 	$fus=$DB->get_record_sql("SELECT face_id_user, is_reverified, is_verified, is_monthly_reverified,registration_skip, region_id FROM mdl_ums_employeemaster WHERE code='".@$mspin."'");
 }
 $v['is_registered']  = false;
 $v['is_reverified']  = false;
 $v['is_month_reverified'] = false;
 $v['registration_skip'] = @$fus->registration_skip;
 if(@$v['registration_skip']==""){
 	$v['registration_skip'] = "no";
 }
 if(@$fus->face_id_user!=""){
 	$v['is_registered']  = @$fus->face_id_user==1?true:false;
 	$v['is_reverified']  = @$fus->is_verified==1?true:false;
 	$v['is_month_reverified'] = @$fus->is_monthly_reverified==1?true:false;
 }

##Start for this code handle multiple server
 $server1=[1,2,6,19];
 $server2=[4,16,5];
 $server3=[7,3,8,11];
 $server4=[13,17,12];
 $server5=[18,14,10,15,9];
 $serverip="http://20.207.201.226";
 $serverip1="http://20.207.201.226";
 $serverip2="http://20.204.42.30";
 $serverip3="http://20.204.112.1";
 $serverip4="http://20.204.113.239";
 $serverip5="http://20.204.114.133";

 if(@in_array($fus->region_id, $server1)){
 	$v['face_base_url'] = $serverip1;
 	$v['face_base_add_url'] = $serverip1."/add_face";
 	$v['face_base_verify_url'] = $serverip1."/verify";
 	$v['face_quiz_verify_url'] = $serverip1;
 	$v['face_quiz_verify_ios_url'] = $serverip1."/quiz_course_face_verify";
 }elseif(@in_array($fus->region_id, $server2)){ 		
 	$v['face_base_url'] = $serverip2;
 	$v['face_base_add_url'] = $serverip2."/add_face";
 	$v['face_base_verify_url'] = $serverip2."/verify";
 	$v['face_quiz_verify_url'] = $serverip2;
 	$v['face_quiz_verify_ios_url'] = $serverip2."/quiz_course_face_verify";
 }elseif(@in_array($fus->region_id, $server3)){ 		
 	$v['face_base_url'] = $serverip3;
 	$v['face_base_add_url'] = $serverip3."/add_face";
 	$v['face_base_verify_url'] = $serverip3."/verify";
 	$v['face_quiz_verify_url'] = $serverip3;
 	$v['face_quiz_verify_ios_url'] = $serverip3."/quiz_course_face_verify";
 }elseif(@in_array($fus->region_id, $server4)){
 	$v['face_base_url'] = $serverip4;
 	$v['face_base_add_url'] = $serverip4."/add_face";
 	$v['face_base_verify_url'] = $serverip4."/verify";
 	$v['face_quiz_verify_url'] = $serverip4;
 	$v['face_quiz_verify_ios_url'] = $serverip4."/quiz_course_face_verify";
 }elseif(@in_array($fus->region_id, $server5)){
 	$v['face_base_url'] = $serverip5;
 	$v['face_base_add_url'] = $serverip5."/add_face";
 	$v['face_base_verify_url'] = $serverip5."/verify";
 	$v['face_quiz_verify_url'] = $serverip5;
 	$v['face_quiz_verify_ios_url'] = $serverip5."/quiz_course_face_verify";
 }else{	 		
 	$v['face_base_url'] = $serverip5;
 	$v['face_base_add_url'] = $serverip5."/add_face";
 	$v['face_base_verify_url'] = $serverip5."/verify";
 	$v['face_quiz_verify_url'] = $serverip5;
 	$v['face_quiz_verify_ios_url'] = $serverip5."/quiz_course_face_verify";
 }
 
  $usersList=["88888888", "888886", "262626", "90825", "72765", "208309", "452639", "404040", "202702", "685637", "863755", "5464"];
 if(in_array($mspin, $usersList)){
 	$serverlessip="https://msil-faceapp.azurewebsites.net";
 	$v['face_base_url'] = $serverlessip;
 	$v['face_base_add_url'] = $serverlessip."/add_face";
 	$v['face_base_verify_url'] = $serverlessip."/verify";
 	$v['face_quiz_verify_url'] = $serverlessip;
 	$v['face_quiz_verify_ios_url'] = $serverlessip."/quiz_course_face_verify";
 }
 ##End for this code handle multiple server
 $v['status']='';
 $v['url']='';
 if(!empty($record)){
 	if($record->version==''){
 		if($version==$record->current_app_version){
 			$v['status']='Verified';
 		}else{
 			$v['status']='Upgrade';
 			$v['url']=$record->url;
 		}
 	}else{
 		if($record->current_app_version>$version){
 //check regionwise criteria
 			$v['status']='Upgrade';
 			$v['url']=$record->url;
 		}else{
 			$v['status']='Verified';	
 		}
 	}
 }else{
 	$v['status']='Error';
 }
 echo json_encode($v);