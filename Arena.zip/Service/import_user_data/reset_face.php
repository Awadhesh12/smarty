 <?php
 header("Access-Control-Allow-Origin: http://20.204.83.30");
 define('AJAX_SCRIPT', true);
 define('REQUIRE_CORRECT_ACCESS', true);
 define('NO_MOODLE_COOKIES', true);
 require_once('../config.php');
 /* NOTE : Ref. taken from api.php */
 global $DB;
 $mspin = required_param('mspin', PARAM_RAW);
 if(@$mspin!=""){
 	$ur = 'UPDATE {ums_employeemaster} SET face_id_user= 0 WHERE code="'.$mspin.'"';
 	$DB->execute($ur);
 	$qurl = 'SELECT code,region_id FROM {ums_employeemaster} WHERE code="'.$mspin.'"';
 	$fetchq=$DB->get_record_sql($qurl);
    if(@$fetchq->code==""){
    	echo "Mspin not valid";
    }
 	$server1=[1,2,6,19];
 	$server2=[4,16,5];
 	$server3=[7,3,8,11];
 	$server4=[13,17,12];
 	$server5=[18,14,10,15,9];
 	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); // return response as a string
 	if(in_array($fetchq->region_id, $server1)){
	curl_setopt($ch, CURLOPT_URL, "http://20.207.201.226/delete_record?ids=".$mspin."_all"); // the URL
 	}
 	if(in_array($fetchq->region_id, $server2)){
	curl_setopt($ch, CURLOPT_URL, "http://20.204.42.30/delete_record?ids=".$mspin."_all"); // the URL
 	}
 	if(in_array($fetchq->region_id, $server3)){
	curl_setopt($ch, CURLOPT_URL, "http://20.204.112.1/delete_record?ids=".$mspin."_all"); // the URL
 	}
 	if(in_array($fetchq->region_id, $server4)){
	curl_setopt($ch, CURLOPT_URL, "http://20.204.113.239/delete_record?ids=".$mspin."_all"); // the URL
 	}
 	if(in_array($fetchq->region_id, $server5)){
 		echo "http://20.204.114.133/delete_record?ids=".$mspin."_all";
	curl_setopt($ch, CURLOPT_URL, "http://20.204.114.133/delete_record?ids=".$mspin."_all"); // the URL
 	}
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE); // verify SSL info
	$result = curl_exec($ch);
	print_r($result);
 }else{
 	echo "Please enter mspin";
 }
 ?>