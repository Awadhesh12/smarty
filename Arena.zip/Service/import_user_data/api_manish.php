<?php
define('AJAX_SCRIPT', true);
define('REQUIRE_CORRECT_ACCESS', true);
define('NO_MOODLE_COOKIES', true);
date_default_timezone_set("UTC");
require_once('../config.php');
require_once('custom_methods.php');
$mspin = required_param('MSPIN', PARAM_RAW);
global $DB;
$error_count=0;
$flag=0;
$error_msg="";
if(!$DB->record_exists('ums_employeemaster',array('code'=>$mspin,'deleted' => 0))) 
{
	$m="Tried To login. Not found in iLearn";
	$sql="insert into mdl_data_log set mspin='".$mspin."',msg='".$m."',created='".time()."'";
	$DB->execute($sql);
		$error_count=$error_count+1;
		$error_msg.='1. MSPIN not found in iLearn<br>';
			
		$checkdump=$DB->get_record_sql("select * from dms_data_msil where MSPIN='".$mspin."'");
		if(empty($checkdump)) 
		{
		
		$m="Tried To login. Not found in DMS Dump";
		$sql="insert into mdl_data_log set mspin='".$mspin."',msg='".$m."',created='".time()."'";
		$DB->execute($sql);
		$error_count=$error_count+1;
		$error_msg.='2. Tried To login. Not found in DMS Dump<br>';
			
		}
		else
		{
		
		
		$m="MSPIN found in DMS Dump";
		echo $sql="insert into mdl_data_log set mspin='".$mspin."',msg='".$m."',created='".time()."'";
		$DB->execute($sql);
		$d = $DB->get_record_sql("SELECT * FROM dms_data_msil where MSPIN='".$mspin."'");
		print_r($d);
/*		
		if (!empty($d))
		{
			$emp_categ           = trim($d->emp_categ);
            $dealer_type         = trim($d->dealer_type);
			if(($dealer_type == '2S' || $dealer_type == '3S') && $emp_categ == 'V')
			{
				
				$username_empcode = trim($d->MSPIN);
				$fullname		  = explode(" ", clean(trim($d->EMP_NAME)));
					$firstname		  =	array_shift($fullname);
					$lastnameT        = '';
					foreach($fullname as $dd){
						$lastnameT .= $dd.' ';
					}
					$lastname		  = $lastnameT!=''?trim($lastnameT):'-';

					$gender           = trim($d->EMP_SEX)!=''?trim($d->EMP_SEX):'';
					$email            = trim($d->EMP_EMAIL_ID)!=''?clean(trim($d->EMP_EMAIL_ID)):'truevaluenooreply@armezo.com';
					$phone            = trim($d->MOBILE)!=''?trim($d->MOBILE):'';
					
					$doj  	 	      = trim($d->EMP_JOINING_DATE)!=''?date('Y-m-d H:i:s',strtotime(trim($d->EMP_JOINING_DATE))):'0000-00-00';
					
					$dol              = trim($d->EMP_LEAVING_DATE)!=''?date('Y-m-d H:i:s',strtotime(trim($d->EMP_LEAVING_DATE))):'0000-00-00';
					if($dol == '0001-01-01 00:00:00')
					{
						$dol = '0000-00-00';
					}	
					
					$designation_id   = getIDFromFieldName(trim($d->EMP_DESG_CD) , "ums_designations","d_name","d","d_desc",trim($d->EMP_DESG));
					
					$sub_designation_id   = trim($d->SUB_DESG_CD)!=''?getIDFromFieldName(trim($d->SUB_DESG_CD) , "ums_sub_designations","sd_name","sd","designations_id",$designation_id):0;
					
					$tl_mspin = trim($d->TL_MSPIN)!=''?trim($d->TL_MSPIN):'-';
					
					if(trim($d->EMP_APPROVE) == 'A'){
						$assgment_status_type = 0;
					}else{
						$assgment_status_type = 1;
					}
					
					$modified_date 		= trim($d->MODIFIED_DATE)!=''?date('Y-m-d H:i:s',strtotime(trim($d->MODIFIED_DATE))):'0000-00-00';
					
					$channels_id = $region_id = $state_id = $city_id =  $location_id =0;
					$outletcodefromsheet = trim($d->DEALER_MAP_CD);
					$loccd				 = trim($d->LOC_CD);
					$outlet_idarr = $DB->get_record_sql("SELECT id,outlet_group_id, region_id FROM mdl_ums_outlet WHERE o_code = '".$outletcodefromsheet."' AND loc_cd = '".$loccd."' AND deleted =0 AND status =0");
					$outletcodefromsheet_new = trim($d->DEALER_MAP_CD).'-'.trim($d->LOC_CD);
					if(!empty($outlet_idarr))
					{	
						$outlet_id	= $outlet_idarr->id;
						$dlermster = $DB->get_record_sql("SELECT * FROM mdl_ums_dealermaster WHERE o_id = '".$outlet_id."'  AND og_id = '".$outlet_idarr->outlet_group_id."' AND region_id = '".$outlet_idarr->region_id."' AND o_status = 0");
						if(count($dlermster) > 0)
						{
							$channels_id = $dlermster->c_id;
							$region_id   = $dlermster->region_id;
							$state_id    = $dlermster->state_id;
							$city_id     = $dlermster->city_id;
							$location_id = $dlermster->location_id;
						}
						
					}	
					else
					{
						$outlet_id = 0;
					}
					$chname = "";
					if($channels_id==1){
						$chname = 'NRM-ARENA';
					}
					if($channels_id==2){
						$chname = 'EXE-NEXA';
					}
					if($channels_id==3){
						$chname = 'COM-True Value';
					}
					if($channels_id==4){
						$chname = 'MDS';
					}
					$deleted = 0;
						
						
						if(!$DB->record_exists('user', array('username'=>$username_empcode))){
							
							$hashedpassword = hash_internal_user_password($username_empcode);
							$record = new stdClass();
							$record->username    = $username_empcode;
							$record->firstname   = $firstname;
							$record->lastname    = $lastname;
							$record->confirmed   = 1;
							$record->mnethostid  = 1;
							$record->email       = $email;
							$record->password    = $hashedpassword;
							$record->suspended   = $assgment_status_type;
							$record->phone1      = $phone;
							$record->deleted     = $deleted;
							$record->timecreated = time();
							
							$lastinsertid        = $DB->insert_record('user',$record);
							$insert = "INSERT INTO {ums_employeemaster} set userid = '".$lastinsertid."', code='".$username_empcode."', password='".$username_empcode."',phone = '".$phone."', doj='".$doj."', dol = '".$dol."', gender = '".$gender."', designation_id = ".$designation_id.", sub_designation_id = ".$sub_designation_id.", channels_id = '".$channels_id."', user_type_id = '', outlet_id = '".$outlet_id."', region_id = '".$region_id."', state_id = '".$state_id."', city_id = '".$city_id."', location_id = '".$location_id."', tl_mspin_no = '".$tl_mspin."', created='".date("Y-m-d H:i:s")."',updated='".date("Y-m-d H:i:s")."', outletcode_from_sheet='".$outletcodefromsheet_new."', modified_date_from_cron = '".$modified_date."', deleted = ".$deleted."  ";
							$DB->execute($insert,array());
							
							$m="MSPIN added in iLearn";
							$sql="insert into mdl_data_log set mspin='".$mspin."',msg='".$m."',created='".time()."'";
							$DB->execute($sql);
							$flag=1;
							
						}
						else{
							
							$userid = $DB->get_field("user","id",array("username"=>trim($d->MSPIN)));
							
							$Eoutlet_id = $DB->get_field("ums_employeemaster","outlet_id",array("code"=>trim($d->MSPIN)));
							
							if($dol!='' && $dol!='0000-00-00' && $dol!='0001-01-01 00:00:00')
							{
								
								if($Eoutlet_id == $outlet_id)
								{
									$deleted = 1;
									$assgment_status_type = 1;
							    }
								else
								{
									$deleted = 0;
									$assgment_status_type = 0;
									continue;
								}
							}else
							{
								$deleted = 0;
								$assgment_status_type = 0;
							}
							
							$recordUpdtUser = new stdClass();
							$recordUpdtUser->id    		 = $userid;
							$recordUpdtUser->firstname   = $firstname;
							$recordUpdtUser->lastname    = $lastname;
							$recordUpdtUser->email       = $email;
							$recordUpdtUser->suspended   = $assgment_status_type;
							$recordUpdtUser->phone1      = $phone;
							$recordUpdtUser->deleted     = $deleted;
							$recordUpdtUser->timemodified     = time();
							
							$DB->update_record('user',$recordUpdtUser);
							
							$updateempmaster = 'UPDATE mdl_ums_employeemaster SET phone = "'.$phone.'", doj="'.$doj.'", dol = "'.$dol.'", gender = "'.$gender.'", designation_id = '.$designation_id.', sub_designation_id = '.$sub_designation_id.', channels_id = "'.$channels_id.'", user_type_id = "", outlet_id = "'.$outlet_id.'", region_id = "'.$region_id.'", state_id = "'.$state_id.'", city_id = "'.$city_id.'", location_id = "'.$location_id.'", tl_mspin_no = "'.$tl_mspin.'", updated="'.date("Y-m-d H:i:s").'", outletcode_from_sheet="'.$outletcodefromsheet_new.'", modified_date_from_cron = "'.$modified_date.'", deleted = "'.$deleted.'"  WHERE userid = '.$userid.'';
							$DB->execute($updateempmaster,array());
							
							$m="MSPIN updated in iLearn";
							$sql="insert into mdl_data_log set mspin='".$mspin."',msg='".$m."',created='".time()."'";
							$DB->execute($sql);
							$flag=1;
							
						}
						
			}
		}
		
*/
		//send otp now
			if($flag==1){
						$phone = $DB->get_field_sql('SELECT phone1 FROM {user} where username = "'.$mspin.'" AND deleted = 0');
						$userid = $DB->get_field('user','id',array('username'=>$mspin));
					$channels_id = $DB->get_field('ums_employeemaster','channels_id',array('code'=>$mspin));
					$i = 0; //counter
					$pin = ""; //our default pin is blank.
					while($i < 4)
					{
						$pin .= mt_rand(1, 9);
						$i++;
					}
					$record = new stdClass();
					$record->userid = $userid;
					$record->otp = $pin;
					$record->timesent = time();
					$record->phone = $phone;
					$insert_record = $DB->insert_record('otp',$record);
					if($insert_record)
					{
						$message = 'Your%20One%20Time%20Password%20is%20'.$pin;
						
						$to = '91'.trim($phone);
						$url = 'https://sms4.tatacommunications.com:3821/sendsms?username=m_msil_lapp&password=w8P3CxnF&from=MSILOT&to='.$to.'&text='.$message;
						//$url = 'https://sms3.tatacommunications.com:3801/sendsms?username=m_msil_lapp&password=w8P3CxnF&from=MSILOT&to='.$to.'&text='.$message;
						
						$ch = curl_init();
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch,CURLOPT_URL, $url);
						$result = curl_exec($ch);
						//print_r($result);
						
						curl_close($ch);
						$rtn = array();
						$rtn['status'] = 'TRUE';
						$rtn['userid'] = $userid;
						$rtn['pin'] = $pin;
						$rtn['phone'] = $phone;
						$rtn['channels_id'] = $channels_id;
						$rtn['ErrorCode'] = 0;
						$rtn['ErrorMessage'] = 'An otp sent on your registered mobile number';
						echo json_encode($rtn);
						
					}	
		}
			//send otp end
		}
		if($error_count>0)
		{
		$rtn = array();
		$rtn['status'] = 'FALSE'
		$rtn['userid'] = $userid;
		$rtn['pin'] = $pin;
		$rtn['phone'] = $phone;
		$rtn['channels_id'] = $channels_id;
		$rtn['ErrorCode'] = $error_count;
		$rtn['ErrorMessage'] = $error_msg;
		echo json_encode($rtn);
		}
		
}
else
{
	/*$chkloginalready = $DB->get_record_sql('SELECT * FROM mdl_ums_device_information WHERE mspin = ?',array($mspin));
	if($chkloginalready->is_logout == 0 && $chkloginalready->logout_date =='0000-00-00 00:00:00')
	{
		$rtn = array();
		$rtn['status'] = 'FALSE';
		$rtn['ErrorCode'] = 1;
		$rtn['ErrorMessage'] = 'MSPIN already login in other device';
		echo json_encode($rtn);
	}
	else
	{
	*/		
		$phone = $DB->get_field_sql('SELECT phone1 FROM {user} where username = "'.$mspin.'" AND deleted = 0');
		$userid = $DB->get_field('user','id',array('username'=>$mspin));
		$channels_id = $DB->get_field('ums_employeemaster','channels_id',array('code'=>$mspin));
		$i = 0; //counter
		$pin = ""; //our default pin is blank.
		while($i < 4)
		{
			$pin .= mt_rand(1, 9);
			$i++;
		}
		$record = new stdClass();
		$record->userid = $userid;
		$record->otp = $pin;
		$record->timesent = time();
		$record->phone = $phone;
		$insert_record = $DB->insert_record('otp',$record);
		if($insert_record)
		{
			$message = 'Your%20One%20Time%20Password%20is%20'.$pin;
			
			$to = '91'.trim($phone);
			$url = 'https://sms4.tatacommunications.com:3821/sendsms?username=m_msil_lapp&password=w8P3CxnF&from=MSILOT&to='.$to.'&text='.$message;
			//$url = 'https://sms3.tatacommunications.com:3801/sendsms?username=m_msil_lapp&password=w8P3CxnF&from=MSILOT&to='.$to.'&text='.$message;
			
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch,CURLOPT_URL, $url);
			$result = curl_exec($ch);
			//print_r($result);
			
			curl_close($ch);
			$rtn = array();
			$rtn['status'] = 'TRUE';
			$rtn['userid'] = $userid;
			$rtn['pin'] = $pin;
			$rtn['phone'] = $phone;
			$rtn['channels_id'] = $channels_id;
			$rtn['ErrorCode'] = 0;
			$rtn['ErrorMessage'] = 'An otp sent on your registered mobile number';
			echo json_encode($rtn);
		}	
	//}//
 
}	
?>		