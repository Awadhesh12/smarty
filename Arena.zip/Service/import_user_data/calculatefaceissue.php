<?php
require_once('../config.php');
global $DB;
$myfile = fopen("successfullymarked.txt", "r") or die("Unable to open file!");
$myfile=fread($myfile,filesize("successfullymarked.txt"));
$results=explode(',', $myfile);
$list=[];
$i=0;
foreach($results as $key => $mspin){
	$sqlr="SELECT region_id FROM mdl_ums_employeemaster WHERE code='".trim($mspin)."'";
	$fetchr=$DB->get_record_sql($sqlr);	
	$sqlt="SELECT r_name FROM mdl_ums_regions WHERE id='".$fetchr->region_id."'";
	$fetcht=$DB->get_record_sql($sqlt);	
	$list[]=["srno"=>$i, "mspin"=>$mspin, "region"=>$fetcht->r_name];
	$i++;
}
echo json_encode($list);
?>