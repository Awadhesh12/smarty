 <?php
 require_once('../config.php');
 /* NOTE : Ref. taken from api.php */
 global $DB;
 $mspin = required_param('mspin', PARAM_RAW);
 if(@$mspin!=""){
 	$qurl = 'SELECT code,region_id FROM {ums_employeemaster} WHERE code="'.$mspin.'"';
 	$fetchq=$DB->get_record_sql($qurl);
    if(@$fetchq->code==""){
    	echo "Mspin not valid";
    	die();
    }
 	$server1=[1,2,6,19];
 	$server2=[4,16,5];
 	$server3=[7,3,8,11];
 	$server4=[13,17,12];
 	$server5=[18,14,10,15,9];
 	if(in_array($fetchq->region_id, $server1)){ // the URL
	$url="http://20.207.201.226/result?mspin=".$mspin;
 	}
 	if(in_array($fetchq->region_id, $server2)){
	$url="http://20.204.42.30/result?mspin=".$mspin;
 	}
 	if(in_array($fetchq->region_id, $server3)){
	$url="http://20.204.112.1/result?mspin=".$mspin;
 	}
 	if(in_array($fetchq->region_id, $server4)){
	$url="http://20.204.113.239/result?mspin=".$mspin;
 	}
 	if(in_array($fetchq->region_id, $server5)){
 	$url="http://20.204.114.133/result?mspin=".$mspin;
 	}
 	?>
 	<script>
 	window.open("<?php echo $url?>", '_blank');
 	</script>
 	<?php
 }else{
 	echo "Please enter mspin";
 }
 ?>