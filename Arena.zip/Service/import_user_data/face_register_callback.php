<?php
define('AJAX_SCRIPT', true);
define('REQUIRE_CORRECT_ACCESS', true);
define('NO_MOODLE_COOKIES', true);
date_default_timezone_set("UTC");
require_once('../config.php');
global $DB;
$mspin = required_param('mspin', PARAM_RAW);
$is_registered = required_param('is_registered', PARAM_RAW);
$msg->text='can not be empty mspin and is_registered params';
$msg = new stdClass;
$msg->status=false;
$msg->text='';
if($_SERVER['REQUEST_METHOD']=='POST'){
	if(@$mspin && @is_numeric($is_registered)){
		try{
			$fus=$DB->get_record_sql("SELECT code FROM {ums_employeemaster} WHERE code='".@$mspin."'");
			if(@$fus->code && @$fus->code!=""){
				$message=$is_registered==1?'Image registered':'Image not registered';
				$ur = 'UPDATE {ums_employeemaster} SET face_id_user = '.$is_registered.' where code="'.$mspin.'"';
/*				$in ='INSERT INTO {quiz_course_face_verify} (`mspin`, `face_verify_status`, `message`, `created_at`) VALUES ("'.$mspin.'", "'.$is_registered.'", "'.$message.'", "'.date('Y-m-d H:i:s').'")';
                $DB->execute($in);*/
				if($DB->execute($ur)==true){
					$msg->status=true;
					$msg->text='data updated';
				}
			}else{
				$msg->text='Please enter a valid mspin';
			}
		} catch(Exception $e) {
			$msg->text='data not updated';
		}
	}else{
		$msg->text='Please enter a integer value(mspin or is_registered)';
	}
}else{
	$msg->text='Method Not Allowed HttpException';
}
echo json_encode($msg);