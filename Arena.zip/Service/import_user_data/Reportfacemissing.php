<?php
require_once('../config.php');
/* NOTE : Ref. taken from api.php */
global $DB;
$myfile = fopen("allmspin.txt", "r") or die("Unable to open file!");
$myfile=fread($myfile,filesize("allmspin.txt"));
$results=explode(',', $myfile);
$list=[];
foreach($results as $key => $mspin){
    if(@$mspin){
    $mspin=trim($mspin);
    $sqlf="SELECT ostype,currentappversion FROM mdl_ums_device_information WHERE mspin='".$mspin."'";
    $fetchq=$DB->get_record_sql($sqlf);
    $sqlr="SELECT region_id FROM mdl_ums_employeemaster WHERE code='".$mspin."'";
    $fetchr=$DB->get_record_sql($sqlr);
    $sqlrn="SELECT r_name FROM mdl_ums_regions WHERE id='".$fetchr->region_id."'";
    $fetchrn=$DB->get_record_sql($sqlrn);
    $list[]=[
        "mspin"=>$mspin,
        "ostype"=>$fetchq->ostype,
        "verion"=>$fetchq->currentappversion,
        "region"=>$fetchrn->r_name
    ];
}
}
echo json_encode($list);
  ?>