 <?php
 define('AJAX_SCRIPT', true);
 define('REQUIRE_CORRECT_ACCESS', true);
 define('NO_MOODLE_COOKIES', true);
 require_once('../config.php');

 /* NOTE : Ref. taken from api.php */

 global $DB;

 $platform = required_param('platform', PARAM_RAW);
 $version = required_param('version', PARAM_RAW);
 $mspin=optional_param('mspin',null,PARAM_RAW);

 $v = array();
 $sql = 'SELECT * FROM {app_version_batch_update} where ostype = "'.$platform.'"';	   
 $record = $DB->get_record_sql($sql);
 if($mspin!=""){
 	$fus=$DB->get_record_sql("SELECT face_id_user, is_reverified, is_verified, is_monthly_reverified FROM mdl_ums_employeemaster WHERE code='".@$mspin."'");
 }
 $v['is_registered']  = false;
 $v['is_reverified']  = false;
 $v['is_month_reverified'] = false;
 if(@$fus->face_id_user!=""){
 	$v['is_registered']  = @$fus->face_id_user==1?true:false;
 	$v['is_reverified']  = @$fus->is_verified==1?true:false;
 	$v['is_month_reverified'] = @$fus->is_monthly_reverified==1?true:false;
 }

$v['status']='';
$v['url']='';
/* if(!empty($record))
 {
		if($record->new_version=='') //check if app upgrade has started
		{
			if($version==$record->current_version)
			{
				$v['status']='Verified';
			}
			
			else
			{
			//check regionwise criteria
				$v['status']='Upgrade';
				$v['url']=$record->url;
			}
		}
		else 
		{
			if($version==$record->current_version)
			{
				//check regionwise criteria
				$v['status']='Upgrade';
				$v['url']=$record->url;
			}
			
			else
			{
				$v['status']='Verified';
				
			}
		}
		
	}
	else
	{
		$v['status']='Error';
	}*/

	echo json_encode($v);