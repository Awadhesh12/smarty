   <?php
   require_once('../config.php');
   global $DB;
   $results=$DB->get_records_sql("SELECT id, r_name AS Region FROM mdl_ums_regions");
   $list=[];
   $sum=0;
   foreach($results as $key => $value){
      $sql1 = "SELECT count(m.id) AS total
      FROM mdl_ums_mark_attendance m INNER JOIN mdl_ums_employeemaster um ON m.mspin=um.code WHERE date(m.created_at)='2022-01-27'  AND um.region_id='".$value->id."'";
      $totalR1=$DB->get_record_sql($sql1);

      $sql2="SELECT count(at.currentappversion) AS version
      FROM mdl_ums_device_information at INNER JOIN mdl_ums_employeemaster um ON at.mspin=um.code 
      WHERE date(at.created)='2022-01-27' OR date(at.updated)='2022-01-27' AND um.region_id='".$value->id."' AND currentappversion='4.1'";
      $totalR2=$DB->get_record_sql($sql2) ;
      $list[]=['Region'=>$value->region, 'Attendance Count'=>$totalR1->total, 'Download version Count'=>$totalR2->version];
      }
   echo json_encode($list);
  ?>