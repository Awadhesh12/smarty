 <?php
 define('AJAX_SCRIPT', true);
 define('REQUIRE_CORRECT_ACCESS', true);
 define('NO_MOODLE_COOKIES', true);
 header("Access-Control-Allow-Methods: POST");
 require_once('../config.php');
 global $DB;
 $allinput = json_decode(file_get_contents('php://input'), true);
 $msg->msg='can not be empty mspin, image, quiz_course_id and quiz_course_type params';
 $msg = new stdClass;
 $msg->status=false;
 if($_SERVER['REQUEST_METHOD']=='POST'){
 	if(@$allinput['mspin'] && $allinput['image'] && @$allinput['quiz_course_type']){
 		/*$fus=$DB->get_record_sql("SELECT code, is_verified FROM {ums_employeemaster} WHERE code='".@$allinput['mspin']."'");
 		if(@$fus->code && @$fus->code!=""){*/
 			##Start for image upload only
/* 			$folderPath = "../faceimg/";
 			$image_base64 = base64_decode($allinput['image']);
 			$name=time().'-'.@$allinput['mspin'].'.png';
 			$file = $folderPath.$name;
 			$msg->img='/faceimg/'.$name;
 			file_put_contents($file, $image_base64);*/
 			##End for image upload only
 			$msg->img='/app/images/white.png';
 			$postData = array(
 				'username' => $allinput['mspin'],
 				'img' =>$allinput['image']
 			);
 			try{
 			$curl = curl_init();
 			curl_setopt_array($curl, array(
 				CURLOPT_URL => "http://20.204.92.82/verify",
 				CURLOPT_RETURNTRANSFER => true,
 				CURLOPT_ENCODING => "",
 				CURLOPT_MAXREDIRS => 10,
 				CURLOPT_TIMEOUT => 0,
 				CURLOPT_FOLLOWLOCATION => true,
 				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
 				CURLOPT_CUSTOMREQUEST => "POST",
 				CURLOPT_POSTFIELDS => $postData,
 			));
 			$response = curl_exec($curl);
 			curl_close($curl);
 			$output = @json_decode($response, true);
 			if(@$output['verified']==true){
            $is_verified='1';
 			}else{
            $is_verified='0';
 			}
 			$msg->msg='Something went wrong';
/* 			$allinput['quiz_course_id']=$allinput['quiz_course_id']==""?"1321999":$allinput['quiz_course_id'];
 			$qin="INSERT INTO {quiz_course_face_verify} (mspin, image, quiz_course_id, quiz_course_type, face_verify_status, message, created_at) VALUES ('".$allinput['mspin']."', '".$allinput['image']."', '".$allinput['quiz_course_id']."', '".@$allinput['quiz_course_type']."', '".$is_verified."', '".@$output['message']."', '".date('Y-m-d H:i:s')."')";
 			$DB->execute($qin);*/
 			if(@$output['verified']==true){
 				$msg->img='';
 				$msg->status=true;
 				$msg->msg='success';
 			}else{
 				$msg->msg=@$output['message'];
 			}
 		}catch(Exception $e){
          $msg->msg='curl error';
          //file_put_contents("/errorlog/log.txt", print_r($e, TRUE)."  date: ".date('Y-m-d H:i:s'));
 		}
/* 		}else{
 			$msg->msg='mspin invalid';
 		}*/
 	}
 }else{
 	$msg->msg='Method Not Allowed HttpException';
 }
 echo json_encode($msg);
 ?>