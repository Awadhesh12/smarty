<?php
define('AJAX_SCRIPT', true);
define('REQUIRE_CORRECT_ACCESS', true);
define('NO_MOODLE_COOKIES', true);
require_once('../config.php');
global $DB;
$mspin = required_param('MSPIN', PARAM_RAW);
$connarena = mysqli_connect("10.0.1.5","maruti-prod","3TjSmpDhY8b","maruti_prod");
$sqlarena   = "SELECT * FROM mdl_ums_employeemaster WHERE code = '".$mspin."' AND deleted = 0"; 
$checkifexists = mysqli_query($connarena,$sqlarena);
$rowsarena     = mysqli_fetch_assoc($checkifexists);
if($checkifexists->num_rows > 0) 
{
	$channels_id = $rowsarena['channels_id'];
}
else
{
	$errorobject = new stdClass;
	$errorobject->exception = 'moodle_exception';
	$errorobject->errorcode = 902;
	$errorobject->error = 'User not authorized';
	echo json_encode($errorobject);
	die();
}

$i = 0;     //counter
$pin = ""; //our default pin is blank.
while($i < 4)
{
	$pin .= mt_rand(1, 9);//generate a random number between 0 and 9.
	$i++;
}
if($rowsarena['channels_id'] == 1)
{
	$userid = $DB->get_field('user','id',array('username'=>$mspin));
	$phone = $DB->get_field('user','phone1',array('username'=>$mspin));
	$record = new stdClass();
	$record->userid = $userid;
	$record->otp = $pin;
	$record->timesent = time();
	$record->phone = $phone;
	$insert_record = $DB->insert_record('otp',$record);
}

if($insert_record)
{
	/* 04/01/2021 changed as per new format given by akshay
	$message = 'Your%20One%20Time%20Password%20is%20'.$pin;
	*/
	$message = 'Your%20One%20Time%20Password%20is%20'.$pin.'.%20-%20Maruti%20Suzuki%20India%20Limited';
						
						
	$to = '91'.$phone;
	$url = 'https://sms4.tatacommunications.com:3821/sendsms?username=m_msil_lapp&password=w8P3CxnF&from=MSILOT&to='.$to.'&text='.$message; //123456
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch,CURLOPT_URL, $url);
	$result = curl_exec($ch);
	curl_close($ch);
	$rtn = array();
	$rtn['status'] = 'TRUE';
	$rtn['userid'] = $userid;
	$rtn['pin'] = $pin;
	$rtn['phone'] = $phone;
	$rtn['channels_id'] = $channels_id;
	echo json_encode($rtn);
}
else
{
	$errorobject = new stdClass;
	$errorobject->exception = 'moodle_exception';
	$errorobject->errorcode = 902;
	$errorobject->error = 'Error Sending OTP';
	echo json_encode($errorobject);
	die();
}