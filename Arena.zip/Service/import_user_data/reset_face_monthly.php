 <?php
 define('AJAX_SCRIPT', true);
 define('REQUIRE_CORRECT_ACCESS', true);
 define('NO_MOODLE_COOKIES', true);
 require_once('../config.php');
 /* NOTE : Ref. taken from api.php */
 global $DB;
 $mspin = required_param('mspin', PARAM_RAW);
 $ur = 'UPDATE {ums_employeemaster} SET is_monthly_reverified=1 WHERE code="'.$mspin.'"';
 $DB->execute($ur);
 ?>