<?php
    $pin = '101010'; 
	/* 04/01/2021 changed as per new format given by akshay
						$message = 'Your%20One%20Time%20Password%20is%20'.$pin;
						*/
						$message = 'Your%20One%20Time%20Password%20is%20'.$pin.'.%20-%20Maruti%20Suzuki%20India%20Limited';
						
	$to = '919503901276';
	//$url = 'https://sms4.tatacommunications.com:3821/sendsms?username=m_msil_lapp&password=w8P3CxnF&from=MSILOT&to='.$to.'&text='.$message; //123456
	$url = 'https://sms4.tatacommunications.com:3821/sendsms?username=m_msil_lapp&password=w8P3CxnF&from=MSILOT&to='.$to.'&text='.$message;
						
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch,CURLOPT_URL, $url);
	$result = curl_exec($ch);
	print_r($result);
	curl_close($ch);
	