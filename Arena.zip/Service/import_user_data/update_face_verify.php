<?php
define('AJAX_SCRIPT', true);
define('REQUIRE_CORRECT_ACCESS', true);
define('NO_MOODLE_COOKIES', true);
date_default_timezone_set("UTC");
require_once('../config.php');
global $DB;
$mspin = required_param('mspin', PARAM_RAW);
$is_verified = required_param('is_verified', PARAM_RAW);
$message = required_param('message', PARAM_RAW);
$msg = new stdClass;
$msg->status=false;
$msg->text='';
if($_SERVER['REQUEST_METHOD']=='POST'){
if(@$mspin && @is_numeric($is_verified)){
	$fus=$DB->get_record_sql("SELECT code FROM {ums_employeemaster} WHERE code='".@$mspin."'");
	if(@$fus->code && @$fus->code!=""){
		$ur = 'UPDATE {ums_employeemaster} SET is_verified = "'.$is_verified.'", is_monthly_reverified=0 WHERE code="'.$mspin.'"';
/*		$in ='INSERT INTO {quiz_course_face_verify} (`mspin`, `face_verify_status`, `message`, `created_at`) VALUES ("'.$mspin.'", "'.$is_verified.'", "'.$message.'", "'.date('Y-m-d H:i:s').'")';*/
		if($DB->execute($ur)==true){
			//$DB->execute($in);
			$msg->status=true;
			$msg->text='success';
		}
	}else{
     $msg->text='Please enter a valid mspin';
	}
}else{
	$msg->text='Please enter a integer value(mspin or is_verified)';
}
}else{
	$msg->text='Method Not Allowed HttpException';
}
echo json_encode($msg);
?>