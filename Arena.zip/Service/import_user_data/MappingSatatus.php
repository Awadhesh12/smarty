<?php
require_once('../config.php');
$sqlc="SELECT id AS scormid, course FROM mdl_scorm WHERE course IN(553)";
$courseRes=$DB->get_records_sql($sqlc);
foreach($courseRes as $courseR){
	$sqlv="SELECT sc.id,sc.value,sc.userid,sc.scormid,sc.scoid,sc.attempt,sc.timemodified FROM mdl_scorm_scoes_track sc INNER JOIN mdl_scorm s ON sc.scormid=s.id WHERE sc.scormid='".$courseR->scormid."' AND sc.element='cmi.core.score.raw' AND sc.value > 0 ";
	$fetcht = $DB->get_records_sql($sqlv);
	foreach($fetcht as $fetchv){
		$sqlt="SELECT sc.id, sc.value FROM mdl_scorm_scoes_track sc INNER JOIN mdl_scorm s ON sc.scormid=s.id WHERE sc.userid='".$fetchv->userid."' AND sc.scormid='".$courseR->scormid."' AND sc.element='cmi.core.lesson_status' AND value IN('failed','incomplete')";
		$fetchr = $DB->get_record_sql($sqlt);
		if($fetchr->value!="" && $fetchr->value=="failed"){
			$sqlupd="UPDATE mdl_scorm_scoes_track SET value='completed' WHERE id='".$fetchr->id."'";
			$DB->execute($sqlupd);
		}

		/*if(!isset($fetchr->value) && $fetchr->value==""){
			$inset=new stdClass();
			$inset->userid=$fetchv->userid;
			$inset->scormid=$fetchv->scormid; 
			$inset->scoid=$fetchv->scoid;
			$inset->attempt=$fetchv->attempt; 
			$inset->element='cmi.core.lesson_status'; 
			$inset->value='completed';
			$inset->timemodified=$fetchv->timemodified;
			$DB->insert_record('scorm_scoes_track', $inset);
		}*/
	}
}
?>