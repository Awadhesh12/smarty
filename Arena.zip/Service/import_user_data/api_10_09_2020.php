<?php
//here need to check timezone//
define('AJAX_SCRIPT', true);
define('REQUIRE_CORRECT_ACCESS', true);
define('NO_MOODLE_COOKIES', true);
date_default_timezone_set("UTC");
require_once('../config.php');
$mspin = required_param('MSPIN', PARAM_RAW);
if(!$DB->record_exists('ums_employeemaster',array('code'=>$mspin))) 
{
		$errorobject = new stdClass;
        $errorobject->exception = 'moodle_exception';
        $errorobject->errorcode = 902;
        $errorobject->error = 'MSPIN not found';
		echo json_encode($errorobject);
		die();
}
else
{
	$phone = $DB->get_field_sql('SELECT phone1 FROM {user} where username = ?',array($mspin));
    if($mspin == '707070' || $mspin == '13820' || $mspin == '1182020' || $mspin == '1282020'  || $mspin == '1382020' || $mspin == '1482020')
	{  // this mspin for internal testing otherwise employee use MyAPP
		$userid = $DB->get_field('user','id',array('username'=>$mspin));
		$channels_id = $DB->get_field('ums_employeemaster','channels_id',array('code'=>$mspin));
		$i = 0; //counter
		$pin = ""; //our default pin is blank.
		while($i < 4)
		{
			$pin .= mt_rand(1, 9);
			$i++;
		}
	    $record = new stdClass();
	    $record->userid = $userid;
	    $record->otp = $pin;
	    $record->timesent = time();
	    $record->phone = $phone;
	    $insert_record = $DB->insert_record('otp',$record);
		if($insert_record)
		{
			$message = 'Your%20One%20Time%20Password%20is%20'.$pin;
			$to = '91'.$phone;
			$url = 'https://sms4.tatacommunications.com:3821/sendsms?username=m_msil_lapp&password=w8P3CxnF&from=ilearn&to='.$to.'&text='.$message;
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch,CURLOPT_URL, $url);
			$result = curl_exec($ch);
			curl_close($ch);
		
			$rtn = array();
			$rtn['status'] = 'TRUE';
			$rtn['userid'] = $userid;
			$rtn['pin'] = $pin;
			$rtn['phone'] = $phone;
			$rtn['channels_id'] = $channels_id;
			$rtn['ErrorCode'] = 0;
			$rtn['ErrorMessage'] = 'An otp sent on your registered mobile number';
			echo json_encode($rtn);
		}	
	}
	else
    {
		$userid = $DB->get_field('user','id',array('username'=>$mspin));
		$ot     = $DB->get_field('user','ostype',array('username'=>$mspin));
		if($ot == 'os')
		{
			$OStype = 1;
		}	
		else
		{
			$OStype = 2;
		}	
		$channels_id = $DB->get_field('ums_employeemaster','channels_id',array('code'=>$mspin));
		$i = 0; //counter
		$pin = ""; //our default pin is blank.
		while($i < 4)
		{
			$pin .= mt_rand(1, 9);
			$i++;
		}
		//-------------- send this value to myapp ---------------------//
		$record = new stdClass();
		$record->userid = $userid;
	    $record->otp = $pin;
	    $record->timesent = time();
	    $record->phone = $phone;
	    $DB->insert_record('otp',$record);
		//-------- here we stored send otp in our database ----------//	   
		$OTP = $pin;
		$ActiveTime = 90; // otp valid for 90 sec
		$DMSUserId = $mspin;
		$OS = $OStype;
		$AppCode = 'ILEARN';
		$CreatedOn = gmdate("Y-m-d\TH:i:s\Z");
		$data      = json_encode(array(
								"OTP"        => $OTP,
								"ActiveTime" => $ActiveTime,
								"DMSUserId"  => $DMSUserId,
								"OS"         => $OS,
								"AppCode"    => $AppCode,
								"CreatedOn"  =>	$CreatedOn
								));
								
		
		$curl = curl_init();
		curl_setopt_array($curl, array(
		CURLOPT_URL => "http://52.172.42.227/OTPApp/api/otp/sendOTP",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => $data,
		CURLOPT_HTTPHEADER => array(
			"AppCode: ILEARN",
			"Content-Type: application/json",
			"X-IntegrationKey: gQBYKfQMm0h05Hne29a0"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		if ($err) 
		{
		  echo "cURL Error #:" . $err;
		} 
		else 
		{
		   $response;
		}
		
		$rtn = array();
		$rtn['status'] = 'TRUE';
		$rtn['userid'] = $userid;
		$rtn['pin'] = $pin;
		$rtn['phone'] = $phone;
		$rtn['channels_id'] = $channels_id;
		$rtn['ErrorCode'] = 0;
		$rtn['ErrorMessage'] = 'An otp sent on your registered mobile number';
		echo json_encode($rtn);
		//-------------------------------------------------//
	}	
   
}	
?>		