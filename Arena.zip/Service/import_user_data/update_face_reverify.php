<?php
define('AJAX_SCRIPT', true);
define('REQUIRE_CORRECT_ACCESS', true);
define('NO_MOODLE_COOKIES', true);
date_default_timezone_set("UTC");
require_once('../config.php');
global $DB;

if(date('d')==1){
	$ur = 'UPDATE {ums_employeemaster} SET is_monthly_reverified = 1, is_reverified = 1';
	$DB->execute($ur);
}
if(date('d')==11){
	$ur = 'UPDATE {ums_employeemaster} SET is_monthly_reverified = 1, is_reverified = 1';
	$DB->execute($ur);
}
if(date('d')==21){
	$ur = 'UPDATE {ums_employeemaster} SET is_monthly_reverified = 1, is_reverified = 1';
	$DB->execute($ur);
}
?>