<?php
function getIDFromFieldName($fieldVal,$tableName,$dbCol,$colInitial,$extraColName1,$extraColVal1){
			global $DB; $pkid = 0;
			if($fieldVal!=''){
				
				if($tableName=='ums_sub_designations'){//as one subdesig is mapped with many designations
					$sql = "SELECT id FROM {".$tableName."} WHERE LOWER($dbCol) = '".strtolower($fieldVal)."' AND ".$extraColName1." = ".$extraColVal1."  ";
				}
				else{
					$sql = "SELECT id FROM {".$tableName."} WHERE LOWER($dbCol) = '".strtolower($fieldVal)."' ";
				}
				
				$data = $DB->get_record_sql($sql);
				$getid = $data->id;
				
				if($getid!=''){
					$pkid = $getid;
				}else{
					$nameCol    = $colInitial."_name";
					$createdCol = $colInitial."_created";
					$updatedCol = $colInitial."_updated";
					$extraColTxt1 = '';
					if($extraColName1!=''){
						$extraColTxt1 = " , $extraColName1='$extraColVal1'";
					}

					$insert = "INSERT INTO {".$tableName."} set $nameCol = '".$fieldVal."',$createdCol = '".date("Y-m-d")."', $updatedCol = '".date("Y-m-d")."', deleted=0 $extraColTxt1 ";
					$DB->execute($insert,array());
					$lastidsql = $DB->get_record_sql("SELECT id FROM {".$tableName."} WHERE 1 ORDER BY id DESC LIMIT 1");
					$pkid = $lastidsql->id;
				}
			}
			return $pkid;
		}
		function clean($value){
			$result = addslashes(str_replace(";","",$value));
			return $result;
		}