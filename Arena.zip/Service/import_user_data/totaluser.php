<?php
require_once('../config.php');
global $DB;

$qr="SELECT code, region_id FROM {ums_employeemaster} WHERE user_type_id='' AND deleted=0";
$result=$DB->get_records_sql($qr);
$list=[];
$i=0;
foreach($result as $key => $value){
	$sqlt="SELECT r_name FROM mdl_ums_regions WHERE id='".$value->region_id."'";
	$fetcht=$DB->get_record_sql($sqlt);	
	$list[]=["srno"=>$i, "mspin"=>$value->code, "region"=>$fetcht->r_name];
	$i++;
}
echo json_encode($list);
?>