<?php
define('AJAX_SCRIPT', true);
define('REQUIRE_CORRECT_ACCESS', true);
define('NO_MOODLE_COOKIES', true);
require_once('../config.php');

/* NOTE : Ref. taken from api.php */

global $DB;

$platform = required_param('platform', PARAM_RAW);
$mspin    = optional_param('mspin', '', PARAM_RAW);
if($mspin!=""){
$fus=$DB->get_record_sql("SELECT face_id_user,is_reverified FROM mdl_ums_employeemaster WHERE code='".@$mspin."'");
}
//arena
//$conn_arena = mysqli_connect("10.0.1.5","maruti-prod","3TjSmpDhY8b","maruti_prod");
$conn_arena = mysqli_connect($CFG->dbhost,$CFG->dbuser,$CFG->dbpass,$CFG->dbname);
$sqlarena   = 'SELECT * FROM mdl_app_version_check WHERE type = "'.$platform.'" ';
$checkifexists = mysqli_query($conn_arena, $sqlarena);
$rows= mysqli_fetch_assoc($checkifexists);

if($rows['version']!=''){
	$rtn = array();
	$rtn['version'] = $rows['version'];
if(@$fus->face_id_user!=""){
	$rtn['is_registered']  = @$fus->face_id_user==1?true:false;
	$rtn['is_reverified'] = @$fus->is_reverified==1?true:false;
}
	echo json_encode($rtn);
}else{
	$errorobject = new stdClass;
	$errorobject->exception = 'moodle_exception';
	$errorobject->errorcode = 902;
	$errorobject->error = 'Version mismatch';
	echo json_encode($errorobject);
	die();
}