<?php
define('AJAX_SCRIPT', true);
define('REQUIRE_CORRECT_ACCESS', true);
define('NO_MOODLE_COOKIES', true);
date_default_timezone_set("UTC");
require_once('../config.php');
global $DB;
$mspin = required_param('mspin', PARAM_RAW);
$image = required_param('image', PARAM_RAW);