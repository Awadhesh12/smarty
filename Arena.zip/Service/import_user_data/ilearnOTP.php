<?php
ini_set('max_execution_time', 0);
ini_set('memory_limit', -1);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
/*$curl = curl_init();
//https://alvinalexander.com/php/php-curl-examples-curl_setopt-json-rest-web-service
curl_setopt_array($curl, array(
  CURLOPT_URL => "http://104.211.214.217/OTP0129/api/otp/sendOTP",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "{\"DMSUserId\":\"568411\",\r\n\"OS\":\"1\",\r\n\"AppCode\":\"ILEARN\"}",
  CURLOPT_HTTPHEADER => array(
    "appcode: ILEARN",
    "cache-control: no-cache",
    "content-type: application/json",
    "postman-token: 81341423-7425-9bc5-4b62-67358961c585",
    "x-integrationkey: gQBYKfQMm0h05Hne29a0"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
*/
$data = array("DMSUserId" =>"568411","OS" => "1","AppCode" =>"ILEARN");
$data_string = json_encode($data);
$ch = curl_init('http://104.211.214.217/OTP0129/api/otp/sendOTP');
curl_setopt($ch,CURLOPT_CUSTOMREQUEST,"POST");
curl_setopt($ch,CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_HTTPHEADER, array(
    'AppCode:ILEARN',
	'Cache-Control:no-cache',
    'Content-Type:application/json',
	'X-IntegrationKey: gQBYKfQMm0h05Hne29a0')
);
curl_setopt($ch,CURLOPT_TIMEOUT, 5);
curl_setopt($ch,CURLOPT_CONNECTTIMEOUT, 5);
$result = curl_exec($ch);
curl_close($ch);
echo $result;
?>