<?php
  require_once('../config.php');
  global $DB;
  $mspin=required_param('mspin',PARAM_RAW);
  if(@$mspin){
  $dsql="DELETE FROM maruti_prod.mdl_ums_mark_attendance WHERE mspin='".$mspin."' AND date(created_at)='".date('Y-m-d')."'";
  $DB->execute($dsql);
}
?>