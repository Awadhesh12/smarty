 <?php
 require_once('../config.php');
 /* NOTE : Ref. taken from api.php */
 global $DB;
 $mspin = required_param('mspin', PARAM_RAW);
 if(@$mspin!=""){
 	$qurl = 'SELECT code,region_id FROM {ums_employeemaster} WHERE code="'.$mspin.'"';
 	$fetchq=$DB->get_record_sql($qurl);
 	if(@$fetchq->code==""){
 		echo "Mspin not valid";
 		die();
 	}else{
 		$sql = 'UPDATE mdl_ums_employeemaster SET deleted="0" WHERE code="'.$mspin.'"';
 		$DB->execute($sql);
 	}
 }else{
 	echo "Please enter mspin";
 }
 ?>