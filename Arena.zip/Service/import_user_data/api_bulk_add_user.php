<?php
define('CLI_SCRIPT', true);//for server cron
ini_set('max_execution_time', 0);
ini_set('memory_limit', -1);
require_once('/var/www/html/maruti_prod/config.php'); 

require_once('custom_methods.php');
global $DB;
$mspindata=$DB->get_records_sql("SELECT mspin FROM dms_data_msil WHERE mspin NOT IN (SELECT username FROM mdl_user)
        AND emp_categ LIKE 'V'
        AND dealer_type IN ('2S', '3S','M')
        AND mspin!='';
");
$mspins=array();
if(!empty($mspindata))
{
	foreach($mspindata as $mspind)
	{
	array_push($mspins,$mspind->mspin);
	}
}
if(!empty($mspins))
{

foreach(array_chunk($mspins, 10) as $mspin_chunk ) 
{
foreach($mspin_chunk as $msp)
{
	
if($msp>0){
	
$mspin = $msp;
$error_count=0;
$flag=0;
$error_msg="";

if(!$DB->record_exists('ums_employeemaster',array('code'=>$mspin,'deleted' => 0))) 
{
	$m="Bulk Upload - Not found in iLearn";
	$sql="insert into mdl_data_log set mspin='".$mspin."',msg='".$m."',created='".time()."'";
	$DB->execute($sql);
	$error_count=$error_count+1;
	$error_msg.='1. MSPIN not found in iLearn ';
			
	$checkdump=$DB->get_record_sql("select * from dms_data_msil where MSPIN='".$mspin."'");
	if(empty($checkdump)) 
		{
		
		$m="Bulk Upload - Not found in DMS Dump";
		$sql="insert into mdl_data_log set mspin='".$mspin."',msg='".$m."',created='".time()."'";
		$DB->execute($sql);
		$error_count=$error_count+1;
		$error_msg.='2. Not found in DMS Dump ';
			
		}
		else
		{
		$m="Bulk Upload - MSPIN found in DMS Dump";
		$sql="insert into mdl_data_log set mspin='".$mspin."',msg='".$m."',created='".time()."'";
		$DB->execute($sql);
		$d = $DB->get_record_sql("SELECT * FROM dms_data_msil where MSPIN='".$mspin."' AND emp_categ like 'V' AND dealer_type in ('3S','2S','M')");
		if (!empty($d))
		{
			//print_r($d);
			$emp_categ           = trim($d->emp_categ);
            $dealer_type         = trim($d->dealer_type);
			if(($dealer_type == '2S' || $dealer_type == '3S' || $dealer_type == 'M') && $emp_categ == 'V')
			{
				
				$username_empcode = trim($d->mspin);
				$fullname		  = explode(" ", clean(trim($d->emp_name)));
				$firstname		  =	array_shift($fullname);
				$lastnameT        = '';
				foreach($fullname as $dd){
				$lastnameT .= $dd.' ';
				}
				$lastname		  = $lastnameT!=''?trim($lastnameT):'-';
				$gender           = trim($d->emp_sex)!=''?trim($d->emp_sex):'';
				$email            = trim($d->emp_email_id)!=''?clean(trim($d->emp_email_id)):'noreply@ilearnservice.com';
				$phone            = trim($d->mobile)!=''?trim($d->mobile):'';
					
				$doj  	 	      = trim($d->emp_joining_date)!=''?date('Y-m-d H:i:s',strtotime(trim($d->emp_joining_date))):'0000-00-00';
					
				$dol              = trim($d->emp_leaving_date)!=''?date('Y-m-d H:i:s',strtotime(trim($d->emp_leaving_date))):'0000-00-00';
				
				
				if($dol == '0001-01-01 00:00:00')
				{
					$dol = '0000-00-00';
				}
				$designation_id   = getIDFromFieldName(trim($d->emp_desg_cd) , "ums_designations","d_name","d","d_desc",trim($d->emp_desg));
				$sub_designation_id   = trim($d->sub_desg_cd)!=''?getIDFromFieldName(trim($d->sub_desg_cd) , "ums_sub_designations","sd_name","sd","designations_id",$designation_id):0;
					
				$tl_mspin = trim($d->tl_mspin)!=''?trim($d->tl_mspin):'-';
					if(trim($d->emp_approve) == 'A'){
						$assgment_status_type = 0;
					}else{
						$assgment_status_type = 1;
					}
					
				$modified_date 		= trim($d->modified_date)!=''?date('Y-m-d H:i:s',strtotime(trim($d->modified_date))):'0000-00-00';
				$channels_id = $region_id = $state_id = $city_id =  $location_id =0;
				$outletcodefromsheet = trim($d->dealer_map_cd);
				$loccd				 = trim($d->loc_cd);
			    $outlet_idarr = $DB->get_record_sql("SELECT id,outlet_group_id, region_id FROM mdl_ums_outlet WHERE o_code = '".$outletcodefromsheet."' AND loc_cd = '".$loccd."' AND deleted =0 AND status =0");
				$outletcodefromsheet_new = trim($d->dealer_map_cd).'-'.trim($d->loc_cd);
					if(!empty($outlet_idarr))
					{	
						$outlet_id	= $outlet_idarr->id;
						$dlermster = $DB->get_record_sql("SELECT * FROM mdl_ums_dealermaster WHERE o_id = '".$outlet_id."'  AND og_id = '".$outlet_idarr->outlet_group_id."' AND region_id = '".$outlet_idarr->region_id."' AND o_status = 0");
						if(count($dlermster) > 0)
						{
							$channels_id = $dlermster->c_id;
							$region_id   = $dlermster->region_id;
							$state_id    = $dlermster->state_id;
							$city_id     = $dlermster->city_id;
							$location_id = $dlermster->location_id;
						}
						
					}	
					else
					{
						$outlet_id = 0;
					}
				$chname = "";
					if($channels_id==1){
						$chname = 'NRM-ARENA';
					}
					if($channels_id==2){
						$chname = 'EXE-NEXA';
					}
					if($channels_id==3){
						$chname = 'COM-True Value';
					}
					if($channels_id==4){
						$chname = 'MDS';
					}
					$deleted = 0;
						if(!$DB->record_exists('user', array('username'=>$username_empcode)))
						{
							
							$hashedpassword = hash_internal_user_password($username_empcode);
							$record = new stdClass();
							$record->username    = $username_empcode;
							$record->firstname   = $firstname;
							$record->lastname    = $lastname;
							$record->confirmed   = 1;
							$record->mnethostid  = 1;
							$record->email       = $email;
							$record->password    = $hashedpassword;
							$record->suspended   = $assgment_status_type;
							$record->phone1      = $phone;
							$record->deleted     = $deleted;
							$record->timecreated = time();
							
							$lastinsertid        = $DB->insert_record('user',$record);
							$insert = "INSERT INTO {ums_employeemaster} set userid = '".$lastinsertid."', code='".$username_empcode."', password='".$username_empcode."',phone = '".$phone."', doj='".$doj."', dol = '".$dol."', gender = '".$gender."', designation_id = ".$designation_id.", sub_designation_id = ".$sub_designation_id.", channels_id = '1',service_channel_id = '".$channels_id."', user_type_id = '', outlet_id = '".$outlet_id."', region_id = '".$region_id."', state_id = '".$state_id."', city_id = '".$city_id."', location_id = '".$location_id."', tl_mspin_no = '".$tl_mspin."', created='".date("Y-m-d H:i:s")."',updated='".date("Y-m-d H:i:s")."', outletcode_from_sheet='".$outletcodefromsheet_new."', modified_date_from_cron = '".$modified_date."', deleted = ".$deleted.",emp_categ = '".$emp_categ."', emp_dealer_type = '".$dealer_type."' ";
							$DB->execute($insert,array());
							
							$m="Bulk Upload - MSPIN added in iLearn";
							$sql="insert into mdl_data_log set mspin='".$mspin."',msg='".$m."',created='".time()."'";
							$DB->execute($sql);
							$flag=1;
							
						}
						else{
							
							$userid = $DB->get_field("user","id",array("username"=>$mspin));
							
							$Eoutlet_id = $DB->get_field("ums_employeemaster","outlet_id",array("code"=>trim($d->MSPIN)));
							
							if($dol!='' && $dol!='0000-00-00' && $dol!='0001-01-01 00:00:00')
							{
								
								if($Eoutlet_id == $outlet_id)
								{
									$deleted = 1;
									$assgment_status_type = 1;
							    }
								else
								{
									$deleted = 0;
									$assgment_status_type = 0;
									continue;
								}
							}else
							{
								$deleted = 0;
								$assgment_status_type = 0;
							}
							
							$recordUpdtUser = new stdClass();
							$recordUpdtUser->id    		 = $userid;
							$recordUpdtUser->firstname   = $firstname;
							$recordUpdtUser->lastname    = $lastname;
							$recordUpdtUser->email       = $email;
							$recordUpdtUser->suspended   = $assgment_status_type;
							$recordUpdtUser->phone1      = $phone;
							$recordUpdtUser->deleted     = $deleted;
							$recordUpdtUser->timemodified     = time();
							
							$DB->update_record('user',$recordUpdtUser);
							
							$updateempmaster = 'UPDATE mdl_ums_employeemaster SET phone = "'.$phone.'", doj="'.$doj.'", dol = "'.$dol.'", gender = "'.$gender.'", designation_id = '.$designation_id.', sub_designation_id = '.$sub_designation_id.', channels_id = "1",service_channel_id = "'.$channels_id.'", user_type_id = "", outlet_id = "'.$outlet_id.'", region_id = "'.$region_id.'", state_id = "'.$state_id.'", city_id = "'.$city_id.'", location_id = "'.$location_id.'", tl_mspin_no = "'.$tl_mspin.'", updated="'.date("Y-m-d H:i:s").'", outletcode_from_sheet="'.$outletcodefromsheet_new.'", modified_date_from_cron = "'.$modified_date.'", deleted = "'.$deleted.'",emp_categ = "'.$emp_categ.'",emp_dealer_type = "'.$dealer_type.'"  WHERE userid = "'.$userid.'"';
							$DB->execute($updateempmaster,array());
							
							$m="Bulk Upload - MSPIN updated in iLearn";
							$sql="insert into mdl_data_log set mspin='".$mspin."',msg='".$m."',created='".time()."'";
							$DB->execute($sql);
							$flag=1;
							
						}
						
					
						
			}
			else
			{
			$error_count=$error_count+1;
			$error_msg.='3. Dealer type or Employee Category Wrong in DMS Dump<br>';
			$m="Bulk Upload - Dealer type or Employee Category Wrong in DMS Dump";
			$sql="insert into mdl_data_log set mspin='".$mspin."',msg='".$m."',created='".time()."'";
			$DB->execute($sql);
			}
			
		}
		}
		
		if($flag==0 && $error_count>0)
		{
			echo '<br>MSPIN : '.$mspin.' Errors : '.$error_msg.'';
			/*
		$errorobject = new stdClass;
        $errorobject->exception = 'moodle_exception';
        $errorobject->errorcode = '902';
		$errorobject->errorcount = $error_count;
        $errorobject->error = $error_msg;
		echo json_encode($errorobject);
		die();
		*/
		}
}
else
{

}
}
}
}	
}
?>		