   <?php
   function distance($lat1, $lon1, $lat2, $lon2, $unit){
   	$theta = $lon1 - $lon2;
   	$dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
   	$dist = acos($dist);
   	$dist = rad2deg($dist);
   	$miles = $dist * 60 * 1.1515;
   	$unit = strtoupper($unit);

   	if ($unit == "K") {
   		echo round($miles * 1.609344)*1000;
   	} else if ($unit == "N") {
   		echo round(($miles * 0.8684)*1852);
   	} else {
   		echo round($miles*1609.34);
   	}
   }
   if($_REQUEST['lat1'] && $_REQUEST['lon1'] && $_REQUEST['lat2'] && $_REQUEST['lon2']){
     echo distance($_REQUEST['lat1'], $_REQUEST['lon1'], $_REQUEST['lat2'], $_REQUEST['lon2']).'meter';
   }
/*   require_once('../config.php');
   global $DB;
   $results=$DB->get_records_sql("SELECT * FROM maruti_prod.mdl_ums_outlet limit 10");
   foreach($results as $key => $value){
   	$outlet=$DB->get_record_sql("SELECT * FROM maruti_prod.mdl_ums_user_cordinate WHERE outlet_id=$value->id");
   }*/
   ?>