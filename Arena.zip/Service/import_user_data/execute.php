<?php
ini_set('memory_limit', -1);
ini_set('max_execution_time', 0);
class Execute {
    var $AuthKey ;
	var $URL;
	function __construct() {
        //$this->URL = "http://220.226.210.10:9003/";	//Test URL
        $this->URL = "http://220.226.210.8:9003/"; //Prod URL
		$this->AuthKey = $this->login();
    }
	
	public function login()
	{
		$url = $this->URL."Login";
		$data['UserName'] = "Administrator";
		$data['Password'] = "m1cr0s0f+";
		
		$result = $this->request($url, $data);
		$data = json_decode($result);
		return  $data->AuthKey; 
		//print_r($data);
	}
	
	public function GetEmpMasterList($p_createD_date = "" , $p_modifieD_date="")
	{
		$url = $this->URL."GetEmpMasterList";
		$data['p_createD_date'] = $p_createD_date;                  # MM/DD/YYYY 01/01/2015
		$data['p_modifieD_date'] = $p_modifieD_date;                 # MM/DD/YYYY 01/01/2015
		$data['AuthKey'] = $this->AuthKey;  
		$data['P_PRINCIPAL_MAP_CD'] = "1";             # MM/DD/YYYY 01/01/2015
		$result = $this->request($url, $data);
		$data = json_decode($result);
		//echo '<pre>';print_r($data);exit;
		return $data;
	}
	
	public function GetDealerMasterList()
	{
		$url = $this->URL."GetDealerMasterList";
		$data['AuthKey'] = $this->AuthKey;
		$data['P_PRINCIPAL_MAP_CD'] = "1";
		$result = $this->request($url, $data);
		$data = json_decode($result);
		 //echo '<pre>';print_r($data);
		return $data;
	}
	
	public function GetProgramMasterList()
	{
		$url = $this->URL."GetProgramMasterList";
		$data['AuthKey'] = $this->AuthKey;
		$data['P_PRINCIPAL_MAP_CD'] = "1";
		$result = $this->request($url, $data);
		$data = json_decode($result);
		//print_r($data);
		return $data;
	}
	
	public function GetProgramComplete($P_FROM_DATE="",$P_TO_DATE="")
	{
		$url = $this->URL."GetProgramComplete";
		$data['P_FROM_DATE'] = $P_FROM_DATE;
		$data['P_TO_DATE'] = $P_TO_DATE;
		$data['AuthKey'] = $this->AuthKey;
		$data['P_PRINCIPAL_MAP_CD'] = "1";
		$result = $this->request($url, $data);
		$data = json_decode($result);
		//print_r($data);
		return $data;
	}
	
	function request($url, $data="")
	{
		
		$ch = curl_init( $url );
		# Setup request to send json via POST.
		$payload = json_encode( $data );
		curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
		curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		# Return response instead of printing.
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		# Send request.
		$result = curl_exec($ch);
		//print_r($result);
		curl_close($ch);	
		
		return $result;
	}
	
}
$call = new Execute();
?>