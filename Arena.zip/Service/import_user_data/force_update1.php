 <?php
 define('AJAX_SCRIPT', true);
 define('REQUIRE_CORRECT_ACCESS', true);
 define('NO_MOODLE_COOKIES', true);
 require_once('../config.php');

 /* NOTE : Ref. taken from api.php */

 global $DB;

 $platform = required_param('platform', PARAM_RAW);
 $version = required_param('version', PARAM_RAW);
 $mspin=optional_param('mspin',null,PARAM_RAW);

 $v = array();
 $sql = 'SELECT * FROM {app_version_check} where type = "'.$platform.'"';	   
 $record = $DB->get_record_sql($sql);
 if($mspin!=""){
 	$fus=$DB->get_record_sql("SELECT face_id_user, is_reverified, is_verified, is_monthly_reverified,registration_skip FROM mdl_ums_employeemaster WHERE code='".@$mspin."'");
 }
 $v['is_registered']  = false;
 $v['is_reverified']  = false;
 $v['is_month_reverified'] = false;
 $v['registration_skip'] = @$fus->registration_skip;
 if(@$v['registration_skip']==""){
 $v['registration_skip'] = "no";
 }
 if(@$fus->face_id_user!=""){
 	$v['is_registered']  = @$fus->face_id_user==1?true:false;
 	$v['is_reverified']  = @$fus->is_verified==1?true:false;
 	$v['is_month_reverified'] = @$fus->is_monthly_reverified==1?true:false;
 }

$v['status']='';
$v['url']='';
/*if($record->version>$record->current_app_version){
	$v['status']='Upgrade';
	$v['url']='https://msilappstore.in/ilearnservice';
}else{
	$v['status']='Verified';
	$v['url']='https://msilappstore.in/ilearnservice';
}*/
/*if($version==3.1){
	$v['status']='Verified';
	$v['url']='https://msilappstore.in/ilearnservice';
}
if($version==3.2 && $platform=="android"){
	$v['status']='Upgrade';
	$v['url']='https://msilappstore.in/ilearnservice-fr';
}
if($version==3.4 && $platform=="android"){
	$v['status']='Verified';
	$v['url']='https://msilappstore.in/ilearnservice';
}
if($version==3.3){
	$v['status']='Verified';
	$v['url']='https://msilappstore.in/ilearnservice';
}
if($version==4.0){
	$v['status']='Upgrade';
	$v['url']='https://msilappstore.in/ilearnservice';
}*/
/* if(!empty($record))
 {
		if($record->version=='') //check if app upgrade has started
		{
			if($version==$record->current_version)
			{
				$v['status']='Verified';
			}
			
			else
			{
			//check regionwise criteria
				$v['status']='Upgrade';
				$v['url']=$record->url;
			}
		}
		else 
		{
			if($version==$record->current_version)
			{
				//check regionwise criteria
				$v['status']='Upgrade';
				$v['url']=$record->url;
			}
			
			else
			{
				$v['status']='Verified';
				
			}
		}
		
	}
	else
	{
		$v['status']='Error';
	}*/
if(!empty($record)){
 	if($record->version==''){
 		if($version==$record->current_app_version){
 			$v['status']='Verified';
 		}else{
 			$v['status']='Upgrade';
 			$v['url']=$record->url;
 		}
 	}else{
 		if($record->current_app_version>$version){
				//check regionwise criteria
 			$v['status']='Upgrade';
 			$v['url']=$record->url;
 		}else{
 			$v['status']='Verified';	
 		}
 	}
 }else{
 	$v['status']='Error';
 }
	echo json_encode($v);